"""Agent-Gateway protocol v2 wire contracts.

V2 currently reuses the v1 envelope, messaging, and task contracts.  The
version split is at the link carrier: v1 is direct WebSocket, v2 is Azure Web
PubSub.
"""

from agent_gateway_protocol.gateway_protocol.v2.transport import *  # noqa: F403
