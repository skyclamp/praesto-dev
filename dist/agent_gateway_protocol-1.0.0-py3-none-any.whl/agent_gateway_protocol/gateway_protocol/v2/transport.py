"""Agent-Gateway v2 link frame contracts.

The frame shape intentionally matches v1 while v2 moves connection ownership to
Azure Web PubSub. V2 negotiates ``server_ping`` so the gateway can detect a
half-open or silently-dead AWPS connection within ~50s; relying on AWPS
``sys.disconnected`` webhooks alone leaves stale agents lingering for the full
record TTL when an event is dropped.
"""

from agent_gateway_protocol.gateway_protocol.v1.transport import *  # noqa: F403

SUPPORTED_FEATURES = frozenset({"resume", "ack", "server_ping"})
