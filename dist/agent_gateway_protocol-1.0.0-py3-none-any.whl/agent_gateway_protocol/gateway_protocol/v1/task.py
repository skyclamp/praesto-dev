"""Task protocol v1 wire types and content-type discriminators."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field

CONTENT_TYPE_TASK_REQUEST = "application/vnd.praestoclaw.task+json"
CONTENT_TYPE_TASK_PROGRESS = "application/vnd.praestoclaw.task.progress+json"
CONTENT_TYPE_TASK_CONTROL = "application/vnd.praestoclaw.task.control+json"

TASK_PROGRESS_TOPIC = "task.progress"
TASK_CONTROL_TOPIC = "task.control"

# Namespace prefix used on Adaptive-Card ``approval_request_id`` values
# so the Teams bridge ``/chatng`` endpoint can short-circuit a2a task
# control button clicks (sender Cancel, recipient Approve/Deny on task
# progress / approval cards) straight to ``TaskCoordinator.handle_control``
# (docs/07 §7) instead of forwarding the click to the agent's approval
# router. Both the gateway-side card builders and the client-side
# AdaptiveCard renderer must format ``approval_request_id`` via
# :func:`format_a2a_task_request_id` and the gateway dispatcher matches
# via :data:`A2A_TASK_CONTROL_PREFIX` so the wire shape stays in sync.
A2A_TASK_CONTROL_PREFIX = "a2a:task:"


def format_a2a_task_request_id(task_id: str) -> str:
    """Build an Action.Submit ``approval_request_id`` for a task control click.

    Used by both the client (``task/inbound.py``) and gateway
    (``task_approval_card.py``) when rendering task progress / approval
    Adaptive Cards. The Teams bridge inverts this with
    :data:`A2A_TASK_CONTROL_PREFIX` to recover the task id.
    """
    return f"{A2A_TASK_CONTROL_PREFIX}{task_id}"


WAITING_APPROVAL_L2_DEADLINE_MS = 180_000
WAITING_APPROVAL_L3_DEADLINE_MS = 300_000
EXECUTING_DEFAULT_DEADLINE_MS = 5 * 60 * 1000
TASK_HARD_CAP_MS = 2 * 60 * 60 * 1000

# Executor-side heartbeat cadence for ``task.progress`` events emitted
# while ``stage=executing``. Shared between Gateway (which uses
# ``next_heartbeat_ms`` from the body to extend the executing deadline,
# spec §5) and the client agent (which ticks at this cadence).
EXECUTING_HEARTBEAT_INTERVAL_MS = 30_000
# Default value the executor advertises as ``next_heartbeat_ms`` — a
# grace window large enough that a short transport reconnect window
# (WebSocket drop → negotiate → resume) won't cause the Gateway to
# kill an otherwise-healthy executor. The cadence is still 30 s
# (``EXECUTING_HEARTBEAT_INTERVAL_MS``) so a real death is detected
# within one missed beat plus the grace; 120 s gives roughly three
# heartbeat opportunities to land before the Gateway flips the task
# to ``timed_out``. Always clamped on the Gateway side by
# ``TASK_HARD_CAP_MS``. Keep in sync with the client-side
# ``_A2A_TASK_HEARTBEAT_GRACE_S`` so the local waiter and the
# Gateway deadline agree on what “healthy” means.
EXECUTING_HEARTBEAT_NEXT_MS = 120_000

TaskStage = Literal[
    "queued",
    "gating",
    "waiting_approval",
    "executing",
    "done",
    "declined",
    "interrupted",
    "failed",
    "timed_out",
]

TERMINAL_STAGES: frozenset[TaskStage] = frozenset(
    {"done", "declined", "interrupted", "failed", "timed_out"}
)


class TaskIntent(BaseModel):
    """Sender's description of what the task is asking for."""

    model_config = ConfigDict(extra="ignore")

    summary: str
    action: str | None = None
    hint_risk: Literal["read", "write", "external"] | None = None
    undoable: bool = False
    args: dict[str, Any] = Field(default_factory=dict)


class TaskDeadlines(BaseModel):
    model_config = ConfigDict(extra="ignore")

    soft_ms: int | None = None
    hard_ms: int | None = None


class TaskRequest(BaseModel):
    """The ``content.task`` body of a task-bearing carrier envelope."""

    model_config = ConfigDict(extra="ignore")

    task_id: str
    intent: TaskIntent
    deadlines: TaskDeadlines = Field(default_factory=TaskDeadlines)


def extract_task_request(carrier_body: dict[str, Any]) -> TaskRequest | None:
    """Return a :class:`TaskRequest` if the carrier body is a task."""

    content = carrier_body.get("content")
    if not isinstance(content, dict):
        return None
    if content.get("content_type") != CONTENT_TYPE_TASK_REQUEST:
        return None
    task = content.get("task")
    if not isinstance(task, dict):
        return None
    try:
        return TaskRequest.model_validate(task)
    except Exception:
        return None
