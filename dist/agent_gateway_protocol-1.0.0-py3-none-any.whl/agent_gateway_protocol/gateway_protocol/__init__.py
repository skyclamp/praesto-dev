"""Shared Agent-Gateway protocol contracts."""

__all__ = []
