"""Errors raised by os_sandbox backends, plus a denial heuristic."""

from __future__ import annotations


class SandboxError(Exception):
    """Base class."""


class SandboxDeniedError(SandboxError):
    """Raised when the kernel denies a sandboxed action (when surfaced as exception)."""


class SandboxUnsupportedError(SandboxError):
    """Raised when a backend cannot run in the current environment."""


# Substrings observed in stderr when the OS sandbox denies an operation.
# These are deliberately specific to sandbox infrastructure — bare ``EACCES``
# / ``EPERM`` strings appear in normal command failures (chmod, rm, npm) and
# would generate false positives.
_DENIAL_PATTERNS: tuple[str, ...] = (
    # macOS Seatbelt — always prefixed with "Sandbox:" or "deny <action>"
    "Sandbox: ",
    "deny file-write",
    "deny file-read",
    "deny network-outbound",
    "deny network-inbound",
    # Linux bubblewrap — always self-prefixed
    "bwrap: ",
    "setting up uid map: Permission denied",
    # Linux Landlock
    "landlock_restrict_self",
    "landlock_create_ruleset",
)


def is_likely_sandbox_denied(stderr: str, exit_code: int | None) -> bool:
    """Heuristic: does this stderr/exit-code combo look like sandbox denial?

    Used by callers to decide whether to surface an "escalation" prompt
    instead of treating the failure as a normal command error.

    The heuristic is conservative: false positives lead to extra prompts,
    which is annoying; false negatives lead to confusing failures, which is
    worse. We err toward false positives by matching a broad pattern set,
    but always require a non-zero exit code so that warnings-on-success
    don't trigger.
    """
    if exit_code is None or exit_code == 0:
        return False
    if not stderr:
        return False
    for pat in _DENIAL_PATTERNS:
        if pat in stderr:
            return True
    return False
