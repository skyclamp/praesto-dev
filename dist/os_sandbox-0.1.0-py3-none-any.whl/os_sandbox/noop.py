"""NoopSandbox — passthrough wrapper used when no real backend is needed."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path

from os_sandbox.spec import SandboxSpec


class NoopSandbox:
    """Returns argv/env unchanged. Intentionally trivial."""

    name = "noop"

    def wrap(
        self,
        argv: Sequence[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        spec: SandboxSpec,
    ) -> tuple[list[str], dict[str, str]]:
        del cwd, spec  # unused; passthrough by design
        return list(argv), dict(env)
