"""Per-platform sandbox backends. Import lazily from :mod:`os_sandbox.manager`."""
