"""FailoverProvider — wraps multiple LLM backends with automatic error recovery."""

from __future__ import annotations

import random
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Any

from loguru import logger

from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse
from praestoclaw.providers.credential_pool import CredentialPool
from praestoclaw.providers.errors import APIErrorKind, classify_api_error


class CompressNeededError(Exception):
    """Raised when error classifier says should_compress."""


# Backward-compat alias
CompressNeeded = CompressNeededError


@dataclass
class ProviderEntry:
    """A backend in the failover chain."""

    backend: LLMProvider
    label: str
    credential_pool: CredentialPool | None = None
    priority: int = 0
    owned: bool = True


class FailoverProvider(LLMProvider):
    """LLMProvider that tries multiple backends with retry and failover."""

    MAX_RETRIES: int = 3
    BASE_DELAY: float = 1.0
    CLOSE_ATTEMPTS: int = 2

    def __init__(self, chain: list[ProviderEntry]) -> None:
        self._chain = chain
        self._active = 0
        self._primary = 0
        self._closed_backend_ids: set[int] = set()

    @property
    def supports_cache_control(self) -> bool:
        return self._chain[self._active].backend.supports_cache_control

    @property
    def supports_thinking(self) -> bool:
        return self._chain[self._active].backend.supports_thinking

    @property
    def api_mode(self) -> str:
        return self._chain[self._active].backend.api_mode

    def restore_primary(self) -> None:
        """Reset active provider to primary."""
        self._active = self._primary

    async def aclose(self) -> None:
        """Close backends owned by this failover chain."""
        seen: set[int] = set()
        for entry in self._chain:
            backend_id = id(entry.backend)
            if not entry.owned or backend_id in seen or backend_id in self._closed_backend_ids:
                continue
            seen.add(backend_id)
            closed = False
            for attempt in range(self.CLOSE_ATTEMPTS):
                try:
                    await entry.backend.aclose()
                except Exception as exc:
                    logger.warning(
                        "Failed to close provider '{}' (attempt {}/{}): {}",
                        entry.label,
                        attempt + 1,
                        self.CLOSE_ATTEMPTS,
                        exc,
                    )
                else:
                    closed = True
                    break
            if closed:
                self._closed_backend_ids.add(backend_id)

    async def complete(self, **kwargs: Any) -> LLMResponse:
        return await self._call_with_recovery("complete", **kwargs)

    async def stream(self, **kwargs: Any) -> AsyncIterator[LLMChunk]:
        entry = self._chain[self._active]
        async for chunk in entry.backend.stream(**kwargs):
            yield chunk

    async def _call_with_recovery(self, method: str, **kwargs: Any) -> LLMResponse:
        last_error: BaseException | None = None
        start = self._active

        for provider_idx in range(len(self._chain)):
            idx = (start + provider_idx) % len(self._chain)
            entry = self._chain[idx]
            self._active = idx

            for attempt in range(self.MAX_RETRIES):
                try:
                    result: LLMResponse = await getattr(entry.backend, method)(**kwargs)
                    return result
                except Exception as exc:
                    last_error = exc
                    classified = classify_api_error(exc)

                    if classified.should_compress:
                        raise CompressNeededError(str(exc)) from exc

                    if not classified.retryable:
                        # Copilot 401: token may have been invalidated by
                        # an external process (e.g. copilot-api).  Clear the
                        # cached session token and allow ONE retry.
                        if (
                            classified.kind == APIErrorKind.AUTH
                            and attempt == 0
                            and "copilot" in str(exc).lower()
                        ):
                            from praestoclaw.security.github_auth import (
                                invalidate_copilot_token,
                            )

                            invalidate_copilot_token()
                            logger.info("Copilot 401 — invalidated cached token, retrying")
                            continue
                        raise

                    if classified.should_rotate_credential and entry.credential_pool:
                        entry.credential_pool.rotate()

                    if classified.should_fallback:
                        logger.warning(
                            "Provider {} failing over ({})",
                            entry.label,
                            classified.kind.value,
                        )
                        break  # try next provider

                    # Jittered backoff
                    if attempt < self.MAX_RETRIES - 1:
                        import asyncio

                        delay = self.BASE_DELAY * (2**attempt) + random.uniform(0, 1)  # noqa: S311
                        await asyncio.sleep(delay)

        assert last_error is not None
        raise last_error
