"""Gemini native provider — uses the google-genai SDK directly."""

from __future__ import annotations

import time
import uuid
from collections.abc import AsyncIterator
from typing import Any, cast

from praestoclaw.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest

try:
    from google import genai
    from google.genai import types
except ImportError:
    genai = None  # type: ignore[assignment]
    types = None  # type: ignore[assignment]


class GeminiProvider(LLMProvider):
    """LLM provider backed by Google's Gemini API (google-genai SDK)."""

    def __init__(
        self,
        api_key: str,
        *,
        project: str | None = None,
        location: str | None = None,
    ) -> None:
        if genai is None:
            raise ImportError(
                "google-genai is required for GeminiProvider. "
                "Install it with: pip install google-genai"
            )
        self._client = genai.Client(
            api_key=api_key,
            project=project,
            location=location,
        )

    # -- capability properties --------------------------------------------------

    @property
    def api_mode(self) -> str:
        return "gemini"

    @property
    def supports_cache_control(self) -> bool:
        return False

    @property
    def supports_thinking(self) -> bool:
        return False

    # -- helpers ----------------------------------------------------------------

    @staticmethod
    def _convert_messages(messages: list[dict[str, Any]]) -> tuple[str | None, list[types.Content]]:
        """Convert OpenAI-style messages to Gemini Content objects.

        Returns (system_instruction, contents).
        """
        system_parts: list[str] = []
        contents: list[types.Content] = []

        for msg in messages:
            role = msg.get("role", "user")
            text = msg.get("content", "") or ""

            if role == "system":
                system_parts.append(text)
            elif role == "assistant":
                contents.append(
                    types.Content(role="model", parts=[types.Part.from_text(text=text)])
                )
            else:
                contents.append(types.Content(role="user", parts=[types.Part.from_text(text=text)]))

        system_instruction = "\n\n".join(system_parts) if system_parts else None
        return system_instruction, contents

    @staticmethod
    def _convert_tools(tools: list[dict[str, Any]] | None) -> list[types.Tool] | None:
        """Convert OpenAI-style tool definitions to Gemini Tool objects."""
        if not tools:
            return None

        declarations: list[types.FunctionDeclaration] = []
        for tool in tools:
            if tool.get("type") != "function":
                continue
            func = tool["function"]
            declarations.append(
                types.FunctionDeclaration(
                    name=func["name"],
                    description=func.get("description", ""),
                    parameters=func.get("parameters"),
                )
            )
        if not declarations:
            return None
        return [types.Tool(function_declarations=declarations)]

    @staticmethod
    def _parse_response(result: Any, model: str, duration_ms: float) -> LLMResponse:
        """Parse a Gemini GenerateContentResponse into an LLMResponse."""
        content = ""
        tool_calls: list[ToolCallRequest] = []

        if result.candidates:
            candidate = result.candidates[0]
            for part in candidate.content.parts:
                if part.text:
                    content += part.text
                elif part.function_call:
                    fc = part.function_call
                    tool_calls.append(
                        ToolCallRequest(
                            id=uuid.uuid4().hex[:24],
                            name=fc.name,
                            arguments=dict(fc.args) if fc.args else {},
                        )
                    )

        # Usage metadata
        prompt_tokens = 0
        completion_tokens = 0
        if hasattr(result, "usage_metadata") and result.usage_metadata:
            prompt_tokens = getattr(result.usage_metadata, "prompt_token_count", 0) or 0
            completion_tokens = getattr(result.usage_metadata, "candidates_token_count", 0) or 0

        finish_reason = "tool_calls" if tool_calls else "stop"

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            model=model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=duration_ms,
        )

    # -- core API ---------------------------------------------------------------

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> LLMResponse:
        system_instruction, contents = self._convert_messages(messages)
        gemini_tools = self._convert_tools(tools)

        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
            # google-genai's public Tool objects are valid here, but the SDK's
            # invariant union annotation rejects list[Tool]. Keep the cast at
            # this third-party boundary rather than weakening our converter.
            tools=cast(Any, gemini_tools),
            system_instruction=system_instruction,
        )

        t0 = time.monotonic()
        result = await self._client.aio.models.generate_content(
            model=model,
            # Same SDK annotation issue as tools above: list[Content] is a
            # supported runtime input but is narrower than its invariant union.
            contents=cast(Any, contents),
            config=config,
        )
        duration_ms = (time.monotonic() - t0) * 1000

        return self._parse_response(result, model, duration_ms)

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        reasoning_effort: str | None = None,
    ) -> AsyncIterator[LLMChunk]:
        # Fall back to complete-then-yield
        response = await self.complete(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
        )
        yield LLMChunk(
            content=response.content,
            tool_calls=response.tool_calls,
            finish_reason=response.finish_reason,
            model=response.model,
        )
