"""Allow `python -m praestoclaw`.

Note: telemetry is initialised in ``praestoclaw.cli.commands`` so packaged
console-script entry points (``praestoclaw = praestoclaw.cli.commands:app``)
also report startup. This file just dispatches.
"""

from praestoclaw.cli.commands import app

app()
