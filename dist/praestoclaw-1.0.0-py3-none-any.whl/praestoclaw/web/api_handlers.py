"""
Shared API handler functions for the admin dashboard.

Pure functions that take a Runtime and return a dict (or list).
handle_approval_resolve returns a (status_code, body_dict) tuple.
Used by both:
  - WebServer (FastAPI endpoints in server.py)
  - CloudChannel admin relay (_handle_admin_endpoint in cloud.py)
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw import __version__
from praestoclaw.config.schema import ChannelType

if TYPE_CHECKING:
    from praestoclaw.agent.tools.base import Tool
    from praestoclaw.runtime import Runtime

# Strong refs for fire-and-forget receipt pushes — see _schedule_approval_receipt.
_RECEIPT_TASKS: set[asyncio.Task[None]] = set()


def _score_to_tier(score: int) -> dict[str, Any]:
    """Map a risk score to display info."""
    if score <= 2:
        tier = "safe"
    elif score <= 4:
        tier = "moderate"
    elif score <= 6:
        tier = "elevated"
    elif score <= 8:
        tier = "high"
    else:
        tier = "critical"
    return {"mode": "fixed", "base_score": score, "tier": tier}


def _tool_risk_info(tool: Tool) -> dict[str, Any]:
    """Get a tool's risk display info from ``risk_range``.

    Range span ≤ 1 → treat as fixed (show single score).
    Range span > 1 → dynamic (show range).
    """
    try:
        lo, hi = tool.risk_range
    except (TypeError, ValueError):
        lo, hi = 0, 10
    if hi - lo <= 1:
        score = (lo + hi) // 2 if lo != hi else lo
        info = _score_to_tier(score)
        info["range"] = [lo, hi]
        return info
    return {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [lo, hi]}


def _skills_summary(rt: Runtime) -> dict[str, int]:
    """Skills count for the status endpoint."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return {"count": 0, "active": 0}
    registry = getattr(rt, "tool_registry", None)
    skills = loader.list_loaded()
    active = sum(
        1
        for s in skills
        if s.is_platform_eligible()
        and not s.is_superseded(registry)
        and not s.disable_model_invocation
        and not s.check_requirements(registry)
    )
    return {"count": len(skills), "active": active}


def handle_status(
    rt: Runtime,
    *,
    uptime_seconds: int | None = None,
    started_at: str | None = None,
    channels: list[dict[str, Any]] | None = None,
    session_count: int | None = None,
) -> dict[str, Any]:
    """GET /api/status — comprehensive runtime snapshot.

    Optional kwargs are added by the local web server which tracks
    uptime and channel state; the cloud relay omits them.
    """
    tools = rt.tool_registry.list_tools()
    by_tier: dict[str, int] = {
        "safe": 0,
        "moderate": 0,
        "elevated": 0,
        "high": 0,
        "critical": 0,
        "dynamic": 0,
    }
    for t in tools:
        by_tier[_tool_risk_info(t)["tier"]] += 1

    if session_count is None:
        session_count = 0

    sched_health = rt.scheduler.health() if rt.scheduler else {}

    result: dict[str, Any] = {
        "version": __version__,
        "status": "halted" if rt.estop.is_halted else "ok",
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
        "provider": {"model": rt.config.agents.default.model},
        "sessions": {"count": session_count},
        "tools": {"count": len(tools), "by_tier": by_tier},
        "skills": _skills_summary(rt),
        "scheduler": {
            "enabled": sched_health.get("running", False),
            "job_count": sched_health.get("total_jobs", 0),
            "active_jobs": sched_health.get("active_jobs", 0),
        },
        "workspace": str(rt.workspace),
        "agent": {
            "name": rt.config.agents.default.name,
            "max_iterations": rt.config.agents.default.max_iterations,
        },
        "security": {
            "profile": rt.config.security.profile.value,
            "audit_enabled": rt.config.security.audit.enabled,
            "audit_redact": rt.config.security.audit.redact_secrets,
            "estop_on_leak": rt.config.security.estop.trigger_on_leak,
            "require_auth": rt.config.security.require_auth,
        },
    }
    if uptime_seconds is not None:
        result["uptime_seconds"] = uptime_seconds
    if started_at is not None:
        result["started_at"] = started_at
    if channels is not None:
        result["channels"] = channels
    return result


def handle_health(rt: Runtime) -> dict[str, Any]:
    """GET /api/health — basic health with E-stop and bus state."""
    return {
        "status": "halted" if rt.estop.is_halted else "ok",
        "version": __version__,
        "estop": rt.estop.status(),
        "bus": {
            "inbound_qsize": rt.bus.inbound_qsize,
            "outbound_qsize": rt.bus.outbound_qsize,
        },
    }


def handle_models(rt: Runtime) -> dict[str, Any]:
    """GET /api/models — list all configured models with context window and input token limits."""
    from praestoclaw.providers.model_catalog import get_context_window, get_max_input_tokens
    from praestoclaw.providers.resolver import resolve_model_chain

    providers = rt.config.providers
    agents_cfg = rt.config.agents

    def _chain_with_limits(chain: list[str]) -> list[dict[str, Any]]:
        return [
            {
                "model": m,
                "context_window": get_context_window(m),
                "max_input_tokens": get_max_input_tokens(m),
            }
            for m in chain
        ]

    # Collect all agent models (builtin + user-defined)
    agents: dict[str, Any] = {}
    all_agents = dict(getattr(rt, "_all_agents", {}))
    if "default" not in all_agents:
        all_agents["default"] = agents_cfg.default
    for name, cfg in all_agents.items():
        model = cfg.model
        chain = resolve_model_chain(model, providers)
        entry: dict[str, Any] = {
            "alias": model,
            "chain": _chain_with_limits(chain),
        }
        if cfg.metadata.get("internal"):
            entry["internal"] = True
        agents[name] = entry

    # Collect alias mappings
    aliases: dict[str, Any] = {}
    for alias in ("auto", "fast", "reasoning", "coding"):
        chain = resolve_model_chain(alias, providers)
        aliases[alias] = {"chain": _chain_with_limits(chain)}

    return {"agents": agents, "aliases": aliases}


async def handle_sessions(rt: Runtime, *, limit: int | None = 200) -> list[dict[str, Any]]:
    """GET /api/sessions — list session metadata.

    Defaults to a bounded list (200 rows); pass ``limit=None`` for a full list.
    """
    return await rt.session_store.list_sessions(limit=limit)


async def handle_session_detail(rt: Runtime, session_id: str) -> dict[str, Any] | None:
    """GET /api/sessions/{id} — session messages. Returns None if not found.

    Accepts both UUID session IDs and ``channel:sender`` format (used by
    web chat clients that don't know the UUID).
    """
    # Resolve ``channel:sender`` shorthand without creating a row — the
    # 404 fallback in the client depends on misses staying as misses.
    if ":" in session_id and len(session_id) < 36:
        try:
            resolved = await rt.session_store.find_session(
                str(ChannelType.of(session_id.split(":")[0])), session_id.split(":", 1)[1]
            )
            if resolved:
                session_id = resolved
        except Exception:
            pass

    if not await rt.session_store.session_exists(session_id):
        return None

    messages = await rt.session_store.get_messages(session_id)
    return {"session_id": session_id, "messages": messages}


async def handle_session_recent(
    rt: Runtime,
    channel: ChannelType | str = "web",
    sender_id: str = "ws-user",
    limit: int = 10,
) -> list[dict[str, Any]]:
    """GET /api/session/recent — last N visible messages for a channel/sender.

    Returns user, assistant, and approval_request turns (tool messages excluded).
    """
    session_id = await rt.session_store.find_session(str(ChannelType.of(channel)), sender_id)
    if not session_id:
        return []
    messages = await rt.session_store.get_messages(session_id)
    visible = [
        m
        for m in messages
        if m.get("role") in ("user", "assistant", "approval_request", "approval_resolved")
    ]
    return visible[-limit:]


def handle_skills(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/skills — list all loaded skills with eligibility status."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return []

    registry = getattr(rt, "tool_registry", None)
    result: list[dict[str, Any]] = []
    for s in loader.load_all():
        user_disabled = loader.is_disabled(s.name)
        # Compute status — cheap checks first, expensive last
        missing: list[str] = []
        if not s.is_platform_eligible():
            status = "platform-ineligible"
        elif s.is_superseded(registry):
            status = "superseded"
        elif s.disable_model_invocation or user_disabled:
            status = "disabled"
        else:
            missing = s.check_requirements(registry)
            status = "ineligible" if missing else "active"

        result.append(
            {
                "name": s.name,
                "description": s.description,
                "mode": s.mode,
                "source_tier": s.source_tier,
                "source_path": s.source_path,
                "status": status,
                "user_disabled": user_disabled,
                "frontmatter_disabled": s.disable_model_invocation,
                "keywords": s.keywords,
                "missing_requirements": missing,
                "superseded_by": s.superseded_by_tools,
                "os_filter": s.os_filter,
            }
        )
    return result


def handle_tools(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/tools — list all registered tools and MCP servers with status."""
    active_names = {t.name for t in rt.tool_registry.get_active_tools()}
    result: list[dict[str, Any]] = []

    for t in rt.tool_registry.list_tools_sorted():
        category = t.metadata.category if t.metadata else "builtin"
        is_mcp_tool = category == "mcp"
        ri = _tool_risk_info(t)
        result.append(
            {
                "name": t.name,
                "description": t.description,
                "tier": "mcp" if is_mcp_tool else (t.metadata.tier if t.metadata else "core"),
                "active": t.name in active_names,
                "type": "mcp_tool" if is_mcp_tool else "builtin",
                "risk_mode": ri["mode"],
                "risk_score": ri["base_score"],
                "risk_tier": ri["tier"],
                "risk_range": ri.get("range"),
            }
        )

    # MCP servers (connection-level entries)
    mcp_mgr = getattr(rt, "_mcp_manager", None)
    risk_policy = rt.config.tools.mcp_risk_policy or {}
    if mcp_mgr:
        for s in mcp_mgr.list_servers():
            if not s.enabled:
                continue
            # Resolve server-level risk from policy.
            # If server has per-tool overrides or _rules, risk varies per tool → dynamic.
            server_policy = risk_policy.get(s.name, {})
            has_per_tool = False
            default_risk = None
            if isinstance(server_policy, dict):
                has_per_tool = any(k for k in server_policy if not k.startswith("_")) or bool(
                    server_policy.get("_rules")
                )
                default_risk = server_policy.get("_default_risk")
            else:
                default_risk = server_policy  # bare int or str
            if default_risk is None:
                default_risk = risk_policy.get("_default_risk")
            if has_per_tool:
                # Compute range from all configured int values
                scores: list[int] = []
                if isinstance(server_policy, dict):
                    for k, v in server_policy.items():
                        if not k.startswith("_") and isinstance(v, int):
                            scores.append(v)
                    if isinstance(default_risk, int):
                        scores.append(default_risk)
                if scores and max(scores) - min(scores) <= 1:
                    # Narrow range — treat as fixed
                    score = (min(scores) + max(scores)) // 2
                    ri = _score_to_tier(score)
                    ri["range"] = [min(scores), max(scores)]
                elif scores:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [min(scores), max(scores)],
                    }
                else:
                    ri = {
                        "mode": "dynamic",
                        "base_score": None,
                        "tier": "dynamic",
                        "range": [0, 10],
                    }
            elif isinstance(default_risk, int):
                ri = _score_to_tier(default_risk)
                ri["range"] = [default_risk, default_risk]
            else:
                ri = {"mode": "dynamic", "base_score": None, "tier": "dynamic", "range": [0, 10]}
            result.append(
                {
                    "name": f"MCP_{s.name}",
                    "description": s.description or "",
                    "tier": "mcp",
                    "active": s.state.value == "connected",
                    "type": "mcp_server",
                    "state": s.state.value,
                    "tool_count": s.tool_count,
                    "risk_mode": ri["mode"],
                    "risk_score": ri["base_score"],
                    "risk_tier": ri["tier"],
                    "risk_range": ri.get("range"),
                }
            )

    return result


def handle_memory(rt: Runtime) -> dict[str, Any]:
    """GET /api/memory — MEMORY.md content + knowledge store entries."""
    result: dict[str, Any] = {"memory_md": "", "knowledge": []}

    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            result["memory_md"] = mem.read_memory() or ""
        except Exception:
            result["memory_md"] = "(error reading MEMORY.md)"
    else:
        from praestoclaw.utils.helpers import get_data_dir

        memory_path = get_data_dir() / "MEMORY.md"
        if memory_path.exists():
            try:
                result["memory_md"] = memory_path.read_text(encoding="utf-8")
            except Exception:
                result["memory_md"] = "(error reading MEMORY.md)"

    try:
        if mem and hasattr(mem, "history"):
            entries = mem.history.list_recent(top_k=50)
            result["knowledge"] = [
                {
                    "id": e.get("id"),
                    "content": e.get("content", ""),
                    "category": e.get("category", ""),
                    "source": e.get("source", ""),
                    "created_at": e.get("created_at", ""),
                }
                for e in entries
            ]
    except Exception:
        pass

    return result


def handle_audit(rt: Runtime) -> dict[str, Any]:
    """GET /api/audit — recent audit log entries (last 200, newest first)."""
    return {"entries": rt.audit.recent_entries(200)}


def handle_cost(rt: Runtime) -> dict[str, Any]:
    """GET /api/cost — token usage stats."""
    return rt.usage_tracker.stats()


def handle_config(rt: Runtime) -> dict[str, Any] | None:
    """GET /api/config — read-only config snapshot. Returns None on error."""
    try:
        config_dict = rt.config.model_dump(mode="json")
        _redact_secrets(config_dict)
        return config_dict
    except Exception:
        return None


def handle_approvals(rt: Runtime) -> dict[str, Any]:
    """GET /api/approvals — pending + recently resolved approval queue."""
    pending: list[dict[str, Any]] = []
    resolved: list[dict[str, Any]] = []
    if hasattr(rt, "approval_manager") and rt.approval_manager:
        mgr = rt.approval_manager
        try:
            for req in mgr.get_pending():
                pending.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "args": req.args,
                        "agent_name": req.agent_name,
                        "score": req.score,
                        "reason": req.reason,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "created_at": req.created_at.isoformat() if req.created_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
        # Include recently resolved requests (kept for 60s in _resolved)
        try:
            for req in mgr._resolved.values():
                resolved.append(
                    {
                        "id": req.id,
                        "tool_name": req.tool_name,
                        "status": req.status.value if hasattr(req.status, "value") else req.status,
                        "resolver": req.resolver,
                        "resolved_at": req.resolved_at.isoformat() if req.resolved_at else None,
                    }
                )
        except (AttributeError, Exception):
            pass
    return {"pending": pending, "resolved": resolved}


def handle_estop(rt: Runtime, reason: str = "admin dashboard") -> dict[str, Any]:
    """POST /api/estop — trigger emergency stop."""
    rt.estop.trigger(reason, actor="admin")
    return rt.estop.status()


def handle_reset(rt: Runtime, actor: str = "admin") -> dict[str, Any]:
    """POST /api/reset — reset emergency stop."""
    rt.estop.reset(actor=actor)
    return rt.estop.status()


def _schedule_approval_receipt(
    rt: Runtime, request_id: str, status: str, resolver: str, req: Any
) -> None:
    """Push an ``approval_resolved`` frame to web clients, fire-and-forget.

    This synchronises *other* connected clients. The client that clicked has the
    authoritative answer in its own 200 response and does not wait on this frame
    — it used to, which meant a dropped push left its card spinning forever.

    Same frame shape the ApprovalGate emits, so the clients need no special case.
    It cannot reuse the APPROVAL_RESOLVED event, whose handler calls
    ``approval_manager.resolve()`` again and would fail on an already-resolved
    request. Scheduled rather than awaited because the callers are sync; both of
    them (the FastAPI route and the cloud admin relay) run inside a loop.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return  # no loop (tests / sync context) — nothing to push onto
    cm = getattr(rt, "channel_manager", None)
    if cm is None:
        return

    payload = {
        "type": "approval_resolved",
        "request_id": request_id,
        "status": status,
        "resolver": resolver,
        "tool_name": getattr(req, "tool_name", "") or "",
    }
    frame = json.dumps(payload)

    async def _push() -> None:
        try:
            for ch_name in cm.active_channel_names():
                key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                if key != ChannelType.WEB.value:
                    continue
                ch = cm.get(ch_name)
                if ch is None:
                    continue
                cid = getattr(req, "channel_id", "") or key
                ok = await ch.send(cid, frame, keep_context=True)
                if ok is False:
                    # The decision is already committed and the HTTP caller got
                    # its 200 — this only means other connected clients won't
                    # learn about it from us. The resolving client no longer
                    # depends on this frame (it acts on its own 200), so log
                    # rather than fail.
                    logger.warning(
                        "approval receipt undelivered request_id={} channel_id={}",
                        request_id,
                        cid,
                    )
        except Exception as exc:  # noqa: BLE001 - receipt is best-effort
            logger.debug("approval receipt push failed for {}: {}", request_id, exc)

    task = loop.create_task(_push())
    # asyncio holds only a weak reference to a running task; without this the
    # push can be collected before it ever reaches the channel.
    _RECEIPT_TASKS.add(task)
    task.add_done_callback(_RECEIPT_TASKS.discard)


def _resolve_approval_decision(
    rt: Runtime,
    request_id: str,
    approved: bool,
    resolver: str = "admin",
    always: bool = False,
) -> tuple[int, dict[str, Any], Any | None, str | None]:
    """Commit an approval decision before performing session-store I/O."""
    if not hasattr(rt, "approval_manager") or not rt.approval_manager:
        return 503, {"error": "Approval manager not available."}, None, None
    req = None
    try:
        req = rt.approval_manager.get_request(request_id)
        _action = "always" if (always and approved) else ("approve" if approved else "deny")
        rt.approval_manager.resolve(
            request_id, approved=approved, resolver=resolver, action=_action
        )
        allowlist = getattr(rt, "_allowlist", None)
        if always and approved and req and allowlist:
            allowlist.add(
                req.tool_name, req.args, added_by=resolver, note="Added via web UI 'Always Allow'"
            )
        status = "approved" if approved else "denied"
        return (
            200,
            {"status": "resolved", "approved": approved, "always": always},
            req,
            status,
        )
    except KeyError:
        # resolve() raises KeyError when request_id not in _pending — but it
        # may exist in _resolved.  Return 409 (not 404) for already-resolved.
        if req and req.status.value != "pending":
            return (
                409,
                {
                    "error": (
                        f"Approval request already resolved as {req.status.value}: {request_id}"
                    ),
                    "request_id": request_id,
                    "resolved_status": req.status.value,
                },
                req,
                None,
            )
        return (
            404,
            {
                "error": f"Approval request not found: {request_id}",
                "request_id": request_id,
            },
            req,
            None,
        )
    except ValueError:
        status = req.status.value if req else "unknown"
        return (
            409,
            {
                "error": f"Approval request already resolved as {status}: {request_id}",
                "request_id": request_id,
                "resolved_status": status,
            },
            req,
            None,
        )
    except Exception as exc:
        return 500, {"error": f"Internal error: {type(exc).__name__}"}, req, None


async def _persist_approval_resolution(
    rt: Runtime, request_id: str, status: str, resolver: str
) -> None:
    """Persist a committed decision in the canonical SQLite session."""
    sid = await rt.session_store.find_session_for_approval_request(request_id)
    if sid is None:
        return
    await rt.session_store.add_message(
        sid,
        {
            "role": "approval_resolved",
            "content": json.dumps(
                {
                    "request_id": request_id,
                    "status": status,
                    "resolver": resolver,
                }
            ),
        },
    )


async def handle_approval_resolve_async(
    rt: Runtime,
    request_id: str,
    approved: bool,
    resolver: str = "admin",
    always: bool = False,
) -> tuple[int, dict[str, Any]]:
    """Resolve and persist the decision on the event loop."""
    code, body, req, status = _resolve_approval_decision(rt, request_id, approved, resolver, always)
    if code != 200 or status is None:
        return code, body
    persistence = asyncio.create_task(
        _persist_approval_resolution(rt, request_id, status, resolver)
    )
    try:
        await asyncio.shield(persistence)
    except asyncio.CancelledError:
        # The decision and waiter notification are already committed. Let the
        # session-store write finish, then publish exactly one receipt
        # from the owning loop before preserving the caller's cancellation.
        try:
            await persistence
        except Exception as exc:  # noqa: BLE001 - cancellation still wins
            logger.debug("Approval resolution persistence failed after cancellation: {}", exc)
        _schedule_approval_receipt(rt, request_id, status, resolver, req)
        raise
    except Exception as exc:
        return 500, {"error": f"Internal error: {type(exc).__name__}"}
    _schedule_approval_receipt(rt, request_id, status, resolver, req)
    return code, body


def handle_system_prompts(rt: Runtime) -> dict[str, Any]:
    """GET /api/system-prompts — return the assembled system prompt and its individual sections.

    Uses the runtime's ContextBuilder for the full prompt, and reads the
    individual identity files via the same resolution logic as ContextBuilder:

    - ``_load_identity_or_builtin``: config path (if file exists) →
      ``~/.praestoclaw/<name>`` override → bundled default.
    - ``USER.md``: only included if a real file exists (no bundled fallback).
    - ``TOOLS.md``: wrapped with ``## Guidelines`` header when not markdown.
    - ``MEMORY.md``: prefixed with section headers and capped at 8 KB.
    """
    from praestoclaw.agent.compaction import count_tokens
    from praestoclaw.agent.prompt_builder import MEMORY_CAP
    from praestoclaw.utils.defaults import load_default

    sections: list[dict[str, Any]] = []
    errors: list[str] = []

    # Prefer the active AgentLoop's config/workspace so sections match the
    # same agent used to build the full prompt (entrypoint may not be "default").
    agent = getattr(rt, "agent", None)
    agent_cfg = getattr(agent, "_config", None) if agent is not None else None
    if agent_cfg is None:
        agent_cfg = rt.config.agents.default
    workspace = getattr(agent, "_workspace", None) if agent is not None else None
    if workspace is None:
        workspace = rt.workspace

    def _resolve_and_read(config_path: str | None, default_name: str) -> str:
        """Resolve an identity file using the same precedence as ContextBuilder.

        config path → load_default (checks ~/.praestoclaw/ then bundled).
        When no config path: ~/.praestoclaw/<name> → bundled default.
        """
        if config_path:
            p = Path(config_path).expanduser()
            if not p.is_absolute():
                p = workspace / p
            if p.is_file():
                return p.read_text(encoding="utf-8").strip()
            # Config path set but file missing — fall through to load_default
            # which checks ~/.praestoclaw/ then bundled (same as ContextBuilder).
            return load_default(default_name)
        from praestoclaw.utils.helpers import get_data_dir

        candidate = get_data_dir() / default_name
        if candidate.is_file():
            return candidate.read_text(encoding="utf-8").strip()
        return load_default(default_name)

    def _section(name: str, content: str) -> dict[str, Any]:
        return {
            "name": name,
            "content": content,
            "tokens": count_tokens(content),
            "bytes": len(content.encode("utf-8")),
        }

    # 1. SOUL.md
    soul = _resolve_and_read(agent_cfg.soul_file, "SOUL.md")
    if soul:
        sections.append(_section("SOUL.md", soul))

    # 2. Config instructions
    if agent_cfg.instructions:
        sections.append(_section("Config Instructions", agent_cfg.instructions))

    # 3. AGENTS.md
    agents = _resolve_and_read(agent_cfg.agents_file, "AGENTS.md")
    if agents:
        sections.append(_section("AGENTS.md", agents))

    # 4. TOOLS.md — match ContextBuilder._load_tools_md() wrapping
    tools_content = load_default("TOOLS.md", allow_empty_override=True)
    if tools_content:
        if not tools_content.lstrip().startswith("#"):
            tools_content = f"## Guidelines\n\n{tools_content}"
        sections.append(_section("TOOLS.md", tools_content))

    # 5. USER.md — only include if a real file exists (no bundled fallback)
    user_path: Path | None = None
    if agent_cfg.user_file:
        p = Path(agent_cfg.user_file).expanduser()
        if not p.is_absolute():
            p = workspace / p
        if p.is_file():
            user_path = p
    else:
        from praestoclaw.utils.helpers import get_data_dir

        candidate = get_data_dir() / "USER.md"
        if candidate.is_file():
            user_path = candidate
    if user_path is not None:
        user_content = user_path.read_text(encoding="utf-8").strip()
        if user_content:
            sections.append(_section("USER.md", user_content))

    # 6. MEMORY.md — add headers and cap at 8 KB to match ContextBuilder
    mem = getattr(rt, "_memory", None)
    if mem:
        try:
            shared = mem.read_shared("MEMORY.md").strip()
            if shared:
                sections.append(
                    _section("MEMORY.md (Shared)", f"## Shared Memory\n\n{shared[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading shared MEMORY.md")
        try:
            personal = mem.read_memory().strip()
            if personal:
                sections.append(
                    _section("MEMORY.md (Personal)", f"## Memory\n\n{personal[:MEMORY_CAP]}")
                )
        except Exception:
            errors.append("Error reading personal MEMORY.md")
    else:
        from praestoclaw.utils.helpers import get_data_dir

        memory_path = get_data_dir() / "MEMORY.md"
        if memory_path.is_file():
            try:
                mc = memory_path.read_text(encoding="utf-8").strip()
                if mc:
                    sections.append(_section("MEMORY.md", mc[:MEMORY_CAP]))
            except Exception:
                errors.append("Error reading MEMORY.md")

    # Build the full assembled system prompt from the agent loop's PromptBuilder
    full_prompt = ""
    pb = getattr(agent, "_prompt_builder", None) if agent is not None else None
    if pb:
        try:
            full_prompt = pb.build_system_prompt(mode="full")
        except Exception as exc:
            errors.append(f"Error building system prompt: {type(exc).__name__}")
            full_prompt = ""

    result: dict[str, Any] = {
        "sections": sections,
        "full_prompt": full_prompt,
        "full_prompt_length": len(full_prompt.encode("utf-8")),
        "full_prompt_tokens": count_tokens(full_prompt),
    }
    if errors:
        result["errors"] = errors
    return result


# ── Helpers ──────────────────────────────────────────────────────────────────


def _redact_secrets(d: dict[str, Any], _secret_keys: set[str] | None = None) -> None:
    """Recursively redact values for keys that look like secrets."""
    if _secret_keys is None:
        _secret_keys = {
            "api_key",
            "secret",
            "token",
            "password",
            "client_secret",
            "connection_string",
            "bypass_token",
        }
    for key in list(d.keys()):
        if isinstance(d[key], dict):
            _redact_secrets(d[key], _secret_keys)
        elif isinstance(d[key], str) and any(s in key.lower() for s in _secret_keys):
            if d[key]:
                d[key] = "***REDACTED***"


# ── Marketplace handlers ────────────────────────────────────────────────────


def handle_marketplace_sources(rt: Runtime) -> list[dict[str, Any]]:
    """GET /api/marketplace/sources — list configured + recommended marketplace sources."""
    from praestoclaw.skills.marketplace import (
        BUILTIN_MARKETPLACES,
        SUPPORTED_MARKETPLACE_FORMATS,
        count_marketplace_skills,
        detect_format,
        get_marketplace_cache_dir,
    )

    sources = rt.config.skills.marketplaces
    seen_ids: set[str] = set()
    result: list[dict[str, Any]] = []
    for src_id, src_cfg in sources.items():
        seen_ids.add(src_id)
        src_path = Path(os.path.expanduser(src_cfg.path))
        if not src_path.is_dir():
            result.append(
                {
                    "id": src_id,
                    "label": src_cfg.label,
                    "path": str(src_path),
                    "format": src_cfg.format,
                    "skill_count": 0,
                    "recommended": False,
                    "error": "Directory not found",
                }
            )
            continue
        try:
            fmt = (
                src_cfg.format
                if src_cfg.format in SUPPORTED_MARKETPLACE_FORMATS
                else detect_format(src_path)
            )
            result.append(
                {
                    "id": src_id,
                    "label": src_cfg.label,
                    "path": str(src_path),
                    "format": fmt,
                    "skill_count": count_marketplace_skills(src_path, fmt),
                    "recommended": any(
                        m.recommended for m in BUILTIN_MARKETPLACES if m.id == src_id
                    ),
                }
            )
        except Exception as exc:
            result.append(
                {
                    "id": src_id,
                    "label": src_cfg.label,
                    "path": str(src_path),
                    "format": src_cfg.format,
                    "skill_count": 0,
                    "recommended": False,
                    "error": str(exc),
                }
            )

    # Always include all builtins even if not in user config
    cache_dir = get_marketplace_cache_dir()
    for m in BUILTIN_MARKETPLACES:
        if m.id in seen_ids:
            continue
        # Check if repo is already cloned
        safe_dir = m.repo.replace("/", "__")
        repo_path = cache_dir / safe_dir
        source_path = repo_path / m.subpath if m.subpath else repo_path
        if source_path.is_dir():
            try:
                result.append(
                    {
                        "id": m.id,
                        "label": m.label,
                        "path": str(source_path),
                        "format": m.format,
                        "skill_count": count_marketplace_skills(
                            source_path, m.format, skill_file=m.skill_file
                        ),
                        "recommended": m.recommended,
                    }
                )
                continue
            except Exception:
                pass
        # Not cloned yet — show as available source
        result.append(
            {
                "id": m.id,
                "label": m.label,
                "path": "",
                "format": m.format,
                "skill_count": 0,
                "recommended": m.recommended,
            }
        )
    return result


def handle_marketplace_skills(rt: Runtime, source_id: str | None = None) -> list[dict[str, Any]]:
    """GET /api/marketplace/skills — list all skills from marketplace sources."""
    from praestoclaw.skills.marketplace import (
        BUILTIN_MARKETPLACES,
        SUPPORTED_MARKETPLACE_FORMATS,
        clone_or_update_github_repo,
        detect_format,
        get_install_dir,
        get_installed_skill_names,
        get_marketplace_cache_dir,
        list_marketplace_skills,
    )

    sources = rt.config.skills.marketplaces
    install_dir = get_install_dir()
    installed = get_installed_skill_names(install_dir)
    seen_ids: set[str] = set()

    result: list[dict[str, Any]] = []
    for src_id, src_cfg in sources.items():
        seen_ids.add(src_id)
        if source_id and src_id != source_id:
            continue
        src_path = Path(os.path.expanduser(src_cfg.path))
        if not src_path.is_dir():
            continue

        fmt = (
            src_cfg.format
            if src_cfg.format in SUPPORTED_MARKETPLACE_FORMATS
            else detect_format(src_path)
        )

        skills = list_marketplace_skills(
            src_path, src_id, src_cfg.label, fmt, installed_names=installed
        )
        for s in skills:
            result.append(
                {
                    "name": s.name,
                    "description": s.description,
                    "source": s.source,
                    "source_label": s.source_label,
                    "plugin": s.plugin,
                    "installed": s.installed,
                    "keywords": s.keywords,
                    "has_references": s.has_references,
                    "recommended": s.recommended,
                }
            )

    # Always include all builtins even if not in user config
    cache_dir = get_marketplace_cache_dir()
    for m in BUILTIN_MARKETPLACES:
        if m.id in seen_ids:
            continue
        if source_id and m.id != source_id:
            continue
        # Check if repo is already cloned
        safe_dir = m.repo.replace("/", "__")
        repo_path = cache_dir / safe_dir
        source_path = repo_path / m.subpath if m.subpath else repo_path

        # Auto-clone when user explicitly browses this source
        if not source_path.is_dir() and source_id and m.id == source_id:
            try:
                repo_path = clone_or_update_github_repo(m.repo, cache_dir)
                source_path = repo_path / m.subpath if m.subpath else repo_path
            except Exception:
                pass  # fall through to synthetic entry

        if source_path.is_dir():
            skills = list_marketplace_skills(
                source_path,
                m.id,
                m.label,
                m.format,
                installed_names=installed,
                skill_file=m.skill_file,
                recommended=m.recommended,
            )
            for s in skills:
                result.append(
                    {
                        "name": s.name,
                        "description": s.description,
                        "source": s.source,
                        "source_label": s.source_label,
                        "plugin": s.plugin,
                        "installed": s.installed,
                        "keywords": s.keywords,
                        "has_references": s.has_references,
                        "recommended": m.recommended,
                    }
                )
        else:
            # Not cloned yet — show synthetic entry so UI can offer browse
            skill_name = m.id
            result.append(
                {
                    "name": skill_name,
                    "description": m.description,
                    "source": m.id,
                    "source_label": m.label,
                    "plugin": skill_name,
                    "installed": skill_name in installed,
                    "keywords": [],
                    "has_references": False,
                    "recommended": m.recommended,
                }
            )
    return result


def handle_marketplace_install(
    rt: Runtime, skill_name: str, source_id: str
) -> tuple[int, dict[str, Any]]:
    """POST /api/marketplace/install — install a skill from a marketplace."""
    from praestoclaw.skills.marketplace import (
        BUILTIN_MARKETPLACES,
        SUPPORTED_MARKETPLACE_FORMATS,
        clone_or_update_github_repo,
        detect_format,
        get_install_dir,
        get_installed_skill_names,
        get_marketplace_cache_dir,
        install_skill,
        list_marketplace_skills,
    )

    sources = rt.config.skills.marketplaces
    install_dir = get_install_dir()
    installed = get_installed_skill_names(install_dir)

    # Resolve source path — from config or from recommended builtins
    if source_id in sources:
        src_cfg = sources[source_id]
        src_path = Path(os.path.expanduser(src_cfg.path))
        if not src_path.is_dir():
            return 404, {"error": f"Marketplace directory not found: {src_path}"}
        fmt = (
            src_cfg.format
            if src_cfg.format in SUPPORTED_MARKETPLACE_FORMATS
            else detect_format(src_path)
        )
        skill_file = None
    else:
        # Check if it's a builtin marketplace
        builtin = next(
            (m for m in BUILTIN_MARKETPLACES if m.id == source_id),
            None,
        )
        if builtin is None:
            return 404, {"error": f"Marketplace source '{source_id}' not found."}
        # Clone on demand
        cache_dir = get_marketplace_cache_dir()
        try:
            repo_path = clone_or_update_github_repo(builtin.repo, cache_dir)
        except Exception as exc:
            return 500, {"error": f"Failed to clone {builtin.repo}: {exc}"}
        src_path = repo_path / builtin.subpath if builtin.subpath else repo_path
        if not src_path.is_dir():
            return 404, {"error": f"Marketplace directory not found: {src_path}"}
        fmt = builtin.format
        skill_file = builtin.skill_file

    src_label = src_cfg.label if source_id in sources else source_id
    skills = list_marketplace_skills(
        src_path,
        source_id,
        src_label,
        fmt,
        installed_names=installed,
        skill_file=skill_file,
    )
    target = next((s for s in skills if s.name == skill_name), None)
    if not target:
        return 404, {"error": f"Skill '{skill_name}' not found in '{source_id}'."}

    try:
        dest = install_skill(
            target,
            install_dir,
            marketplace_root=src_path,
            skill_file=skill_file,
        )
        # Reload skills so the new skill appears immediately
        loader = getattr(rt, "skill_loader", None)
        if loader:
            loader.load_all()
        return 200, {"installed": True, "name": skill_name, "path": str(dest)}
    except (ValueError, FileExistsError, FileNotFoundError, NotADirectoryError) as exc:
        return 400, {"error": str(exc)}
    except Exception as exc:
        return 500, {"error": str(exc)}


def handle_marketplace_uninstall(rt: Runtime, skill_name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/marketplace/uninstall — uninstall a marketplace skill."""
    from praestoclaw.skills.marketplace import get_install_dir, uninstall_skill

    install_dir = get_install_dir()
    try:
        removed = uninstall_skill(skill_name, install_dir)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    if removed:
        loader = getattr(rt, "skill_loader", None)
        if loader:
            loader.load_all()
        return 200, {"uninstalled": True, "name": skill_name}
    return 404, {"error": f"Skill '{skill_name}' not installed."}


def _persist_skills_disabled(rt: Runtime, disabled: list[str]) -> None:
    """Write the skills.disabled list to the local config yaml.

    Mirrors the pattern used by ConfigPraestoclawTool — read existing local
    overrides (if any), deep-merge the new value, write back atomically.
    """
    from praestoclaw.config.loader import _deep_merge, _home_local_override, save_yaml

    local_path = rt._config_local_path or _home_local_override()
    existing: dict[str, Any] = {}
    if local_path.exists():
        import yaml as _yaml

        existing = _yaml.safe_load(local_path.read_text(encoding="utf-8")) or {}
    merged = _deep_merge(existing, {"skills": {"disabled": list(disabled)}})
    save_yaml(local_path, merged)


def handle_skill_disable(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/skills/disable — hide an installed skill from the LLM.

    Persists to local config yaml AND updates the runtime config + loader's
    in-memory disabled set so the change takes effect on the next prompt
    build without a server restart.
    """
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return 500, {"error": "Skill loader unavailable."}
    skill = loader.find_by_name(name)
    if not skill:
        return 404, {"error": f"Skill not found: {name}"}
    if skill.disable_model_invocation:
        return 400, {
            "error": (
                f"Skill '{name}' is disabled by its SKILL.md frontmatter "
                "(disable-model-invocation); UI toggle is not allowed."
            )
        }
    cfg = rt.config.skills
    if name not in cfg.disabled:
        cfg.disabled = [*cfg.disabled, name]
        try:
            _persist_skills_disabled(rt, cfg.disabled)
        except Exception as exc:
            logger.exception(
                "Failed to persist disabled skills config while disabling '{}': {}", name, exc
            )
            cfg.disabled = [n for n in cfg.disabled if n != name]
            return 500, {"error": "Failed to persist config."}
        loader.set_disabled(cfg.disabled)
    return 200, {"disabled": True, "name": name}


def handle_skill_enable(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/skills/enable — re-enable a previously user-disabled skill."""
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return 500, {"error": "Skill loader unavailable."}
    cfg = rt.config.skills
    if name in cfg.disabled:
        new_list = [n for n in cfg.disabled if n != name]
        try:
            _persist_skills_disabled(rt, new_list)
        except Exception as exc:
            logger.exception(
                "Failed to persist disabled skills config while enabling '{}': {}", name, exc
            )
            return 500, {"error": "Failed to persist config."}
        cfg.disabled = new_list
        loader.set_disabled(cfg.disabled)
    return 200, {"enabled": True, "name": name}


# Strict whitelist for user skill directory names — letters/digits/_-./
# (matches MarketplaceSkill._safe_skill_dirname semantics). Lets static
# analysers (CodeQL) see an explicit guard against traversal characters
# before the value is ever joined with a trusted root.
_SAFE_SKILL_DIRNAME = re.compile(r"[A-Za-z0-9._-]{1,128}")


def _resolve_user_skill_md(
    rt: Runtime, name: str
) -> tuple[Path | None, dict[str, Any] | None, int]:
    """Locate the SKILL.md for a user-tier skill, with path-traversal guard.

    Returns (skill_md_path, error_payload, status_code). On success, error is None.
    """
    loader = getattr(rt, "skill_loader", None)
    if not loader:
        return None, {"error": "Skill loader unavailable."}, 500
    skill = loader.find_by_name(name)
    if skill is None:
        return None, {"error": f"Skill '{name}' not found."}, 404
    if skill.source_tier != "user":
        return (
            None,
            {
                "error": f"Only user-tier skills are editable. '{name}' is '{skill.source_tier}'.",
            },
            403,
        )

    from praestoclaw.utils.helpers import get_data_dir

    user_root = (get_data_dir() / "skills").resolve()
    raw_path = Path(skill.source_path).resolve()
    try:
        rel = raw_path.relative_to(user_root)
    except ValueError:
        return None, {"error": "Skill path is outside the user skills directory."}, 403

    # Reconstruct the path from the trusted user_root + a strictly-validated
    # single-segment skill directory name. This makes the safe-construction
    # explicit to static analysers (CodeQL) and removes any chance that a
    # crafted source_path could escape via separators or traversal segments.
    parts = rel.parts
    if len(parts) != 2 or parts[1] != "SKILL.md":
        return None, {"error": "Only <skill>/SKILL.md may be edited for user-tier skills."}, 403
    skill_dirname = parts[0]
    if not _SAFE_SKILL_DIRNAME.fullmatch(skill_dirname):
        return None, {"error": "Skill directory name contains unsafe characters."}, 403

    skill_md = user_root / skill_dirname / "SKILL.md"
    if skill_md.is_symlink():
        return None, {"error": "Symlinked skill files are not editable."}, 403
    if not skill_md.is_file():
        return None, {"error": f"SKILL.md not found at {skill_md}."}, 404
    return skill_md, None, 200


def handle_skill_content_get(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """GET /api/skills/content?name=<name> — read a user-tier SKILL.md."""
    skill_md, err, code = _resolve_user_skill_md(rt, name)
    if err is not None or skill_md is None:
        return code, err or {"error": "Unknown error."}
    try:
        text = skill_md.read_text(encoding="utf-8")
    except OSError:
        logger.exception("Failed to read SKILL.md for skill '{}'.", name)
        return 500, {"error": "Failed to read SKILL.md due to an internal error."}
    return 200, {"name": name, "path": str(skill_md), "content": text}


def handle_skill_content_put(rt: Runtime, name: str, content: str) -> tuple[int, dict[str, Any]]:
    """PUT /api/skills/content — overwrite a user-tier SKILL.md."""
    if not isinstance(content, str):
        return 400, {"error": "'content' must be a string."}
    skill_md, err, code = _resolve_user_skill_md(rt, name)
    if err is not None or skill_md is None:
        return code, err or {"error": "Unknown error."}
    try:
        skill_md.write_text(content, encoding="utf-8")
    except OSError:
        logger.exception("Failed to write SKILL.md for skill '{}'.", name)
        return 500, {"error": "Failed to write SKILL.md due to an internal error."}
    loader = getattr(rt, "skill_loader", None)
    if loader:
        loader.load_all()
    return 200, {"ok": True, "name": name, "path": str(skill_md)}


# ── Local skill import handlers ─────────────────────────────────────────────
# Scan the user's machine for skills already installed by Claude Code,
# Claude plugin marketplaces, or Copilot CLI, and let the user import any
# subset into PraestoClaw without re-running ``pc init``.


def _scan_local_skill_sources() -> list[dict[str, Any]]:
    """Return a list of local skill sources discovered on this machine.

    Each entry is ``{id, label, root, skills: [{name, path, source_tool}]}``.
    Only sources with at least one SKILL.md are returned.
    """
    home = Path.home()

    # (id, label, root) — root may not exist
    candidates: list[tuple[str, str, Path]] = [
        ("claude-user", "Claude Code (~/.claude/skills)", home / ".claude" / "skills"),
        ("copilot-cli", "Copilot CLI (~/.copilot/skills)", home / ".copilot" / "skills"),
    ]

    results: list[dict[str, Any]] = []

    for src_id, label, root in candidates:
        if not root.is_dir():
            continue
        skills = _scan_skills_under(root, source_tool=src_id)
        if skills:
            results.append({"id": src_id, "label": label, "root": str(root), "skills": skills})

    # Claude plugin marketplaces — each marketplace is a separate source so the
    # user can pick & choose which marketplace to import from.
    plugins_root = home / ".claude" / "plugins" / "marketplaces"
    if plugins_root.is_dir():
        for mkt_dir in sorted(plugins_root.iterdir()):
            if not mkt_dir.is_dir():
                continue
            mkt_skills_dir = mkt_dir / "skills"
            if not mkt_skills_dir.is_dir():
                continue
            skills = _scan_skills_under(mkt_skills_dir, source_tool=f"claude-plugin:{mkt_dir.name}")
            if skills:
                results.append(
                    {
                        "id": f"claude-plugin:{mkt_dir.name}",
                        "label": f"Claude plugin: {mkt_dir.name}",
                        "root": str(mkt_skills_dir),
                        "skills": skills,
                    }
                )

    return results


def _scan_skills_under(skills_dir: Path, *, source_tool: str) -> list[dict[str, Any]]:
    """Scan a directory for skill subdirs containing SKILL.md.

    Skips symlinks and any child whose resolved path escapes ``skills_dir``.
    Mirrors the safety check in :func:`praestoclaw.skills.marketplace.install_skill`
    so the UI never lists a skill that would later fail import with
    "source ... is outside marketplace root".
    """
    out: list[dict[str, Any]] = []
    try:
        children = sorted(skills_dir.iterdir())
    except OSError:
        return out
    try:
        skills_dir_resolved = skills_dir.resolve()
    except OSError:
        return out
    for child in children:
        # Skip symlinks (and broken links) — install_skill() rejects sources
        # whose resolved path escapes the marketplace root, so a symlinked
        # entry would show up as importable but always error out.
        if child.is_symlink() or not child.is_dir():
            continue
        try:
            child_resolved = child.resolve()
        except OSError:
            continue
        if child_resolved.parent != skills_dir_resolved:
            # Defense-in-depth: even if not a symlink, refuse anything that
            # resolves outside the scan root (e.g. mount-point shenanigans).
            continue
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            skill_md = child / "skill.md"
        if not skill_md.is_file():
            continue
        # Best-effort description from frontmatter (skip on any error)
        description = ""
        try:
            text = skill_md.read_text(encoding="utf-8", errors="replace")
            # Cheap frontmatter parse: look for "description:" line within first
            # ~20 lines so we don't slurp huge files.
            for line in text.splitlines()[:20]:
                stripped = line.strip()
                if stripped.startswith("description:"):
                    description = stripped[len("description:") :].strip().strip('"').strip("'")
                    break
        except OSError:
            pass
        out.append(
            {
                "name": child.name,
                "path": str(child),
                "source_tool": source_tool,
                "description": description[:200],
            }
        )
    return out


def handle_local_skills_scan(rt: Runtime) -> dict[str, Any]:
    """GET /api/skills/import/scan — list locally-discoverable skills.

    Result: ``{sources: [...], installed_names: [...]}`` so the UI can show
    install state per skill.
    """
    from praestoclaw.skills.marketplace import get_install_dir, get_installed_skill_names

    sources = _scan_local_skill_sources()
    installed = sorted(get_installed_skill_names(get_install_dir()))
    return {"sources": sources, "installed_names": installed}


def handle_local_skills_import(rt: Runtime, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    """POST /api/skills/import — install one or more locally-discovered skills.

    Body:
      ``{"items": [{"source": "<id>", "name": "<skill>"}, ...]}``
        — explicit list. Use this when the UI lets the user pick.

      ``{"source": "<id>"}`` — install every skill in that source.
      ``{"all": true}`` — install every skill from every source.

    Returns ``{installed: [{source, name, path}], errors: [...]}``.
    """
    from praestoclaw.skills.marketplace import (
        MarketplaceSkill,
        get_install_dir,
        get_installed_skill_names,
        install_skill,
    )

    if not isinstance(payload, dict):
        return 400, {"error": "Body must be a JSON object"}

    sources = _scan_local_skill_sources()
    by_id = {s["id"]: s for s in sources}

    # Build the work list of (source_dict, skill_dict) pairs.
    work: list[tuple[dict[str, Any], dict[str, Any]]] = []
    if payload.get("all"):
        for s in sources:
            for sk in s["skills"]:
                work.append((s, sk))
    elif payload.get("items"):
        items = payload["items"]
        if not isinstance(items, list):
            return 400, {"error": "'items' must be a list"}
        for item in items:
            if not isinstance(item, dict):
                continue
            sid = item.get("source")
            sname = item.get("name")
            if not sid or not sname:
                continue
            src = by_id.get(sid)
            if not src:
                continue
            sk = next((x for x in src["skills"] if x["name"] == sname), None)
            if sk:
                work.append((src, sk))
    elif payload.get("source"):
        src = by_id.get(payload["source"])
        if not src:
            return 404, {"error": f"Source '{payload['source']}' not found."}
        for sk in src["skills"]:
            work.append((src, sk))
    else:
        return 400, {"error": "Provide 'items', 'source', or 'all'."}

    if not work:
        return 200, {"installed": [], "errors": [], "skipped": []}

    install_dir = get_install_dir()
    installed_names = get_installed_skill_names(install_dir)

    installed: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []
    skipped: list[dict[str, Any]] = []

    for src, sk in work:
        if sk["name"] in installed_names:
            skipped.append({"source": src["id"], "name": sk["name"], "reason": "already installed"})
            continue
        try:
            ms = MarketplaceSkill(
                name=sk["name"],
                description=sk.get("description", ""),
                source=src["id"],
                source_label=src["label"],
                plugin=sk["name"],
                path=sk["path"],
                installed=False,
            )
            dest = install_skill(
                ms,
                install_dir,
                marketplace_root=Path(src["root"]),
                skill_file=None,
            )
            installed.append({"source": src["id"], "name": sk["name"], "path": str(dest)})
            installed_names.add(sk["name"])
        except (
            ValueError,
            FileExistsError,
            FileNotFoundError,
            NotADirectoryError,
            OSError,
        ) as exc:
            errors.append({"source": src["id"], "name": sk["name"], "error": str(exc)})

    if installed:
        loader = getattr(rt, "skill_loader", None)
        if loader:
            loader.load_all()

    return 200, {"installed": installed, "errors": errors, "skipped": skipped}


# ── Cron handlers (Phase 2 — BACK-05/06/07) ─────────────────────────────────


def _scheduler_unavailable() -> tuple[int, dict[str, Any]]:
    return 503, {"error": "Scheduler not enabled"}


def handle_cron_preview(rt: Runtime, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    """POST /api/cron/preview — validate + describe + next-N runs. Pure; no scheduler needed."""
    if not isinstance(payload, dict):
        return 400, {"error": "Body must be a JSON object"}
    schedule = payload.get("schedule")
    if schedule is None:
        return 400, {"error": "Missing 'schedule' field"}
    count_raw = payload.get("count", 5)
    count = count_raw if isinstance(count_raw, int) and count_raw >= 1 else 5
    tz = payload.get("tz") or payload.get("timezone")
    from praestoclaw.cron.preview import preview_schedule

    return 200, preview_schedule(schedule, count=count, tz=tz)


def handle_cron_list(rt: Runtime) -> tuple[int, list[dict[str, Any]] | dict[str, Any]]:
    """GET /api/cron/jobs — list all user jobs with next_run_at + unified status.

    Filters out internal system jobs (heartbeat) — the Cron UI is for user-managed
    tasks only. CLI / CronTool callers continue to see them via SchedulerService.list_jobs().
    """
    if rt.scheduler is None:
        return _scheduler_unavailable()
    from praestoclaw.cron.heartbeat import JOB_NAME as _HEARTBEAT_JOB_NAME

    return 200, [j for j in rt.scheduler.list_jobs() if j["name"] != _HEARTBEAT_JOB_NAME]


def handle_cron_create(rt: Runtime, payload: dict[str, Any]) -> tuple[int, dict[str, Any]]:
    """POST /api/cron/jobs — create or replace a job."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if not isinstance(payload, dict):
        return 400, {"error": "Body must be a JSON object"}
    name = payload.get("name")
    schedule = payload.get("schedule")
    if not name or schedule is None:
        return 400, {"error": "Missing required field: 'name' and/or 'schedule'"}
    kwargs: dict[str, Any] = {
        k: v
        for k, v in payload.items()
        if k
        in (
            "prompt",
            "message",
            "agent",
            "session_mode",
            "notify_channels",
            "exclude_tools",
            "tool",
            "arguments",
            "timezone",
            "description",
        )
        and v is not None
    }
    try:
        rt.scheduler.add_job(name=name, schedule=schedule, **kwargs)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 201, {"created": True, "name": name}


def handle_cron_update(
    rt: Runtime, name: str, payload: dict[str, Any]
) -> tuple[int, dict[str, Any]]:
    """PUT /api/cron/jobs/{name} — partial-merge update."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if not isinstance(payload, dict):
        return 400, {"error": "Body must be a JSON object"}
    if name not in rt.scheduler._jobs:  # noqa: SLF001 — single-process membership probe
        return 404, {"error": f"Job not found: {name}"}
    try:
        rt.scheduler.update_job(name, payload)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 200, {"updated": True, "name": name}


def handle_cron_delete(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """DELETE /api/cron/jobs/{name}."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if name not in rt.scheduler._jobs:  # noqa: SLF001
        return 404, {"error": f"Job not found: {name}"}
    try:
        rt.scheduler.remove_job(name)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 200, {"deleted": True, "name": name}


def handle_cron_enable(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/cron/jobs/{name}/enable — uses existing SchedulerService.enable()."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if name not in rt.scheduler._jobs:  # noqa: SLF001
        return 404, {"error": f"Job not found: {name}"}
    try:
        rt.scheduler.enable(name)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 200, {"enabled": True, "name": name}


def handle_cron_disable(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/cron/jobs/{name}/disable — uses existing SchedulerService.disable()."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if name not in rt.scheduler._jobs:  # noqa: SLF001
        return 404, {"error": f"Job not found: {name}"}
    try:
        rt.scheduler.disable(name)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 200, {"disabled": True, "name": name}


async def handle_cron_run(rt: Runtime, name: str) -> tuple[int, dict[str, Any]]:
    """POST /api/cron/jobs/{name}/run — fire job in background, return 202 immediately."""
    if rt.scheduler is None:
        return _scheduler_unavailable()
    if name not in rt.scheduler._jobs:  # noqa: SLF001
        return 404, {"error": f"Job not found: {name}"}
    try:
        await rt.scheduler.run_job(name, background=True)
    except ValueError as exc:
        return 400, {"error": str(exc)}
    return 202, {"started": True, "name": name}
