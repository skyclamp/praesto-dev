"""
Web server authentication — API key + Entra ID JWT verification.

Auth priority: X-API-Key header → Bearer (API key) → Bearer (Entra JWT)
              → ?key= query → ?token= query → reject

The public (no-auth) endpoints are `/`, `/app/` (webui SPA), `/chat` and
`/chat.html` (redirect into the SPA), `/health`, `/api/health`, `/api/status`,
`/api/auth/config`, `/api/auth/device-code[/poll]`, `/api/auth/azcli-token`,
`/auth/spa-callback`, `/favicon.svg`, and the `/static/` assets — see
`_PUBLIC_PATHS` below for the authoritative list.
"""

from __future__ import annotations

import hmac
import ipaddress
import time
from collections.abc import Iterable
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.config.schema import WebServerConfig


def verify_api_key(api_key: str | None, config: WebServerConfig) -> bool:
    """
    Verify an API key against the configured web server key.

    Returns True if:
    - No API key is configured (auth disabled)
    - The provided key matches the configured key (constant-time comparison)
    """
    if config.api_key is None:
        return True  # No key configured = auth disabled

    if api_key is None:
        return False

    expected = config.api_key.get_secret_value()
    return hmac.compare_digest(api_key, expected)


def is_loopback_host(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


# ── Entra ID JWT validation ────────────────────────────────────────────────

# Cache JWKS keys for 1 hour to avoid re-fetching on every request
_jwks_cache: dict[str, Any] = {}
_jwks_cache_time: float = 0
_JWKS_CACHE_TTL = 3600  # seconds


def _get_jwks_client(tenant_id: str) -> Any:
    """Get a PyJWKClient for the given tenant, with caching."""
    import jwt

    global _jwks_cache, _jwks_cache_time

    now = time.monotonic()
    if tenant_id in _jwks_cache and (now - _jwks_cache_time) < _JWKS_CACHE_TTL:
        return _jwks_cache[tenant_id]

    jwks_url = f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys"
    client = jwt.PyJWKClient(jwks_url)
    _jwks_cache[tenant_id] = client
    _jwks_cache_time = now
    return client


def validate_entra_token(token: str, config: WebServerConfig) -> dict[str, Any] | None:
    """
    Validate an Entra ID JWT token.

    Returns decoded claims on success, None on failure.
    Validates: signature (JWKS), audience, issuer, expiry.

    Accepts two audience families:
    1. The configured ``entra_client_id`` (and any legacy IDs) — the standard
       MSAL.js login-popup path.
    2. The Azure Resource Manager audience ``https://management.azure.com``
       (with or without trailing slash) — the ``az cli`` short-circuit path
       used by ``/api/auth/azcli-token``. ARM tokens are issued by the same
       tenant's STS, so iss + signature checks are still binding; we then
       enforce ``oid == owner_oid`` to scope the trust to the local user.
    """
    if not getattr(config, "entra_tenant_id", None):
        return None

    try:
        import jwt

        jwks_client = _get_jwks_client(config.entra_tenant_id)
        signing_key = jwks_client.get_signing_key_from_jwt(token)

        # Entra ID v2.0 issuer format
        issuer_v2 = f"https://login.microsoftonline.com/{config.entra_tenant_id}/v2.0"
        # ARM tokens are issued under the v1 (STS) issuer; accept both.
        issuer_v1 = f"https://sts.windows.net/{config.entra_tenant_id}/"

        audiences: list[str] = []
        if getattr(config, "entra_client_id", None):
            audiences.append(config.entra_client_id)
        if getattr(config, "entra_client_id_legacy", None):
            audiences.extend(config.entra_client_id_legacy)
        # ARM audiences (az cli default resource).
        audiences.extend(["https://management.azure.com", "https://management.azure.com/"])

        try:
            claims = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=audiences,
                issuer=issuer_v2,
            )
        except jwt.InvalidIssuerError:
            claims = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=audiences,
                issuer=issuer_v1,
            )
        # Require oid claim — reject tokens without a user identity
        if not claims.get("oid"):
            logger.debug("Entra ID token rejected: missing oid claim")
            return None
        # When owner_oid is set (from cloud channel identity), only allow
        # tokens from the same user — prevents other tenant users from
        # accessing the local web server.
        if getattr(config, "owner_oid", None) and claims["oid"] != config.owner_oid:
            logger.debug("Entra ID token rejected: oid mismatch")
            return None
        return claims
    except Exception as exc:
        logger.debug(f"Entra ID token validation failed: {exc}")
        return None


# ── Auth Middleware ──────────────────────────────────────────────────────────


class AuthMiddleware:
    """
    ASGI middleware that enforces API key or Entra ID authentication.

    Auth priority:
    1. X-API-Key header (constant-time comparison)
    2. Bearer token matched as API key
    3. Bearer token validated as Entra ID JWT
    4. ?key= query parameter (WebSocket API key)
    5. ?token= query parameter (WebSocket Entra JWT)
    """

    # Paths that skip authentication
    _PUBLIC_PATHS: frozenset[str] = frozenset(
        {
            "/",
            "/app",
            "/chat",
            "/chat.html",
            "/health",
            "/api/health",
            "/api/status",
            "/api/auth/config",
            "/api/auth/device-code",
            "/api/auth/device-code/poll",
            "/api/auth/azcli-token",
            "/auth/spa-callback",
            "/favicon.svg",
        }
    )

    def __init__(
        self,
        app: object,
        config: WebServerConfig,
        extra_api_keys: Iterable[str] | None = None,
    ) -> None:
        self._app = app
        self._config = config
        self._entra_enabled = bool(config.entra_tenant_id and config.entra_client_id)
        self._extra_api_keys = tuple(k for k in (extra_api_keys or ()) if k)

    @staticmethod
    def _is_loopback_scope(scope: dict) -> bool:
        client = scope.get("client")
        host = client[0] if isinstance(client, (tuple, list)) and client else ""
        return is_loopback_host(str(host))

    def _verify_api_key(self, api_key: str | None, *, allow_extra_api_keys: bool) -> bool:
        if not api_key:
            return False
        if self._config.api_key is not None and verify_api_key(api_key, self._config):
            return True
        if not allow_extra_api_keys:
            return False
        return any(hmac.compare_digest(api_key, expected) for expected in self._extra_api_keys)

    async def __call__(self, scope: dict, receive: object, send: object) -> None:  # noqa: ANN401
        if scope["type"] not in ("http", "websocket"):
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        path: str = scope.get("path", "")

        # Skip auth for public paths and static assets. The single-page webui
        # (/app/…) and the legacy /static/ JS are public; the security boundary
        # is the /api/* endpoints the UI calls, which still require auth.
        if path in self._PUBLIC_PATHS or path.startswith("/static/") or path.startswith("/app/"):
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        # Skip auth entirely if neither API key nor Entra ID is configured
        if self._config.api_key is None and not self._extra_api_keys and not self._entra_enabled:
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        _has_api_key = self._config.api_key is not None or bool(self._extra_api_keys)
        _allow_extra_api_keys = self._is_loopback_scope(scope)

        # ── Try API key auth (configured key, plus loopback-only bootstrap key) ──
        if _has_api_key:
            api_key = self._extract_x_api_key(scope)
            if self._verify_api_key(api_key, allow_extra_api_keys=_allow_extra_api_keys):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Try Bearer token ──
        bearer = self._extract_bearer_token(scope)
        if bearer:
            # Try as API key (configured key, plus loopback-only bootstrap key)
            if _has_api_key and self._verify_api_key(
                bearer, allow_extra_api_keys=_allow_extra_api_keys
            ):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return
            # Try as Entra ID JWT
            entra_claims = (
                validate_entra_token(bearer, self._config) if self._entra_enabled else None
            )
            if entra_claims:
                scope["user_claims"] = entra_claims
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Try query parameters (WebSocket fallback) ──
        if _has_api_key:
            query_key = self._extract_query_param(scope, "key")
            if self._verify_api_key(query_key, allow_extra_api_keys=_allow_extra_api_keys):
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        if self._entra_enabled:
            query_token = self._extract_query_param(scope, "token")
            entra_claims_q = (
                validate_entra_token(query_token, self._config) if query_token else None
            )
            if entra_claims_q:
                scope["user_claims"] = entra_claims_q
                await self._app(scope, receive, send)  # type: ignore[operator]
                return

        # ── Reject ──
        logger.warning(f"Unauthorized request to {path}")
        if scope["type"] == "websocket":
            await self._send_ws_close(receive, send)
        else:
            await self._send_401(send)

    @staticmethod
    def _extract_x_api_key(scope: dict) -> str | None:
        """Extract X-API-Key from ASGI scope headers."""
        headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        for name, value in headers:
            if name.lower() == b"x-api-key":
                return value.decode("utf-8", errors="ignore").strip()
        return None

    @staticmethod
    def _extract_bearer_token(scope: dict) -> str | None:
        """Extract the Bearer token from ASGI scope headers."""
        headers: list[tuple[bytes, bytes]] = scope.get("headers", [])
        for name, value in headers:
            if name.lower() == b"authorization":
                decoded = value.decode("utf-8", errors="ignore")
                if decoded.lower().startswith("bearer "):
                    return decoded[7:].strip()
                return None
        return None

    @staticmethod
    def _extract_query_param(scope: dict, param: str) -> str | None:
        """Extract a named parameter from the query string."""
        from urllib.parse import parse_qs

        qs: str = scope.get("query_string", b"").decode("utf-8", errors="ignore")
        params = parse_qs(qs)
        values = params.get(param)
        return values[0] if values else None

    @staticmethod
    async def _send_ws_close(receive: object, send: object) -> None:
        """Reject a WebSocket connection with close code 1008 (Policy Violation)."""
        await receive()  # type: ignore[operator]  # consume the ws connect
        await send({"type": "websocket.close", "code": 1008})  # type: ignore[operator]

    @staticmethod
    async def _send_401(send: object) -> None:
        """Send a 401 Unauthorized JSON response."""
        import json

        body = json.dumps(
            {"error": "Unauthorized", "message": "Invalid or missing API key"}
        ).encode()

        await send(
            {  # type: ignore[operator]
                "type": "http.response.start",
                "status": 401,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send(
            {  # type: ignore[operator]
                "type": "http.response.body",
                "body": body,
            }
        )
