"""Text coercions shared by the workflow tool and its profile subsystem.

These lived in ``agent/tools/workflow.py``. They moved here so
``agent/tools/workflow_profile.py`` can use them without importing the tool that
imports it — a shared leaf instead of a cycle.
"""

from __future__ import annotations

import re
from typing import Any

# A recipe name, a project name and a slug all share this cap. It bounds a path
# component, so it is a filesystem concern rather than a prompt-budget one.
MAX_NAME_LEN = 80
# Device names Windows refuses to create a file for, at any extension.
WIN_RESERVED = frozenset(
    {"con", "prn", "aux", "nul"}
    | {f"com{i}" for i in range(1, 10)}
    | {f"lpt{i}" for i in range(1, 10)}
)


def as_bool(value: Any) -> bool:
    """Coerce a tool arg that *should* be a bool but may arrive as a string.

    LLMs don't always honor the declared JSON type, so ``replace`` can show up as
    the string ``"false"`` — and ``bool("false")`` is ``True``, which would
    silently overwrite an existing file. Only an intentional true (real ``True``,
    or a ``"true"``-ish string) counts; everything else stays ``False`` so a stray
    value cannot clobber something saved.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes", "on")
    return False


def slugify(name: str) -> str:
    """Lowercase; keep unicode letters/digits; collapse the rest to a single dash.

    Returns "" if nothing usable remains (the caller rejects). The slug is both a
    filename stem and an identifier callers key off, so producers and consumers
    agree. Unicode letters (e.g. 中文) are kept so a non-ASCII name is not silently
    rejected.
    """
    slug = re.sub(r"[^\w]+", "-", name.strip().lower(), flags=re.UNICODE).replace("_", "-")
    slug = re.sub(r"-+", "-", slug).strip("-")
    slug = slug[:MAX_NAME_LEN].strip("-")  # re-trim: truncation can land on a dash
    if slug.lower() in WIN_RESERVED:
        # "con.md" et al. cannot be created on Windows — suffix so the id stays usable.
        slug = f"{slug}-wf"
    return slug
