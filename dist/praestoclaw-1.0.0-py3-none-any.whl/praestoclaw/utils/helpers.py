"""Common utilities."""

from __future__ import annotations

import os
import re
from pathlib import Path
from urllib.parse import urlparse, urlunparse

# Snippet width for the quoted question shared by the channel ↩️ reply quote
# (``channels/cloud.py::_prefix_reply_quote``), the durable ``[Re: …]`` fold-back
# row, and the ``[BG task=…]`` promotion ack row. These three MUST agree so the
# reaper can match an ack row to its fold-back; keep the width here as the single
# source of truth.
REPLY_QUOTE_SNIPPET_MAX = 80


def contains_cjk(text: str) -> bool:
    """True iff *text* contains any CJK Unified Ideograph (``\\u4e00-\\u9fff``).

    Bilingual zh/en copy across the carrier bubble, fold-back row, and status
    acks all branch on this one heuristic so the same question always renders in
    the same language.
    """
    return any("一" <= ch <= "鿿" for ch in text)


def truncate_ellipsis(text: str, max_len: int) -> str:
    """Cap *text* at *max_len*, collapsing the overflow to a single ``…``.

    Trailing whitespace before the ellipsis is stripped. *text* is otherwise
    returned unchanged; callers that need leading/trailing trim should strip
    before calling.
    """
    if len(text) <= max_len:
        return text
    return text[:max_len].rstrip() + "…"


def ensure_dir(path: Path) -> Path:
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        from loguru import logger

        logger.warning("Cannot create directory {}: {}", path, exc)
    return path


_data_dir_override: Path | None = None


def set_data_dir(path: str | Path | None) -> None:
    """Set or clear the process-wide data directory override.

    When ``path`` is not None it takes precedence over the
    ``PRAESTOCLAW_DATA_DIR`` environment variable and the default
    ``~/.praestoclaw/`` location. Pass ``None`` to clear the override.

    The path is resolved to an absolute path immediately so subsequent
    chdir calls don't shift the data directory.
    """
    global _data_dir_override
    if path is None:
        _data_dir_override = None
        return
    _data_dir_override = Path(path).expanduser().resolve()


def get_data_dir() -> Path:
    """Return the effective data directory.

    Resolution order (highest precedence first):

    1. Process-wide override set via :func:`set_data_dir` (e.g. CLI ``--data-dir``).
    2. ``PRAESTOCLAW_DATA_DIR`` environment variable.
    3. Default ``~/.praestoclaw/``.

    The returned directory is created on demand. All sub-helpers
    (:func:`get_auth_dir`, :func:`get_skills_dir`)
    automatically inherit the override because they resolve from this function.
    """
    if _data_dir_override is not None:
        return ensure_dir(_data_dir_override)
    env_dir = os.environ.get("PRAESTOCLAW_DATA_DIR")
    if env_dir:
        return ensure_dir(Path(env_dir).expanduser().resolve())
    from praestoclaw.utils.channel import is_staging

    if is_staging():
        return ensure_dir(Path.home() / ".praestoclaw-staging")
    return ensure_dir(Path.home() / ".praestoclaw")


def get_auth_dir() -> Path:
    """Return the auth data directory: ``<data-dir>/auth/``."""
    return ensure_dir(get_data_dir() / "auth")


def get_workspace_dir() -> Path:
    """Default agent workspace: <data-dir>/workspace/.

    Used when ``config.workspace`` is empty, so the sandbox root stays
    on a known writable path instead of inheriting process cwd (which
    can be ``C:\\Windows\\System32`` under Task Scheduler / autostart).
    """
    return ensure_dir(get_data_dir() / "workspace")


def get_skills_dir() -> Path:
    return ensure_dir(get_data_dir() / "skills")


def get_feedback_dir() -> Path:
    """Legacy persistent directory for feedback issue body drafts.

    Kept for compatibility and access to drafts created by older versions.
    Current initial submissions keep the body in memory and stream it to
    ``feedback_submit`` over stdin instead of writing here.
    """
    return ensure_dir(get_data_dir() / "feedbacks")


def webchat_url_from_connect(connect_url: str) -> str:
    """Derive the web-chat URL from a PraestoClaw cloud connect URL.

    wss://host/connect  →  https://host/chat
    ws://host/connect   →  http://host/chat

    Raises ValueError for unexpected schemes so callers can handle
    misconfiguration rather than silently propagating an invalid URL.
    """
    parsed = urlparse(connect_url)
    scheme_map = {"wss": "https", "ws": "http"}
    if parsed.scheme not in scheme_map:
        raise ValueError(
            f"webchat_url_from_connect: expected ws:// or wss:// URL, got {connect_url!r}"
        )
    http_scheme = scheme_map[parsed.scheme]
    path = re.sub(r"/connect$", "/chat", parsed.path) if parsed.path else "/chat"
    return urlunparse((http_scheme, parsed.netloc, path, "", "", ""))
