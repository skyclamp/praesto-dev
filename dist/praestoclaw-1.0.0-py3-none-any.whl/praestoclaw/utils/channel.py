"""Channel resolver — production vs staging.

Channel is decided by the entry-point invoked (``pc`` vs ``pc-staging``);
``main_staging()`` in :mod:`praestoclaw.cli.commands` calls :func:`set_channel`
before delegating to the shared Typer app. All channel-aware code paths
(data dir routing, cloud URL overlay, mirror branch selection) read from
:func:`get_channel`.
"""

from __future__ import annotations

from typing import Literal

Channel = Literal["production", "staging"]

_channel: Channel = "production"


def set_channel(channel: Channel) -> None:
    global _channel
    _channel = channel


def get_channel() -> Channel:
    return _channel


def is_staging() -> bool:
    return _channel == "staging"


def default_bot_display_name() -> str:
    """Fallback Teams @mention display name when config doesn't override it.

    Always the production name. The agent has no intrinsic staging identity —
    it is "staging" only by virtue of the gateway it connects to, which isn't
    known this early, so we must not infer the display name from the channel
    singleton. A staging or custom-named deployment sets its real bot name via
    ``channels.cloud.bot_display_name`` (the staging bundled diff does this).

    Used so a group turn can tell the LLM which ``@name`` refers to itself; a
    wrong name here makes the bot fail to strip its own @mention and record its
    own name as a topic.
    """
    return "PraestoClaw"
