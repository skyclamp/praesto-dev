"""Shared update-check logic — used by heartbeat tool and CLI (wheel mirror path).

PraestoClaw is not published on PyPI. Wheel-install users check the public
installer mirror's ``latest.txt`` pointer instead. Git users check their
upstream branch (unchanged)."""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from praestoclaw import __version__

# Public mirror that hosts pre-built wheels + ``latest.txt`` pointer.
# Must stay in sync with install.ps1 / install.sh.
# Channel selects the mirror repo: production → cogao/praestoclaw-installer,
# staging → xchunzhao/praestoclaw-installer-staging (separate repo, not a
# branch of prod — keeps perms / settings fully independent).
_MIRROR_BASES: dict[str, str] = {
    "production": "https://raw.githubusercontent.com/cogao/praestoclaw-installer/main",
    "staging": "https://raw.githubusercontent.com/xchunzhao/praestoclaw-installer-staging/main",
}


def mirror_base() -> str:
    """Return the mirror base URL for the active channel."""
    from praestoclaw.utils.channel import get_channel

    return _MIRROR_BASES[get_channel()]


# Backwards-compatible re-export — existing call sites are migrated to
# ``mirror_base()``; keeping the constant prevents import-time breakage in
# tests that monkey-patch it.
MIRROR_BASE = _MIRROR_BASES["production"]


def _live_version() -> str:
    """Re-read the installed package version from disk.

    ``praestoclaw.__version__`` is captured at import time and stays frozen
    for the life of the process. A long-running ``praestoclaw s`` daemon
    that survives a ``pc update`` would otherwise keep reporting the old
    version forever, so for the update check we always look at the freshly
    installed metadata. Falls back to the cached module-level value when
    package metadata is unavailable (e.g. running directly from a source
    checkout without an installed distribution).
    """
    try:
        from importlib.metadata import (
            MetadataPathFinder,
            PackageNotFoundError,
            version,
        )

        # ``importlib.metadata`` caches distribution lookups in-process
        # (FastPath / MetadataPathFinder). After ``pc update`` replaces the
        # on-disk dist-info, a long-running daemon could otherwise still see
        # the old version from the cache. Invalidate before reading so we
        # always reflect the freshly installed metadata.
        MetadataPathFinder.invalidate_caches()
        return version("praestoclaw")
    except PackageNotFoundError:
        return __version__


@dataclass
class UpdateStatus:
    """Result of an update check."""

    up_to_date: bool
    current: str = ""
    latest: str | None = None
    commit_count: int = 0
    commit_log: str = ""  # oneline summaries (git only)
    install_mode: str = "unknown"  # "git" | "mirror"
    error: str | None = None

    def __post_init__(self) -> None:
        if not self.current:
            self.current = _live_version()

    @property
    def summary(self) -> str:
        if self.error:
            return f"Update check failed: {self.error}"
        if self.up_to_date:
            if self.install_mode == "git":
                return f"PraestoClaw v{self.current} is up to date (git)."
            return f"PraestoClaw v{self.current} is up to date (latest: v{self.latest or self.current})."
        if self.install_mode == "git":
            msg = f"PraestoClaw update available: {self.commit_count} new commit(s).\nCurrent: v{self.current}"
            if self.commit_log:
                msg += f"\nLatest commits:\n{self.commit_log}"
            return msg + "\nRun `praestoclaw update` to install."
        return (
            f"PraestoClaw update available: v{self.current} -> v{self.latest}\n"
            f"Run `praestoclaw update` to install."
        )


def is_git_install() -> Path | None:
    """Return repo root if editable git install, else None."""
    repo_root = Path(__file__).resolve().parent.parent.parent
    return repo_root if (repo_root / ".git").exists() else None


def parse_version(v: str) -> tuple[int, ...]:
    """Parse version string to comparable tuple (e.g. '0.7.0' -> (0, 7, 0)).

    Legacy helper kept for callers that just need a quick numeric tuple.
    For correct version comparison (post-releases, pre-releases, etc.)
    use :func:`_is_at_least` which delegates to ``packaging.version``.
    """
    return tuple(int(x) for x in re.findall(r"\d+", v))


def check_git(repo: Path) -> UpdateStatus:
    """Fetch and compare with upstream. Does NOT pull."""
    if _run(["git", "fetch"], cwd=repo) is None:
        return UpdateStatus(up_to_date=False, install_mode="git", error="git fetch failed")

    local = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    remote = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if not local or not remote:
        return UpdateStatus(
            up_to_date=False, install_mode="git", error="could not compare local/remote"
        )

    if local == remote:
        return UpdateStatus(up_to_date=True, install_mode="git")

    # Detect ahead/behind/diverged
    lr_out = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    behind = 0
    if lr_out:
        parts = lr_out.split()
        if len(parts) == 2:
            behind = int(parts[1])

    if behind == 0:
        # Ahead only or diverged with no upstream commits — no update available
        return UpdateStatus(up_to_date=True, install_mode="git")

    log_out = _run(["git", "log", "--oneline", "-5", f"{local}..{remote}"], cwd=repo) or ""

    return UpdateStatus(
        up_to_date=False,
        install_mode="git",
        commit_count=behind,
        commit_log=log_out,
    )


def _is_at_least(current: str, latest: str) -> bool:
    """Return True if ``current`` >= ``latest`` per PEP 440 ordering.

    Falls back to legacy digit-tuple compare when ``packaging`` isn't
    importable (which would already break the wheel install).
    """
    try:
        from packaging.version import InvalidVersion, Version

        return Version(current) >= Version(latest)
    except (ImportError, InvalidVersion):
        return parse_version(current) >= parse_version(latest)


def check_mirror() -> UpdateStatus:
    """Check the public installer mirror's ``latest.txt`` for a newer version."""
    latest = _fetch_mirror_version()
    if latest is None:
        return UpdateStatus(
            up_to_date=False,
            install_mode="mirror",
            error="could not determine latest version from mirror",
        )

    current = _live_version()
    if _is_at_least(current, latest):
        return UpdateStatus(up_to_date=True, current=current, install_mode="mirror", latest=latest)

    return UpdateStatus(up_to_date=False, current=current, install_mode="mirror", latest=latest)


# Backward-compat alias — old callers / docs may still say "pypi".
check_pypi = check_mirror


def check_update() -> UpdateStatus:
    """Auto-detect install mode and check for updates.

    Writes ``~/.praestoclaw/.last_update_check`` on success so heartbeat
    pre-flight and startup check share the same throttle marker.
    """
    repo = is_git_install()
    status = check_git(repo) if repo else check_mirror()

    if not status.error:
        _touch_marker()

    return status


def _touch_marker() -> None:
    """Update the shared throttle marker file."""
    import time

    try:
        from praestoclaw.utils.helpers import get_data_dir

        marker = get_data_dir() / ".last_update_check"
        marker.write_text(str(int(time.time())), encoding="utf-8")
    except OSError:
        pass


# ── Internal helpers ─────────────────────────────────────────────────────────


def _run(cmd: list[str], cwd: Path | None = None, timeout: int = 30) -> str | None:
    """Run a command, return stdout or None on failure."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd)
        return r.stdout.strip() if r.returncode == 0 else None
    except Exception:
        return None


def _fetch_mirror_version() -> str | None:
    """Get latest version from the installer mirror's ``latest.txt``.

    Uses a cache-busting query string so GitHub Raw's 5-minute CDN TTL
    doesn't serve a stale pointer right after a release.
    """
    import time

    url = f"{mirror_base()}/latest.txt?t={int(time.time())}"
    try:
        import httpx

        resp = httpx.get(url, timeout=10, follow_redirects=True)
        resp.raise_for_status()
        text = resp.text.strip()
        # Validate PEP 440-ish version string
        if re.match(r"^\d+(\.\d+)*([.-][a-zA-Z0-9]+)*$", text):
            return text
    except Exception:
        pass
    return None
