"""Durable MCP bindings owned by one group conversation."""

from __future__ import annotations

import builtins
import hashlib
import json
import re
import threading
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")


@dataclass(slots=True)
class GroupMCPRecord:
    chat_id: str
    name: str
    url: str | None = None
    command: str | None = None
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    headers: dict[str, str] = field(default_factory=dict)
    client_id: str | None = None
    scopes: list[str] = field(default_factory=list)
    callback_port: int | None = None
    auth_server_url: str | None = None
    installed_by: str = ""
    installed_at: str = ""
    updated_at: str = ""


def normalise_name(value: str) -> str:
    name = str(value or "").strip()
    if not _NAME_RE.fullmatch(name):
        raise ValueError("MCP name must be lowercase letters, digits, '-' or '_'")
    return name


def normalise_chat_id(value: str) -> str:
    return str(value or "").strip()


def physical_name(chat_id: str, name: str) -> str:
    digest = hashlib.sha256(normalise_chat_id(chat_id).encode("utf-8")).hexdigest()[:16]
    return f"group_{digest}_{normalise_name(name)}"


class GroupMCPRegistry:
    def __init__(self, data_dir: Path) -> None:
        self.base_dir = Path(data_dir) / "group-mcps"
        self._path = self.base_dir / "registry.json"
        self._lock = threading.RLock()
        self._records: dict[tuple[str, str], GroupMCPRecord] = {}
        if self._path.is_file():
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            for item in raw:
                record = GroupMCPRecord(**item)
                self._records[(record.chat_id, record.name)] = record

    def add(
        self,
        *,
        chat_id: str,
        name: str,
        url: str | None = None,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        client_id: str | None = None,
        scopes: list[str] | None = None,
        callback_port: int | None = None,
        auth_server_url: str | None = None,
        installed_by: str = "",
    ) -> GroupMCPRecord:
        cid = normalise_chat_id(chat_id)
        canonical = normalise_name(name)
        endpoint = str(url or "").strip() or None
        executable = str(command or "").strip() or None
        if bool(endpoint) == bool(executable):
            raise ValueError("exactly one of url or command is required")
        key = (cid, canonical)
        with self._lock:
            if key in self._records:
                raise ValueError(f"group MCP '{canonical}' is already registered in this chat")
            now = datetime.now(UTC).isoformat()
            record = GroupMCPRecord(
                chat_id=cid,
                name=canonical,
                url=endpoint,
                command=executable,
                args=list(args or []),
                env={str(key): str(value) for key, value in (env or {}).items()},
                headers={str(key): str(value) for key, value in (headers or {}).items()},
                client_id=str(client_id or "").strip() or None,
                scopes=list(scopes or []),
                callback_port=callback_port,
                auth_server_url=auth_server_url,
                installed_by=installed_by,
                installed_at=now,
                updated_at=now,
            )
            self._records[key] = record
            self._persist()
            return GroupMCPRecord(**asdict(record))

    def get(self, chat_id: str, name: str) -> GroupMCPRecord | None:
        with self._lock:
            record = self._records.get((normalise_chat_id(chat_id), normalise_name(name)))
            return GroupMCPRecord(**asdict(record)) if record else None

    def list(self, chat_id: str) -> list[GroupMCPRecord]:
        with self._lock:
            records = [
                GroupMCPRecord(**asdict(record))
                for (cid, _), record in self._records.items()
                if cid == normalise_chat_id(chat_id)
            ]
        return sorted(records, key=lambda item: item.name)

    def remove(self, chat_id: str, name: str) -> bool:
        with self._lock:
            removed = self._records.pop((normalise_chat_id(chat_id), normalise_name(name)), None)
            if removed:
                self._persist()
            return removed is not None

    def set_scopes(self, chat_id: str, name: str, scopes: builtins.list[str]) -> GroupMCPRecord:
        key = (normalise_chat_id(chat_id), normalise_name(name))
        with self._lock:
            record = self._records.get(key)
            if record is None:
                raise ValueError(f"group MCP '{name}' is not registered in this chat")
            record.scopes = [str(scope) for scope in scopes]
            record.updated_at = datetime.now(UTC).isoformat()
            self._persist()
            return GroupMCPRecord(**asdict(record))

    def _persist(self) -> None:
        self.base_dir.mkdir(parents=True, exist_ok=True)
        payload = [asdict(record) for record in self._records.values()]
        temporary = self._path.with_suffix(".tmp")
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        temporary.replace(self._path)
