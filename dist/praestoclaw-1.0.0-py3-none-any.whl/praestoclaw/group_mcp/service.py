"""Runtime lifecycle for group-owned remote MCP servers."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Literal

from praestoclaw.agent.tools.registry import ToolRegistry
from praestoclaw.config.schema import MCPAuthConfig, MCPServerConfig, ProvidersConfig
from praestoclaw.group_mcp.core import GroupMCPRecord, GroupMCPRegistry, physical_name
from praestoclaw.mcp.manager import MCPManager
from praestoclaw.mcp.oauth_storage import MCPTokenStorage


class GroupMCPService:
    def __init__(
        self,
        registry: GroupMCPRegistry,
        tool_registry: ToolRegistry,
        *,
        providers: ProvidersConfig | None = None,
        security_profile: str | None = None,
        risk_policy: dict[str, Any] | None = None,
        risk_variables: dict[str, str] | None = None,
    ) -> None:
        self.registry = registry
        self._tool_registry = tool_registry
        self._configs: dict[str, MCPServerConfig] = {}
        for record in self._all_records():
            self._configs[physical_name(record.chat_id, record.name)] = self._config(record)
        self._manager = MCPManager(
            self._configs,
            tool_registry,
            providers=providers,
            security_profile=security_profile,
            risk_policy=risk_policy,
            risk_variables=risk_variables,
        )

    def _all_records(self) -> list[GroupMCPRecord]:
        # Registry intentionally exposes only chat-scoped reads. Startup loading
        # is confined here and does not widen model-facing access.
        return [GroupMCPRecord(**asdict(record)) for record in self.registry._records.values()]

    @staticmethod
    def _config(record: GroupMCPRecord, *, interactive: bool = False) -> MCPServerConfig:
        auth_type: Literal["implicit", "oauth"] = "oauth" if interactive else "implicit"
        return MCPServerConfig(
            url=record.url,
            command=record.command,
            args=record.args,
            env=record.env,
            headers=record.headers,
            description=None,
            risk=None,
            namespace=physical_name(record.chat_id, record.name),
            auth=MCPAuthConfig(
                type=auth_type,
                client_id=record.client_id,
                scopes=record.scopes,
                callback_port=record.callback_port,
                auth_server_url=record.auth_server_url,
                use_sdk_oauth=True,
            ),
        )

    async def add(
        self,
        *,
        chat_id: str,
        name: str,
        url: str | None = None,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
        actor: str = "",
        **auth: Any,
    ) -> str:
        record = self.registry.add(
            chat_id=chat_id,
            name=name,
            url=url,
            command=command,
            args=args,
            env=env,
            headers=headers,
            installed_by=actor,
            client_id=auth.get("client_id"),
            scopes=auth.get("scopes"),
            callback_port=auth.get("callback_port"),
            auth_server_url=auth.get("auth_server_url"),
        )
        physical = physical_name(chat_id, record.name)
        self._configs[physical] = self._config(record)
        await self._manager.connect_server(physical, auto_describe=False)
        if self._manager.get_server_status(physical).state.value == "connected":  # type: ignore[union-attr]
            self._manager.ensure_tools_registered(physical)
            return f"Added group MCP '{record.name}' and connected it ({len(self.server_tool_names(chat_id, record.name))} tools)."
        return f"Added group MCP '{record.name}', but could not connect. Use mcp login '{record.name}' if authentication is required."

    async def login(self, chat_id: str, name: str, scopes: list[str] | None = None) -> str:
        record = self._require(chat_id, name)
        if not record.url:
            return f"Group MCP '{record.name}' uses stdio; login is not applicable."
        if scopes is not None:
            record = self.registry.set_scopes(chat_id, name, scopes)
        physical = physical_name(chat_id, record.name)
        storage = MCPTokenStorage(physical)
        if record.client_id is None:
            storage.clear()
        self._configs[physical] = self._config(record, interactive=True)
        await self._manager.connect_server(physical, force=True, auto_describe=False)
        if self._manager.get_server_status(physical).state.value != "connected":  # type: ignore[union-attr]
            self._configs[physical] = self._config(record)
            return f"Login for group MCP '{record.name}' did not complete."
        self._manager.ensure_tools_registered(physical)
        # Later reconnects are silent and reuse the token stored under the
        # physical per-chat server name.
        self._configs[physical] = self._config(record)
        return f"Logged in and connected group MCP '{record.name}' ({len(self.server_tool_names(chat_id, record.name))} tools available)."

    async def logout(self, chat_id: str, name: str) -> str:
        record = self._require(chat_id, name)
        physical = physical_name(chat_id, record.name)
        await self._manager.disconnect_server(physical)
        MCPTokenStorage(physical).clear()
        return f"Logged out group MCP '{record.name}' and disconnected it."

    async def remove(self, chat_id: str, name: str) -> str:
        record = self._require(chat_id, name)
        physical = physical_name(chat_id, record.name)
        await self._manager.disconnect_server(physical)
        self._configs.pop(physical, None)
        self.registry.remove(chat_id, name)
        return f"Removed group MCP '{record.name}' from this chat."

    async def prepare_chat(self, chat_id: str) -> list[str]:
        for record in self.registry.list(chat_id):
            physical = physical_name(chat_id, record.name)
            status = self._manager.get_server_status(physical)
            if status is None:
                self._configs[physical] = self._config(record)
            if status is None or status.state.value not in {"connected", "connecting"}:
                await self._manager.connect_server(physical, auto_describe=False)
            status = self._manager.get_server_status(physical)
            if status and status.state.value == "connected":
                self._manager.ensure_tools_registered(physical)
        return self.tool_names(chat_id)

    def tool_names(self, chat_id: str) -> list[str]:
        prefixes = [
            f"MCP_{physical_name(chat_id, item.name)}_" for item in self.registry.list(chat_id)
        ]
        return sorted(
            tool.name
            for tool in self._tool_registry.list_tools()
            if any(tool.name.startswith(prefix) for prefix in prefixes)
        )

    def server_tool_names(self, chat_id: str, name: str) -> list[str]:
        prefix = f"MCP_{physical_name(chat_id, name)}_"
        return sorted(
            tool.name for tool in self._tool_registry.list_tools() if tool.name.startswith(prefix)
        )

    def list(self, chat_id: str) -> str:
        records = self.registry.list(chat_id)
        if not records:
            return "No MCP servers are bound to this chat."
        lines = []
        for record in records:
            status = self._manager.get_server_status(physical_name(chat_id, record.name))
            endpoint = record.url or " ".join([record.command or "", *record.args])
            lines.append(
                f"- {record.name}: {status.state.value if status else 'idle'} ({endpoint})"
            )
        return "Group MCP servers:\n" + "\n".join(lines)

    def get(self, chat_id: str, name: str) -> str:
        record = self._require(chat_id, name)
        status = self._manager.get_server_status(physical_name(chat_id, record.name))
        auth = "sdk-oauth" if record.url else "not-applicable"
        return (
            f"{record.name}: {status.state.value if status else 'idle'}; "
            f"transport={'http' if record.url else 'stdio'}; endpoint={record.url or record.command}; "
            f"auth={auth}; tools={len(self.server_tool_names(chat_id, record.name))}"
        )

    async def close(self) -> None:
        await self._manager.disconnect_all()

    def _require(self, chat_id: str, name: str) -> GroupMCPRecord:
        record = self.registry.get(chat_id, name)
        if record is None:
            raise ValueError(f"group MCP '{name}' is not registered in this chat")
        return record
