"""Direct chatsvc client — the messaging API Teams Web itself uses.

Endpoint shape (discovered by recording Teams Web's own traffic; every part of
the obvious guess was wrong)::

    GET https://teams.cloud.microsoft/api/chatsvc/{region}/v1/users/ME/
        conversations/{conversationId}/messages
        ?view=msnp24Equivalent|supportsMessageProperties&pageSize=200
    Authorization:    Bearer <ic3.teams.office.com token>
    behavioroverride: redirectAs404
    x-ms-migration:   True
    clientinfo:       os=windows; ...; clientName=skypeteams; ...

Versus Graph (which the Teams MCP wraps) this returns the *system* events too —
``ThreadActivity/TopicUpdate`` (rename history), ``RichText/Media_CallRecording``
(the transcript pointer), ``Event/Call`` (call boundaries). Graph filters all of
those out, which is precisely why the transcript could not be found through it.

Two error codes matter:

* ``911`` — authentication failed. Either the wrong credential or, far more
  often, an ic3 token that expired between being read and being used.
* ``752`` — "User is in a different cloud". This is an *authorisation success*
  with a routing failure: right token, wrong region. It is what makes region
  discovery possible without guessing blindly.
"""

from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from html import unescape
from typing import Any
from urllib.parse import quote, urlparse

import httpx
from loguru import logger

CHATSVC_HOST = "https://teams.cloud.microsoft"
MESSAGE_VIEW = "msnp24Equivalent|supportsMessageProperties"
CLIENT_INFO = (
    "os=windows; osVer=NT 10.0; proc=x86; lcid=en-us; deviceType=1; "
    "country=us; clientName=skypeteams; clientVer=1415/2607260"
)

# Ordered candidates for region discovery. The pilot rings are listed next to
# their base ring because Teams Web was observed using both in one session.
DEFAULT_REGION_CANDIDATES: tuple[str, ...] = (
    "apac-pilot1",
    "apac",
    "amer-pilot1",
    "amer",
    "emea-pilot1",
    "emea",
)

_WRONG_CLOUD_ERROR_CODE = 752
_AUTH_FAILED_ERROR_CODE = 911

DEFAULT_PAGE_SIZE = 200
DEFAULT_MAX_PAGES = 20


class ChatsvcError(Exception):
    """A chatsvc call failed in a way the caller must surface."""


class ChatsvcAuthError(ChatsvcError):
    """The ic3 credential was rejected — re-acquire and retry once."""


@dataclass(slots=True)
class ChatsvcFetchResult:
    """Everything one message pull produced."""

    conversation_id: str
    region: str
    raw_pages: list[dict[str, Any]] = field(default_factory=list)
    messages: list[dict[str, Any]] = field(default_factory=list)
    pages_fetched: int = 0
    reached_start: bool = False
    foreign_messages_dropped: int = 0


def message_time(message: dict[str, Any]) -> str:
    return str(message.get("originalarrivaltime") or message.get("composetime") or "")


# chatsvc emits 7 fractional digits (".5780000"); ``fromisoformat`` accepts at
# most 6. Splitting on "." alone is not enough — the remainder also carries the
# UTC offset, and a naive "strip everything that is not a digit" pass swallows
# the offset's digits too, silently producing a *naive* datetime that is then
# misread as local time.
_FRACTION_RE = re.compile(r"^(?P<head>.*T\d{2}:\d{2}:\d{2})\.(?P<frac>\d+)(?P<rest>.*)$")


def parse_message_time(value: str) -> datetime | None:
    """Parse a chatsvc timestamp into an aware UTC datetime, or None.

    Always returns an aware value: chatsvc timestamps are UTC, and a naive one
    leaking out compares unequal-and-unorderable against every other timestamp
    in this package.
    """
    text = (value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    match = _FRACTION_RE.match(text)
    if match:
        text = f"{match['head']}.{match['frac'][:6]}{match['rest']}"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


class TeamsChatsvcClient:
    """Pull messages for exactly one conversation.

    The conversation id is fixed at construction time. There is deliberately no
    method that searches, enumerates chats, or reaches outside it.
    """

    def __init__(
        self,
        conversation_id: str,
        *,
        access_token: str,
        region: str = "",
        timeout: float = 30.0,
    ) -> None:
        conversation_id = (conversation_id or "").strip()
        if not conversation_id:
            raise ValueError("TeamsChatsvcClient requires a conversation id")
        self._cid = conversation_id
        self._token = access_token
        self._region = (region or "").strip()
        self._timeout = timeout

    @property
    def region(self) -> str:
        return self._region

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/json",
            "behavioroverride": "redirectAs404",
            "x-ms-migration": "True",
            "clientinfo": CLIENT_INFO,
        }

    def _messages_url(self, region: str, *, page_size: int, start_time_ms: int | None) -> str:
        cid = quote(self._cid, safe="")
        url = (
            f"{CHATSVC_HOST}/api/chatsvc/{region}/v1/users/ME/conversations/{cid}/messages"
            f"?view={quote(MESSAGE_VIEW, safe='|')}&pageSize={page_size}"
        )
        if start_time_ms is not None:
            url += f"&startTime={start_time_ms}"
        return url

    async def fetch_messages(
        self,
        *,
        since: datetime | None = None,
        max_pages: int = DEFAULT_MAX_PAGES,
        page_size: int = DEFAULT_PAGE_SIZE,
        region_candidates: tuple[str, ...] = DEFAULT_REGION_CANDIDATES,
    ) -> ChatsvcFetchResult:
        """Page backwards through the conversation until *since* is crossed."""
        async with httpx.AsyncClient(timeout=self._timeout, follow_redirects=False) as client:
            region = self._region or await self._discover_region(
                client, region_candidates, page_size=page_size
            )
            self._region = region

            result = ChatsvcFetchResult(conversation_id=self._cid, region=region)
            url: str | None = self._messages_url(region, page_size=page_size, start_time_ms=None)
            seen: set[str] = set()

            while url and result.pages_fetched < max_pages:
                body = await self._get_json(client, url)
                result.raw_pages.append(body)
                result.pages_fetched += 1

                page_messages = [m for m in (body.get("messages") or []) if isinstance(m, dict)]
                for message in page_messages:
                    # Hard cid scoping: chatsvc is already per-conversation, but a
                    # cached/replayed page must never smuggle another chat in.
                    message_cid = str(message.get("conversationid") or "").strip()
                    if message_cid and message_cid != self._cid:
                        result.foreign_messages_dropped += 1
                        continue
                    message_id = str(message.get("id") or "")
                    if message_id and message_id in seen:
                        continue
                    if message_id:
                        seen.add(message_id)
                    result.messages.append(message)

                if since is not None and page_messages:
                    oldest = min(
                        (
                            t
                            for t in (parse_message_time(message_time(m)) for m in page_messages)
                            if t
                        ),
                        default=None,
                    )
                    if oldest is not None and oldest <= since:
                        result.reached_start = True
                        break

                url = (body.get("_metadata") or {}).get("backwardLink") or body.get("nextLink")

            result.messages.sort(key=message_time)
            if since is not None:
                result.messages = [
                    m
                    for m in result.messages
                    if (parsed := parse_message_time(message_time(m))) is None or parsed >= since
                ]
            if result.foreign_messages_dropped:
                logger.warning(
                    "[teams_web] dropped {} message(s) not belonging to cid={}",
                    result.foreign_messages_dropped,
                    self._cid,
                )
            return result

    async def _discover_region(
        self,
        client: httpx.AsyncClient,
        candidates: tuple[str, ...],
        *,
        page_size: int,
    ) -> str:
        """Find the ring that serves this user, using 752 as the negative signal."""
        errors: list[str] = []
        for candidate in candidates:
            url = self._messages_url(candidate, page_size=1, start_time_ms=None)
            try:
                response = await client.get(url, headers=self._headers())
            except httpx.HTTPError as exc:
                errors.append(f"{candidate}: {exc}")
                continue
            if response.status_code == 200:
                logger.info("[teams_web] chatsvc region resolved to {}", candidate)
                return candidate
            code = _error_code(response)
            if code == _AUTH_FAILED_ERROR_CODE:
                raise ChatsvcAuthError(
                    "chatsvc rejected the ic3 token (errorCode 911); it is expired or wrong."
                )
            errors.append(f"{candidate}: HTTP {response.status_code} errorCode={code}")
        del page_size  # discovery always probes with pageSize=1
        raise ChatsvcError(
            "Could not determine the chatsvc region for this conversation. Tried: "
            + "; ".join(errors)
        )

    async def _get_json(self, client: httpx.AsyncClient, url: str) -> dict[str, Any]:
        try:
            response = await client.get(url, headers=self._headers())
        except httpx.HTTPError as exc:
            raise ChatsvcError(f"chatsvc request failed: {exc}") from exc
        if response.status_code == 200:
            try:
                body = response.json()
            except ValueError as exc:
                raise ChatsvcError("chatsvc returned a non-JSON body") from exc
            return body if isinstance(body, dict) else {}
        code = _error_code(response)
        if code == _AUTH_FAILED_ERROR_CODE or response.status_code == 401:
            raise ChatsvcAuthError(
                "chatsvc rejected the ic3 token (errorCode 911); it is expired or wrong."
            )
        raise ChatsvcError(
            f"chatsvc HTTP {response.status_code} errorCode={code}: {response.text[:300]}"
        )


def _error_code(response: httpx.Response) -> int | None:
    try:
        body = response.json()
    except ValueError:
        return None
    if not isinstance(body, dict):
        return None
    code = body.get("errorCode")
    if isinstance(code, int):
        return code
    inner = body.get("errorDetails") or body.get("error")
    if isinstance(inner, dict) and isinstance(inner.get("code"), int):
        return int(inner["code"])
    return None


def build_message_digest(conversation_id: str, messages: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarise a pull without dumping every body into the model's context."""
    types = Counter(str(m.get("messagetype") or "unknown") for m in messages)
    senders = Counter(
        str(m.get("imdisplayname") or m.get("fromDisplayNameInToken") or "").strip()
        for m in messages
        if (m.get("imdisplayname") or m.get("fromDisplayNameInToken"))
    )
    times = [t for t in (message_time(m) for m in messages) if t]
    return {
        "conversation_id": conversation_id,
        "message_count": len(messages),
        "message_types": dict(types.most_common()),
        "participants": dict(senders.most_common()),
        "first_message_at": min(times) if times else None,
        "last_message_at": max(times) if times else None,
        "conversation_created_at": extract_conversation_created_at(messages),
        "topic_history": extract_topic_history(messages),
        "call_events": extract_call_events(messages),
    }


def extract_conversation_created_at(messages: list[dict[str, Any]]) -> str | None:
    """Return Teams' meeting-chat creation signal when present.

    ``ThreadActivity/MeetingPolicyUpdated`` is emitted when the meeting chat is
    initialized. Unlike AddMember or TopicUpdate it is not also produced merely
    because somebody later adds the bot or renames an old chat, so it is safe to
    use for deciding whether calendar propagation is still likely in flight.
    """
    times = [
        message_time(message)
        for message in messages
        if str(message.get("messagetype") or "") == "ThreadActivity/MeetingPolicyUpdated"
        and message_time(message)
    ]
    return min(times) if times else None


def extract_topic_history(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Rename history, straight out of ``ThreadActivity/TopicUpdate`` events.

    Ground truth: no model inference needed to bridge an old title to a new one.
    """
    history: list[dict[str, Any]] = []
    for message in messages:
        if str(message.get("messagetype") or "") != "ThreadActivity/TopicUpdate":
            continue
        content = str(message.get("content") or "")
        value = re.search(r"<value>(.*?)</value>", content, re.DOTALL)
        event_time = re.search(r"<eventtime>(\d+)</eventtime>", content)
        initiator = re.search(r"<initiator>(.*?)</initiator>", content, re.DOTALL)
        history.append(
            {
                "topic": value.group(1).strip() if value else None,
                "event_time_ms": int(event_time.group(1)) if event_time else None,
                "at": message_time(message),
                "initiator": initiator.group(1).strip() if initiator else None,
            }
        )
    history.sort(key=lambda item: item.get("event_time_ms") or 0)
    return history


def extract_call_events(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Call boundaries, roster and meeting details from ``Event/Call`` messages.

    These carry the participant list with per-person durations and the
    organizer/iCalUid — the closest thing to attendance ground truth available
    without the calendar event, which for a deleted meeting no longer exists.
    """

    def _tag(pattern: str, text: str) -> str | None:
        found = re.search(pattern, text, re.DOTALL)
        return found.group(1).strip() if found else None

    events: list[dict[str, Any]] = []
    for message in messages:
        if str(message.get("messagetype") or "") != "Event/Call":
            continue
        content = str(message.get("content") or "")
        participants = [
            {
                "id": part.group(1),
                "display_name": (_tag(r"<displayName>(.*?)</displayName>", part.group(2)) or ""),
                "duration_s": int(_tag(r"<duration>(\d+)</duration>", part.group(2)) or 0),
            }
            for part in re.finditer(r'<part identity="([^"]*)">(.*?)</part>', content, re.DOTALL)
        ]
        events.append(
            {
                "at": message_time(message),
                "event": _tag(r"<callEventType>(.*?)</callEventType>", content),
                "call_id": _tag(r"<callId>(.*?)</callId>", content),
                "conversation_start_time": _tag(
                    r"<conversationStartTime>(.*?)</conversationStartTime>", content
                ),
                "organizer_upn": _tag(r"<organizerUpn>(.*?)</organizerUpn>", content),
                "meeting_start_time": _tag(r"<startTime>(.*?)</startTime>", content),
                "meeting_end_time": _tag(r"<endTime>(.*?)</endTime>", content),
                "ical_uid": _tag(r"<iCalUid>(.*?)</iCalUid>", content),
                "participants": participants,
            }
        )
    return events


def summarize_message(message: dict[str, Any], *, body_limit: int = 4000) -> dict[str, Any]:
    """Project one raw message down to the fields worth putting in context."""
    content = str(message.get("content") or "")
    truncated = len(content) > body_limit
    raw_properties = message.get("properties")
    properties: dict[str, Any] = raw_properties if isinstance(raw_properties, dict) else {}
    normalized = normalize_message_for_capture(message)
    return {
        "id": message.get("id"),
        "time": message_time(message),
        "from": message.get("imdisplayname") or message.get("fromDisplayNameInToken"),
        "from_id": message.get("from"),
        "type": message.get("messagetype"),
        "content": content[:body_limit],
        "content_truncated": truncated,
        "content_full_length": len(content),
        "links": _decode_property(properties.get("links")),
        "mentions": _decode_property(properties.get("mentions")),
        "files": _decode_property(properties.get("files")),
        # Keep the compact read API useful for material preparation too.  The
        # verbatim message object remains in the conversation cache (and in a
        # KB capture); these are projections, never replacements for it.
        "is_quote": normalized["is_quote"],
        "quoted_original": normalized["quoted_original"],
        "images": normalized["images"],
        "file_attachments": normalized["file_attachments"],
        "reactions": normalized["reactions"],
        "unsupported_media": normalized["unsupported_media"],
    }


def _decode_property(value: Any) -> Any:
    """chatsvc nests JSON inside ``properties`` as strings; decode when possible."""
    if isinstance(value, (dict, list)):
        return value
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        decoded = json.loads(value)
    except json.JSONDecodeError:
        return value
    return decoded or None


# Teams Web has used several representations for a quote over time.  The
# inline Reply schema is the common one, but desktop/web clients also put a
# structured payload in a message property.  This normalizer deliberately
# accepts both, while leaving the raw chatsvc payload untouched in the cache.
_QUOTE_HTML_RE = re.compile(
    r"<blockquote\b(?P<attrs>[^>]*)>(?P<body>.*?)</blockquote\s*>",
    re.IGNORECASE | re.DOTALL,
)
_HTML_IMAGE_RE = re.compile(r"<img\b(?P<attrs>[^>]*)>", re.IGNORECASE)
_HTML_LINK_RE = re.compile(r"<a\b(?P<attrs>[^>]*)>", re.IGNORECASE)
_HTML_ATTR_RE = re.compile(r"""(?P<key>[\w:-]+)\s*=\s*["'](?P<value>.*?)["']""")
_URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)
_IMAGE_EXTENSIONS = frozenset({"jpg", "jpeg", "png", "gif", "webp", "bmp", "tif", "tiff"})
_TEXT_FILE_EXTENSIONS = frozenset(
    {"txt", "log", "md", "csv", "json", "jsonl", "xml", "yaml", "yml", "html"}
)
_DOCUMENT_FILE_EXTENSIONS = frozenset({"docx", "pdf", "pptx", "xlsx"})
_AUDIO_VIDEO_EXTENSIONS = frozenset(
    {"mp3", "wav", "m4a", "aac", "ogg", "flac", "mp4", "mov", "avi", "mkv", "webm"}
)


def normalize_message_for_capture(message: dict[str, Any]) -> dict[str, Any]:
    """Return material metadata for one message without mutating its raw data.

    The result is intentionally URL/pointer based.  Teams' message response is
    the provenance record; fetching a binary later must use the item URL that
    message supplied and never search a drive or another conversation.
    """
    properties = _decoded_properties(message.get("properties"))
    content = str(message.get("content") or "")
    quote_raw, quote_content, quoted_id = _quoted_source(content, properties)
    # A reply's quoted preview must not make its image/file appear to have
    # been attached by the replying user. It is material of the quote only.
    image_refs, file_refs, unsupported_media = _material_refs(
        _content_without_quote(content), properties
    )

    quoted_original: dict[str, Any] | None = None
    if quote_raw is not None or quote_content:
        quote_props = quote_raw if isinstance(quote_raw, dict) else {}
        quote_images, quote_files, quote_media = _material_refs(quote_content, quote_props)
        quoted_original = {
            "content": quote_content,
            # Preserve a structured reply payload exactly when Teams supplied
            # one. For inline HTML the original source is the raw Reply block.
            "raw": quote_raw if quote_raw is not None else quote_content,
            "referenced_message_id": quoted_id or None,
            "images": quote_images,
            "file_attachments": quote_files,
            "unsupported_media": quote_media,
        }

    reactions = _first_present(
        message.get("reactions"),
        properties.get("reactions"),
        properties.get("reaction"),
        properties.get("emotions"),
    )
    return {
        "message_id": message.get("id"),
        "is_quote": quoted_original is not None,
        "quoted_original": quoted_original,
        "images": image_refs,
        "file_attachments": file_refs,
        "reactions": reactions if reactions is not None else [],
        "unsupported_media": unsupported_media,
    }


def _decoded_properties(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    return {str(key): _decode_property(item) for key, item in value.items()}


def _first_present(*values: Any) -> Any:
    return next((value for value in values if value not in (None, "", [], {})), None)


def _quoted_source(content: str, properties: dict[str, Any]) -> tuple[Any | None, str, str]:
    mentions = properties.get("mentions")
    quote_mention: dict[str, Any] | None = None
    if isinstance(mentions, list):
        for mention in mentions:
            if (
                not isinstance(mention, dict)
                or str(
                    _first_present(mention.get("type"), mention.get("mentionType")) or ""
                ).lower()
                != "quote"
            ):
                continue
            quote_mention = mention
            break
    inline_content = ""
    inline_id = ""
    for match in _QUOTE_HTML_RE.finditer(content):
        attrs = match.group("attrs").lower()
        if (
            "schema.skype.com/reply" in attrs
            or "data-quote" in attrs
            or "data-reply" in attrs
            or "quote" in attrs
        ):
            attrs_dict = _html_attrs(match.group("attrs"))
            inline_content, inline_id = match.group(0), _quote_id(attrs_dict)
            break
    if quote_mention is not None:
        body = _first_present(
            quote_mention.get("content"), quote_mention.get("body"), quote_mention.get("text")
        )
        # Mentions often carry only the quoted message identity; the Skype
        # Reply block holds its visible preview and image/file references.
        return quote_mention, str(body or inline_content), _quote_id(quote_mention) or inline_id
    qtd_msgs = properties.get("qtdMsgs")
    if isinstance(qtd_msgs, list):
        for quoted in qtd_msgs:
            if isinstance(quoted, dict):
                body = _first_present(quoted.get("content"), quoted.get("body"), quoted.get("text"))
                return quoted, str(body or inline_content), _quote_id(quoted) or inline_id
    for key, value in properties.items():
        if key.lower().replace("_", "") in {
            "quotedmessage",
            "quotedmessagepayload",
            "replymessage",
            "replyto",
            "replycontext",
        }:
            if isinstance(value, dict):
                body = _first_present(value.get("content"), value.get("body"), value.get("text"))
                return value, str(body or ""), _quote_id(value)
            if isinstance(value, str) and value.strip():
                return value, value, ""
    if inline_content:
        return None, inline_content, inline_id
    return None, "", ""


def _quote_id(value: dict[str, Any]) -> str:
    for key in ("id", "messageId", "message_id", "itemid", "itemId", "targetId"):
        item = value.get(key)
        if item is not None and str(item).strip():
            return str(item).strip()
    return ""


def _content_without_quote(content: str) -> str:
    return _QUOTE_HTML_RE.sub(
        lambda match: (
            ""
            if (
                "schema.skype.com/reply" in match.group("attrs").lower()
                or "data-quote" in match.group("attrs").lower()
                or "data-reply" in match.group("attrs").lower()
                or "quote" in match.group("attrs").lower()
            )
            else match.group(0)
        ),
        content,
    )


def _material_refs(
    content: str, properties: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Classify message-local attachments and links with their raw source.

    A file link is only considered a OneDrive/SharePoint attachment when it is
    explicitly present in the message; we do not enumerate or resolve drives.
    Audio/video pointers remain visible as raw metadata but are marked as not
    fetched, which prevents accidental media collection.
    """
    candidates: list[tuple[dict[str, Any], str]] = []
    for key in ("files", "attachments", "file", "links", "link"):
        _append_candidates(candidates, properties.get(key), source=f"properties.{key}")
    _append_html_candidates(candidates, content)

    images: list[dict[str, Any]] = []
    files: list[dict[str, Any]] = []
    media: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for raw, source in candidates:
        url = _candidate_url(raw)
        name = str(
            _first_present(
                raw.get("name"), raw.get("filename"), raw.get("fileName"), raw.get("title")
            )
            or ""
        )
        content_type = str(
            _first_present(
                raw.get("contentType"),
                raw.get("content_type"),
                raw.get("mimeType"),
                raw.get("fileType"),
            )
            or ""
        )
        extension = _file_extension(name or url, content_type)
        identity = (url, name)
        if not (url or name) or identity in seen:
            continue
        seen.add(identity)
        base = {
            "name": name or None,
            "url": url or None,
            "content_type": content_type or None,
            "extension": extension or None,
            "source": source,
            "raw": raw,
        }
        if _is_audio_or_video(extension, content_type):
            media.append({**base, "fetch_status": "unsupported_audio_video"})
        elif source == "html.image" or _is_image(extension, content_type):
            images.append(base)
        elif _is_supported_file(extension, content_type) or _is_onedrive_url(url):
            files.append(
                {
                    **base,
                    "source_kind": "onedrive_link"
                    if _is_onedrive_url(url)
                    else "uploaded_attachment",
                    "supported": _is_supported_file(extension, content_type),
                }
            )
    return images, files, media


def _append_candidates(
    target: list[tuple[dict[str, Any], str]], value: Any, *, source: str
) -> None:
    if isinstance(value, list):
        for item in value:
            _append_candidates(target, item, source=source)
    elif isinstance(value, dict):
        target.append((value, source))
    elif isinstance(value, str):
        for url in _URL_RE.findall(unescape(value)):
            target.append(({"url": url}, source))


def _append_html_candidates(target: list[tuple[dict[str, Any], str]], content: str) -> None:
    for match in _HTML_IMAGE_RE.finditer(content):
        attrs = _html_attrs(match.group("attrs"))
        if attrs.get("src"):
            target.append(({"url": attrs["src"], "name": attrs.get("alt", "")}, "html.image"))
    for match in _HTML_LINK_RE.finditer(content):
        attrs = _html_attrs(match.group("attrs"))
        if attrs.get("href"):
            target.append(({"url": attrs["href"]}, "html.link"))


def _html_attrs(text: str) -> dict[str, str]:
    return {
        m.group("key").lower(): unescape(m.group("value")) for m in _HTML_ATTR_RE.finditer(text)
    }


def _candidate_url(raw: dict[str, Any]) -> str:
    file_info = raw.get("fileInfo")
    if not isinstance(file_info, dict):
        file_info = {}
    value = _first_present(
        raw.get("downloadUrl"),
        raw.get("contentUrl"),
        raw.get("webUrl"),
        raw.get("shareUrl"),
        file_info.get("fileUrl"),
        file_info.get("shareUrl"),
        raw.get("objectUrl"),
        raw.get("url"),
        raw.get("href"),
    )
    return str(value).strip() if isinstance(value, str) else ""


def _file_extension(value: str, content_type: str) -> str:
    clean = value.split("?", 1)[0].rsplit("/", 1)[-1]
    if "." in clean:
        return clean.rsplit(".", 1)[-1].lower()
    mime = content_type.split(";", 1)[0].lower()
    if mime == "text/plain":
        return "txt"
    if mime.endswith("wordprocessingml.document"):
        return "docx"
    return ""


def _is_image(extension: str, content_type: str) -> bool:
    return extension in _IMAGE_EXTENSIONS or content_type.lower().startswith("image/")


def _is_audio_or_video(extension: str, content_type: str) -> bool:
    return extension in _AUDIO_VIDEO_EXTENSIONS or content_type.lower().startswith(
        ("audio/", "video/")
    )


def _is_supported_file(extension: str, content_type: str) -> bool:
    return (
        extension in _TEXT_FILE_EXTENSIONS | _DOCUMENT_FILE_EXTENSIONS
        or content_type.lower().startswith("text/")
    )


def _is_onedrive_url(url: str) -> bool:
    host = (urlparse(url).hostname or "").lower()
    return (
        host.endswith((".sharepoint.com", ".sharepoint-df.com", ".onedrive.com"))
        or host == "1drv.ms"
    )
