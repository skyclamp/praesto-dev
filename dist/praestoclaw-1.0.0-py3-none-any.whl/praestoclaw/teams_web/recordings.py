"""Transcript discovery and download, anchored on the chat's own messages.

The breakthrough this module encodes: a meeting chat *embeds* its transcript
pointer. ``RichText/Media_CallRecording`` carries ``callId``, ``iCalUid``,
``transcriptId``, ``driveId``, ``driveItemId`` and both download URLs verbatim.
So no calendar event, no organizer privilege, no Graph admin consent and no
tenant-wide search is needed — and, critically, nothing outside this one
conversation is ever touched.

Two renditions of the same meeting exist and they are not equivalent:

``amsTranscript``
    ``https://<ring>.asyncgw.teams.microsoft.com/v1/objects/<id>/views/transcript``
    Returns VTT with ``<v Speaker>`` tags — speaker attribution is ground
    truth. Authenticates with the same ic3 bearer as chatsvc. May be less
    durable (``canVideoExpire="True"`` appears on exported chunks).

``onedriveForBusinessTranscript``
    An item-scoped SharePoint URL. No speaker tags, finer cue granularity.
    Bearer tokens are routinely absent for that origin, so it needs a
    same-origin cookie fetch: navigate to the message's ``Play`` link to
    establish SSO on that host, then fetch the item URL with
    ``credentials: 'include'``. The landing page itself may render
    *Access Denied* — permission was granted on the single item, not the
    organizer's drive — while the item call still returns 200.

Capturing both is deliberate: they cross-check each other, and the durability
of the AMS copy is not guaranteed.
"""

from __future__ import annotations

import asyncio
import contextlib
import re
from dataclasses import dataclass, field
from html import unescape
from pathlib import Path
from typing import Any

import httpx
from loguru import logger

RENDITION_AMS = "ams"
RENDITION_ODSP = "odsp"
ALL_RENDITIONS: tuple[str, ...] = (RENDITION_AMS, RENDITION_ODSP)

_ODSP_NAV_SETTLE_MS = 8000


class TranscriptFetchError(Exception):
    """A transcript rendition could not be downloaded."""


@dataclass(slots=True)
class RecordingPointer:
    """Everything the chat itself tells us about one recorded call."""

    message_id: str = ""
    arrival_time: str = ""
    title: str = ""
    original_name: str = ""
    call_id: str = ""
    call_leg_id: str = ""
    ical_uid: str = ""
    ams_document_id: str = ""
    transcript_id: str = ""
    drive_id: str = ""
    drive_item_id: str = ""
    ams_transcript_url: str = ""
    odsp_transcript_url: str = ""
    play_url: str = ""
    timestamp: str = ""
    duration: str = ""
    content_types: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "message_id": self.message_id,
            "arrival_time": self.arrival_time,
            "title": self.title,
            "original_name": self.original_name,
            "call_id": self.call_id,
            "call_leg_id": self.call_leg_id,
            "ical_uid": self.ical_uid,
            "ams_document_id": self.ams_document_id,
            "transcript_id": self.transcript_id,
            "drive_id": self.drive_id,
            "drive_item_id": self.drive_item_id,
            "ams_transcript_url": self.ams_transcript_url,
            "odsp_transcript_url": self.odsp_transcript_url,
            "play_url": self.play_url,
            "timestamp": self.timestamp,
            "duration": self.duration,
            "content_types": self.content_types,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> RecordingPointer:
        known = {f for f in cls.__slots__}  # type: ignore[attr-defined]
        return cls(**{k: str(v or "") for k, v in data.items() if k in known})


@dataclass(slots=True)
class TranscriptCue:
    time: str
    speaker: str | None
    text: str


@dataclass(slots=True)
class TranscriptDownload:
    rendition: str
    vtt: str
    cues: list[TranscriptCue] = field(default_factory=list)
    content_type: str = ""

    @property
    def speaker_cue_count(self) -> int:
        return sum(1 for cue in self.cues if cue.speaker)


_SIMPLE_FIELDS: tuple[tuple[str, str], ...] = (
    ("title", r"<Title>([^<]*)</Title>"),
    ("original_name", r'<OriginalName v="([^"]*)"'),
    ("ical_uid", r'<ICalUid value="([^"]*)"'),
    ("play_url", r'<a href="([^"]*)">Play</a>'),
    ("timestamp", r'<RecordingContent[^>]*timestamp="([^"]*)"'),
    ("duration", r'<RecordingContent[^>]*duration="([^"]*)"'),
    ("content_types", r'<RecordingContent[^>]*contentTypes="([^"]*)"'),
    ("ams_transcript_url", r'<item type="amsTranscript" uri="([^"]*)"'),
)

_ID_FIELDS: tuple[tuple[str, str], ...] = (
    ("call_id", "callId"),
    ("call_leg_id", "callLegId"),
    ("ams_document_id", "AMSDocumentID"),
)


def parse_recording_pointer(content: str) -> RecordingPointer | None:
    """Parse one ``RichText/Media_CallRecording`` body into a pointer."""
    text = unescape(content or "")
    if "URIObject" not in text:
        return None
    pointer = RecordingPointer()
    for attr, pattern in _SIMPLE_FIELDS:
        found = re.search(pattern, text)
        if found and found.group(1):
            setattr(pointer, attr, found.group(1).strip())
    for attr, id_type in _ID_FIELDS:
        found = re.search(rf'<Id type="{id_type}" value="([^"]*)"', text)
        if found and found.group(1):
            setattr(pointer, attr, found.group(1).strip())

    odsp = re.search(r'<item type="onedriveForBusinessTranscript"([^>]*)/>', text)
    if odsp:
        attrs = odsp.group(1)
        for attr, key in (
            ("odsp_transcript_url", "uri"),
            ("transcript_id", "id"),
            ("drive_id", "driveId"),
            ("drive_item_id", "driveItemId"),
        ):
            found = re.search(rf'{key}="([^"]*)"', attrs)
            if found and found.group(1):
                setattr(pointer, attr, found.group(1).strip())

    if not (pointer.ams_transcript_url or pointer.odsp_transcript_url):
        return None
    return pointer


def parse_recording_pointers(messages: list[dict[str, Any]]) -> list[RecordingPointer]:
    """Extract every transcript pointer embedded in a conversation's messages."""
    pointers: list[RecordingPointer] = []
    for message in messages:
        if str(message.get("messagetype") or "") != "RichText/Media_CallRecording":
            continue
        pointer = parse_recording_pointer(str(message.get("content") or ""))
        if pointer is None:
            continue
        pointer.message_id = str(message.get("id") or "")
        pointer.arrival_time = str(
            message.get("originalarrivaltime") or message.get("composetime") or ""
        )
        pointers.append(pointer)
    return pointers


_CUE_ID = re.compile(r"^[a-f0-9-]+/\d+-\d+$", re.IGNORECASE)
_SPEAKER = re.compile(r"<v ([^>]+)>")
_TAG = re.compile(r"<[^>]+>")


def parse_vtt(vtt: str) -> list[TranscriptCue]:
    """Flatten WebVTT into dialogue lines, keeping ``<v Speaker>`` attribution."""
    lines = [line.strip() for line in (vtt or "").splitlines() if line.strip()]
    cues: list[TranscriptCue] = []
    index = 0
    while index < len(lines):
        if "-->" not in lines[index]:
            index += 1
            continue
        start = lines[index].split("-->", 1)[0].strip().split(".", 1)[0]
        index += 1
        buffer: list[str] = []
        while index < len(lines) and "-->" not in lines[index] and not _CUE_ID.match(lines[index]):
            buffer.append(lines[index])
            index += 1
        raw = " ".join(buffer)
        speaker = _SPEAKER.search(raw)
        text = unescape(_TAG.sub("", raw)).strip()
        if text:
            cues.append(
                TranscriptCue(
                    time=start, speaker=speaker.group(1).strip() if speaker else None, text=text
                )
            )
    return cues


def cues_to_text(cues: list[TranscriptCue]) -> str:
    """Render cues as ``[time] Speaker: text`` lines."""
    out = []
    for cue in cues:
        who = f"{cue.speaker}: " if cue.speaker else ""
        out.append(f"[{cue.time}] {who}{cue.text}")
    return "\n".join(out) + ("\n" if out else "")


async def fetch_ams_transcript(
    pointer: RecordingPointer, *, access_token: str, timeout: float = 60.0
) -> TranscriptDownload:
    """Download the speaker-tagged AMS rendition with the ic3 bearer."""
    if not pointer.ams_transcript_url:
        raise TranscriptFetchError("this recording has no amsTranscript URL")
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "text/vtt, text/plain, */*",
    }
    async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
        try:
            response = await client.get(pointer.ams_transcript_url, headers=headers)
        except httpx.HTTPError as exc:
            raise TranscriptFetchError(f"AMS request failed: {exc}") from exc
    if response.status_code != 200:
        raise TranscriptFetchError(
            f"AMS returned HTTP {response.status_code}: {response.text[:200]}"
        )
    vtt = response.text
    return TranscriptDownload(
        rendition=RENDITION_AMS,
        vtt=vtt,
        cues=parse_vtt(vtt),
        content_type=response.headers.get("content-type", ""),
    )


async def fetch_odsp_transcript(
    pointer: RecordingPointer,
    *,
    profile_dir: Path,
    headless: bool = True,
    timeout_ms: int = 90_000,
) -> TranscriptDownload:
    """Download the OneDrive rendition through same-origin SSO cookies.

    Bearer tokens for the SharePoint origin are provisioned lazily by Teams and
    are usually simply absent, so every one of them 401s. Landing on the file's
    own origin first and then issuing a credentialed same-origin fetch is what
    actually works.
    """
    if not pointer.odsp_transcript_url:
        raise TranscriptFetchError("this recording has no onedriveForBusinessTranscript URL")

    from praestoclaw.auth.m365.playwright_session import (
        _find_edge_binary,
        _kill_async,
        _pick_free_port,
        _start_edge,
        _wait_for_cdp_ready,
    )

    try:
        from playwright.async_api import async_playwright
    except ImportError as exc:  # pragma: no cover - dependency is declared
        raise TranscriptFetchError("playwright is not installed") from exc

    edge_binary = _find_edge_binary()
    if edge_binary is None:
        raise TranscriptFetchError("Microsoft Edge was not found")

    profile_dir.mkdir(parents=True, exist_ok=True)
    port = _pick_free_port(9225)
    landing = pointer.play_url or pointer.odsp_transcript_url
    argv = [
        edge_binary,
        f"--remote-debugging-port={port}",
        f"--user-data-dir={profile_dir}",
        "--no-first-run",
        "--no-default-browser-check",
    ]
    if headless:
        argv.append("--headless=new")
    argv.append(landing)

    proc = await _start_edge(argv)
    try:
        if not await asyncio.to_thread(_wait_for_cdp_ready, port, 20):
            raise TranscriptFetchError("Edge CDP endpoint did not come up")
        async with async_playwright() as pw:
            browser = await pw.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=30_000)
            try:
                ctx = browser.contexts[0] if browser.contexts else None
                if ctx is None:
                    raise TranscriptFetchError("no browser context after attach")
                page = ctx.pages[0] if ctx.pages else await ctx.new_page()
                with contextlib.suppress(Exception):
                    await page.goto(landing, wait_until="domcontentloaded", timeout=timeout_ms)
                await page.wait_for_timeout(_ODSP_NAV_SETTLE_MS)
                result = await page.evaluate(
                    """async (url) => {
                      const r = await fetch(url, {credentials: 'include',
                        headers: {Accept: 'text/vtt, text/plain, */*'}});
                      const body = await r.text();
                      return {status: r.status, ok: r.ok,
                              contentType: r.headers.get('content-type') || '', body};
                    }""",
                    pointer.odsp_transcript_url,
                )
            finally:
                with contextlib.suppress(Exception):
                    cdp = await browser.new_browser_cdp_session()
                    await cdp.send("Browser.close")
                with contextlib.suppress(Exception):
                    await browser.close()
    finally:
        await _kill_async(proc)

    if not result or not result.get("ok"):
        status = (result or {}).get("status")
        raise TranscriptFetchError(f"OneDrive rendition returned HTTP {status}")
    vtt = str(result.get("body") or "")
    logger.debug("[teams_web] odsp transcript bytes={}", len(vtt))
    return TranscriptDownload(
        rendition=RENDITION_ODSP,
        vtt=vtt,
        cues=parse_vtt(vtt),
        content_type=str(result.get("contentType") or ""),
    )
