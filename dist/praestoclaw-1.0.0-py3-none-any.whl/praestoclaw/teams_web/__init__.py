"""Deterministic Teams capture over the Teams Web session.

EXPERIMENTAL / THROWAWAY — part of the ``praesto_tag_exp`` experiment.

Replaces the Teams MCP (Graph-backed, model-mediated, tenant-wide) retrieval
path with the chain validated in ``D:\\tmp\\pc-kb-dev``::

    cid (metadata["cid"])
      └─ chatsvc /messages                     raw messages + system events
           ├─ ThreadActivity/TopicUpdate       rename history
           ├─ RichText/Media_CallRecording     callId / iCalUid / transcriptId /
           │                                   driveId / driveItemId / URLs
           │    ├─ amsTranscript               VTT *with* <v Speaker> tags
           │    └─ onedriveForBusinessTranscript  VTT without speaker tags
           └─ Event/Call                       call boundaries

Why it matters: Graph filters out the system events, and those events are
exactly where the transcript pointer and the rename history live. The MCP
search path additionally has no ``chatId`` filter at all, so it cannot be
constrained to one conversation — which is the whole point here.

Everything is scoped to a single conversation id. There is no tenant-wide
surface in this package by construction.
"""

from praestoclaw.teams_web.chatsvc import (
    ChatsvcError,
    TeamsChatsvcClient,
    build_message_digest,
)
from praestoclaw.teams_web.recordings import (
    RecordingPointer,
    parse_recording_pointers,
    parse_vtt,
)
from praestoclaw.teams_web.store import TeamsWebChatStore, cid_slug
from praestoclaw.teams_web.tokens import (
    IC3_AUDIENCE,
    TeamsWebTokenError,
    TeamsWebTokenProvider,
)

__all__ = [
    "IC3_AUDIENCE",
    "ChatsvcError",
    "RecordingPointer",
    "TeamsChatsvcClient",
    "TeamsWebChatStore",
    "TeamsWebTokenError",
    "TeamsWebTokenProvider",
    "build_message_digest",
    "cid_slug",
    "parse_recording_pointers",
    "parse_vtt",
]
