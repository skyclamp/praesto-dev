"""Chronicle CLI — run collection / reporting from the command line.

Examples:
    python -m praestoclaw.chronicle daily               # collect + daily report
    python -m praestoclaw.chronicle daily --today       # today 00:00 → now
    python -m praestoclaw.chronicle collect --hours 24  # archive only
    python -m praestoclaw.chronicle search "kafka"      # search the archive
    python -m praestoclaw.chronicle stats               # archive size
"""

from __future__ import annotations

import argparse
import asyncio
from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

from praestoclaw.chronicle.config import (
    ChronicleConfig,
    db_path,
    identity_cache_path,
    load_config,
)
from praestoclaw.chronicle.identity import resolve_identity
from praestoclaw.chronicle.mcp_caller import StdioMcpCaller
from praestoclaw.chronicle.pipeline import (
    run_collect,
    run_daily,
)
from praestoclaw.chronicle.store import ChronicleStore
from praestoclaw.chronicle.workday import manual_report_window


def _provider_and_model(cfg: ChronicleConfig):
    from praestoclaw.config.loader import load_config as load_app_config
    from praestoclaw.providers.resolver import get_provider

    app = load_app_config()
    provider = get_provider(app.providers)
    model = cfg.model if cfg.model and cfg.model != "auto" else app.agents.default.model
    return provider, model


async def _amain(args: argparse.Namespace) -> int:
    cfg = load_config()
    # Allow the CLI to run even when chronicle.yaml hasn't enabled it yet.
    cfg.model = args.model or cfg.model
    store = ChronicleStore(db_path())
    caller = StdioMcpCaller()
    try:
        identity = await resolve_identity(caller, identity_cache_path())
        print(f"[identity] {identity.display_name} <{identity.mail}> id={identity.aad_id[:8]}")

        now = datetime.now(UTC)
        since = now - timedelta(hours=args.hours)

        if args.command == "collect":
            print(f"[collect] window = {since.isoformat()} to {now.isoformat()}")
            stats = await run_collect(caller, store, identity, cfg, until=now, since_override=since)
            for src, s in stats["sources"].items():
                print(f"  {src:9}: {s}")
            print(f"[archive] total items now = {store.count_items()}")

        if args.command == "search":
            rows = store.search(args.query, limit=15)
            for r in rows:
                print(
                    f"- [{r['created_at']}] {r['source']}/{r['kind']}: "
                    f"{(r['body_text'] or '')[:120]}  {r['link'] or ''}"
                )

        if args.command == "stats":
            print(f"[archive] db={db_path()} items={store.count_items()}")

        if args.command == "daily":
            provider, model = _provider_and_model(cfg)
            cfg.model = model
            window = None
            if args.today or args.since or args.until:
                from datetime import date

                tz = ZoneInfo(cfg.timezone)
                if args.today:
                    sd = ed = now.astimezone(tz).date()
                else:
                    sd = date.fromisoformat(args.since or args.until)
                    ed = date.fromisoformat(args.until or args.since)
                window = manual_report_window(now, cfg, sd, ed)
                if window is None:
                    print("[daily] invalid window (start must be ≤ end and not in the future).")
                    return 1
                print(
                    f"[daily] manual window = {window.label} "
                    f"({window.since.isoformat()} → {window.until.isoformat()})"
                )
            print(f"[daily] model={model} now={now.isoformat()}")
            markdown = await run_daily(
                caller,
                store,
                identity,
                cfg,
                provider,
                now=now,
                force=args.force,
                window=window,
            )
            if markdown:
                print("\n" + "=" * 70 + "\n" + markdown + "\n" + "=" * 70)
            else:
                print(
                    "[daily] collected; nothing to deliver (paused / non-workday / "
                    "already delivered / nothing new)."
                )

        if args.command == "pref":
            from praestoclaw.chronicle.tools import ChronicleSettingsTool

            tool = ChronicleSettingsTool()
            if args.remove is not None:
                print(await tool.execute(action="remove", target=args.remove))
            elif args.pref_set:
                fields = dict(p.split("=", 1) for p in args.pref_set if "=" in p)
                print(await tool.execute(action="add", **fields))
            else:
                print(await tool.execute(action="show"))
        return 0
    finally:
        await caller.aclose()
        store.close()


def main() -> int:
    import sys

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
        except (AttributeError, ValueError):
            pass
    parser = argparse.ArgumentParser(prog="chronicle", description="Chronicle archive CLI")
    parser.add_argument(
        "command",
        choices=["collect", "search", "stats", "daily", "pref"],
    )
    parser.add_argument("query", nargs="?", default="", help="search query (for `search`)")
    parser.add_argument("--hours", type=int, default=24, help="collection window in hours")
    parser.add_argument("--model", default="", help="override summarization model")
    parser.add_argument("--force", action="store_true", help="regenerate report even if cached")
    parser.add_argument(
        "--today",
        action="store_true",
        help="(daily) summarize today 00:00 → now instead of the previous-workday window",
    )
    parser.add_argument(
        "--since",
        default="",
        help="(daily) manual window start, local date YYYY-MM-DD (inclusive)",
    )
    parser.add_argument(
        "--until",
        default="",
        help="(daily) manual window end, local date YYYY-MM-DD (inclusive); defaults to --since",
    )
    parser.add_argument(
        "--set",
        dest="pref_set",
        action="append",
        default=[],
        help="pref field as key=value (repeatable), e.g. --set scope=chat --set directive=exclude --set target=XX",
    )
    parser.add_argument(
        "--remove",
        type=str,
        default=None,
        help="remove preferences matching this target/chat name (substring match)",
    )
    args = parser.parse_args()
    return asyncio.run(_amain(args))


if __name__ == "__main__":
    raise SystemExit(main())
