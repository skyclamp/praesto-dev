"""Resolve and cache the signed-in user's identity for Chronicle.

Used to mark which collected items are authored by "me" (for the
"what I did yesterday" report section) and to resolve @mentions to the user.
Identity is fetched once via the ``m365-user`` MCP tool ``GetMyDetails`` and
cached on disk so subsequent runs are offline-friendly.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.chronicle.mcp_caller import McpCaller
from praestoclaw.chronicle.textutil import extract_json


@dataclass
class Identity:
    """The signed-in user's identity."""

    aad_id: str = ""
    mail: str = ""
    upn: str = ""
    display_name: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def resolved(self) -> bool:
        return bool(self.aad_id or self.mail)

    def is_me(self, *, author_id: str | None = None, email: str | None = None) -> bool:
        if author_id and self.aad_id and author_id.lower() == self.aad_id.lower():
            return True
        if email and self.mail and email.lower() == self.mail.lower():
            return True
        return False

    def to_dict(self) -> dict[str, Any]:
        return {
            "aad_id": self.aad_id,
            "mail": self.mail,
            "upn": self.upn,
            "display_name": self.display_name,
        }


async def resolve_identity(caller: McpCaller, cache_path: Path) -> Identity:
    """Return the user's identity, using the on-disk cache when available."""
    if cache_path.is_file():
        try:
            data = json.loads(cache_path.read_text(encoding="utf-8"))
            ident = Identity(
                aad_id=data.get("aad_id", ""),
                mail=data.get("mail", ""),
                upn=data.get("upn", ""),
                display_name=data.get("display_name", ""),
            )
            if ident.resolved:
                return ident
        except (json.JSONDecodeError, OSError):
            logger.warning("chronicle: identity cache unreadable, refetching")

    raw = await caller.call_tool("m365-user", "GetMyDetails", {}, timeout=60.0)
    payload = extract_json(raw) or {}
    ident = Identity(
        aad_id=str(payload.get("id", "")),
        mail=str(payload.get("mail", "") or payload.get("userPrincipalName", "")),
        upn=str(payload.get("userPrincipalName", "")),
        display_name=str(payload.get("displayName", "")),
        extra=payload,
    )
    if ident.resolved:
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(
                json.dumps(ident.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
            )
        except OSError:
            logger.warning("chronicle: could not persist identity cache")
    else:
        logger.warning("chronicle: failed to resolve identity from GetMyDetails")
    return ident
