"""Workday / holiday calendar and natural-day report-window computation.

Data is collected every day, but the daily report is only delivered on
*workdays*. The report covers from the previous reported workday up to the run
time, and the first workday after a weekend/holiday gap summarizes everything
since the last reported workday (the last workday before the gap plus any data
produced during it).

Workday rules (highest priority first):
1. an explicit ``extra_workdays`` date (China-style 调休 makeup day) → workday
2. an explicit ``holidays`` date → not a workday
3. if ``holiday_region`` is set, a public holiday in that region (resolved via
   the bundled ``holidays`` package) → not a workday
4. otherwise: a workday iff ``weekday()`` is in ``cfg.workdays``

Note: the ``holidays`` package only exposes public *holidays* (rest days), not
regional makeup workdays (a 调休 weekend that becomes a workday). Such a day
stays a non-workday here, but its content is still folded into the next
workday's report (the window covers every calendar day in range). Use
``extra_workdays`` to force a report to run on a specific makeup day.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.chronicle.config import ChronicleConfig

_MAX_GAP_DAYS = 30  # safety bound when walking back to the previous workday

# Cache of public-holiday date sets keyed by (region, year). previous_workday()
# can call is_workday() up to _MAX_GAP_DAYS times per run, each of which would
# otherwise re-import the holidays lib and rebuild the calendar for the same
# (region, year); caching keeps is_workday() effectively O(1) per date.
_HOLIDAY_CACHE: dict[tuple[str, int], set[str]] = {}


def _tz(cfg: ChronicleConfig) -> ZoneInfo:
    try:
        return ZoneInfo(cfg.timezone)
    except Exception:  # noqa: BLE001 - bad tz string falls back to UTC
        logger.warning("chronicle.workday: bad timezone {!r}, using UTC", cfg.timezone)
        return ZoneInfo("UTC")


def _region_holidays(cfg: ChronicleConfig, year: int) -> set[str]:
    """Public holidays for the configured region via the ``holidays`` lib."""
    if not cfg.holiday_region:
        return set()
    region = cfg.holiday_region.strip().upper()
    if not region:
        return set()
    cache_key = (region, year)
    cached = _HOLIDAY_CACHE.get(cache_key)
    if cached is not None:
        return cached
    try:
        import holidays as _holidays  # type: ignore[import-not-found]
    except Exception:  # noqa: BLE001 - degrade gracefully if the lib is unavailable
        _HOLIDAY_CACHE[cache_key] = set()  # cache the miss: don't re-import per call
        return _HOLIDAY_CACHE[cache_key]
    try:
        cal = _holidays.country_holidays(region, years=[year])
        result = {d.isoformat() for d in cal}
    except Exception as exc:  # noqa: BLE001 - bad region code etc.
        logger.warning("chronicle.workday: holidays lib failed for {}: {}", region, exc)
        _HOLIDAY_CACHE[cache_key] = set()  # cache the miss: don't rebuild/re-log per call
        return _HOLIDAY_CACHE[cache_key]
    _HOLIDAY_CACHE[cache_key] = result
    return result


def is_workday(d: date, cfg: ChronicleConfig) -> bool:
    iso = d.isoformat()
    # These config fields are small lists; test membership directly rather than
    # rebuilding a set on every call (previous_workday calls this many times).
    if iso in cfg.extra_workdays:
        return True
    if iso in cfg.holidays:
        return False
    if iso in _region_holidays(cfg, d.year):
        return False
    return d.weekday() in cfg.workdays


def previous_workday(d: date, cfg: ChronicleConfig) -> date:
    """The most recent workday strictly before ``d``."""
    cur = d - timedelta(days=1)
    for _ in range(_MAX_GAP_DAYS):
        if is_workday(cur, cfg):
            return cur
        cur -= timedelta(days=1)
    return d - timedelta(days=1)  # give up after the bound; treat yesterday as workday


@dataclass
class ReportWindow:
    since: datetime  # UTC, inclusive
    until: datetime  # UTC, exclusive (run time = now)
    covered_dates: list[str]  # local YYYY-MM-DD dates the report covers
    label: str  # human label for the section 一 heading
    delivery_date: str  # today's local date (the report's target_date)


def _local_midnight_utc(d: date, tz: ZoneInfo) -> datetime:
    return datetime.combine(d, time.min, tzinfo=tz).astimezone(UTC)


def compute_report_window(
    now: datetime,
    cfg: ChronicleConfig,
) -> ReportWindow | None:
    """Return the natural-day window the report should cover, or None if empty.

    The window starts at the previous workday's local midnight and ends at the
    run time (``now``) — i.e. ``[previous workday 00:00, now)`` in the local
    timezone. The start spans the previous workday plus any intervening
    non-workdays (a weekend/holiday); the end is the moment the report runs, so
    work already done earlier today is folded in. A missed run is deliberately
    NOT caught up: the next report still covers only its own previous workday
    (the skipped span stays in the searchable archive but isn't re-summarized).
    Returns None only in the degenerate case where the window is empty.
    """
    tz = _tz(cfg)
    today_local = now.astimezone(tz).date()
    until = now
    since = _local_midnight_utc(previous_workday(today_local, cfg), tz)

    if since >= until:
        return None

    # Enumerate the local calendar dates in [since, until): every day from the
    # start date through today (today included, since the window now runs up to
    # ``now``).
    since_date = since.astimezone(tz).date()
    covered: list[str] = []
    d = since_date
    while _local_midnight_utc(d, tz) < until:
        covered.append(d.isoformat())
        d += timedelta(days=1)
    if not covered:
        return None

    label = covered[0] if len(covered) == 1 else f"{covered[0]} ~ {covered[-1]}"
    return ReportWindow(
        since=since,
        until=until,
        covered_dates=covered,
        label=label,
        delivery_date=today_local.isoformat(),
    )


def manual_report_window(
    now: datetime,
    cfg: ChronicleConfig,
    start_date: date,
    end_date: date,
) -> ReportWindow | None:
    """Build a report window from explicit local start/end dates (both inclusive).

    Unlike :func:`compute_report_window` (which derives the span from the workday
    calendar), this honors an exact caller-chosen range for manual/test runs. The
    window is ``[start_date 00:00 local, min((end_date + 1) 00:00 local, now))`` —
    the upper bound is capped at ``now`` so passing today as both ends yields
    ``[today 00:00, now)`` (the day so far). Returns None when the range is empty
    or inverted (``end_date < start_date``).
    """
    if end_date < start_date:
        return None
    tz = _tz(cfg)
    since = _local_midnight_utc(start_date, tz)
    until = min(_local_midnight_utc(end_date + timedelta(days=1), tz), now)
    if since >= until:
        return None
    covered: list[str] = []
    d = start_date
    while _local_midnight_utc(d, tz) < until:
        covered.append(d.isoformat())
        d += timedelta(days=1)
    if not covered:
        return None
    label = covered[0] if len(covered) == 1 else f"{covered[0]} ~ {covered[-1]}"
    # For a past-range preview the report is "about" the requested end date, not
    # today; only fall back to today when the range reaches the current day (the
    # window is capped at ``now``). delivery_date is title-only for custom-window
    # previews — they are never persisted — so this just keeps the title honest.
    today_local = now.astimezone(tz).date()
    title_date = end_date if end_date < today_local else today_local
    return ReportWindow(
        since=since,
        until=until,
        covered_dates=covered,
        label=label,
        delivery_date=title_date.isoformat(),
    )


def local_day_bounds(cfg: ChronicleConfig, day: datetime) -> tuple[datetime, datetime]:
    """UTC [start, end) bounds of the local calendar day containing ``day``."""
    tz = _tz(cfg)
    d = day.astimezone(tz).date()
    return _local_midnight_utc(d, tz), _local_midnight_utc(d + timedelta(days=1), tz)
