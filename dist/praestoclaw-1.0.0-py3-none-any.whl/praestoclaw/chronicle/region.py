"""Resolve the signed-in user's holiday region (ISO 3166-1 alpha-2 code).

The daily report is delivered only on *workdays*, and which days are public
holidays depends on the user's region. Rather than hard-coding a region, we
detect it from the user's Microsoft 365 profile (Graph ``usageLocation``) at run
time and cache it on disk, so a transient Graph failure or an offline run still
resolves to the last known region.

Note: ``usageLocation`` is the account's *licensing* region. For most users it
matches where they actually work; if it doesn't, pin ``holiday_region`` in
chronicle.yaml to override (that always wins over auto-detection).
"""

from __future__ import annotations

from pathlib import Path

from loguru import logger

from praestoclaw.chronicle.mcp_caller import McpCaller
from praestoclaw.chronicle.textutil import extract_json


def _norm(value: object) -> str:
    """Normalise to an ISO 3166-1 alpha-2 code, or "" if it isn't one."""
    code = str(value or "").strip().upper()
    return code if len(code) == 2 and code.isalpha() else ""


async def resolve_country_code(caller: McpCaller, cache_path: Path) -> str:
    """Best-effort ISO alpha-2 country code for the signed-in user.

    Resolution order: Graph ``usageLocation`` → Graph ``country`` (only if it is
    already a 2-letter code) → the on-disk cache (last known) → "" (caller then
    falls back to weekday-only behaviour).
    """
    code = ""
    try:
        raw = await caller.call_tool(
            "m365-user",
            "GetMyDetails",
            {"select": "usageLocation,country"},
            timeout=30.0,
        )
        payload = extract_json(raw) or {}
        code = _norm(payload.get("usageLocation")) or _norm(payload.get("country"))
    except Exception as exc:  # noqa: BLE001 - region is best-effort, never fatal
        logger.warning("chronicle.region: GetMyDetails failed: {}", exc)

    if code:
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(code, encoding="utf-8")
        except OSError:
            logger.warning("chronicle.region: could not persist region cache")
        return code

    # Offline / empty → fall back to the last known region.
    if cache_path.is_file():
        try:
            cached = _norm(cache_path.read_text(encoding="utf-8"))
        except OSError:
            cached = ""
        if cached:
            logger.info("chronicle.region: using cached region {}", cached)
            return cached
    return ""
