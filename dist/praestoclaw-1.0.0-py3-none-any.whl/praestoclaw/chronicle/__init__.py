"""Chronicle — personal work archive & daily report subsystem.

Chronicle collects a user's whole workday across Teams chats (1:1 / group /
meeting), GitHub pull requests, Azure DevOps, email and calendar, persists
everything to a local timeline-centric SQLite archive (RAG-ready), and once a
day distills the work since the previous workday into a daily report delivered
via the Teams bot.

Design notes:
- Code-driven collection (deterministic, complete, retryable) + LLM-only
  summarization. This differs from the skill-driven ``megaphone`` subsystem on
  purpose: the archive must be reliable and complete even when slow.
- FULLY DECOUPLED from ``megaphone``: Chronicle never imports anything from
  ``praestoclaw.megaphone``. It only depends on platform-level shared infra
  (mcp client, providers, config, cron, utils). Deleting megaphone does not
  break Chronicle.
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.0"
