"""Chronicle storage — local SQLite archive (timeline-centric, RAG-ready).

Layers:
- L1 ``source_items``  : raw, immutable, deduplicated records from every source
  (Teams messages, PRs, emails, calendar events). The timeline spine. Mirrored
  into an FTS5 index for keyword search / future RAG.
- ``watermarks``       : per-source "last successfully pulled" cursor.
- ``digests``          : rendered daily reports (idempotent per date).
- ``runs`` / ``run_stages`` : workflow bookkeeping for reliable, resumable
  daily collection.

The schema deliberately carries ``share_scope`` from day one so a future team
archive can select which rows are shareable.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

_DDL = """
CREATE TABLE IF NOT EXISTS source_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    source        TEXT NOT NULL,              -- teams | meeting | github | ado | email | calendar
    external_id   TEXT NOT NULL,              -- stable id within the source
    kind          TEXT NOT NULL,              -- teams_message | meeting_transcript | pr | pr_approved | pr_review_requested | work_item | pipeline_run | email | calendar_event
    chat_id       TEXT,
    chat_type     TEXT,                        -- oneOnOne | group | meeting
    chat_topic    TEXT,
    thread_id     TEXT,
    author_id     TEXT,
    author_name   TEXT,
    is_me         INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT,                        -- ISO8601 UTC (event time)
    modified_at   TEXT,
    title         TEXT,                        -- subject / PR title / event subject
    body_text     TEXT,
    link          TEXT,
    share_scope   TEXT NOT NULL DEFAULT 'personal',  -- personal | shareable
    raw_json      TEXT,
    collected_at  TEXT NOT NULL,
    UNIQUE(source, external_id)
);
CREATE INDEX IF NOT EXISTS idx_items_created ON source_items(created_at);
CREATE INDEX IF NOT EXISTS idx_items_source  ON source_items(source, created_at);
CREATE INDEX IF NOT EXISTS idx_items_chat    ON source_items(chat_id);

CREATE VIRTUAL TABLE IF NOT EXISTS source_items_fts USING fts5(
    title, body_text, author_name, chat_topic,
    content='source_items', content_rowid='id',
    tokenize='porter unicode61'
);

CREATE TRIGGER IF NOT EXISTS source_items_ai AFTER INSERT ON source_items BEGIN
    INSERT INTO source_items_fts(rowid, title, body_text, author_name, chat_topic)
    VALUES (new.id, new.title, new.body_text, new.author_name, new.chat_topic);
END;
CREATE TRIGGER IF NOT EXISTS source_items_ad AFTER DELETE ON source_items BEGIN
    INSERT INTO source_items_fts(source_items_fts, rowid, title, body_text, author_name, chat_topic)
    VALUES ('delete', old.id, old.title, old.body_text, old.author_name, old.chat_topic);
END;
CREATE TRIGGER IF NOT EXISTS source_items_au AFTER UPDATE ON source_items BEGIN
    INSERT INTO source_items_fts(source_items_fts, rowid, title, body_text, author_name, chat_topic)
    VALUES ('delete', old.id, old.title, old.body_text, old.author_name, old.chat_topic);
    INSERT INTO source_items_fts(rowid, title, body_text, author_name, chat_topic)
    VALUES (new.id, new.title, new.body_text, new.author_name, new.chat_topic);
END;

CREATE TABLE IF NOT EXISTS watermarks (
    source         TEXT PRIMARY KEY,
    last_pulled_at TEXT NOT NULL,
    updated_at     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS digests (
    target_date TEXT PRIMARY KEY,     -- YYYY-MM-DD (the day the report is delivered)
    sections_md TEXT NOT NULL,
    model       TEXT,
    created_at  TEXT NOT NULL,
    period_start  TEXT,               -- UTC ISO: start of the covered window
    period_end    TEXT,               -- UTC ISO: end of the covered window (coverage cursor)
    covered_dates TEXT,               -- JSON list of local YYYY-MM-DD covered
    status        TEXT,               -- generated | delivered
    source        TEXT DEFAULT 'cli'  -- cli (ad-hoc) | cron (scheduled, advances coverage)
);

CREATE TABLE IF NOT EXISTS runs (
    run_id      TEXT PRIMARY KEY,
    kind        TEXT NOT NULL,        -- collect (historical DBs may also have 'report')
    target_date TEXT,
    status      TEXT NOT NULL,        -- running | done | failed
    attempt     INTEGER NOT NULL DEFAULT 1,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    heartbeat   TEXT,
    error       TEXT,
    stats_json  TEXT
);

CREATE TABLE IF NOT EXISTS run_stages (
    run_id     TEXT NOT NULL,
    stage      TEXT NOT NULL,
    status     TEXT NOT NULL,
    cursor     TEXT,
    error      TEXT,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (run_id, stage)
);
"""


def _now() -> str:
    return datetime.now(UTC).isoformat()


@dataclass
class SourceItem:
    """A single archived record (L1)."""

    source: str
    external_id: str
    kind: str
    created_at: str | None = None
    modified_at: str | None = None
    chat_id: str | None = None
    chat_type: str | None = None
    chat_topic: str | None = None
    thread_id: str | None = None
    author_id: str | None = None
    author_name: str | None = None
    is_me: bool = False
    title: str | None = None
    body_text: str | None = None
    link: str | None = None
    share_scope: str = "personal"
    raw: dict[str, Any] = field(default_factory=dict)


class ChronicleStore:
    """SQLite-backed Chronicle archive."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(db_path))
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(_DDL)
        self._migrate()
        self._conn.commit()

    def _migrate(self) -> None:
        """Idempotently add columns introduced after the initial schema.

        Note: the old ``digest_drafts`` table (from the retired two-pass
        nightly/morning design) is intentionally NOT dropped — leaving the orphan
        is non-destructive; new DBs simply never create it.
        """
        cols = {r["name"] for r in self._conn.execute("PRAGMA table_info(digests)")}
        for name, decl in (
            ("period_start", "TEXT"),
            ("period_end", "TEXT"),
            ("covered_dates", "TEXT"),
            ("status", "TEXT"),
            ("source", "TEXT DEFAULT 'cli'"),
        ):
            if name not in cols:
                self._conn.execute(f"ALTER TABLE digests ADD COLUMN {name} {decl}")

    def close(self) -> None:
        self._conn.close()

    # -- L1 source_items ---------------------------------------------------

    def upsert_item(self, item: SourceItem) -> bool:
        """Insert or update one item. Returns True if newly inserted."""
        cur = self._conn.execute(
            "SELECT id FROM source_items WHERE source=? AND external_id=?",
            (item.source, item.external_id),
        )
        existing = cur.fetchone()
        raw_json = json.dumps(item.raw, ensure_ascii=False) if item.raw else None
        if existing is None:
            self._conn.execute(
                """INSERT INTO source_items
                   (source, external_id, kind, chat_id, chat_type, chat_topic, thread_id,
                    author_id, author_name, is_me, created_at, modified_at, title, body_text,
                    link, share_scope, raw_json, collected_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    item.source,
                    item.external_id,
                    item.kind,
                    item.chat_id,
                    item.chat_type,
                    item.chat_topic,
                    item.thread_id,
                    item.author_id,
                    item.author_name,
                    1 if item.is_me else 0,
                    item.created_at,
                    item.modified_at,
                    item.title,
                    item.body_text,
                    item.link,
                    item.share_scope,
                    raw_json,
                    _now(),
                ),
            )
            return True
        self._conn.execute(
            """UPDATE source_items SET kind=?, chat_id=?, chat_type=?, chat_topic=?, thread_id=?,
               author_id=?, author_name=?, is_me=?, created_at=?, modified_at=?, title=?,
               body_text=?, link=?, share_scope=?, raw_json=? WHERE id=?""",
            (
                item.kind,
                item.chat_id,
                item.chat_type,
                item.chat_topic,
                item.thread_id,
                item.author_id,
                item.author_name,
                1 if item.is_me else 0,
                item.created_at,
                item.modified_at,
                item.title,
                item.body_text,
                item.link,
                item.share_scope,
                raw_json,
                existing["id"],
            ),
        )
        return False

    def commit(self) -> None:
        self._conn.commit()

    def items_in_range(
        self,
        start: datetime,
        end: datetime,
        *,
        sources: list[str] | None = None,
        exclude_chat_ids: set[str] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Return archived items whose event time is within [start, end).

        ``limit`` is pushed into SQL when there is no ``exclude_chat_ids``
        post-filter (which can drop rows, so a SQL LIMIT would under-count);
        with an exclusion set we fetch, filter, then trim to ``limit``.
        """
        sql = "SELECT * FROM source_items WHERE created_at >= ? AND created_at < ?"
        params: list[Any] = [start.isoformat(), end.isoformat()]
        if sources:
            placeholders = ",".join("?" * len(sources))
            sql += f" AND source IN ({placeholders})"
            params.extend(sources)
        sql += " ORDER BY created_at ASC"
        if limit is not None and not exclude_chat_ids:
            sql += " LIMIT ?"
            params.append(limit)
        rows = [dict(r) for r in self._conn.execute(sql, params).fetchall()]
        if exclude_chat_ids:
            rows = [r for r in rows if r.get("chat_id") not in exclude_chat_ids]
            if limit is not None:
                rows = rows[:limit]
        return rows

    def search(
        self,
        query: str,
        *,
        limit: int = 20,
        since: datetime | None = None,
        until: datetime | None = None,
        sources: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Keyword search across the archive (FTS5 BM25), optionally bounded by
        event-time range [since, until) and a source allow-list."""
        where = ["source_items_fts MATCH ?"]
        params: list[Any] = [query]
        if since is not None:
            where.append("s.created_at >= ?")
            params.append(since.isoformat())
        if until is not None:
            where.append("s.created_at < ?")
            params.append(until.isoformat())
        if sources:
            placeholders = ",".join("?" * len(sources))
            where.append(f"s.source IN ({placeholders})")
            params.extend(sources)
        sql = (
            "SELECT s.*, bm25(source_items_fts) AS rank FROM source_items_fts "
            "JOIN source_items s ON s.id = source_items_fts.rowid WHERE "
        )
        sql += " AND ".join(where)
        sql += " ORDER BY rank LIMIT ?"
        params.append(limit)
        try:
            return [dict(r) for r in self._conn.execute(sql, params).fetchall()]
        except sqlite3.OperationalError as exc:
            logger.warning("chronicle.search failed (query={!r}): {}", query, exc)
            return []

    # -- watermarks --------------------------------------------------------

    def get_watermark(self, source: str) -> datetime | None:
        row = self._conn.execute(
            "SELECT last_pulled_at FROM watermarks WHERE source=?", (source,)
        ).fetchone()
        if not row:
            return None
        try:
            return datetime.fromisoformat(row["last_pulled_at"])
        except ValueError:
            return None

    def set_watermark(self, source: str, dt: datetime) -> None:
        self._conn.execute(
            "INSERT INTO watermarks(source, last_pulled_at, updated_at) VALUES (?,?,?) "
            "ON CONFLICT(source) DO UPDATE SET last_pulled_at=excluded.last_pulled_at, "
            "updated_at=excluded.updated_at",
            (source, dt.isoformat(), _now()),
        )
        self._conn.commit()

    # -- digests -----------------------------------------------------------

    def save_digest(
        self,
        target_date: str,
        sections_md: str,
        model: str | None,
        *,
        period_start: datetime | None = None,
        period_end: datetime | None = None,
        covered_dates: list[str] | None = None,
        status: str = "generated",
        source: str = "cli",
    ) -> None:
        self._conn.execute(
            "INSERT INTO digests(target_date, sections_md, model, created_at, period_start, "
            "period_end, covered_dates, status, source) VALUES (?,?,?,?,?,?,?,?,?) "
            "ON CONFLICT(target_date) DO UPDATE SET sections_md=excluded.sections_md, "
            "model=excluded.model, created_at=excluded.created_at, "
            "period_start=excluded.period_start, period_end=excluded.period_end, "
            "covered_dates=excluded.covered_dates, status=excluded.status, source=excluded.source",
            (
                target_date,
                sections_md,
                model,
                _now(),
                period_start.isoformat() if period_start else None,
                period_end.isoformat() if period_end else None,
                json.dumps(covered_dates) if covered_dates is not None else None,
                status,
                source,
            ),
        )
        self._conn.commit()

    def get_digest(self, target_date: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT * FROM digests WHERE target_date=?", (target_date,)
        ).fetchone()
        return dict(row) if row else None

    # -- chat lookup (for natural-language preferences) --------------------

    def find_chats_by_topic(self, query: str, *, limit: int = 8) -> list[dict[str, Any]]:
        """Fuzzy-match archived group/meeting chats by topic for preference setting."""
        like = f"%{query.strip()}%"
        rows = self._conn.execute(
            "SELECT chat_id, chat_type, "
            "       MAX(chat_topic) AS chat_topic, "
            "       COUNT(*) AS msg_count, "
            "       MAX(created_at) AS last_seen "
            "FROM source_items "
            "WHERE source='teams' AND chat_id IS NOT NULL AND chat_topic LIKE ? "
            "GROUP BY chat_id ORDER BY last_seen DESC LIMIT ?",
            (like, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    # -- runs --------------------------------------------------------------

    def start_run(self, run_id: str, kind: str, target_date: str | None) -> None:
        self._conn.execute(
            "INSERT INTO runs(run_id, kind, target_date, status, started_at, heartbeat) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(run_id) DO UPDATE SET status='running', "
            "attempt=runs.attempt+1, heartbeat=excluded.heartbeat",
            (run_id, kind, target_date, "running", _now(), _now()),
        )
        self._conn.commit()

    def finish_run(
        self,
        run_id: str,
        *,
        status: str,
        stats: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        self._conn.execute(
            "UPDATE runs SET status=?, finished_at=?, error=?, stats_json=? WHERE run_id=?",
            (status, _now(), error, json.dumps(stats or {}, ensure_ascii=False), run_id),
        )
        self._conn.commit()

    def set_stage(
        self,
        run_id: str,
        stage: str,
        status: str,
        *,
        cursor: str | None = None,
        error: str | None = None,
    ) -> None:
        self._conn.execute(
            "INSERT INTO run_stages(run_id, stage, status, cursor, error, updated_at) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(run_id, stage) DO UPDATE SET status=excluded.status, "
            "cursor=excluded.cursor, error=excluded.error, updated_at=excluded.updated_at",
            (run_id, stage, status, cursor, error, _now()),
        )
        self._conn.commit()

    def count_items(self) -> int:
        return int(self._conn.execute("SELECT COUNT(*) AS c FROM source_items").fetchone()["c"])
