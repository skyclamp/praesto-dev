"""Chronicle agent tools — the daily-report entry point, settings, and search.

Tools:
- :class:`ChronicleRunTool` (``chronicle_run``) — standard tier. Runs the daily
  pipeline: collects the latest data and, on workdays, summarizes + assembles the
  full report and returns its markdown for delivery. The single scheduled cron job
  calls it with ``from="cron"`` (deterministic, no LLM loop); the bot calls it
  with ``from="manual"`` when the user asks to run the report on demand ("跑日报")
  — a manual run bypasses the workday/already-delivered guards.
- :class:`ChronicleSettingsTool` (``chronicle_settings``) — standard tier. Lets
  the bot pause/resume/inspect the daily report and add/remove report preferences
  ("以后日报别关注 XX 群了") in natural language. Settings live in chronicle.yaml.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.chronicle.config import (
    ChronicleConfig,
    ChroniclePreference,
    add_preference,
    db_path,
    identity_cache_path,
    load_config,
    remove_preferences,
    update_config,
)
from praestoclaw.chronicle.identity import resolve_identity
from praestoclaw.chronicle.mcp_caller import ManagerMcpCaller, McpCaller, StdioMcpCaller
from praestoclaw.chronicle.pipeline import run_daily
from praestoclaw.chronicle.store import ChronicleStore
from praestoclaw.chronicle.workday import manual_report_window

# Only one chronicle pipeline run at a time (a scheduled run and a manual
# trigger could otherwise overlap and share the DB / MCP connection).
_RUN_LOCK = asyncio.Lock()


def _provider_and_model(cfg: ChronicleConfig) -> tuple[Any, str]:
    from praestoclaw.config.loader import load_config as load_app_config
    from praestoclaw.providers.resolver import get_provider

    app = load_app_config()
    provider = get_provider(app.providers)
    model = cfg.model if cfg.model and cfg.model != "auto" else app.agents.default.model
    return provider, model


class ChronicleRunTool(Tool):
    """Run the chronicle daily pipeline (collect + summarize + deliver)."""

    def __init__(self, tool_registry: Any | None = None) -> None:
        # The runtime sets the live MCPManager on the registry *after* tools are
        # registered, so resolve it lazily at execute time rather than capturing
        # a (still-None) reference now.
        self._tool_registry = tool_registry

    @property
    def name(self) -> str:
        return "chronicle_run"

    @property
    def description(self) -> str:
        return (
            "运行 Chronicle 每日工作日报流程（生成日报/跑日报/出一份档案日报）：采集最新数据，"
            "并在工作日把「前一个工作日0点→现在」的窗口汇总成完整日报返回投递。"
            "When the user asks to run/generate the daily report now (跑日报/生成日报/"
            "现在出一份日报), call this DIRECTLY with from='manual' — do NOT use "
            "cron(action='run'). Required 'from': 'manual' for a user-triggered run "
            "(bypasses the workday/already-delivered guards so it always produces the "
            "report), 'cron' for the scheduled job. Optional start_date/end_date "
            "(YYYY-MM-DD, inclusive local dates) run a preview over a custom span "
            "(same date on both ends = that day 00:00→now) and are NOT persisted."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "from": {
                    "type": "string",
                    "enum": ["manual", "cron"],
                    "description": (
                        "Who triggered the run: 'manual' when the user asks to run the "
                        "report on demand (skips dedup so it always runs), 'cron' for the "
                        "scheduled daily job."
                    ),
                },
                "start_date": {
                    "type": "string",
                    "description": (
                        "Optional manual window start, local date YYYY-MM-DD (inclusive). "
                        "With end_date it overrides the report span to "
                        "[start 00:00, (end+1) 00:00) capped at now, for a preview that is "
                        "NOT persisted. Omit for the normal previous-workday→today window."
                    ),
                },
                "end_date": {
                    "type": "string",
                    "description": (
                        "Optional manual window end, local date YYYY-MM-DD (inclusive). "
                        "Defaults to start_date when only one is given; pass today as both "
                        "to summarize today 00:00 → now."
                    ),
                },
            },
            "required": ["from"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        # Visible to the LLM so it can run the report on demand; long timeout
        # because a busy day can take many minutes to collect + summarize.
        return ToolMetadata(category="builtin", tier="standard", timeout=1800)

    def _build_caller(self) -> McpCaller:
        manager = getattr(self._tool_registry, "_mcp_manager", None)
        if manager is not None:
            return ManagerMcpCaller(manager)
        return StdioMcpCaller()

    async def execute(self, **kwargs: Any) -> str:
        # 'from' is a Python keyword, so it can only be read via kwargs.
        frm = (kwargs.get("from") or "").strip()
        if frm not in ("manual", "cron"):
            return "Error: 'from' must be 'manual' or 'cron'."
        manual = frm == "manual"

        start_date = (kwargs.get("start_date") or "").strip()
        end_date = (kwargs.get("end_date") or "").strip()

        async with _RUN_LOCK:
            cfg = load_config()
            if not cfg.enabled:
                logger.info("chronicle_run: disabled in config; skipping")
                # Cron tool-mode treats "" as "nothing to deliver"; a manual call
                # needs an explicit reason or the empty result looks like success.
                if manual:
                    return "Chronicle 档案功能当前未启用（chronicle.yaml: enabled=false），无法生成日报。"
                return ""
            provider, model = _provider_and_model(cfg)
            cfg.model = model
            store: ChronicleStore | None = None
            caller: McpCaller | None = None
            try:
                store = ChronicleStore(db_path())
                caller = self._build_caller()
                now = datetime.now(UTC)
                window = None
                if start_date or end_date:
                    try:
                        sd = date.fromisoformat(start_date or end_date)
                        ed = date.fromisoformat(end_date or start_date)
                    except ValueError:
                        return "Error: start_date/end_date must be YYYY-MM-DD."
                    window = manual_report_window(now, cfg, sd, ed)
                    if window is None:
                        return (
                            "Error: empty/invalid window — start_date must be ≤ "
                            "end_date and not in the future."
                        )
                identity = await resolve_identity(caller, identity_cache_path())
                markdown = await run_daily(
                    caller,
                    store,
                    identity,
                    cfg,
                    provider,
                    now=now,
                    window=window,
                    manual=manual,
                )
                if not markdown:
                    logger.info("chronicle_run: nothing to deliver")
                return markdown
            except Exception:
                # Let the exception propagate so ToolRegistry formats it once
                # (and the cron tool-mode runner surfaces it as a failed job);
                # returning our own "Error: ..." string here duplicated that
                # formatting. We still log it with chronicle context first.
                logger.exception("chronicle_run failed")
                raise
            finally:
                if caller is not None:
                    await caller.aclose()
                if store is not None:
                    store.close()


class ChronicleSettingsTool(Tool):
    """Manage the daily report: pause/resume delivery and report preferences."""

    @property
    def name(self) -> str:
        return "chronicle_settings"

    @property
    def description(self) -> str:
        return (
            "Manage the user's daily Chronicle report settings. Actions:\n"
            "- 'show': report on/off state + current preferences (use when the user asks "
            "'日报开着吗'/'我设了哪些日报偏好').\n"
            "- 'pause': stop delivering the daily report ('关掉日报'/'暂停日报'/'别再发日报了'). "
            "Background data collection always continues; pausing only stops DELIVERY.\n"
            "- 'resume': resume delivery ('恢复日报'/'重新开始发日报').\n"
            "- 'add': add a preference for what the report focuses on/excludes "
            "('以后日报别关注 XX 群了' → scope='chat',directive='exclude',target='XX'; "
            "'多关注安全相关的讨论' → scope='topic',directive='focus',target='安全'). For a "
            "chat, pass the group name in 'target'; ambiguous names return candidates.\n"
            "- 'remove': drop matching preference(s) ('恢复关注 XX 群') by scope/directive/"
            "target — no id needed.\n"
            "This tool does NOT run the report — to run one on demand use chronicle_run "
            "with from='manual'."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["show", "pause", "resume", "add", "remove"],
                },
                "scope": {
                    "type": "string",
                    "enum": list(_SCOPES),
                    "description": "What the preference applies to (for add/remove).",
                },
                "directive": {
                    "type": "string",
                    "enum": list(_DIRECTIVES),
                    "description": (
                        "exclude/hard_mute = drop from report; highlight/focus = emphasize; "
                        "ignore_topic = de-emphasize; verbosity/language/section_toggle = "
                        "formatting (for add/remove)."
                    ),
                },
                "target": {
                    "type": "string",
                    "description": "Group/person/topic name to match (for add/remove).",
                },
                "target_id": {
                    "type": "string",
                    "description": "Explicit chat_id, if already known (skips name matching).",
                },
                "value": {"type": "string", "description": "Extra value, e.g. language code."},
                "raw_text": {"type": "string", "description": "The user's original phrasing."},
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(category="builtin", tier="standard", timeout=30)

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action")
        cfg = load_config()
        if not cfg.enabled:
            return "Chronicle 档案功能当前未启用（chronicle.yaml: enabled=false），没有日报任务可操作。"

        if action == "show":
            return self._show(cfg)
        if action == "pause":
            if cfg.report_paused:
                return "日报已经是暂停状态了，无需重复操作。"
            update_config({"report_paused": True})
            return (
                "已关闭日报投递。后台数据采集会继续（档案保持完整），随时说"
                "「恢复日报」即可重新开始。"
            )
        if action == "resume":
            if not cfg.report_paused:
                return "日报本来就是开启状态。"
            update_config({"report_paused": False})
            return "已恢复日报。下一个工作日早晨会汇总「前一个工作日」的内容并投递（不会补发暂停期间的积压）。"
        if action == "add":
            return self._add(kwargs)
        if action == "remove":
            return self._remove(kwargs)
        return "Error: action must be 'show', 'pause', 'resume', 'add', or 'remove'."

    def _show(self, cfg: ChronicleConfig) -> str:
        head = (
            "📭 日报当前已暂停（仍在后台采集数据）。"
            if cfg.report_paused
            else "📬 日报当前为开启状态，工作日每天早上投递。"
        )
        if not cfg.preferences:
            return head + "\n当前没有设置任何日报偏好。"
        lines = [head, "当前日报偏好："]
        for p in cfg.preferences:
            tgt = p.target_name or p.target_id or "—"
            lines.append(
                f"- [{p.scope}/{p.directive}] {tgt}" + (f" = {p.value}" if p.value else "")
            )
        return "\n".join(lines)

    def _add(self, kwargs: dict[str, Any]) -> str:
        scope = kwargs.get("scope")
        directive = kwargs.get("directive")
        if scope not in _SCOPES:
            return f"Error: scope must be one of {_SCOPES}."
        if directive not in _DIRECTIVES:
            return f"Error: directive must be one of {_DIRECTIVES}."

        target = (kwargs.get("target") or "").strip()
        target_id = (kwargs.get("target_id") or "").strip() or None
        target_name = target or None

        # For a chat-scoped preference, resolve the group name to a chat_id from
        # the archive (the only DB read this tool needs).
        if scope == "chat" and not target_id:
            if not target:
                return "Error: a chat preference needs a group name in 'target'."
            store = ChronicleStore(db_path())
            try:
                candidates = store.find_chats_by_topic(target)
            finally:
                store.close()
            if not candidates:
                return f"没有在档案里找到名为「{target}」的群聊，请确认群名。"
            if len(candidates) > 1:
                lines = [f"「{target}」匹配到多个群聊，请指明是哪一个（用 target_id 重试）："]
                for c in candidates:
                    lines.append(
                        f"- {c.get('chat_topic') or '(无主题)'} "
                        f"[{c.get('chat_type')}, {c.get('msg_count')} 条, "
                        f"最近 {c.get('last_seen')}] id={c.get('chat_id')}"
                    )
                return "\n".join(lines)
            only = candidates[0]
            target_id = only.get("chat_id")
            target_name = only.get("chat_topic") or target

        add_preference(
            ChroniclePreference(
                scope=scope,
                directive=directive,
                target_id=target_id,
                target_name=target_name,
                value=kwargs.get("value"),
                raw_text=kwargs.get("raw_text"),
            )
        )
        tgt = target_name or target_id or scope
        return f"已记录偏好：对「{tgt}」执行 {directive}（自下一份日报起生效）。"

    def _remove(self, kwargs: dict[str, Any]) -> str:
        scope = kwargs.get("scope") or None
        directive = kwargs.get("directive") or None
        target = (kwargs.get("target") or "").strip() or None
        # target_id is an alias for target here: remove_preferences() matches the
        # needle against either target_name or target_id, so a caller that only
        # knows the chat_id (e.g. from a prior 'show') can still remove by id.
        target = target or ((kwargs.get("target_id") or "").strip() or None)
        if not (scope or directive or target):
            return "Error: 删除偏好需要至少提供 scope / directive / target 之一来匹配。"
        _, removed = remove_preferences(scope=scope, directive=directive, target=target)
        if removed == 0:
            return "没有找到匹配的日报偏好，未做改动。"
        return f"已删除 {removed} 条匹配的日报偏好（自下一份日报起生效）。"


_DIRECTIVES = (
    "exclude",
    "hard_mute",
    "highlight",
    "focus",
    "ignore_topic",
    "verbosity",
    "language",
    "section_toggle",
)
_SCOPES = ("chat", "person", "topic", "source", "section", "global")


class ChronicleSearchTool(Tool):
    """Search the personal Chronicle archive (档案) and fetch past daily reports."""

    @property
    def name(self) -> str:
        return "chronicle_search"

    @property
    def description(self) -> str:
        return (
            "查询用户的个人档案（Chronicle archive，关键词：档案、日报）。用于回答「我以前做过 X 吗」"
            "「某次开会讨论了什么」「上周关于 X 的讨论」「把某天的日报给我」这类问题——数据来自归档的 "
            "Teams 单聊/会议/群聊、会议纪要、邮件、GitHub/Azure DevOps 的 PR 和工作项、日历。三种用法：\n"
            "1) 关键词检索：传 query；可加 start_date/end_date 限定时间、source 限定来源。\n"
            "2) 取回某天日报：传 report_date（YYYY-MM-DD），返回那天投递的完整日报。\n"
            "3) 按时间浏览：只传 start_date/end_date（不带 query），列出该区间的归档条目。\n"
            "返回带时间、来源、作者和链接的条目，便于继续追问细节。"
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        '关键词或短语（FTS5 语法：空格=AND，OR，"精确短语"）。检索标题、正文、'
                        "作者、群聊/会议主题。"
                    ),
                },
                "start_date": {
                    "type": "string",
                    "description": "起始本地日期 YYYY-MM-DD（含），限定时间范围。",
                },
                "end_date": {
                    "type": "string",
                    "description": "结束本地日期 YYYY-MM-DD（含）；只给一个则按单天。",
                },
                "source": {
                    "type": "string",
                    "enum": ["teams", "meeting", "email", "github", "ado", "calendar"],
                    "description": "只看某个来源。",
                },
                "report_date": {
                    "type": "string",
                    "description": "取回该本地日期（YYYY-MM-DD）投递的完整日报全文。",
                },
                "limit": {
                    "type": "integer",
                    "description": "返回条数上限（默认 15，最多 50）。",
                },
            },
            "required": [],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(category="builtin", tier="standard", timeout=30)

    async def execute(self, **kwargs: Any) -> str:
        cfg = load_config()
        if not cfg.enabled:
            return "Chronicle 档案功能当前未启用（chronicle.yaml: enabled=false），无法检索档案。"
        store = ChronicleStore(db_path())
        try:
            # Mode 1: fetch a past daily report by date.
            report_date = (kwargs.get("report_date") or "").strip()
            if report_date:
                try:
                    date.fromisoformat(report_date)
                except ValueError:
                    return "Error: report_date 必须是 YYYY-MM-DD。"
                digest = store.get_digest(report_date)
                if not digest or not digest.get("sections_md"):
                    return f"档案里没有 {report_date} 的日报记录。"
                return str(digest["sections_md"])

            query = (kwargs.get("query") or "").strip()
            source = (kwargs.get("source") or "").strip() or None
            sources = [source] if source else None
            try:
                limit = max(1, min(int(kwargs.get("limit") or 15), 50))
            except (TypeError, ValueError):
                limit = 15

            since: datetime | None = None
            until: datetime | None = None
            sd = (kwargs.get("start_date") or "").strip()
            ed = (kwargs.get("end_date") or "").strip()
            if sd or ed:
                try:
                    s = date.fromisoformat(sd or ed)
                    e = date.fromisoformat(ed or sd)
                except ValueError:
                    return "Error: start_date/end_date 必须是 YYYY-MM-DD。"
                if e < s:
                    return "Error: 结束日期不能早于起始日期。"
                tz = self._tz(cfg.timezone)
                since = datetime.combine(s, time.min, tzinfo=tz).astimezone(UTC)
                until = datetime.combine(e + timedelta(days=1), time.min, tzinfo=tz).astimezone(UTC)

            if query:
                rows = store.search(query, limit=limit, since=since, until=until, sources=sources)
            elif since is not None and until is not None:
                rows = store.items_in_range(since, until, sources=sources, limit=limit)
            else:
                return (
                    "请提供 query（关键词）、start_date/end_date（时间范围），"
                    "或 report_date（取回某天日报）。"
                )

            if not rows:
                return "档案里没有找到匹配的内容。"
            return self._format(rows, cfg.timezone)
        finally:
            store.close()

    @staticmethod
    def _tz(tz_name: str) -> ZoneInfo:
        try:
            return ZoneInfo(tz_name)
        except Exception:  # noqa: BLE001 - bad tz string falls back to UTC
            return ZoneInfo("UTC")

    def _format(self, rows: list[dict[str, Any]], tz_name: str) -> str:
        tz = self._tz(tz_name)
        lines = [f"在档案中找到 {len(rows)} 条相关内容："]
        for r in rows:
            when = r.get("created_at") or ""
            try:
                when = datetime.fromisoformat(when).astimezone(tz).strftime("%Y-%m-%d %H:%M")
            except (ValueError, TypeError):
                pass
            label = r.get("chat_topic") or r.get("title") or ""
            who = r.get("author_name") or ""
            body = (r.get("body_text") or "").replace("\n", " ").strip()
            if len(body) > 180:
                body = body[:180] + "…"
            src = f"{r.get('source', '')}/{r.get('kind', '')}".strip("/")
            head = (
                f"- [{when}] {src}"
                + (f" · {label}" if label else "")
                + (f" · {who}" if who else "")
            )
            snippet = f"\n  {body}" if body else ""
            tail = f"\n  {r['link']}" if r.get("link") else ""
            lines.append(head + snippet + tail)
        return "\n".join(lines)
