"""Best-effort GitHub Draft PRs for staged KB proposals.

The local proposal remains the source of truth.  This module only mirrors that
commit to GitHub when the repository, cached Git credential and API permissions
all support it.  Callers deliberately treat an empty result as "local review
only" so this optional surface can never block curation or publishing.
"""

from __future__ import annotations

import getpass
import re
from datetime import UTC, datetime
from typing import Any
from urllib.parse import unquote, urlparse

import httpx
from loguru import logger

from praestoclaw.kb.repo import KbRepo, KbRepoError
from praestoclaw.security.github_auth import (
    github_token_from_gh_cli,
    github_token_from_git_credential,
)

_API_ROOT = "https://api.github.com"
_API_TIMEOUT_S = 15.0


def _now() -> str:
    return datetime.now(UTC).isoformat()


def github_repo_coordinates(remote: str) -> tuple[str, str] | None:
    """Return ``(owner, repo)`` for github.com remotes only."""
    value = (remote or "").strip()
    if value.startswith("git@github.com:"):
        path = value.removeprefix("git@github.com:")
    elif value.startswith("ssh://"):
        parsed = urlparse(value)
        if (parsed.hostname or "").casefold() != "github.com":
            return None
        path = parsed.path
    elif value.startswith(("http://", "https://")):
        parsed = urlparse(value)
        if (parsed.hostname or "").casefold() != "github.com":
            return None
        path = parsed.path
    else:
        return None
    parts = path.strip("/").removesuffix(".git").split("/")
    if len(parts) != 2 or not all(parts):
        return None
    return parts[0], parts[1]


def _effective_remote(repo: KbRepo) -> str:
    try:
        return repo.origin_url()
    except (AttributeError, KbRepoError):
        return repo.remote_url


def _credential_context(remote: str) -> dict[str, str]:
    """Build the exact GCM key for a GitHub remote.

    Preserve an explicit account hint such as ``{alias}_microsoft`` when origin
    supplies one. Default configuration intentionally has no username, so an
    enrolled host's OS alias supplies the same deterministic account hint.
    """
    value = (remote or "").strip()
    username = ""
    host = ""
    path = ""
    if value.startswith("git@"):
        host, _, path = value[4:].partition(":")
    elif "://" in value:
        parsed = urlparse(value)
        host = parsed.hostname or ""
        path = parsed.path.lstrip("/")
        username = unquote(parsed.username or "")
    if not username:
        alias = getpass.getuser().strip().split("\\")[-1].split("@", 1)[0]
        if re.fullmatch(r"[A-Za-z0-9_.-]+", alias):
            username = alias if alias.endswith("_microsoft") else f"{alias}_microsoft"
    return {"host": host, "path": path, "username": username}


def _credential_token(remote: str) -> str | None:
    """Resolve a Draft PR API token from the narrowest credential key outward.

    Keep the generic git-credential reader strict: callers that request a repo
    path still get a repo-path match.  This Draft PR adapter deliberately makes
    progressively broader *new* queries because GCM commonly stores one
    host-level OAuth credential when ``credential.useHttpPath`` is false.
    GitHub CLI is last so a remote/account-specific GCM credential always wins.
    """
    context = _credential_context(remote)
    logger.debug(
        "kb_draft_pr.status step=credential outcome=start host={} path={} username_hint={}",
        context["host"] or "(none)",
        context["path"] or "(none)",
        context["username"] or "(none)",
    )
    host = context["host"]
    path = context["path"]
    username = context["username"]
    attempts = [
        ("exact", {"host": host, "path": path, "username": username}),
        ("repo_without_username", {"host": host, "path": path, "username": ""}),
        ("host_with_username", {"host": host, "path": "", "username": username}),
        ("host_only", {"host": host, "path": "", "username": ""}),
    ]
    seen: set[tuple[str, str, str]] = set()
    for attempt, query in attempts:
        key = (query["host"], query["path"], query["username"])
        if key in seen:
            continue
        seen.add(key)
        logger.debug(
            "kb_draft_pr.status step=credential outcome=attempt_start attempt={} "
            "path_present={} username_present={}",
            attempt,
            bool(query["path"]),
            bool(query["username"]),
        )
        token = github_token_from_git_credential(timeout=3.0, **query)
        logger.debug(
            "kb_draft_pr.status step=credential outcome={} attempt={}",
            "attempt_match" if token else "attempt_miss",
            attempt,
        )
        if token:
            return token

    logger.debug("kb_draft_pr.status step=credential outcome=attempt_start attempt=gh_cli")
    token = github_token_from_gh_cli(timeout=3.0)
    logger.debug(
        "kb_draft_pr.status step=credential outcome={} attempt=gh_cli",
        "attempt_match" if token else "attempt_miss",
    )
    if not token:
        logger.debug("kb_draft_pr.status step=credential outcome=unavailable attempts=all")
    return token


def _api_request(
    method: str,
    path: str,
    token: str,
    *,
    payload: dict[str, Any] | None = None,
    params: dict[str, str] | None = None,
) -> Any:
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {token}",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    logger.debug(
        "kb_draft_pr.status step=http outcome=request method={} path={} "
        "payload_present={} params_present={}",
        method,
        path,
        payload is not None,
        params is not None,
    )
    with httpx.Client(timeout=_API_TIMEOUT_S, headers=headers) as client:
        response = client.request(
            method,
            f"{_API_ROOT}{path}",
            json=payload,
            params=params,
        )
        logger.debug(
            "kb_draft_pr.status step=http outcome=response method={} path={} "
            "status_code={} request_id={}",
            method,
            path,
            response.status_code,
            response.headers.get("x-github-request-id") or "(none)",
        )
        response.raise_for_status()
        return response.json()


def _review_body(overview: str, changes: list[dict[str, str]]) -> str:
    lines = [
        "This Draft PR mirrors a PraestoClaw KB proposal for review.",
        "Approval and publishing remain in the originating Teams conversation.",
        "",
        "## Overview",
        overview.strip(),
        "",
        "## Changes",
    ]
    for change in changes:
        lines.append(f"- `{change['path']}` — {change['summary']}")
    return "\n".join(lines).strip() + "\n"


def _open_review(
    owner: str,
    name: str,
    branch: str,
    base: str,
    token: str,
) -> dict[str, Any]:
    found = _api_request(
        "GET",
        f"/repos/{owner}/{name}/pulls",
        token,
        params={"state": "open", "head": f"{owner}:{branch}", "base": base},
    )
    if not isinstance(found, list) or not found or not isinstance(found[0], dict):
        return {}
    return found[0]


def upsert_draft_review(
    repo: KbRepo,
    *,
    branch: str,
    sha: str,
    base: str,
    title: str,
    overview: str,
    changes: list[dict[str, str]],
    current: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Mirror a proposal into a Draft PR, returning persisted review metadata.

    Any unsupported or failed step returns an empty/current record and logs only
    locally.  The proposal branch is removed again when initial PR creation
    fails, so an unavailable optional review does not leave remote debris.
    """
    prior = dict(current or {})
    logger.info(
        "kb_draft_pr.status step=upsert outcome=start branch={} sha={} base={} prior_number={}",
        branch,
        sha[:12],
        base,
        int(prior.get("number") or 0),
    )
    remote = _effective_remote(repo)
    coordinates = github_repo_coordinates(remote)
    if coordinates is None:
        logger.info("kb_draft_pr.status step=remote outcome=unsupported provider=non_github")
        return prior
    owner, name = coordinates
    logger.debug("kb_draft_pr.status step=remote outcome=resolved repository={}/{}", owner, name)
    token = _credential_token(remote)
    if not token:
        logger.warning(
            "kb_draft_pr.status step=credential outcome=unavailable repository={}/{} "
            "action=skip_optional_review",
            owner,
            name,
        )
        return prior

    logger.debug(
        "kb_draft_pr.status step=credential outcome=available repository={}/{}", owner, name
    )
    try:
        logger.info(
            "kb_draft_pr.status step=branch_push outcome=start branch={} sha={} force=true",
            branch,
            sha[:12],
        )
        repo.push_ref(sha, branch, force=True)
    except KbRepoError as exc:
        logger.warning(
            "kb_draft_pr.status step=branch_push outcome=failed branch={} error_type={} detail={}",
            branch,
            type(exc).__name__,
            exc,
        )
        return prior
    logger.info("kb_draft_pr.status step=branch_push outcome=succeeded branch={}", branch)

    existing: dict[str, Any] = {}
    number = int(prior.get("number") or 0)
    if number and prior.get("state") == "open":
        existing = {"number": number, "html_url": prior.get("url")}
        logger.debug("kb_draft_pr.status step=lookup outcome=use_persisted number={}", number)
    else:
        try:
            logger.debug(
                "kb_draft_pr.status step=lookup outcome=start repository={}/{} branch={} base={}",
                owner,
                name,
                branch,
                base,
            )
            existing = _open_review(owner, name, branch, base, token)
            number = int(existing.get("number") or 0)
            logger.debug(
                "kb_draft_pr.status step=lookup outcome={} number={}",
                "found" if number else "not_found",
                number,
            )
        except (httpx.HTTPError, ValueError, TypeError) as exc:
            logger.warning(
                "kb_draft_pr.status step=lookup outcome=failed error_type={} detail={}",
                type(exc).__name__,
                exc,
            )

    body = _review_body(overview, changes)
    operation = "update" if number else "create"
    try:
        logger.info(
            "kb_draft_pr.status step=pr_write outcome=start operation={} number={} "
            "branch={} base={}",
            operation,
            number,
            branch,
            base,
        )
        if number:
            data = _api_request(
                "PATCH",
                f"/repos/{owner}/{name}/pulls/{number}",
                token,
                payload={"title": title, "body": body, "state": "open", "base": base},
            )
        else:
            data = _api_request(
                "POST",
                f"/repos/{owner}/{name}/pulls",
                token,
                payload={
                    "title": title,
                    "body": body,
                    "head": branch,
                    "base": base,
                    "draft": True,
                },
            )
        if not isinstance(data, dict):
            raise TypeError("GitHub returned a non-object Draft PR response")
        number = int(data.get("number") or number)
        url = str(data.get("html_url") or existing.get("html_url") or prior.get("url") or "")
        if not number or not url:
            raise ValueError("GitHub Draft PR response omitted its number or URL")
    except (httpx.HTTPError, ValueError, TypeError) as exc:
        logger.warning(
            "kb_draft_pr.status step=pr_write outcome=failed operation={} number={} "
            "error_type={} detail={}",
            operation,
            number,
            type(exc).__name__,
            exc,
        )
        if not prior:
            removed = repo.delete_remote_branch(branch)
            logger.info(
                "kb_draft_pr.status step=cleanup outcome={} branch={} reason=initial_write_failed",
                "removed" if removed else "unavailable",
                branch,
            )
        return prior

    logger.info(
        "kb_draft_pr.status step=pr_write outcome=succeeded operation={} number={} "
        "draft={} branch={}",
        operation,
        number,
        bool(data.get("draft", True)),
        branch,
    )
    return {
        "provider": "github",
        "repository": f"{owner}/{name}",
        "number": number,
        "url": url,
        "branch": branch,
        "base": base,
        "state": "open",
        "draft": bool(data.get("draft", True)),
        "synced_sha": sha,
        "updated_at": _now(),
    }


def close_draft_review(
    repo: KbRepo,
    review: dict[str, Any] | None,
    *,
    fallback_branch: str = "",
) -> dict[str, Any]:
    """Best-effort close of the Draft PR and deletion of its remote branch."""
    current = dict(review or {})
    branch = str(current.get("branch") or fallback_branch).strip()
    if not current and not branch:
        logger.debug("kb_draft_pr.status step=close outcome=nothing_to_close")
        return {}

    api_closed = False
    remote = _effective_remote(repo)
    coordinates = github_repo_coordinates(remote)
    number = int(current.get("number") or 0)
    logger.info(
        "kb_draft_pr.status step=close outcome=start number={} branch={} repository_supported={}",
        number,
        branch or "(none)",
        coordinates is not None,
    )
    if coordinates is not None and number:
        token = _credential_token(remote)
        if token:
            owner, name = coordinates
            try:
                _api_request(
                    "PATCH",
                    f"/repos/{owner}/{name}/pulls/{number}",
                    token,
                    payload={"state": "closed"},
                )
                api_closed = True
                logger.info("kb_draft_pr.status step=close_api outcome=succeeded number={}", number)
            except (httpx.HTTPError, ValueError, TypeError) as exc:
                logger.warning(
                    "kb_draft_pr.status step=close_api outcome=failed number={} "
                    "error_type={} detail={}",
                    number,
                    type(exc).__name__,
                    exc,
                )
        else:
            logger.warning(
                "kb_draft_pr.status step=close_api outcome=credential_unavailable number={}",
                number,
            )

    branch_removed = False
    if branch:
        try:
            branch_removed = repo.delete_remote_branch(branch)
            logger.info(
                "kb_draft_pr.status step=close_branch outcome={} branch={}",
                "removed" if branch_removed else "unavailable",
                branch,
            )
        except KbRepoError as exc:
            logger.warning(
                "kb_draft_pr.status step=close_branch outcome=failed branch={} "
                "error_type={} detail={}",
                branch,
                type(exc).__name__,
                exc,
            )

    current.update(
        {
            "state": "closed" if api_closed or branch_removed else "cleanup_unavailable",
            "closed_at": _now(),
            "api_closed": api_closed,
            "remote_branch_removed": branch_removed,
        }
    )
    logger.info(
        "kb_draft_pr.status step=close outcome=complete number={} api_closed={} "
        "branch_removed={} state={}",
        number,
        api_closed,
        branch_removed,
        current["state"],
    )
    return current


__all__ = ["close_draft_review", "github_repo_coordinates", "upsert_draft_review"]
