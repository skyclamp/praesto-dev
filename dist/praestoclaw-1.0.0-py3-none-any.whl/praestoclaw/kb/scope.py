"""Which knowledge base a *group* writes to, and where in it.

The operator's ``praesto_tag_exp.kb.repos`` says what this agent may ever write
to on the lending employee's behalf — it is the authorisation boundary and only
they can widen it. This module adds the second, per-conversation half: which of
those repositories *this* group uses, and which folder inside it the group
prefers. That half is set from the chat, because it is a working preference
rather than a permission.

Two properties are worth stating because the rest of the flow leans on them:

* **The subfolder is a preference, not a fence.** It is where rules are read
  from and where drafts land by default. Curation may still propose a different
  area when the repository's own conventions point elsewhere — that judgement
  belongs to ``kb_inspect(action="rules")``, not to this binding.
* **A configured subfolder always exists.** It is validated against a real
  checkout when it is set and stored as a repository-relative POSIX path. A
  binding that points at nothing would turn every later "draft it here" into a
  guess, and a guess is exactly what the group cannot review.

Repository references are matched **canonically, never by substring**. The
allowlist is expected to hold every repository the employee can reach, so a
loose match on a short word the group typed would quietly aim a later commit at
the wrong repository while reporting success.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.kb.repo import KbRepo, KbRepoError, normalize_remote, remote_slug

SCOPE_FILENAME = "kb.json"


class ScopeError(Exception):
    """Base class for a knowledge-base scope problem worth reporting verbatim."""


class RepoNotAllowedError(ScopeError):
    """The requested repository is not in the operator's allowlist."""

    def __init__(self, wanted: str, allowed: list[str]) -> None:
        self.wanted = wanted
        self.allowed = list(allowed)
        super().__init__(f"{wanted!r} is not an allowed knowledge base")


class RepoAmbiguousError(ScopeError):
    """A bare repository name matched more than one allowlist entry."""

    def __init__(self, wanted: str, candidates: list[str]) -> None:
        self.wanted = wanted
        self.candidates = list(candidates)
        super().__init__(f"{wanted!r} matches several allowed knowledge bases")


class SubfolderMissingError(ScopeError):
    """The requested folder does not exist in the checkout."""

    def __init__(self, subfolder: str, existing_at: str, siblings: list[str]) -> None:
        self.subfolder = subfolder
        self.existing_at = existing_at
        self.siblings = list(siblings)
        super().__init__(f"{subfolder!r} does not exist in the knowledge base")


class SubfolderNotADirectoryError(ScopeError):
    """The requested path exists but is a file."""

    def __init__(self, subfolder: str) -> None:
        self.subfolder = subfolder
        super().__init__(f"{subfolder!r} is a file, not a folder")


@dataclass(frozen=True, slots=True)
class KbScope:
    """One group's chosen knowledge base and preferred area within it."""

    repo: str
    subfolder: str = ""
    set_by: str = ""
    set_at: str = ""
    subject_id: str = ""
    tenant_id: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "repo": self.repo,
            "subfolder": self.subfolder,
            "set_by": self.set_by,
            "set_at": self.set_at,
            "subject_id": self.subject_id,
            "tenant_id": self.tenant_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> KbScope | None:
        repo = str((data or {}).get("repo") or "").strip()
        if not repo:
            return None
        return cls(
            repo=repo,
            subfolder=str(data.get("subfolder") or "").strip(),
            set_by=str(data.get("set_by") or "").strip(),
            set_at=str(data.get("set_at") or "").strip(),
            subject_id=str(data.get("subject_id") or "").strip(),
            tenant_id=str(data.get("tenant_id") or "").strip(),
        )

    def describe(self) -> str:
        """One-line human summary used in tool output and group replies."""
        where = f"{self.repo}/{self.subfolder}" if self.subfolder else self.repo
        if self.set_by:
            return f"{where} (set by {self.set_by})"
        return where


# ── allowlist resolution ────────────────────────────────────────────────────


def allowlist(config: Any) -> list[str]:
    """The operator-configured repositories, in configuration order."""
    return [str(item).strip() for item in getattr(config, "repos", []) or [] if item]


def _canonical(reference: str) -> str | None:
    """``owner/name`` / URL / local path → comparable slug, or ``None``.

    ``None`` means "not a repository reference this machine can make sense of",
    which is the normal answer for a bare name like ``TeamKb``. That is not an
    error here: bare names are resolved separately, against the allowlist.
    """
    try:
        return remote_slug(normalize_remote(reference))
    except (ValueError, KbRepoError):
        return None


def _bare_name(entry: str) -> str:
    """Last path component of an allowlist entry, lowercased, without ``.git``."""
    cleaned = entry.strip().rstrip("/").replace("\\", "/")
    if cleaned.endswith(".git"):
        cleaned = cleaned[: -len(".git")]
    tail = cleaned.rsplit("/", 1)[-1]
    return tail.rsplit(":", 1)[-1].strip().lower()


def resolve_allowed_repo(allowed: list[str], wanted: str) -> str:
    """Map a requested repository onto exactly one allowlist entry.

    Matching is canonical (``owner/name``, clone URL and local path all compare
    equal when they denote the same repository) with one convenience: a bare
    repository name is accepted when it identifies a single entry. Anything
    less certain raises, because the alternative is aiming a later commit at a
    repository nobody chose.
    """
    entries = [entry for entry in allowed if entry]
    if not entries:
        raise RepoNotAllowedError(wanted, [])
    request = (wanted or "").strip()
    if not request:
        raise RepoNotAllowedError(request, entries)

    wanted_slug = _canonical(request)
    if wanted_slug:
        for entry in entries:
            if _canonical(entry) == wanted_slug:
                return entry

    # A bare name ("TeamKb") carries no owner, so it may only be accepted when
    # the allowlist leaves no doubt about which repository is meant.
    if "/" not in request and ":" not in request:
        matches = [entry for entry in entries if _bare_name(entry) == request.strip().lower()]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise RepoAmbiguousError(request, matches)

    raise RepoNotAllowedError(request, entries)


# ── subfolder resolution ────────────────────────────────────────────────────


def normalize_subfolder(subfolder: str) -> str:
    """Trim a user-typed folder into a repository-relative POSIX path."""
    cleaned = (subfolder or "").strip().replace("\\", "/")
    while "//" in cleaned:
        cleaned = cleaned.replace("//", "/")
    return cleaned.strip("/").strip()


def resolve_subfolder(repo: KbRepo, subfolder: str) -> str:
    """Validate *subfolder* against a real checkout and return its clean form.

    An empty request is legitimate and means "no preferred area". Anything else
    must resolve to a directory that exists right now: the binding is meant to
    make later drafting predictable, and a path that does not exist cannot do
    that. Depth is unrestricted — a third-level folder is as valid as a
    top-level one.
    """
    cleaned = normalize_subfolder(subfolder)
    if not cleaned:
        return ""

    root = repo.path.resolve()
    candidate = (root / cleaned).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise SubfolderMissingError(cleaned, "", _child_dirs(root)) from None
    if candidate == root:
        return ""

    if candidate.is_dir():
        return candidate.relative_to(root).as_posix()
    if candidate.exists():
        raise SubfolderNotADirectoryError(cleaned)

    # Report the deepest part of the path that *does* exist, so the group is
    # told where the trail goes cold instead of just "not found".
    existing = root
    for part in Path(cleaned).parts:
        probe = existing / part
        if probe.is_dir():
            existing = probe
        else:
            break
    rel = "" if existing == root else existing.relative_to(root).as_posix()
    raise SubfolderMissingError(cleaned, rel, _child_dirs(existing))


def _child_dirs(directory: Path, limit: int = 40) -> list[str]:
    """Visible child directory names, so a rejection can suggest real options."""
    try:
        names = sorted(
            item.name
            for item in directory.iterdir()
            if item.is_dir() and not item.name.startswith(".")
        )
    except OSError:
        return []
    return names[:limit]


# ── persistence ─────────────────────────────────────────────────────────────


class GroupScopeStore:
    """Reads and writes ``kb.json`` beside a group's own ``MEMORY.md``.

    The binding lives with the rest of that conversation's isolated state, so
    it inherits the same per-conversation separation: one group can neither see
    nor change another group's knowledge base.
    """

    def __init__(self, group_store: Any) -> None:
        self._groups = group_store

    def path(self, cid: str) -> Path:
        group_dir: Path = self._groups.group_dir(cid)
        return group_dir / SCOPE_FILENAME

    def read(self, cid: str) -> KbScope | None:
        path = self.path(cid)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            logger.warning("kb scope unreadable for cid={}: {}", cid, exc)
            return None
        if not isinstance(data, dict):
            return None
        return KbScope.from_dict(data)

    def write(self, cid: str, scope: KbScope) -> KbScope:
        stored = KbScope(
            repo=scope.repo,
            subfolder=scope.subfolder,
            set_by=scope.set_by,
            set_at=scope.set_at or datetime.now(UTC).isoformat(),
            subject_id=scope.subject_id,
            tenant_id=scope.tenant_id,
        )
        group_dir = self._groups.group_dir(cid)
        group_dir.mkdir(parents=True, exist_ok=True)
        path = group_dir / SCOPE_FILENAME
        path.write_text(
            json.dumps(stored.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        logger.info("kb scope: cid={} repo={} subfolder={}", cid, stored.repo, stored.subfolder)
        return stored

    def clear(self, cid: str) -> bool:
        path = self.path(cid)
        if not path.is_file():
            return False
        path.unlink()
        logger.info("kb scope cleared: cid={}", cid)
        return True


__all__ = [
    "SCOPE_FILENAME",
    "GroupScopeStore",
    "KbScope",
    "RepoAmbiguousError",
    "RepoNotAllowedError",
    "ScopeError",
    "SubfolderMissingError",
    "SubfolderNotADirectoryError",
    "allowlist",
    "normalize_subfolder",
    "resolve_allowed_repo",
    "resolve_subfolder",
]
