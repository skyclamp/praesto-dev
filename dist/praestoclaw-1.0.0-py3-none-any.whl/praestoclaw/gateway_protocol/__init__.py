"""Client-side Agent-Gateway protocol implementation.

This package is intentionally standalone. It implements the new transport and
business protocol layers without wiring them into the existing channel/runtime
code paths yet.
"""

from praestoclaw.gateway_protocol.transport import (
    GatewayTransportClient,
    PayloadTooLargeError,
    TransportClientConfig,
    TransportCloseCodes,
    TransportDisconnectedBackpressureError,
    TransportError,
    TransportEvent,
    TransportState,
    TransportWireProtocol,
)

__all__ = [
    "GatewayTransportClient",
    "PayloadTooLargeError",
    "TransportClientConfig",
    "TransportCloseCodes",
    "TransportDisconnectedBackpressureError",
    "TransportError",
    "TransportEvent",
    "TransportState",
    "TransportWireProtocol",
]
