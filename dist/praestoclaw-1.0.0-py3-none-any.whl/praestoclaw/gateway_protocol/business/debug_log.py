"""Structured debug logging for Agent-Gateway business envelopes."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal

from loguru import logger

from praestoclaw.gateway_protocol.business.envelope import Envelope, json_size


def log_business_envelope_debug(direction: Literal["rx", "tx"], envelope: Envelope) -> None:
    """Log one business envelope in the same compact shape as the Gateway."""

    logger.debug(
        "{} [{}] {}",
        _direction_icon(direction),
        _message_type(envelope),
        _message_summary(envelope),
    )


def _direction_icon(direction: Literal["rx", "tx"]) -> str:
    return "⬇" if direction == "rx" else "⬆"


def _message_type(envelope: Envelope) -> str:
    if envelope.topic:
        return f"{envelope.kind.value}:{envelope.topic}"
    return envelope.kind.value


def _message_summary(envelope: Envelope) -> str:
    parts = [f"id={envelope.id}"]
    if envelope.correlation_id:
        parts.append(f"correlation_id={envelope.correlation_id}")
    parts.extend(_body_summary_parts(envelope.body))
    return " ".join(parts)


def _body_summary_parts(body: Mapping[str, Any]) -> list[str]:
    parts: list[str] = []

    identity = body.get("identity")
    if isinstance(identity, Mapping):
        parts.append(f"identity={identity.get('user_id', '')}/{identity.get('agent_id', '')}")

    features = body.get("features")
    if isinstance(features, list):
        parts.append(f"features={','.join(str(feature) for feature in features)}")

    scope = body.get("scope")
    if scope is not None:
        parts.append(f"scope={scope}")

    sender = body.get("sender")
    if isinstance(sender, Mapping):
        parts.append(
            "sender="
            f"{sender.get('kind', '')}:"
            f"{sender.get('user_id') or sender.get('id') or ''}/"
            f"{sender.get('agent_id') or ''}"
        )

    recipient = body.get("recipient")
    if isinstance(recipient, Mapping):
        parts.append(
            "recipient="
            f"{recipient.get('kind', '')}:"
            f"{recipient.get('user_id') or recipient.get('id') or ''}/"
            f"{recipient.get('agent_id') or recipient.get('channel') or ''}"
        )

    query = body.get("query")
    if isinstance(query, Mapping):
        parts.append(
            f"query={query.get('kind', '')}:{query.get('user_id') or query.get('agent_id') or ''}"
        )

    subject = body.get("subject")
    if isinstance(subject, Mapping):
        parts.append(f"subject={subject.get('user_id') or ''}/{subject.get('agent_id') or ''}")

    presence = body.get("presence")
    if isinstance(presence, Mapping):
        parts.append(f"presence={presence.get('state') or ''}")

    content_text = _body_text(body)
    if content_text:
        parts.append(f"text={_truncate_for_log(content_text)}")

    if "accepted" in body:
        parts.append(f"accepted={body.get('accepted')}")
    if "code" in body:
        parts.append(f"code={body.get('code')}")
    if "message" in body:
        parts.append(f"message={_truncate_for_log(str(body.get('message')))}")

    if not parts:
        parts.append(f"body_bytes={json_size(body)}")
    return parts


def _body_text(body: Mapping[str, Any]) -> str:
    content = body.get("content")
    if isinstance(content, Mapping):
        text = content.get("text")
        if text is not None:
            return str(text)
    text = body.get("text")
    if text is not None:
        return str(text)
    return ""


def _truncate_for_log(value: str, limit: int = 160) -> str:
    clean = " ".join(value.split())
    if len(clean) <= limit:
        return clean
    return f"{clean[: limit - 1]}…"
