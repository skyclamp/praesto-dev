"""Topic registry, lifecycle tracking, and concurrent business dispatch."""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import AsyncIterator, Callable, Coroutine, Mapping
from dataclasses import dataclass, field, replace
from typing import Any, Literal

from loguru import logger

from praestoclaw.gateway_protocol.business.data import (
    FileChunkContent,
    SessionBye,
    validate_conversation_body,
)
from praestoclaw.gateway_protocol.business.envelope import (
    BusinessError,
    BusinessProtocolError,
    Envelope,
    EnvelopeKind,
    is_valid_reserved_topic,
    is_valid_topic,
)
from praestoclaw.gateway_protocol.business.outbound import Outbound

Handler = Callable[[dict[str, Any], "RequestContext"], Any]
SessionEventHandler = Callable[[dict[str, Any]], Any]
SerialScope = Literal["per_topic", "per_conversation_id", "per_session"]


@dataclass
class CancelScope:
    """Coroutine-friendly cancellation token for one request correlation."""

    reason: str | None = None
    _event: asyncio.Event = field(default_factory=asyncio.Event)

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def cancel(self, reason: str | None = None) -> None:
        if self.cancelled:
            return
        self.reason = reason or "caller_cancelled"
        self._event.set()

    async def wait_cancelled(self) -> str | None:
        await self._event.wait()
        return self.reason


@dataclass
class RequestContext:
    """Context exposed to business handlers."""

    principal: Any | None = None
    session_id: str | None = None
    connection_epoch: int | None = None
    envelope: Envelope | None = None
    cancel_scope: CancelScope | None = None
    outbound: Outbound | None = None
    features: frozenset[str] = frozenset()
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def transport_session_id(self) -> str | None:
        """Compatibility alias for callers that still use the old field name."""

        return self.session_id

    @property
    def negotiated_features(self) -> frozenset[str]:
        """Compatibility alias for callers that still use the old field name."""

        return self.features


@dataclass(frozen=True)
class _HandlerRegistration:
    handler: Handler
    serial_scope: SerialScope | None = None


@dataclass
class _CorrelationEntry:
    state: str
    cancel_scope: CancelScope
    task: asyncio.Task[None] | None = None


class Dispatcher:
    """Ordered per-session business envelope dispatcher.

    `dispatch()` performs cheap ordered validation/lifecycle updates, then
    schedules handler execution in background tasks so unrelated correlations
    can run concurrently.
    """

    def __init__(self) -> None:
        self._event_handlers: dict[str, _HandlerRegistration] = {}
        self._request_handlers: dict[str, _HandlerRegistration] = {}
        self._session_event_handlers: dict[str, list[SessionEventHandler]] = {}
        self._correlations: dict[str, _CorrelationEntry] = {}
        self._tasks: set[asyncio.Task[None]] = set()
        self._locks: dict[tuple[str, str], asyncio.Lock] = {}

    def on_event(
        self,
        topic: str,
        *,
        serial_scope: SerialScope | None = None,
    ) -> Callable[[Handler], Handler]:
        """Register an event handler decorator."""

        def decorator(handler: Handler) -> Handler:
            self._event_handlers[topic] = _HandlerRegistration(handler, serial_scope)
            return handler

        return decorator

    def on_request(
        self,
        topic: str,
        *,
        serial_scope: SerialScope | None = None,
    ) -> Callable[[Handler], Handler]:
        """Register a request handler decorator."""

        def decorator(handler: Handler) -> Handler:
            self._request_handlers[topic] = _HandlerRegistration(handler, serial_scope)
            return handler

        return decorator

    def on_session_event(self, kind: str) -> Callable[[SessionEventHandler], SessionEventHandler]:
        """Register a transport lifecycle callback."""

        def decorator(handler: SessionEventHandler) -> SessionEventHandler:
            self._session_event_handlers.setdefault(kind, []).append(handler)
            return handler

        return decorator

    async def emit_session_event(self, kind: str, payload: Mapping[str, Any]) -> None:
        """Invoke registered session lifecycle callbacks sequentially."""

        for handler in self._session_event_handlers.get(kind, []):
            try:
                result = handler(dict(payload))
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                logger.exception("Unhandled session event handler error for {}: {}", kind, exc)

    async def dispatch(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        outbound: Outbound | None = None,
    ) -> None:
        """Dispatch one already-parsed envelope."""

        active_outbound = outbound or ctx.outbound
        if active_outbound is None:
            raise BusinessProtocolError("outbound is required")

        if await active_outbound.handle_incoming(envelope):
            return

        if envelope.kind is EnvelopeKind.EVENT and envelope.topic == "_session.bye":
            await self._handle_inbound_session_bye(envelope, ctx)
            return

        request_ctx = replace(ctx, envelope=envelope, outbound=active_outbound)
        if envelope.kind is EnvelopeKind.EVENT:
            self._dispatch_event(envelope, request_ctx)
            return
        if envelope.kind is EnvelopeKind.REQUEST:
            await self._dispatch_request(envelope, request_ctx, active_outbound)
            return
        if envelope.kind is EnvelopeKind.CANCEL:
            self._handle_cancel(envelope)
            return
        self._record_lifecycle_violation(envelope)

    async def wait_idle(self) -> None:
        """Wait for currently scheduled handler tasks to finish."""

        while self._tasks:
            await asyncio.gather(*list(self._tasks), return_exceptions=True)

    def _dispatch_event(self, envelope: Envelope, ctx: RequestContext) -> None:
        topic = envelope.topic or ""
        if not self._topic_allowed(topic):
            logger.warning("Dropping event with invalid topic {}", topic)
            return
        registration = self._event_handlers.get(topic)
        if registration is None:
            logger.debug("Dropping event for unregistered topic {}", topic)
            return
        self._schedule(self._run_event(envelope, ctx, registration))

    async def _handle_inbound_session_bye(
        self,
        envelope: Envelope,
        ctx: RequestContext,
    ) -> None:
        try:
            bye = SessionBye.parse(envelope.body)
        except BusinessProtocolError as exc:
            logger.warning("Dropping malformed _session.bye: {}", exc)
            bye = SessionBye()
        logger.info(
            "Session bye received: reason={} message={} session_id={}",
            bye.reason,
            bye.message,
            ctx.session_id,
        )
        await self.emit_session_event(
            "bye",
            {
                "reason": bye.reason,
                "message": bye.message,
                "details": dict(bye.details),
                "session_id": ctx.session_id,
                "connection_epoch": ctx.connection_epoch,
            },
        )

    async def _dispatch_request(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        outbound: Outbound,
    ) -> None:
        topic = envelope.topic or ""
        if not self._topic_allowed(topic):
            await outbound.send_error(
                envelope.id,
                BusinessError("invalid_topic", f"invalid topic: {topic}", retryable=False),
            )
            return

        registration = self._request_handlers.get(topic)
        if registration is None:
            await outbound.send_error(
                envelope.id,
                BusinessError("unknown_topic", f"unknown topic: {topic}", retryable=False),
            )
            return

        required_feature = self._required_feature_for_topic(topic)
        if required_feature is not None and required_feature not in ctx.features:
            await outbound.send_error(
                envelope.id,
                BusinessError(
                    "feature_not_enabled",
                    f"feature not enabled for topic: {topic}",
                    retryable=False,
                ),
            )
            return

        try:
            parsed_body = self._validate_topic_body(envelope)
        except BusinessProtocolError as exc:
            await outbound.send_error(
                envelope.id,
                BusinessError("invalid_envelope", str(exc), retryable=False),
            )
            return
        if (
            parsed_body is not None
            and isinstance(parsed_body.content, FileChunkContent)
            and "file_stream" not in ctx.features
        ):
            await outbound.send_error(
                envelope.id,
                BusinessError(
                    "feature_not_enabled",
                    "file_stream feature is not enabled",
                    retryable=False,
                ),
            )
            return

        cancel_scope = CancelScope()
        self._correlations[envelope.id] = _CorrelationEntry("open", cancel_scope)
        request_ctx = replace(ctx, cancel_scope=cancel_scope)
        task = self._schedule(self._run_request(envelope, request_ctx, outbound, registration))
        self._correlations[envelope.id].task = task

    async def _run_event(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        registration: _HandlerRegistration,
    ) -> None:
        try:
            async with self._handler_lock(envelope, registration.serial_scope):
                result = registration.handler(dict(envelope.body), ctx)
                if inspect.isawaitable(result):
                    await result
        except Exception as exc:
            logger.exception("Unhandled event handler error for topic {}: {}", envelope.topic, exc)

    async def _run_request(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        outbound: Outbound,
        registration: _HandlerRegistration,
    ) -> None:
        try:
            async with self._handler_lock(envelope, registration.serial_scope):
                await self._execute_request_handler(envelope, ctx, outbound, registration.handler)
        except BusinessError as exc:
            await outbound.send_error(envelope.id, exc)
        except TimeoutError:
            await outbound.send_error(
                envelope.id,
                BusinessError("timeout", "request deadline exceeded", retryable=True),
            )
        except asyncio.CancelledError:
            await outbound.send_error(
                envelope.id,
                BusinessError("cancelled", "request was cancelled", retryable=False),
            )
        except Exception as exc:
            logger.exception(
                "Unhandled request handler error for topic {}: {}", envelope.topic, exc
            )
            await outbound.send_error(
                envelope.id,
                BusinessError("internal", "internal handler error", retryable=True),
            )
        finally:
            entry = self._correlations.get(envelope.id)
            if entry is not None:
                entry.state = "terminal"
                self._correlations.pop(envelope.id, None)

    async def _execute_request_handler(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        outbound: Outbound,
        handler: Handler,
    ) -> None:
        timeout_s = self._deadline_timeout_s(envelope.headers)
        async with self._maybe_timeout(timeout_s):
            result = handler(dict(envelope.body), ctx)
            if inspect.isawaitable(result):
                result = await result

            if inspect.isasyncgen(result) or isinstance(result, AsyncIterator):
                await self._send_stream_result(envelope, ctx, outbound, result)
                return

            if ctx.cancel_scope and ctx.cancel_scope.cancelled:
                raise BusinessError("cancelled", "request was cancelled", retryable=False)
            body = result if isinstance(result, Mapping) else {"value": result}
            await outbound.send_response(envelope.id, body)

    async def _send_stream_result(
        self,
        envelope: Envelope,
        ctx: RequestContext,
        outbound: Outbound,
        result: Any,
    ) -> None:
        async for item in result:
            if ctx.cancel_scope and ctx.cancel_scope.cancelled:
                raise BusinessError("cancelled", "request was cancelled", retryable=False)
            if not isinstance(item, Mapping):
                raise BusinessError(
                    "invalid_envelope",
                    "stream handler yielded a non-object body",
                    retryable=False,
                )
            entry = self._correlations.get(envelope.id)
            if entry is not None:
                entry.state = "streaming"
            await outbound.send_stream_item(envelope.id, item)
        await outbound.send_stream_end(envelope.id, {"reason": "complete"})

    def _handle_cancel(self, envelope: Envelope) -> None:
        correlation_id = envelope.correlation_id
        if correlation_id is None:
            return
        entry = self._correlations.get(correlation_id)
        if entry is None or entry.state == "terminal":
            return
        reason = envelope.body.get("reason")
        entry.cancel_scope.cancel(str(reason) if reason is not None else "caller_cancelled")
        if entry.task is not None and not entry.task.done():
            entry.task.cancel()

    def _record_lifecycle_violation(self, envelope: Envelope) -> None:
        logger.debug(
            "Dropping unmatched business reply/control envelope {} for {}",
            envelope.kind.value,
            envelope.correlation_id,
        )

    def _schedule(self, awaitable: Coroutine[Any, Any, None]) -> asyncio.Task[None]:
        task = asyncio.create_task(awaitable)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return task

    def _handler_lock(self, envelope: Envelope, scope: SerialScope | None) -> asyncio.Lock:
        if scope is None:
            return _NoopAsyncLock()
        if scope == "per_session":
            key = ("session", "*")
        elif scope == "per_topic":
            key = ("topic", envelope.topic or "")
        else:
            conversation_id = ""
            context = envelope.body.get("context")
            if isinstance(context, Mapping):
                value = context.get("conversation_id")
                if isinstance(value, str):
                    conversation_id = value
            key = ("conversation", conversation_id)
        return self._locks.setdefault(key, asyncio.Lock())

    @staticmethod
    def _deadline_timeout_s(headers: Mapping[str, Any]) -> float | None:
        deadline_ms = headers.get("deadline_ms")
        if not isinstance(deadline_ms, int) or isinstance(deadline_ms, bool) or deadline_ms <= 0:
            return None
        return deadline_ms / 1000

    @staticmethod
    def _maybe_timeout(timeout_s: float | None) -> Any:
        if timeout_s is None:
            return _NoopAsyncLock()
        return asyncio.timeout(timeout_s)

    @staticmethod
    def _topic_allowed(topic: str) -> bool:
        return is_valid_topic(topic) or is_valid_reserved_topic(topic)

    @staticmethod
    def _required_feature_for_topic(topic: str) -> str | None:
        if topic.startswith("conversation."):
            return "conversation"
        if topic.startswith("a2a."):
            return "a2a"
        if topic.startswith("u2u."):
            return "u2u"
        return None

    @staticmethod
    def _validate_topic_body(envelope: Envelope) -> Any | None:
        if envelope.topic in {"conversation.message.send", "conversation.message.stream"}:
            return validate_conversation_body(envelope.body)
        return None


class _NoopAsyncLock(asyncio.Lock):
    """Tiny async context manager with the same shape as `asyncio.timeout`."""

    async def __aenter__(self) -> None:
        return None

    async def __aexit__(self, *args: object) -> None:
        return None
