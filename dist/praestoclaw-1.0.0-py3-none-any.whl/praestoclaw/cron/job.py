"""Job dataclass and schedule utility functions for the cron subsystem."""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from praestoclaw.config.schema import ChannelType


@dataclass(frozen=True, slots=True)
class ScheduledKbCapability:
    """Immutable KB read provenance captured from a trusted personal Teams turn."""

    version: int
    job_id: str
    conversation_id: str
    subject_id: str
    tenant_id: str
    repo: str
    subfolder: str
    scope_set_at: str
    granted_at: str
    origin_session_id: str = ""
    issuer: str = "trusted_teams_personal"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: object) -> ScheduledKbCapability | None:
        if not isinstance(data, dict):
            return None
        try:
            capability = cls(
                version=int(data.get("version", 0)),
                job_id=str(data.get("job_id") or "").strip(),
                conversation_id=str(data.get("conversation_id") or "").strip(),
                subject_id=str(data.get("subject_id") or "").strip(),
                tenant_id=str(data.get("tenant_id") or "").strip(),
                repo=str(data.get("repo") or "").strip(),
                subfolder=str(data.get("subfolder") or "").strip(),
                scope_set_at=str(data.get("scope_set_at") or "").strip(),
                granted_at=str(data.get("granted_at") or "").strip(),
                origin_session_id=str(data.get("origin_session_id") or "").strip(),
                issuer=str(data.get("issuer") or "").strip(),
            )
        except (TypeError, ValueError):
            return None
        required = (
            capability.job_id,
            capability.conversation_id,
            capability.subject_id,
            capability.tenant_id,
            capability.repo,
            capability.scope_set_at,
            capability.granted_at,
        )
        if capability.version != 1 or capability.issuer != "trusted_teams_personal":
            return None
        return capability if all(required) else None


def normalize_channel_list(value: Any) -> list[str] | None:
    """Coerce a ``notify_channels`` value into ``list[str] | None``.

    LLM tool-call payloads sometimes pass a JSON-encoded string such as
    ``'["cloud"]'`` (or a bare ``'cloud'``) instead of a real list. Left
    uncoerced, a string is later iterated character-by-character
    (``list('["cloud"]')``) and each character is routed to a garbage channel,
    silently dropping the message. This normalizes such inputs to a proper
    list.

    Returns ``None`` for ``None`` or empty/whitespace strings so callers can
    apply their own default.  Returns ``[]`` for empty collections (e.g. an
    empty list) so callers can distinguish "caller explicitly passed nothing"
    from "caller didn't pass anything".
    """
    if value is None:
        return None
    if isinstance(value, str):
        raw = value.strip()
        if not raw:
            return None
        try:
            parsed: Any = json.loads(raw)
        except (ValueError, TypeError):
            parsed = raw
        if isinstance(parsed, list):
            return [s for c in parsed if (s := _channel_str(c))]
        text = _channel_str(parsed)
        return [text] if text else None
    if isinstance(value, (list, tuple, set)):
        return [s for c in value if (s := _channel_str(c))]
    text = _channel_str(value)
    return [text] if text else None


def _channel_str(item: Any) -> str:
    """Convert a single channel value to its string name, or empty string."""
    if item is None:
        return ""
    if hasattr(item, "value"):
        # ChannelType enum → use .value ("cloud") not repr ("ChannelType.CLOUD")
        return str(item.value).strip()
    return str(item).strip()


def prompt_requires_current_kb_scope(prompt: str) -> bool:
    """Whether a scheduled prompt explicitly invokes the KB-backed PMO grill."""
    return bool(
        re.search(
            r"(?:^|[^A-Za-z0-9])pmo[\s_-]*grill(?![A-Za-z0-9])",
            str(prompt or ""),
            flags=re.IGNORECASE,
        )
    )


@dataclass
class Job:
    """Internal representation of a scheduled job."""

    name: str
    schedule: str | int  # cron expr, interval seconds, or event type
    agent: str
    prompt: str
    message: str | None = None  # static text mode (zero execution)
    tool: str | None = None
    arguments: dict[str, Any] | None = None
    workflow_recipe: str | None = None  # workflow recipe name; body resolved fresh at each fire
    session_mode: str = "isolated"
    notify_channels: list[str] = field(default_factory=lambda: ["*"])
    exclude_tools: list[str] = field(default_factory=list)
    enabled: bool = True
    description: str | None = None  # free-text label shown in UI
    last_run_at: str | None = None  # ISO8601 UTC, set by SchedulerService after each run
    last_status: str | None = None  # "success" | "error" | None (never run)
    last_error: str | None = None  # truncated error message (≤500 chars), None on success
    pending_catchup_at: str | None = None  # missed cron occurrence awaiting a successful retry
    dynamic: bool = False  # True if added via CronTool/CLI (persisted to jobs.json)
    failure_count: int = 0
    channel: ChannelType | None = None  # originating channel (e.g. "cloud")
    # Originating channel_id for ordinary jobs. Societas scanner jobs preserve
    # their trusted personal-Teams owner scope here for legacy jobs.json compatibility.
    channel_id: str | None = None
    # Read-only KB scope captured from a trusted personal Teams turn. The
    # scheduler restores this capability without restoring a stale ReplyContext.
    kb_capability: ScheduledKbCapability | None = None
    created_at: str | None = None  # ISO timestamp
    updated_at: str | None = None  # ISO timestamp (set on replace)
    timezone: str | None = None  # IANA name; None → server tzlocal() at trigger time
    _running: bool = field(default=False, repr=False)  # guard against concurrent execution


def safe_filename(name: str) -> str:
    """Sanitize job name for use in file paths."""
    return re.sub(r"[^\w\-.]", "_", name)[:100]


def _resolve_at_timezone(timezone: str | None):
    """Resolve the timezone used for naive absolute `at:` schedules."""
    if timezone:
        from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

        try:
            return ZoneInfo(timezone)
        except ZoneInfoNotFoundError:
            logger.error("Unknown timezone for 'at' schedule: {!r}", timezone)
            return None

    try:
        from tzlocal import get_localzone

        return get_localzone()
    except Exception as exc:  # noqa: BLE001 - tzlocal may be absent or unable to detect local tz
        logger.warning(
            "Could not resolve local timezone for 'at' schedule; falling back to UTC: {}", exc
        )
        return UTC


def parse_at_schedule(schedule: str, timezone: str | None = None) -> datetime | None:
    """Parse 'at' schedule into target datetime.

    Formats:
      'at'                            → None (immediate)
      'at:+60'                        → now + 60 seconds (relative)
      'at:2026-03-04T15:00:00'        → absolute ISO datetime (uses timezone or local tz)
      'at:2026-03-04T15:00:00+08:00'  → absolute ISO with timezone
    """
    from datetime import timedelta

    s = str(schedule).strip()
    # "at" with nothing after → immediate
    if len(s) <= 2 or s[2:3] != ":":
        return None
    value = s[3:]  # everything after "at:"
    if not value:
        return None
    if value.startswith("+"):
        try:
            seconds = int(value[1:])
        except ValueError:
            logger.error("Invalid relative 'at' schedule {!r}; expected integer after '+'", value)
            return None
        return datetime.now(UTC) + timedelta(seconds=seconds)
    # Absolute ISO datetime
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        logger.error("Invalid absolute 'at' schedule {!r}; expected ISO 8601 datetime", value)
        return None
    if dt.tzinfo is None:
        tz = _resolve_at_timezone(timezone)
        if tz is None:
            return None
        dt = dt.replace(tzinfo=tz)
    return dt


def detect_trigger_type(schedule: str | int) -> str:
    """Auto-detect trigger type from schedule value.

    Supports: cron expressions, interval seconds, event types,
    and 'at' one-shot (immediate, relative delay, or absolute ISO datetime).
    """
    if isinstance(schedule, str):
        s = schedule.strip().lower()
        if s == "at" or s.startswith("at:"):
            return "at"
    if isinstance(schedule, int):
        return "interval"
    # JSON may deserialize 3600 as string — check if it's a numeric string
    if isinstance(schedule, str) and schedule.isdigit():
        return "interval"
    if (
        isinstance(schedule, str)
        and "." in schedule
        and schedule.replace(".", "").replace("_", "").isalpha()
    ):
        return "event"
    return "cron"
