"""Tools CLI subcommands — praestoclaw tools list|info."""

from __future__ import annotations

import typer
from rich.panel import Panel
from rich.table import Table

from praestoclaw.cli.commands import (
    _get_runtime,
    console,
    tools_app,
)


@tools_app.command("list")
def tools_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    profile: str | None = typer.Option(None, "--profile", "-p", help="Config profile"),
) -> None:
    """List all available tools (built-in + MCP)."""
    rt = _get_runtime(config, profile)

    active_names = {t.name for t in rt.tool_registry.get_active_tools()}

    table = Table(title="Built-in Tools")
    table.add_column("Tool", style="bold")
    table.add_column("Tier")
    table.add_column("Status")
    table.add_column("Description")

    for tool in rt.tool_registry.list_tools_sorted():
        if tool.metadata.category == "mcp":
            continue
        brief = tool.description.split(".")[0]
        status = "[green]active[/green]" if tool.name in active_names else "[dim]inactive[/dim]"
        table.add_row(tool.name, tool.metadata.tier, status, brief)

    console.print(table)

    # MCP tools
    cfg = rt.config
    mcp_servers = cfg.tools.mcp_servers
    if mcp_servers:
        mcp_table = Table(title="MCP Servers")
        mcp_table.add_column("Name", style="bold")
        mcp_table.add_column("Transport")
        mcp_table.add_column("Command / URL")

        for name, srv in mcp_servers.items():
            if srv.command:
                cmd_display = f"{srv.command} {' '.join(srv.args)}"
                mcp_table.add_row(name, "stdio", cmd_display)
            elif srv.url:
                mcp_table.add_row(name, "http", srv.url)
            else:
                mcp_table.add_row(name, "[dim]unknown[/dim]", "")

        console.print(mcp_table)
    else:
        console.print("\n[dim]No MCP servers configured.[/dim]")


@tools_app.command("info")
def tools_info(
    name: str = typer.Argument(..., help="Tool name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed info for a specific tool."""
    import json as _json

    rt = _get_runtime(config)
    tool = rt.tool_registry.get(name)
    if tool is None:
        console.print(f"[red]Tool not found:[/red] {name}")
        raise typer.Exit(1)

    console.print(Panel(f"[bold]{tool.name}[/bold]", border_style="blue"))
    console.print(f"[bold]Description:[/bold] {tool.description}\n")

    m = tool.metadata
    table = Table(title="Metadata")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Timeout", f"{m.timeout}s")
    table.add_row("Streaming", str(m.streaming))
    table.add_row("Category", m.category)
    console.print(table)

    console.print("\n[bold]Parameters (JSON Schema):[/bold]")
    from rich.syntax import Syntax

    console.print(Syntax(_json.dumps(tool.parameters, indent=2), "json", theme="monokai"))
