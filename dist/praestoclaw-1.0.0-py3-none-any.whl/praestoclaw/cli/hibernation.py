"""Hibernation Delay Agent bootstrap command."""

from __future__ import annotations

import ctypes
import os
import shutil
import subprocess
import sys
import tempfile
from importlib.resources import files
from pathlib import Path

import typer

from praestoclaw.cli.commands import app, console

_SCRIPT_PACKAGE = "praestoclaw.assets"
_SCRIPT_NAME = "HibernationDelayAgent-Bootstrap.ps1"


def _is_windows() -> bool:
    return sys.platform == "win32"


def _is_cpc_dev_box() -> bool:
    return os.environ.get("COMPUTERNAME", "").upper().startswith("CPC-")


def _is_already_installed() -> bool:
    """Return True when the 1ES Hibernation Delay Agent is already bootstrapped.

    Both probes are readable by a standard (non-elevated) user, so we can
    short-circuit before triggering a UAC prompt on every install.ps1 re-run.

    Signals (any one is sufficient):
      - The install script the bootstrap downloads:
        ``C:\\.tools\\Setup\\HibernationDelayAgent\\HibernationDelayAgent-Install.ps1``
      - The scheduled task the agent registers: ``1ESDevBoxHibernationDelayAgent``
    """
    if not _is_windows():
        return False

    install_script = Path(
        r"C:\.tools\Setup\HibernationDelayAgent\HibernationDelayAgent-Install.ps1"
    )
    if install_script.is_file():
        return True

    powershell = _powershell_executable()
    try:
        result = subprocess.run(
            [
                powershell,
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                "if (Get-ScheduledTask -TaskName '1ESDevBoxHibernationDelayAgent' "
                "-ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }",
            ],
            check=False,
            capture_output=True,
            timeout=10,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return result.returncode == 0


def _is_admin() -> bool:
    if not _is_windows():
        return False
    try:
        windll = getattr(ctypes, "windll", None)
        if windll is None:
            return False
        return bool(windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _powershell_executable() -> str:
    for candidate in ("powershell.exe", "powershell", "pwsh.exe", "pwsh"):
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
    return "powershell.exe"


def _materialize_bootstrap_script() -> Path:
    script_text = files(_SCRIPT_PACKAGE).joinpath(_SCRIPT_NAME).read_text(encoding="utf-8")
    target_dir = Path(os.environ.get("TEMP") or tempfile.gettempdir()) / "PraestoClaw"
    target_dir.mkdir(parents=True, exist_ok=True)
    target_path = target_dir / _SCRIPT_NAME
    target_path.write_text(script_text, encoding="utf-8")
    return target_path


def _ps_quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _run_direct(powershell: str, script_path: Path) -> int:
    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(script_path),
        ],
        check=False,
    )
    return result.returncode


def _run_elevated(powershell: str, script_path: Path) -> int:
    script_args = ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path)]
    argument_list = "@(" + ", ".join(_ps_quote(arg) for arg in script_args) + ")"
    command = (
        "$ErrorActionPreference = 'Stop'; "
        "try { "
        f"$p = Start-Process -FilePath {_ps_quote(powershell)} "
        f"-ArgumentList {argument_list} -Verb RunAs -Wait -PassThru; "
        "if ($null -eq $p.ExitCode) { exit 0 }; "
        "exit $p.ExitCode "
        "} catch { Write-Error $_; exit 1 }"
    )
    result = subprocess.run(
        [powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command],
        check=False,
    )
    return result.returncode


@app.command("hibernation-delay-agent")
def hibernation_delay_agent() -> None:
    """Bootstrap the 1ES Dev Box Hibernation Delay Agent on Windows Dev Boxes."""
    if not _is_windows():
        console.print(
            "[dim]Hibernation Delay Agent bootstrap is Windows-only; nothing to do.[/dim]"
        )
        return

    if not _is_cpc_dev_box():
        console.print("[dim]Not a CPC Dev Box; Hibernation Delay Agent bootstrap skipped.[/dim]")
        return

    if _is_already_installed():
        console.print(
            "[dim]Hibernation Delay Agent is already installed; skipping bootstrap "
            "(no UAC prompt needed).[/dim]"
        )
        return

    script_path = _materialize_bootstrap_script()
    powershell = _powershell_executable()

    if _is_admin():
        console.print("[cyan]Running Hibernation Delay Agent bootstrap...[/cyan]")
        return_code = _run_direct(powershell, script_path)
    else:
        console.print(
            "[yellow]Administrator approval is required to initialize the Hibernation Delay Agent.[/yellow]"
        )
        return_code = _run_elevated(powershell, script_path)

    if return_code != 0:
        console.print(
            f"[red]Hibernation Delay Agent bootstrap failed or was cancelled (exit {return_code}).[/red]"
        )
        raise typer.Exit(return_code if return_code > 0 else 1)

    console.print("[green]Hibernation Delay Agent bootstrap completed.[/green]")
