"""Autostart CLI command — praestoclaw autostart enable|disable|status.

Registers PraestoClaw to start automatically on user login.

Platform support:
  - Windows: Task Scheduler (schtasks) with ONLOGON trigger
  - Linux:   systemd user service (~/.config/systemd/user/)
  - macOS:   launchd plist (~/Library/LaunchAgents/)
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import typer

from praestoclaw.cli.commands import app, console

TASK_NAME = "PraestoClaw"
SERVICE_NAME = "praestoclaw"
LAUNCHD_LABEL = "com.praestoclaw.serve"


# ── Helpers ─────────────────────────────────────────────────────────────────


def _get_serve_command() -> list[str]:
    """Return the command list to launch ``praestoclaw serve``."""
    exe = shutil.which("praestoclaw") or shutil.which("pc")
    if exe:
        return [exe, "serve"]
    # Fallback: use current Python interpreter with -m
    return [sys.executable, "-m", "praestoclaw", "serve"]


# ── Windows (Registry HKCU\...\Run — no elevation required) ─────────────────

_WIN_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


def _windows_enable() -> bool:
    """Add a registry Run entry to start ``praestoclaw serve`` on logon."""
    import winreg

    cmd = _get_serve_command()
    # Build a quoted command string suitable for the Run key
    value = " ".join(f'"{c}"' if " " in c else c for c in cmd)

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, TASK_NAME, 0, winreg.REG_SZ, value)
        return True
    except OSError:
        return False


def _windows_disable() -> bool:
    """Remove the PraestoClaw registry Run entry."""
    import winreg

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, TASK_NAME)
        return True
    except FileNotFoundError:
        return True  # already absent
    except OSError:
        return False


def _windows_is_enabled() -> bool:
    """Check if the PraestoClaw registry Run entry exists."""
    import winreg

    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY, 0, winreg.KEY_QUERY_VALUE
        ) as key:
            winreg.QueryValueEx(key, TASK_NAME)
        return True
    except FileNotFoundError:
        return False
    except OSError:
        return False


# ── Linux (systemd) ────────────────────────────────────────────────────────


def _systemd_service_path() -> Path:
    return Path.home() / ".config" / "systemd" / "user" / f"{SERVICE_NAME}.service"


def _systemd_enable() -> bool:
    """Create and enable a systemd user service for ``praestoclaw serve``."""
    cmd = _get_serve_command()
    exec_start = " ".join(cmd)

    service_content = f"""\
[Unit]
Description=PraestoClaw AI Assistant
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={exec_start}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
"""
    service_path = _systemd_service_path()
    service_path.parent.mkdir(parents=True, exist_ok=True)
    service_path.write_text(service_content, encoding="utf-8")

    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True,
            timeout=10,
        )
        result = subprocess.run(
            ["systemctl", "--user", "enable", f"{SERVICE_NAME}.service"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def _systemd_disable() -> bool:
    """Disable and remove the systemd user service."""
    try:
        subprocess.run(
            ["systemctl", "--user", "stop", f"{SERVICE_NAME}.service"],
            capture_output=True,
            timeout=10,
        )
        subprocess.run(
            ["systemctl", "--user", "disable", f"{SERVICE_NAME}.service"],
            capture_output=True,
            timeout=10,
        )
    except Exception:
        pass

    service_path = _systemd_service_path()
    if service_path.exists():
        service_path.unlink()

    try:
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"],
            capture_output=True,
            timeout=10,
        )
    except Exception:
        pass
    return True


def _systemd_is_enabled() -> bool:
    """Check if the systemd user service is enabled."""
    try:
        result = subprocess.run(
            ["systemctl", "--user", "is-enabled", f"{SERVICE_NAME}.service"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.stdout.strip() == "enabled"
    except Exception:
        return False


# ── macOS (launchd) ─────────────────────────────────────────────────────────


def _launchd_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"


def _launchd_domain() -> str:
    return f"gui/{os.getuid()}"


def _launchd_run(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["launchctl", *args],
        capture_output=True,
        text=True,
        timeout=10,
    )


def _launchd_bootstrap(plist_path: Path) -> bool:
    """Reload a LaunchAgent from its plist, preferring modern launchctl verbs.

    ``launchctl kickstart`` restarts the already-loaded job but does not
    reload changed plist environment variables. That matters for PATH-like
    fixes (Agency CLI, SSL cert bundle). Use ``bootout`` + ``bootstrap``
    first, then fall back to legacy ``unload`` + ``load`` for older macOS
    behaviour / environments where the modern domain command fails.
    """
    domain = _launchd_domain()
    plist = str(plist_path)

    # Ignore bootout/unload failures: the service may not be loaded yet.
    _launchd_run(["bootout", domain, plist])
    result = _launchd_run(["bootstrap", domain, plist])
    if result.returncode == 0:
        return True

    _launchd_run(["unload", plist])
    result = _launchd_run(["load", plist])
    return result.returncode == 0


def _launchd_bootout(plist_path: Path) -> None:
    """Unload a LaunchAgent using modern launchctl, with legacy fallback."""
    plist = str(plist_path)
    result = _launchd_run(["bootout", _launchd_domain(), plist])
    if result.returncode != 0:
        _launchd_run(["unload", plist])


def _launchd_enable() -> bool:
    """Create and load a launchd plist for ``praestoclaw serve``."""
    import plistlib

    cmd = _get_serve_command()

    # launchd agents inherit a minimal PATH that excludes shell profile
    # additions (~/.zshrc, ~/.profile). Pre-pend the locations where common
    # PraestoClaw dependencies install so serve can find them without a
    # terminal restart:
    #   - praestoclaw binary's own directory (typically a venv/bin)
    #   - agency CLI install location
    #   - common user/system bin dirs
    home = str(Path.home())
    serve_bin_dir = str(Path(cmd[0]).parent) if cmd else ""
    path_dirs = [
        d
        for d in (
            serve_bin_dir,
            f"{home}/.config/agency/CurrentVersion",
            f"{home}/.local/bin",
            f"{home}/bin",
            "/usr/local/bin",
            "/opt/homebrew/bin",
            "/usr/bin",
            "/bin",
            "/usr/sbin",
            "/sbin",
        )
        if d
    ]
    path_value = ":".join(path_dirs)

    # SSL trust roots — without these the macOS-framework Python's OpenSSL
    # cannot validate certs in the minimal launchd environment, so the very
    # first WS connect to the cloud gateway fails with
    # ``SSL: CERTIFICATE_VERIFY_FAILED — unable to get local issuer certificate``
    # and the user sees a perpetual "Agent offline". Looking up
    # ``certifi.where()`` at enable time picks the bundle that ships with
    # this exact venv, so a venv recreate / Python version bump stays
    # in sync without a plist re-edit. See issue #343.
    env_vars: dict[str, str] = {"PATH": path_value}
    try:
        import certifi

        cacert = certifi.where()
        env_vars["SSL_CERT_FILE"] = cacert
        env_vars["REQUESTS_CA_BUNDLE"] = cacert
    except Exception:
        # certifi missing is unusual (it's a transitive dep of httpx/requests)
        # but we don't want autostart enable to fail over it — the user will
        # just see the SSL error in logs and can install certifi to fix.
        pass

    # Build via plistlib so values containing XML-special characters
    # (e.g. ``&``, ``<`` in unusual user home paths or custom install
    # locations) are escaped correctly instead of producing a malformed
    # plist that launchd will refuse to load.
    plist_obj: dict[str, Any] = {
        "Label": LAUNCHD_LABEL,
        "ProgramArguments": list(cmd),
        "EnvironmentVariables": env_vars,
        "RunAtLoad": True,
        "KeepAlive": {"SuccessfulExit": False},
        "StandardOutPath": str(Path.home() / ".praestoclaw" / "launchd-stdout.log"),
        "StandardErrorPath": str(Path.home() / ".praestoclaw" / "launchd-stderr.log"),
    }
    plist_path = _launchd_plist_path()
    plist_path.parent.mkdir(parents=True, exist_ok=True)
    with plist_path.open("wb") as fh:
        plistlib.dump(plist_obj, fh)

    try:
        return _launchd_bootstrap(plist_path)
    except Exception:
        return False


def _launchd_disable() -> bool:
    """Unload and remove the launchd plist."""
    plist_path = _launchd_plist_path()
    if plist_path.exists():
        try:
            _launchd_bootout(plist_path)
        except Exception:
            pass
        plist_path.unlink()
    return True


def _launchd_is_enabled() -> bool:
    """Check if the launchd plist is loaded."""
    plist_path = _launchd_plist_path()
    if not plist_path.exists():
        return False
    try:
        result = subprocess.run(
            ["launchctl", "list", LAUNCHD_LABEL],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


# ── Platform dispatch ───────────────────────────────────────────────────────


def enable_autostart() -> bool:
    """Enable autostart on the current platform. Returns True on success."""
    if sys.platform == "win32":
        return _windows_enable()
    elif sys.platform == "darwin":
        return _launchd_enable()
    else:
        return _systemd_enable()


def disable_autostart() -> bool:
    """Disable autostart on the current platform. Returns True on success."""
    if sys.platform == "win32":
        return _windows_disable()
    elif sys.platform == "darwin":
        return _launchd_disable()
    else:
        return _systemd_disable()


def is_autostart_enabled() -> bool:
    """Check if autostart is currently enabled."""
    if sys.platform == "win32":
        return _windows_is_enabled()
    elif sys.platform == "darwin":
        return _launchd_is_enabled()
    else:
        return _systemd_is_enabled()


# ── CLI commands ────────────────────────────────────────────────────────────


@app.command()
def autostart(
    action: str = typer.Argument(
        "status",
        help="Action: enable, disable, or status",
    ),
) -> None:
    """Manage auto-start on login (enable | disable | status)."""
    action = action.lower().strip()

    if action == "enable":
        console.print("Enabling PraestoClaw autostart...")
        if enable_autostart():
            console.print("[green]+[/green] Autostart enabled — PraestoClaw will start on login.")
        else:
            console.print("[red]Failed to enable autostart.[/red]")
            raise typer.Exit(1)

    elif action == "disable":
        console.print("Disabling PraestoClaw autostart...")
        if disable_autostart():
            console.print("[green]+[/green] Autostart disabled.")
        else:
            console.print("[red]Failed to disable autostart.[/red]")
            raise typer.Exit(1)

    elif action == "status":
        if is_autostart_enabled():
            console.print("[green]+[/green] Autostart is [bold]enabled[/bold].")
        else:
            console.print("[dim]-[/dim] Autostart is [bold]disabled[/bold].")
            console.print("  Run [cyan]pc autostart enable[/cyan] to enable.")

    else:
        console.print(f"[red]Unknown action:[/red] {action}")
        console.print("  Usage: pc autostart [enable|disable|status]")
        raise typer.Exit(1)
