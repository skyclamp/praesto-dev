"""Update CLI command — praestoclaw update.

Detects install mode automatically:
  - Git (editable install)  → git pull + pip install -e ".[all]"
  - Mirror (wheel install)  → pip install --upgrade --force-reinstall <wheel URL>

On Windows, pip is delegated to a helper process that waits for the current
entry-point exe to exit before installing, avoiding file-lock failures.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import traceback
from datetime import datetime
from pathlib import Path

import typer

from praestoclaw import __version__
from praestoclaw.cli.commands import app, console

# ── Diagnostic log (spawner side) ──────────────────────────────────────────
# Mirrors the diagnostic logger in :mod:`praestoclaw.cli.update_worker`. The
# bot self-update path runs ``pc update`` inside the daemon's shell-tool
# subprocess whose stdout is consumed by the bot; once the daemon dies the
# pipe is gone and we lose all output. A raw file-handle log keyed by date
# captures the spawn-side checkpoints so we can correlate them with the
# worker's log to pinpoint where a self-update silently breaks.

_DIAG_LOG_PATH: Path | None = None


def _diag_log_path() -> Path:
    """Resolve the spawner-side diagnostic log path. Memoised, never raises."""
    global _DIAG_LOG_PATH
    if _DIAG_LOG_PATH is not None:
        return _DIAG_LOG_PATH
    today = datetime.now().strftime("%Y%m%d")
    name = f"update-{today}.log"
    candidates: list[Path | None] = [
        Path.home() / ".praestoclaw" / "logs",
        Path(os.environ.get("TEMP", "")) if os.environ.get("TEMP") else None,
    ]
    # ``Path.cwd()`` raises FileNotFoundError when the working directory
    # has been deleted (e.g., updater spawned from a now-removed temp
    # dir). Resolve it lazily so the HOME/TEMP fallbacks still work
    # when CWD is unreadable.
    try:
        candidates.append(Path.cwd())
    except OSError:
        pass
    for base in candidates:
        if base is None:
            continue
        try:
            base.mkdir(parents=True, exist_ok=True)
            _DIAG_LOG_PATH = base / name
            return _DIAG_LOG_PATH
        except OSError:
            continue
    _DIAG_LOG_PATH = Path(name)
    return _DIAG_LOG_PATH


def _diag(msg: str, *, exc: BaseException | None = None) -> None:
    """Append a timestamped line to the spawner-side diagnostic log. Never raises."""
    try:
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        line = f"{ts} pid={os.getpid()} [spawner] {msg}\n"
        if exc is not None:
            line += "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        with open(_diag_log_path(), "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
    except Exception:  # noqa: BLE001
        pass


# Flags whose values may embed credentials (e.g. URLs with tokens). When
# echoing argv for diagnostics, substitute "<redacted>" for the value.
# Mirrors the same list in :mod:`praestoclaw.cli.update_worker`.
_SENSITIVE_FLAGS = frozenset(
    {
        "--package",
        "--mirror",
        "--index-url",
        "--extra-index-url",
        "-i",
    }
)


def _redact_argv(argv: list[str]) -> list[str]:
    """Return a copy of ``argv`` with values of sensitive flags redacted.

    Handles both ``--flag value`` and ``--flag=value`` forms.
    """
    out: list[str] = []
    i = 0
    while i < len(argv):
        token = argv[i]
        if "=" in token:
            flag, _, _value = token.partition("=")
            if flag in _SENSITIVE_FLAGS:
                out.append(f"{flag}=<redacted>")
                i += 1
                continue
        if token in _SENSITIVE_FLAGS and i + 1 < len(argv):
            out.append(token)
            out.append("<redacted>")
            i += 2
            continue
        out.append(token)
        i += 1
    return out


_SIGNAL_LOGGER_INSTALLED = False


def _install_signal_logger() -> None:
    """Register handlers that log every signal received. Best-effort.

    The spawner sometimes exits silently mid-flight (no _diag past entry,
    no .update_pending marker, no worker spawn). The only thing that can
    kill a Python process between two adjacent statements without raising
    a Python exception is an external signal (SIGINT/SIGTERM/SIGBREAK on
    Windows, plus the console-Ctrl events). Capture them here so we know.

    We save the *previous* handler at install time and restore it before
    re-sending the signal so the original Python semantics are preserved
    (in particular, SIGINT still raises ``KeyboardInterrupt`` via
    ``signal.default_int_handler`` instead of being hard-terminated
    through ``SIG_DFL``, which would bypass Typer/Click cleanup).
    """
    global _SIGNAL_LOGGER_INSTALLED
    if _SIGNAL_LOGGER_INSTALLED:
        return
    _SIGNAL_LOGGER_INSTALLED = True
    import signal as _signal

    previous: dict[int, object] = {}

    def _handler(signum: int, frame: object) -> None:
        try:
            name = _signal.Signals(signum).name
        except (ValueError, AttributeError):
            name = str(signum)
        _diag(f"!! SIGNAL RECEIVED {name} ({signum}) — restoring prior handler")
        prev = previous.get(signum, _signal.SIG_DFL)
        try:
            _signal.signal(signum, prev)  # type: ignore[arg-type]
        except (ValueError, OSError, TypeError) as exc:
            _diag(f"signal restore failed for {name}", exc=exc)
            prev = _signal.SIG_DFL
            try:
                _signal.signal(signum, _signal.SIG_DFL)
            except (ValueError, OSError):
                pass
        # If the previous handler is a Python callable (e.g. the default
        # SIGINT handler that raises KeyboardInterrupt), invoke it directly
        # so the signal semantics happen synchronously in this frame.
        if callable(prev):
            try:
                prev(signum, frame)
                return
            except BaseException:
                raise
        # Otherwise re-send the signal so the OS-level handler runs.
        try:
            os.kill(os.getpid(), signum)
        except Exception as exc:  # noqa: BLE001
            _diag(f"signal re-raise failed for {name}", exc=exc)

    names = ["SIGINT", "SIGTERM", "SIGBREAK", "SIGHUP"]
    for n in names:
        sig = getattr(_signal, n, None)
        if sig is None:
            continue
        try:
            previous[sig] = _signal.getsignal(sig)
            _signal.signal(sig, _handler)
        except (ValueError, OSError) as exc:
            _diag(f"could not install handler for {n}", exc=exc)


def _read_daemon_pid() -> int | None:
    """Return the PID of the running praestoclaw web daemon, or None.

    Delegates to ``praestoclaw.cli.serve._check_web_running()`` which
    validates liveness via both a port-listening socket test *and* a
    PID check. This is more robust than a bare liveness check alone: if
    ``web.pid`` is stale and the OS reused that PID for an unrelated
    process, the port-listening check will fail and we will correctly
    return ``None`` instead of false-positiving on the reused PID.
    """
    _diag("_read_daemon_pid: entry")
    try:
        from praestoclaw.cli.serve import _check_web_running
    except Exception as exc:  # noqa: BLE001
        _diag("_read_daemon_pid: import _check_web_running failed", exc=exc)
        return None
    try:
        result = _check_web_running()
    except Exception as exc:  # noqa: BLE001
        _diag("_read_daemon_pid: _check_web_running raised", exc=exc)
        return None
    _diag(f"_read_daemon_pid: _check_web_running -> {result!r}")
    if result is None:
        return None
    pid, _port = result
    return pid


def _invoked_by_daemon() -> int | None:
    """Detect whether this ``pc update`` was invoked from inside the running daemon.

    The daemon's shell tool spawns ``pc update`` as a child process. Running
    pip against an editable install or stopping the daemon directly from
    that child process tree corrupts the in-flight bot session: killing the
    daemon also kills our own ancestor (the shell tool's pipe), so the bot
    never reports back to the user and the post-update ``pc s`` ends up
    orphaned and dies with it.

    Returns the daemon's PID when this process is a descendant of the
    recorded ``web.pid`` PID, otherwise ``None``. Callers should then
    delegate to a detached worker via :func:`_schedule_self_update_detached`.
    """
    _diag("_invoked_by_daemon: entry")
    daemon_pid = _read_daemon_pid()
    _diag(f"_invoked_by_daemon: daemon_pid={daemon_pid}")
    if daemon_pid is None:
        return None
    chain = _own_pid_chain()
    _diag(f"_invoked_by_daemon: own_pid_chain={sorted(chain)}")
    if daemon_pid in chain:
        _diag(f"_invoked_by_daemon: MATCH — returning {daemon_pid}")
        return daemon_pid
    _diag("_invoked_by_daemon: daemon not in chain — returning None")
    return None


def _write_update_pending_marker() -> None:
    """Drop the ``.update_pending`` signal file for the post-update daemon.

    Written by :func:`_schedule_self_update_detached` right before the
    detached worker is spawned, and consumed by
    :meth:`praestoclaw.runtime.Runtime._notify_version_change_if_any`.
    The contents are the *current* version string so the new daemon can
    render ``"v<old> → v<new>"`` even when the user installed the same
    version (e.g. dev mirror reinstall).

    The marker exists *only* on the bot-self-update path. First-install
    daemons and user-typed ``pc update`` runs never write it, so they
    never produce a Teams notification (the user is already watching
    the terminal in those cases).
    """
    try:
        from praestoclaw import __version__ as _curver
        from praestoclaw.utils.helpers import get_data_dir

        marker = get_data_dir() / ".update_pending"
        marker.write_text(_curver, encoding="utf-8")
        _diag(f"wrote .update_pending marker: {marker} content={_curver}")
    except Exception as exc:  # noqa: BLE001
        # Non-fatal — losing the marker only suppresses the Teams ping;
        # the actual update still proceeds via the detached worker.
        console.print(f"[dim]Could not write .update_pending marker: {exc}[/dim]")
        _diag("failed to write .update_pending marker", exc=exc)


def _schedule_self_update_detached(daemon_pid: int, original_argv: list[str]) -> None:
    """Spawn a detached worker that kills the daemon then re-runs ``pc update``.

    Used when the running daemon (or its shell-tool descendant) invokes
    ``pc update`` on itself — see :func:`_invoked_by_daemon`. The worker
    survives our exit, gives the bot a couple of seconds to flush its
    reply, kills the daemon so pip can replace the locked files, and then
    re-execs ``pc update`` with the original argv. ``pc update`` from a
    standalone process then runs through the normal path (mirror/git +
    post-update ``pc s`` restart).

    Also drops a ``.update_pending`` marker (see
    :func:`_write_update_pending_marker`) so the freshly-restarted daemon
    pushes a "✅ updated" Teams notification regardless of whether the
    version string actually changed.
    """
    _write_update_pending_marker()
    # Tag the bot self-update path with --titled so the launcher.bat sets a
    # window title (the bot path always opens a fresh console; user-typed
    # `pc update` runs in their own pwsh and must NOT have its title hijacked).
    forwarded_argv = list(original_argv)
    if "--titled" not in forwarded_argv:
        forwarded_argv.append("--titled")
    cmd = [
        sys.executable,
        "-m",
        "praestoclaw.cli.update_worker",
        "--reexec-update",
        "--parent-pid",
        str(daemon_pid),
        "--launcher-json",
        json.dumps(_current_launcher()),
        "--data-dir",
        str(_current_data_dir()),
        "--",
        *forwarded_argv,
    ]

    creationflags = 0
    start_new_session = False
    if sys.platform == "win32":
        # Fully detach so the worker survives even after the daemon (our
        # ancestor) is killed. Use named constants from ``subprocess`` for
        # readability — these are the same values as the raw Windows
        # ``CREATE_*`` flags but spelled out.
        creationflags = (
            subprocess.DETACHED_PROCESS  # type: ignore[attr-defined]
            | subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        start_new_session = True

    _diag(
        f"_schedule_self_update_detached: about to Popen worker "
        f"creationflags=0x{creationflags:x} start_new_session={start_new_session} "
        f"daemon_pid={daemon_pid} cmd={_redact_argv(cmd)!r}"
    )
    try:
        proc = subprocess.Popen(  # noqa: S603
            cmd,
            close_fds=True,
            creationflags=creationflags,
            start_new_session=start_new_session,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError as exc:
        console.print(f"[red]Could not schedule self-update worker:[/red] {exc}")
        _diag("failed to spawn detached update_worker", exc=exc)
        raise typer.Exit(1)

    _diag(
        f"_schedule_self_update_detached: Popen returned worker pid={proc.pid} "
        f"daemon_pid={daemon_pid}"
    )

    console.print(
        "[green]Update scheduled.[/green] "
        f"The daemon (PID {daemon_pid}) will be stopped and "
        "`pc update` will resume in the background. The bot will restart "
        "automatically when the update completes."
    )


def _win_defer_pip(
    pip_args: list[str], cwd: Path | str | None = None, *, start_praestoclaw: bool = True
) -> bool:
    """Start a helper that waits for this process to exit, then runs pip."""
    cmd = [
        sys.executable,
        "-m",
        "praestoclaw.cli.update_worker",
        "--parent-pid",
        str(os.getpid()),
        "--launcher-json",
        json.dumps(_current_launcher()),
        "--data-dir",
        str(_current_data_dir()),
    ]
    if cwd is not None:
        cmd.extend(["--cwd", str(cwd)])
    if start_praestoclaw:
        cmd.append("--start-praestoclaw")
    cmd.append("--")
    cmd.extend(pip_args)

    try:
        subprocess.Popen(cmd, close_fds=True)
    except OSError as exc:
        console.print(f"[red]Could not start Windows updater:[/red] {exc}")
        raise typer.Exit(1)

    console.print(
        "[green]Update helper started.[/green]\n"
        "  It will wait for this command to exit, run pip, then start PraestoClaw."
    )
    return False


def _is_git_install() -> Path | None:
    from praestoclaw.utils.update import is_git_install

    return is_git_install()


def _our_exe_paths() -> set[str]:
    """Return the exact install paths of our ``praestoclaw`` and ``pc`` entry-points.

    Uses ``sysconfig`` to resolve both the system and user Scripts dirs, then
    checks for the actual files. Result is a set of lowercased, normalised
    absolute paths — safe for direct comparison with process executable paths.
    """
    import sysconfig

    candidates: set[str] = set()
    dirs: list[str] = []
    for scheme in ("nt", "nt_user"):
        try:
            d = sysconfig.get_path("scripts", scheme)
            if d:
                dirs.append(d)
        except KeyError:
            pass
    # Also consider the directory of the current executable itself.
    dirs.append(str(Path(sys.executable).parent))

    for d in dirs:
        for name in ("praestoclaw.exe", "praestoclaw", "pc.exe", "pc"):
            p = Path(d) / name
            if p.exists():
                candidates.add(str(p.resolve()).lower())
    return candidates


def _is_praestoclaw_process(
    image_name: str,
    command_line: str,
    executable_path: str = "",
    *,
    our_paths: set[str] | None = None,
) -> bool:
    """Return True only when the process can be confidently identified as PraestoClaw."""
    cmd = command_line or ""
    img = (image_name or "").strip().lower()
    lower_cmd = cmd.lower()
    exe = (executable_path or "").strip()

    # 1. Exact executable path match — most reliable.
    if exe:
        paths = our_paths if our_paths is not None else _our_exe_paths()
        norm_exe = str(Path(exe).resolve()).lower() if Path(exe).exists() else exe.lower()
        if norm_exe in paths:
            return True

    # 2. Process named "praestoclaw" — unambiguous.
    if img in {"praestoclaw.exe", "praestoclaw", "praestoclaw-script.py"}:
        return True

    # 3. Command line contains praestoclaw executable path or module invocation.
    if "praestoclaw.cli.commands" in lower_cmd:
        return True
    if re.search(r"(?:^|\s)-m\s+praestoclaw(?:\s|$)", cmd, re.IGNORECASE):
        return True
    if re.search(r"[/\\]praestoclaw(?:\.exe)?[\"'\s]", lower_cmd):
        return True

    # 4. `pc` shorthand — only when command line mentions praestoclaw internals.
    #    We do NOT rely on name/path heuristics alone for `pc`.
    if img in {"pc.exe", "pc", "pc-script.py"} and "praestoclaw" in lower_cmd:
        return True

    return False


def _own_pid_chain() -> set[int]:
    """Return a set of PIDs to exclude: current process + ancestor chain.

    Walking the *full* ancestor chain (not just the immediate parent) is
    required for two callers:

    * :func:`_invoked_by_daemon` — the daemon spawns ``pc update`` via
      ``shell tool -> sh -c -> pc update`` (POSIX) or
      ``pythonw -> cmd /c -> pc update`` (Windows). The immediate ppid is
      the shell, not the daemon, so ``os.getppid()`` alone misses the
      detection and we'd skip the detached-worker path.
    * :func:`_find_running_pc_processes` — never kill any of our own
      ancestors during cleanup.
    """
    pids = {os.getpid()}
    _diag(f"_own_pid_chain: entry pid={os.getpid()} ppid={os.getppid()}")
    if sys.platform == "win32":
        try:
            ps = (
                "$p = Get-CimInstance Win32_Process "
                f"-Filter 'ProcessId = {os.getpid()}';"
                "while ($p) {"
                "  Write-Output $p.ProcessId;"
                "  $p = Get-CimInstance Win32_Process "
                '    -Filter ("ProcessId = {0}" -f $p.ParentProcessId) '
                "    -ErrorAction SilentlyContinue"
                "}"
            )
            _diag("_own_pid_chain: about to spawn powershell Get-CimInstance (timeout=10)")
            r = _run(["powershell", "-NoProfile", "-Command", ps], timeout=10)
            _diag(
                f"_own_pid_chain: powershell returncode={r.returncode} "
                f"stdout_bytes={len(r.stdout) if r.stdout else 0} "
                f"stderr_bytes={len(r.stderr) if r.stderr else 0}"
            )
            if r.returncode == 0:
                for line in r.stdout.splitlines():
                    line = line.strip()
                    if line.isdigit():
                        pids.add(int(line))
        except Exception as exc:  # noqa: BLE001 — best-effort
            _diag("_own_pid_chain: powershell ancestor walk raised", exc=exc)
    else:
        # Walk /proc/<pid>/status PPid: chain. Cap at 32 to avoid any
        # pathological loop. Falls back to immediate ppid if /proc isn't
        # available (macOS lacks /proc — covered by the fallback below).
        try:
            current = os.getpid()
            for _ in range(32):
                ppid = _posix_parent_pid(current)
                if not ppid or ppid in pids or ppid == 1:
                    break
                pids.add(ppid)
                current = ppid
        except Exception:  # noqa: BLE001
            try:
                pids.add(os.getppid())
            except Exception:  # noqa: BLE001
                pass
    _diag(f"_own_pid_chain: exit pids={sorted(pids)}")
    return pids


def _posix_parent_pid(pid: int) -> int | None:
    """Return the parent PID of ``pid`` on POSIX, or None if unknown.

    Tries ``/proc/<pid>/status`` first (Linux), falls back to ``ps -o ppid=``
    (macOS / BSD). Best-effort — returns None on any error.
    """
    proc_status = Path(f"/proc/{pid}/status")
    if proc_status.exists():
        try:
            for line in proc_status.read_text(encoding="utf-8").splitlines():
                if line.startswith("PPid:"):
                    return int(line.split()[1])
        except Exception:  # noqa: BLE001
            return None
        return None
    try:
        r = _run_best_effort(["ps", "-o", "ppid=", "-p", str(pid)], timeout=5)
        if r is not None and r.returncode == 0:
            text = r.stdout.strip()
            if text.isdigit():
                return int(text)
    except Exception:  # noqa: BLE001
        return None
    return None


def _find_running_pc_processes() -> list[tuple[int, str]]:
    """Return running PraestoClaw process list excluding own process chain."""
    exclude_pids = _own_pid_chain()
    found: list[tuple[int, str]] = []

    cached_paths = _our_exe_paths()

    if sys.platform == "win32":
        ps_cmd = (
            "$ErrorActionPreference='SilentlyContinue';"
            "Get-CimInstance Win32_Process | "
            "Where-Object { $_.ProcessId -notin @("
            f"{','.join(str(p) for p in exclude_pids)}"
            ") } | "
            'ForEach-Object { "$($_.ProcessId)\t$($_.Name)\t$($_.ExecutablePath)\t$($_.CommandLine)" }'
        )
        result = _run_best_effort(["powershell", "-NoProfile", "-Command", ps_cmd], timeout=20)
        if result is None or result.returncode != 0:
            return []
        for line in result.stdout.splitlines():
            parts = line.strip().split("\t", 3)
            if len(parts) < 2:
                continue
            try:
                pid = int(parts[0])
            except ValueError:
                continue
            image_name = parts[1]
            exe_path = parts[2] if len(parts) >= 3 else ""
            cmdline = parts[3] if len(parts) >= 4 else ""
            if _is_praestoclaw_process(image_name, cmdline, exe_path, our_paths=cached_paths):
                found.append((pid, image_name))
        return found

    result = _run_best_effort(["ps", "-eo", "pid=,args="], timeout=20)
    if result is None or result.returncode != 0:
        return []
    for line in result.stdout.splitlines():
        raw = line.strip()
        if not raw:
            continue
        pieces = raw.split(None, 1)
        if len(pieces) != 2:
            continue
        try:
            pid = int(pieces[0])
        except ValueError:
            continue
        if pid in exclude_pids:
            continue
        cmdline = pieces[1]
        image_name = Path(cmdline.split()[0]).name if cmdline.split() else ""
        if _is_praestoclaw_process(image_name, cmdline, our_paths=cached_paths):
            found.append((pid, cmdline))
    return found


def _stop_running_pc_processes() -> bool:
    """Kill running PraestoClaw processes so update/install can proceed safely."""
    running = _find_running_pc_processes()
    if not running:
        console.print("[dim]No running PraestoClaw process detected.[/dim]")
        return False

    console.print(f"[yellow]Stopping {len(running)} running PraestoClaw process(es)...[/yellow]")
    for pid, label in running:
        if sys.platform == "win32":
            result = _run(["taskkill", "/PID", str(pid), "/F"], timeout=20)
            if result.returncode == 0:
                console.print(f"  [green]+[/green] killed PID {pid} ({label})")
            else:
                console.print(f"  [yellow]![/yellow] could not kill PID {pid} ({label})")
        else:
            result = _run(["kill", "-9", str(pid)], timeout=10)
            if result.returncode == 0:
                console.print(f"  [green]+[/green] killed PID {pid}")
            else:
                console.print(f"  [yellow]![/yellow] could not kill PID {pid}")
    return True


def _current_launcher() -> list[str]:
    from praestoclaw.cli.watchdog import current_cli_prefix

    return current_cli_prefix()


def _current_data_dir() -> Path:
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir()


def _stop_services_for_update() -> bool:
    """Stop the watchdog first, falling back to the legacy process scan."""
    from praestoclaw.cli.watchdog import stop_watchdog_if_running

    if stop_watchdog_if_running():
        return True
    return _stop_running_pc_processes() is True


def _start_praestoclaw_best_effort(*, cwd: Path | str | None = None) -> None:
    cmd = [*_current_launcher(), "s", "--data-dir", str(_current_data_dir())]
    console.print("[dim]Starting PraestoClaw server...[/dim]")
    try:
        subprocess.Popen(cmd, cwd=cwd)
    except OSError as exc:
        console.print(f"[yellow]Warning:[/yellow] Could not start PraestoClaw: {exc}")


def _run_post_update_startup_sequence() -> None:
    """Post-update startup: re-init config then start server (best-effort)."""
    console.print("\n[dim]Running post-update startup sequence...[/dim]")

    init_result = _run_best_effort([*_current_launcher(), "init", "--quick"], timeout=300)
    if init_result is None or init_result.returncode != 0:
        console.print("[yellow]Warning:[/yellow] `praestoclaw init --quick` failed.")

    _start_praestoclaw_best_effort()


def _ensure_daemon_running() -> None:
    """(Re)start ``pc s`` if the web daemon isn't already serving. Idempotent.

    Used on the bot self-update path when the update flow stopped the daemon
    but then performed no install (already current, or a race between the
    pre-check and the actual update). Without this the bot would stay offline.
    The running-check makes it safe against a double-bind if a server is
    somehow already up.
    """
    try:
        from praestoclaw.cli.commands import _check_web_running

        running = _check_web_running()
        if running:
            _diag(f"_ensure_daemon_running: web already running {running} — skip")
            return
    except Exception as exc:  # noqa: BLE001 — best-effort; proceed to start on check failure
        _diag("_ensure_daemon_running: running-check failed; proceeding", exc=exc)

    console.print("[dim]Restarting PraestoClaw server...[/dim]")
    try:
        subprocess.Popen([*_current_launcher(), "s", "--data-dir", str(_current_data_dir())])
        _diag("_ensure_daemon_running: spawned `praestoclaw s`")
    except OSError as exc:
        console.print(f"[yellow]Warning:[/yellow] Could not start `praestoclaw s`: {exc}")
        _diag("_ensure_daemon_running: spawn failed", exc=exc)


def _delegate_to_mirror_script(
    *,
    force_mirror: bool = False,
    package: str | None = None,
    titled: bool = False,
) -> None:
    """Execute the update script to handle the full upgrade lifecycle.

    When ``force_mirror`` is True (explicit ``--mirror`` flag), uses the local
    repo copy of the script for easy development testing.
    Otherwise downloads the latest script from the public mirror so the
    update logic is always current even when the local binary is outdated.

    When ``package`` is set, exports it as ``PRAESTOCLAW_PACKAGE`` so the
    script's ``pip install`` step picks it up and skips the mirror version
    query (see ``update.ps1`` step 2 / ``update.sh`` equivalent). Useful
    for dev testing with a local wheel or a custom git URL.

    ``titled`` marks the bot self-update path (set by
    ``_schedule_self_update_detached``). On Windows it also makes the
    launcher.bat set a console window title so the user knows what the new
    console is doing; on POSIX it signals that the daemon was already stopped
    and must be brought back up even when nothing was installed. User-typed
    ``pc update`` leaves it False so we don't touch their window or restart.

    On Windows: runs update.ps1 via powershell.
    On macOS/Linux: runs update.sh via bash.
    """
    _diag(
        f"_delegate_to_mirror_script: entry force_mirror={force_mirror} titled={titled} package={'<set>' if package else None}"
    )
    if sys.platform == "win32":
        script_name = "update.ps1"
        runner = ["powershell", "-ExecutionPolicy", "Bypass", "-File"]
    else:
        script_name = "update.sh"
        runner = ["bash"]

    import tempfile

    # Create a unique tempdir per run to avoid:
    #  - symlink/hardlink pre-creation attacks on shared /tmp (Unix)
    #  - collisions between concurrent `pc update` runs
    script_dir = Path(tempfile.mkdtemp(prefix="pc_update_"))
    script_path = script_dir / script_name
    _diag(f"_delegate_to_mirror_script: script_dir={script_dir}")

    if force_mirror:
        # --mirror: use local script for dev testing.
        # Copy to tempdir via the same write path as the download branch so
        # any byte-handling regressions (e.g. CRLF double-encoding) surface
        # in local testing too.
        repo = _is_git_install()
        local_script = (repo / script_name) if repo else Path(script_name)
        if not local_script.is_file():
            console.print(f"[yellow]{script_name} not found locally.[/yellow]")
            return
        console.print(f"[dim]Using local {script_name} (copied to tempdir)[/dim]")
        script_path.write_bytes(local_script.read_bytes())
    else:
        # Default: download from mirror
        import httpx

        from praestoclaw.utils.update import mirror_base

        url = f"{mirror_base()}/{script_name}?t={int(__import__('time').time())}"
        console.print("[dim]Downloading latest update script from mirror...[/dim]")

        try:
            resp = httpx.get(url, timeout=15, follow_redirects=True)
            resp.raise_for_status()
        except Exception as exc:
            console.print(
                f"[yellow]Could not download update script:[/yellow] {exc}\n"
                "  Falling back to built-in update logic."
            )
            _mirror_update(check_only=False, restart_required=titled)
            return

        script_path.write_bytes(resp.content)
        _diag(f"_delegate_to_mirror_script: downloaded {len(resp.content)} bytes to {script_path}")

    console.print(f"[dim]Running {script_name}...[/dim]\n")

    # Build the env passed to the script. Inherit current env, then layer
    # PRAESTOCLAW_PACKAGE on top so the script's pip install step uses it
    # instead of querying the mirror for the latest wheel URL.
    script_env = os.environ.copy()
    script_env["PRAESTOCLAW_LAUNCHER"] = json.dumps(_current_launcher())
    script_env["PRAESTOCLAW_DATA_DIR"] = str(_current_data_dir())
    if titled:
        # ``titled`` is added only on the bot self-update path
        # (_schedule_self_update_detached), by which point the re-exec worker
        # has already stopped the daemon. Signal the update script to restart
        # ``pc s`` even when it finds nothing to install — otherwise an
        # already-current re-check exits without bringing the bot back online.
        script_env["PRAESTOCLAW_ENSURE_RUNNING"] = "1"
    if package:
        script_env["PRAESTOCLAW_PACKAGE"] = package
        console.print("[dim]Using package override.[/dim]")

    try:
        if sys.platform != "win32":
            cmd = runner + [str(script_path)]
            os.execvpe(cmd[0], cmd, script_env)  # noqa: S606 — intentional process replacement
        else:
            # Write a tiny .bat launcher that waits for our process to exit,
            # then runs the ps1 script in a clean PowerShell environment.
            # This avoids Python's stdio pollution that breaks Start-Process
            # -RedirectStandardOutput inside the child PowerShell.
            bat_path = script_dir / "_pc_update_launcher.bat"
            title_line = "title PraestoClaw self-update\n" if titled else ""
            bat_path.write_text(
                f'@echo off\n{title_line}pwsh -ExecutionPolicy Bypass -File "{script_path}"\n',
                encoding="utf-8",
            )
            _diag(f"_delegate_to_mirror_script: wrote launcher bat={bat_path} titled={titled}")
            # Detach: start the bat and exit immediately.
            # The bat inherits the current console window (no new window).
            proc = subprocess.Popen(  # noqa: S602 — shell=True needed for cmd /c
                f'cmd /c "{bat_path}"',
                shell=True,
                close_fds=True,
                env=script_env,
            )
            _diag(f"_delegate_to_mirror_script: spawned cmd /c pid={proc.pid}")
            console.print("[dim]Update launched — this process will exit now.[/dim]")
            raise SystemExit(0)
    except OSError as exc:
        console.print(f"[red]Failed to run update script:[/red] {exc}")
        _diag("_delegate_to_mirror_script: OSError", exc=exc)
        raise typer.Exit(1)


# Windows: isolate every child subprocess.run() we launch from our own console
# group. Without this, when ``pc update`` runs inside the bot's shell tool
# (which shares the daemon's console), spawning powershell/curl/git as a child
# can cause a CTRL_C_EVENT to be broadcast across the entire console group —
# killing the daemon and every MCP child along with the spawner. CREATE_NEW_-
# PROCESS_GROUP keeps any Ctrl+C the child generates inside the child;
# CREATE_NO_WINDOW prevents flashing a console window.
_CHILD_CREATIONFLAGS = 0
if sys.platform == "win32":
    _CHILD_CREATIONFLAGS = (
        subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
        | subprocess.CREATE_NO_WINDOW  # type: ignore[attr-defined]
    )


def _run(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str]:
    try:
        if timeout > 0:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout,
                creationflags=_CHILD_CREATIONFLAGS,
            )
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            creationflags=_CHILD_CREATIONFLAGS,
        )
    except subprocess.TimeoutExpired:
        console.print(f"[red]Command timed out ({timeout}s):[/red] {' '.join(cmd)}")
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Command not found:[/red] {cmd[0]}")
        raise typer.Exit(1)


def _run_best_effort(
    cmd: list[str], cwd: Path | str | None = None, timeout: int = 120
) -> subprocess.CompletedProcess[str] | None:
    """Like _run but returns None on any failure instead of exiting."""
    try:
        if timeout > 0:
            return subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                cwd=cwd,
                timeout=timeout,
                creationflags=_CHILD_CREATIONFLAGS,
            )
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=cwd,
            creationflags=_CHILD_CREATIONFLAGS,
        )
    except Exception:  # noqa: BLE001
        return None


def _git_update(repo: Path, check_only: bool, *, restart_required: bool = False) -> bool:
    """Update from git: fetch, compare, pull, reinstall deps if needed.

    Returns True if the update is fully complete (code pulled and deps up-to-date).
    Returns False if there is nothing to update, or if a manual step is still
    required (e.g. Windows: pip must be run manually after closing this process).
    """
    restart_state = [restart_required, False, False]
    try:
        return _git_update_inner(
            repo,
            check_only,
            restart_state=restart_state,
        )
    finally:
        if restart_state[0] and not restart_state[2]:
            if restart_state[1]:
                _run_post_update_startup_sequence()
            else:
                _start_praestoclaw_best_effort(cwd=repo)


def _git_update_inner(repo: Path, check_only: bool, *, restart_state: list[bool]) -> bool:
    # Check for dirty working tree
    status_result = _run(["git", "status", "--porcelain"], cwd=repo)
    if status_result.returncode != 0:
        console.print(f"[red]git status failed:[/red]\n{status_result.stderr.strip()}")
        raise typer.Exit(1)
    if status_result.stdout.strip():
        console.print(
            "[yellow]Working tree has uncommitted changes.[/yellow]\n"
            "  Commit or stash them before updating."
        )
        raise typer.Exit(1)

    # Fetch latest
    result = _run(["git", "fetch"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git fetch failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)

    # Check for upstream changes
    local_result = _run(["git", "rev-parse", "HEAD"], cwd=repo)
    if local_result.returncode != 0:
        console.print(f"[red]git rev-parse HEAD failed:[/red]\n{local_result.stderr.strip()}")
        raise typer.Exit(1)
    local = local_result.stdout.strip()

    remote_result = _run(["git", "rev-parse", "@{u}"], cwd=repo)
    if remote_result.returncode != 0:
        console.print(
            "[red]No upstream tracking branch set.[/red]\n"
            "  Set one with: [bold]git branch --set-upstream-to origin/<branch>[/bold]"
        )
        raise typer.Exit(1)
    remote = remote_result.stdout.strip()

    if local == remote:
        console.print("[green]Already up to date![/green]  (no new commits)")
        return False

    # Detect ahead/behind/diverged state
    count_result = _run(["git", "rev-list", "--left-right", "--count", "HEAD...@{u}"], cwd=repo)
    if count_result.returncode != 0:
        console.print(f"[red]git rev-list failed:[/red]\n{count_result.stderr.strip()}")
        raise typer.Exit(1)
    parts = count_result.stdout.strip().split()
    if len(parts) != 2:
        console.print(f"[red]Unexpected git rev-list output:[/red] {count_result.stdout.strip()}")
        raise typer.Exit(1)
    ahead, behind = int(parts[0]), int(parts[1])

    if behind == 0 and ahead > 0:
        console.print(
            f"[yellow]Local branch is {ahead} commit(s) ahead of upstream.[/yellow]\n"
            "  Nothing to pull. Push your changes or reset to upstream."
        )
        return False

    if ahead > 0 and behind > 0:
        console.print(
            f"[yellow]Branch has diverged:[/yellow] {ahead} ahead, {behind} behind.\n"
            "  Resolve manually (rebase or merge) before updating."
        )
        raise typer.Exit(1)

    # Show what's new (behind > 0, ahead == 0)
    log_result = _run(["git", "log", "--oneline", f"{local}..{remote}"], cwd=repo)
    new_commits = log_result.stdout.strip()
    commit_count = len(new_commits.splitlines()) if new_commits else 0
    console.print(f"[cyan]{commit_count}[/cyan] new commit(s) available:")
    for line in new_commits.splitlines()[:10]:
        console.print(f"  {line}")
    if commit_count > 10:
        console.print(f"  [dim]... and {commit_count - 10} more[/dim]")

    if check_only:
        console.print("\n  Run [bold]pc update[/bold] to pull and install.")
        return False

    # Kill running PraestoClaw processes before modifying files.
    _stop_services_for_update()
    restart_state[0] = True

    # Pull
    console.print("\n[dim]Pulling...[/dim]")
    result = _run(["git", "pull"], cwd=repo)
    if result.returncode != 0:
        console.print(f"[red]git pull failed:[/red]\n{result.stderr.strip()}")
        raise typer.Exit(1)
    console.print("[green]Pull complete.[/green]")

    # For editable installs, Python sources are used directly from the repo —
    # git pull alone is sufficient for pure code changes.  Only re-run pip if
    # pyproject.toml changed in the pulled commits (new deps or entry points).
    toml_changed_result = _run(
        ["git", "diff", "--name-only", f"{local}..{remote}", "--", "pyproject.toml"],
        cwd=repo,
    )
    # If the diff command fails (e.g. SHA no longer resolvable), err on the
    # side of caution and assume pyproject.toml may have changed.
    if toml_changed_result.returncode != 0:
        needs_pip = True
    else:
        needs_pip = bool(toml_changed_result.stdout.strip())

    if needs_pip:
        console.print("[dim]pyproject.toml changed — dependencies need reinstalling.[/dim]")
        if sys.platform == "win32":
            console.print("[dim]Starting Windows update helper...[/dim]")
            deferred = _win_defer_pip(
                ["install", "-e", ".[all]"],
                cwd=repo,
                start_praestoclaw=restart_state[0],
            )
            restart_state[2] = True
            return deferred

        with console.status("[bold cyan]Installing dependencies..."):
            pip_result = _run(
                [sys.executable, "-m", "pip", "install", "-e", ".[all]"],
                cwd=repo,
                timeout=300,
            )
        if pip_result.returncode != 0:
            console.print(f"[red]pip install failed:[/red]\n{pip_result.stderr.strip()}")
            raise typer.Exit(1)
        console.print("[green]Dependencies updated![/green]")

    restart_state[1] = True
    return True


def _mirror_update(check_only: bool, *, restart_required: bool = False) -> bool:
    """Update from the public wheel mirror: check latest.txt, pip install --upgrade.

    Returns True if an update was performed.
    """
    restart_state = [restart_required, False, False]
    try:
        return _mirror_update_inner(check_only, restart_state=restart_state)
    finally:
        if restart_state[0] and not restart_state[2]:
            if restart_state[1]:
                _run_post_update_startup_sequence()
            else:
                _start_praestoclaw_best_effort()


def _mirror_update_inner(check_only: bool, *, restart_state: list[bool]) -> bool:
    from praestoclaw.utils.update import check_mirror, mirror_base

    console.print("[dim]Checking mirror...[/dim]")
    status = check_mirror()

    if status.error:
        console.print(
            "[yellow]Could not check for updates.[/yellow]\n"
            "  Re-run the installer to upgrade:\n"
            "  [bold]irm https://aka.ms/praestoclaw/install.ps1 | iex[/bold]  (Windows)\n"
            "  [bold]curl -fsSL https://aka.ms/praestoclaw/install.sh | sh[/bold]  (macOS/Linux)"
        )
        raise typer.Exit(1)

    if status.up_to_date:
        console.print(f"[green]Already up to date![/green]  (latest: v{status.latest})")
        return False

    latest = status.latest
    console.print(f"New version available: [cyan]v{latest}[/cyan]")

    if check_only:
        console.print("  Run [bold]pc update[/bold] to install it.")
        return False

    # Kill running PraestoClaw processes before pip replaces files.
    _stop_services_for_update()
    restart_state[0] = True

    wheel_url = f"{mirror_base()}/dist/praestoclaw-{latest}-py3-none-any.whl"
    pip_args = ["install", "--upgrade", "--force-reinstall", wheel_url]

    console.print("[dim]Upgrading...[/dim]")

    if sys.platform == "win32":
        console.print("[dim]Starting Windows update helper...[/dim]")
        result = _win_defer_pip(pip_args, start_praestoclaw=restart_state[0])
        restart_state[2] = True
        return result

    with console.status("[bold cyan]Installing..."):
        pip_result = _run([sys.executable, "-m", "pip", *pip_args], timeout=180)
    if pip_result.returncode == 0:
        console.print(f"[green]Updated to v{latest}![/green]")
        restart_state[1] = True
        return True

    console.print(f"[red]Update failed:[/red]\n{pip_result.stderr.strip()}")
    raise typer.Exit(1)


def _normalize_command_argv(ctx: typer.Context, *, exclude: set[str] | None = None) -> list[str]:
    """Reconstruct a normalized argv from typer/click's parsed parameters.

    Walks ``ctx.command.params`` and rebuilds the flag form for every option
    whose value differs from its default. Used by the daemon self-update
    guard to forward whatever flags the user (or bot) passed to ``pc update``
    without hard-coding the list — adding a new option to ``update()`` just
    works without touching the worker dispatch.

    * Boolean flags emit their canonical long form (e.g. ``--mirror``).
    * Value options emit ``["--name", str(value)]`` for non-default values.
    * Click ``Argument`` instances are preserved positionally.
    * Names in ``exclude`` are skipped (e.g. ``check`` — read-only, never
      part of a self-update dispatch).

    The output is a list of strings safe to splice after ``["pc", "update"]``.
    """
    import click

    excluded = exclude or set()
    out: list[str] = []
    for param in ctx.command.params:
        if param.name in excluded or param.name is None:
            continue
        value = ctx.params.get(param.name, param.default)
        if value is None or value == param.default:
            continue
        if isinstance(param, click.Argument):
            out.append(str(value))
            continue
        if not param.opts:
            continue
        flag = param.opts[0]
        if getattr(param, "is_flag", False):
            if bool(value):
                out.append(flag)
        else:
            out.extend([flag, str(value)])
    return out


@app.command(name="update")
def update(
    ctx: typer.Context,
    check: bool = typer.Option(False, "--check", help="Only check for updates, don't install"),
    mirror: bool = typer.Option(
        False,
        "--mirror",
        help="Force mirror mode even for git/editable installs (dev only).",
        hidden=True,
    ),
    package: str | None = typer.Option(
        None,
        "--package",
        help=(
            "Override the package source passed to pip (wheel URL, local "
            "path, or git+...). Sets PRAESTOCLAW_PACKAGE for the update "
            "script. Dev only."
        ),
        hidden=True,
    ),
    titled: bool = typer.Option(
        False,
        "--titled",
        help=(
            "Marks the bot self-update path (on Windows also sets the update "
            "launcher window title). Used internally by the bot self-update "
            "path; not intended for manual use."
        ),
        hidden=True,
    ),
) -> None:
    """Update PraestoClaw to the latest version."""
    _install_signal_logger()
    _diag(
        f"pc update entered: version={__version__} check={check} mirror={mirror} "
        f"titled={titled} argv={_redact_argv(sys.argv)!r} pid={os.getpid()} ppid={os.getppid()}"
    )
    console.print(f"Current version: [bold]v{__version__}[/bold]")

    # Self-update guard: when the running daemon (or its shell tool) invokes
    # ``pc update`` against itself, delegate to a detached worker so the bot
    # can finish replying and the daemon can be safely killed before pip
    # touches its install files. ``--check`` is read-only and stays in-process.
    if not check:
        _diag("calling _invoked_by_daemon()")
        try:
            daemon_pid = _invoked_by_daemon()
        except BaseException as exc:  # noqa: BLE001
            _diag("_invoked_by_daemon RAISED", exc=exc)
            raise
        _diag(f"_invoked_by_daemon() returned -> {daemon_pid}")
        if daemon_pid is not None:
            # NOTE: the "already up to date?" pre-check lives at the call site
            # (the cloud.py fast-path checks ``check_update()`` BEFORE spawning
            # ``pc update`` — see issue #467). We deliberately do NOT repeat it
            # here: running ``check_update()`` inside this intermediate process
            # adds network I/O and import/teardown latency to the very process
            # whose prompt exit the detached worker's self-kill avoidance
            # depends on, and it would be redundant on the bot path.
            _diag("taking detached self-update path")
            original_argv = _normalize_command_argv(ctx, exclude={"check"})
            _diag(f"normalized argv for worker: {original_argv}")
            _schedule_self_update_detached(daemon_pid, original_argv)
            _diag("_schedule_self_update_detached returned — update() returning")
            return

    _diag("calling _is_git_install()")
    repo = _is_git_install()
    _diag(f"_is_git_install() -> {repo}")

    # Mirror mode: delegate to the latest update script from the mirror.
    # This ensures the update logic is always current even when the local
    # pc binary is outdated.
    if mirror or not repo:
        if not check:
            _delegate_to_mirror_script(force_mirror=mirror, package=package, titled=titled)
            return  # _delegate_to_mirror_script replaces the process or exits
        # --check only: just check, don't delegate
        console.print("Install mode:    [cyan]mirror[/cyan]")
        updated = _mirror_update(check)
    else:
        console.print(f"Install mode:    [cyan]git[/cyan]  ({repo})")
        updated = _git_update(repo, check, restart_required=titled)

    # Remind to restart if web server is running and we actually updated
    if updated:
        from praestoclaw.cli.commands import _check_web_running

        running = _check_web_running()
        if running:
            pid, port = running
            console.print(
                f"\n[yellow]Web server is running (PID {pid}, port {port}).[/yellow]\n"
                "  Restart it to use the new version."
            )


# "upgrade" is a hidden alias — keeps the same convention as other aliases in commands.py
app.command("upgrade", hidden=True)(update)
