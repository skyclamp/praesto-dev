"""Non-interactive plans CLI subcommands: list, show, and delete."""

from __future__ import annotations

import typer
from rich.table import Table

from praestoclaw.agent.tools.plan import PlanStore, render_plan
from praestoclaw.cli.commands import console, plans_app


@plans_app.command("list")
def plans_list(
    active_only: bool = typer.Option(
        False, "--active", help="Show only plans with unfinished items"
    ),
) -> None:
    """List task plans (all by default; use --active to hide completed)."""
    store = PlanStore()
    all_plans = store.list_all()
    active_total = sum(1 for p in all_plans if not p.is_complete and p.items)
    plans = [p for p in all_plans if not p.is_complete and p.items] if active_only else all_plans
    if not plans:
        console.print("[dim]No plans found.[/dim]")
        return

    title = (
        f"Task Plans  ({active_total} active)"
        if active_only
        else f"Task Plans  ({active_total} active / {len(all_plans)} total)"
    )
    table = Table(title=title)
    table.add_column("Status", style="bold", no_wrap=True)
    table.add_column("Session", style="bold")
    table.add_column("Workflow")
    table.add_column("Progress")
    table.add_column("Current / Last Item")
    table.add_column("Updated")

    for p in plans:
        done, total = p.progress
        if not p.items:
            status = "[dim]empty[/dim]"
            current = "—"
        elif p.is_complete:
            status = "[green]✓ done[/green]"
            current = p.items[-1].title
        elif p.active_item:
            status = "[cyan]▶ in-progress[/cyan]"
            current = p.active_item.title
        elif any(it.status == "blocked" for it in p.items):
            status = "[yellow]! blocked[/yellow]"
            blocked = next(it for it in p.items if it.status == "blocked")
            current = blocked.title
        else:
            status = "[dim]pending[/dim]"
            nxt = next((it for it in p.items if it.status == "not_started"), p.items[0])
            current = nxt.title

        if len(current) > 50:
            current = current[:47] + "…"

        # Truncate very long session ids for readability
        sid_display = p.session_id
        if len(sid_display) > 60:
            sid_display = sid_display[:30] + "…" + sid_display[-25:]

        table.add_row(
            status,
            sid_display,
            p.workflow or "—",
            f"{done}/{total}",
            current,
            p.updated_at[:19],
        )
    console.print(table)


@plans_app.command("show")
def plans_show(
    session_id: str | None = typer.Argument(
        None, help="Session id (default: most recently updated active plan)"
    ),
) -> None:
    """Show the full plan for a session."""
    store = PlanStore()
    if session_id is None:
        actives = store.list_active()
        if not actives:
            all_plans = store.list_all()
            if not all_plans:
                console.print("[yellow]No plans found.[/yellow]")
                raise typer.Exit(0)
            plan = all_plans[0]  # newest by mtime
            console.print(f"[dim]Most recent plan: {plan.session_id}[/dim]\n")
        else:
            plan = actives[0]
            console.print(f"[dim]Most recent active plan: {plan.session_id}[/dim]\n")
    else:
        loaded = store.load(session_id)
        if not loaded or not loaded.items:
            console.print(f"[red]No plan for session {session_id!r}[/red]")
            raise typer.Exit(1)
        plan = loaded
    console.print(render_plan(plan))


@plans_app.command("delete")
def plans_delete(
    session_id: str = typer.Argument(..., help="Session id whose plan to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a plan file."""
    if not yes:
        confirm = typer.confirm(f"Delete plan for session {session_id!r}?")
        if not confirm:
            raise typer.Abort()
    if PlanStore().delete(session_id):
        console.print(f"[green]Deleted plan for {session_id}[/green]")
    else:
        console.print(f"[yellow]No plan to delete for {session_id}[/yellow]")
