"""MCP CLI subcommands — praestoclaw mcp list|add|remove|get|setup|login|logout|test."""

from __future__ import annotations

import contextlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any
from urllib.parse import urlparse

if TYPE_CHECKING:
    import httpx

import typer
import yaml
from rich.table import Table

from praestoclaw.cli.commands import (
    _load_config_safe,
    console,
    mcp_app,
)
from praestoclaw.cli.commands import (
    resolve_config_path as _resolve_config_path,
)
from praestoclaw.cli.commands import (
    resolve_local_config_path as _resolve_local_config_path,
)
from praestoclaw.config.loader import ensure_schema_line
from praestoclaw.mcp.defaults import get_default_description


def _load_yaml(config_path: Path) -> dict[str, Any]:
    return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}


def _save_mcp_servers(config_path: Path, servers: dict[str, dict[str, Any]]) -> None:
    """Update only the tools.mcp_servers section in a praestoclaw yaml file.

    Preserves the rest of the file as-is by doing targeted text replacement.
    Works for both praestoclaw.yaml (base) and praestoclaw.local.yaml (override).
    """

    content = config_path.read_text(encoding="utf-8") if config_path.is_file() else ""

    # Build the new mcp_servers YAML block
    lines: list[str] = []
    for name, srv in servers.items():
        lines.append(f"    {name}:")
        for key, val in srv.items():
            if isinstance(val, list):
                # Flow style for short lists: args: ["mcp", "icm"]
                items = ", ".join(_yaml_scalar(v) for v in val)
                lines.append(f"      {key}: [{items}]")
            elif isinstance(val, dict):
                lines.append(f"      {key}:")
                for dk, dv in val.items():
                    lines.append(f"        {dk}: {_yaml_scalar(dv)}")
            else:
                lines.append(f"      {key}: {_yaml_scalar(val)}")
    new_block = "\n".join(lines)

    # Try to find and replace existing tools.mcp_servers section
    # Pattern: "tools:\n  mcp_servers:\n" followed by indented content until next top-level key
    pattern = r"(tools:\s*\n\s*mcp_servers:\s*\n)((?:\s{4,}\S.*\n)*)"
    if re.search(pattern, content):
        replacement = f"tools:\n  mcp_servers:\n{new_block}\n"
        content = re.sub(pattern, lambda _: replacement, content)
    else:
        # No existing section — insert before channels: or append
        insert_before = re.search(r"^(channels:|cron:|logging:)", content, re.MULTILINE)
        block = f"\ntools:\n  mcp_servers:\n{new_block}\n\n"
        if insert_before:
            pos = insert_before.start()
            content = content[:pos] + block + content[pos:]
        else:
            content = content.rstrip() + "\n" + block

    config_path.write_text(content, encoding="utf-8")
    ensure_schema_line(config_path)


def _yaml_scalar(val: Any) -> str:
    """Format a scalar value for inline YAML."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        # Escape YAML double-quote special characters
        escaped = (
            val.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
        )
        return f'"{escaped}"'
    return str(val)


def _auth_label(srv: Any) -> str:
    """Short label for the auth mechanism used by a server."""
    if srv.auth.type == "oauth" and srv.auth.client_id:
        return "entra"
    if srv.auth.type == "oauth":
        return "oauth"
    if srv.auth.type == "bearer":
        return "bearer"
    if srv.auth.type == "implicit":
        return "token"
    return "none"


def _status_label(name: str, srv: Any) -> str:
    """Status label showing token availability."""
    if srv.enabled is False:
        return "[dim]disabled[/dim]"
    suffix = " [dim](auto)[/dim]" if srv.enabled == "auto" else ""
    # Stdio servers handle auth internally — always "ready"
    if srv.command:
        return f"[green]+ ready[/green]{suffix}"
    from praestoclaw.mcp.auth import has_cached_token

    if has_cached_token(name, srv):
        return f"[green]+ ready[/green]{suffix}"
    return f"[yellow]x no token[/yellow]{suffix}"


@mcp_app.command("list")
def mcp_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured MCP servers with auth and token status."""
    cfg = _load_config_safe(config)

    servers = cfg.tools.mcp_servers
    if not servers:
        console.print("[dim]No MCP servers configured.[/dim]")
        return

    table = Table(title="MCP Servers")
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Auth", style="dim")
    table.add_column("Status")

    for name, srv in servers.items():
        desc = (
            srv.description
            if srv.description is not None
            else get_default_description(name, is_agency=srv.is_agency) or ""
        )
        name_display = f"[dim]{name}[/dim]" if not srv.enabled else name
        table.add_row(name_display, desc, _auth_label(srv), _status_label(name, srv))

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name"),
    command: list[str] | None = typer.Argument(None, help="Server command and args (after --)"),
    transport: str = typer.Option(
        "stdio", "--transport", "-t", help="Transport: stdio (default) or http"
    ),
    url: str | None = typer.Option(
        None, "--url", help="HTTP endpoint URL (alternative to command)"
    ),
    env: list[str] | None = typer.Option(
        None, "-e", "--env", help="Environment variable KEY=VALUE (repeatable)"
    ),
    timeout: int | None = typer.Option(None, "--timeout", help="Tool call timeout in seconds"),
    risk: int | None = typer.Option(None, "--risk", help="Server default risk score: 0-10"),
    namespace: str | None = typer.Option(None, "--namespace", help="Override namespace prefix"),
    header: list[str] | None = typer.Option(
        None, "--header", help="HTTP header 'Key: Value' (repeatable)"
    ),
    auth: str | None = typer.Option(
        None, "--auth", help="Auth type: oauth (bearer auto-detected from --header)"
    ),
    client_id: str | None = typer.Option(None, "--client-id", help="OAuth client ID"),
    grant_type: str | None = typer.Option(
        None, "--grant-type", help="OAuth grant: authorization_code or client_credentials"
    ),
    callback_port: int | None = typer.Option(None, "--callback-port", help="OAuth callback port"),
    auth_server_url: str | None = typer.Option(
        None, "--auth-server-url", help="OAuth auth server URL (skip discovery)"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server to the configuration.

    Stdio: praestoclaw mcp add <name> -- <command> [args...]
    HTTP:  praestoclaw mcp add --transport http <name> --url <url>
    """
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Read local override to update (never touch the base praestoclaw.yaml)
    local_raw = _load_yaml(local_path) if local_path.is_file() else {}
    tools_section = local_raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    # Collision check: only block if local config has substantial config
    # (not just enabled: true/false). Simple enable/disable entries are
    # overwritten freely — `pc mcp add` is a "configure" action.
    existing = mcp_section.get(name)
    if existing and not force:
        has_real_config = isinstance(existing, dict) and any(k != "enabled" for k in existing)
        if has_real_config:
            console.print(
                f"[yellow]MCP server '{name}' already configured in local config. Use --force to overwrite.[/yellow]"
            )
            raise typer.Exit(1)

    entry: dict[str, Any] = {}

    # Auto-detect well-known servers when no explicit --url or command given.
    user_explicit = transport != "stdio" or url or command
    if not user_explicit:
        from praestoclaw.mcp.defaults import extract_params

        merged_cfg = _load_config_safe(str(config_path.parent))
        merged_srv = merged_cfg.tools.mcp_servers.get(name)
        if merged_srv and merged_srv.url:
            # Known HTTP server — enable + auth + optional param config
            entry["enabled"] = True
            # Prompt for optional params derived from {var} in url/headers/env
            params = extract_params(merged_srv.url, merged_srv.headers, merged_srv.env)
            if params:
                resolved = _prompt_optional_params(name, params)
                if resolved:
                    # Write resolved URL/headers to local config
                    if merged_srv.url and "{" in merged_srv.url:
                        resolved_url = merged_srv.url
                        for pk, pv in resolved.items():
                            resolved_url = resolved_url.replace(f"{{{pk}}}", pv)
                        if "{" not in resolved_url:
                            entry["url"] = resolved_url
                    if merged_srv.headers:
                        resolved_hdrs: dict[str, str] = {}
                        for hk, hv in merged_srv.headers.items():
                            for pk, pv in resolved.items():
                                hv = hv.replace(f"{{{pk}}}", pv)
                            resolved_hdrs[hk] = hv
                        if resolved_hdrs:
                            entry["headers"] = resolved_hdrs

            mcp_section[name] = entry
            _save_mcp_servers(local_path, mcp_section)
            console.print(
                f"  [green]+[/green] MCP server [bold]{name}[/bold] enabled in [cyan]{local_path}[/cyan]"
            )
            return

    if transport == "http" or url:
        # HTTP transport
        if not url and command:
            url = command[0]  # first positional arg as URL
        if not url:
            console.print("[red]HTTP transport requires --url or a URL argument.[/red]")
            raise typer.Exit(1)
        entry["url"] = url
        # Headers → auth config
        if header:
            for h in header:
                if ":" in h:
                    key, val = h.split(":", 1)
                    key, val = key.strip(), val.strip()
                    if key.lower() == "authorization" and val.lower().startswith("bearer "):
                        entry.setdefault("auth", {})["type"] = "bearer"
                        entry["auth"]["token"] = val[7:]  # strip "Bearer "
        # OAuth auth config (overrides any bearer detected from --header)
        if auth and auth != "oauth":
            console.print(
                f"[red]Invalid --auth '{auth}'. Use 'oauth' (bearer is auto-detected from --header).[/red]"
            )
            raise typer.Exit(1)
        if auth == "oauth" or client_id:
            auth_cfg = entry.setdefault("auth", {})
            auth_cfg.pop("token", None)  # clear conflicting bearer keys
            auth_cfg.pop("token_env", None)
            auth_cfg["type"] = "oauth"
            if client_id:
                auth_cfg["client_id"] = client_id
            if grant_type:
                if grant_type not in ("authorization_code", "client_credentials"):
                    console.print(
                        f"[red]Invalid --grant-type '{grant_type}'. "
                        "Use 'authorization_code' or 'client_credentials'.[/red]"
                    )
                    raise typer.Exit(1)
                auth_cfg["grant_type"] = grant_type
            if callback_port is not None:
                auth_cfg["callback_port"] = callback_port
            if auth_server_url:
                auth_cfg["auth_server_url"] = auth_server_url
        # Env for HTTP (rare but supported)
        if env:
            env_dict: dict[str, str] = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict
    else:
        # Stdio transport
        if not command:
            console.print(
                "[red]Stdio transport requires a command. Usage: pc mcp add <name> -- <command> [args...][/red]"
            )
            raise typer.Exit(1)
        entry["command"] = command[0]
        if len(command) > 1:
            entry["args"] = list(command[1:])
        # Env vars
        if env:
            env_dict = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict

    # Optional per-server overrides
    if timeout is not None:
        entry["timeout"] = timeout
    if risk is not None:
        entry["risk"] = risk
    if namespace:
        entry["namespace"] = namespace

    # Prompt for description if not already set (helps LLM discover the server)
    if "description" not in entry:
        try:
            desc = console.input(
                f"  [dim]Description for [bold]{name}[/bold] "
                "(helps LLM understand when to use it, Enter to skip): [/dim]"
            ).strip()
            if desc:
                entry["description"] = desc[:100]
        except (EOFError, KeyboardInterrupt):
            pass

    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]+[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )

    # Auto-test connectivity
    cfg = _load_config_safe(config)
    ok, msg = _test_single_server(name, cfg)
    if not ok:
        m = msg.lower()
        if "401" in m or "unauthorized" in m or "token" in m or "auth" in m:
            console.print(f"[dim]Tip: run 'praestoclaw mcp login {name}' to authenticate.[/dim]")


@mcp_app.command("add-json")
def mcp_add_json(
    name: str = typer.Argument(..., help="MCP server name"),
    json_config: str = typer.Argument(..., help="JSON configuration string"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server from a JSON configuration string.

    Example: praestoclaw mcp add-json icm '{"command":"agency","args":["mcp","icm"],"timeout":60}'
    """

    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    try:
        entry = json.loads(json_config)
    except json.JSONDecodeError as exc:
        console.print(f"[red]Invalid JSON: {exc}[/red]")
        raise typer.Exit(1)

    if not isinstance(entry, dict):
        console.print("[red]JSON must be an object.[/red]")
        raise typer.Exit(1)

    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    mcp_section = local_raw.setdefault("tools", {}).setdefault("mcp_servers", {})

    # Collision check: only block if local config has substantial config
    existing = mcp_section.get(name)
    if existing and not force:
        has_real_config = isinstance(existing, dict) and any(k != "enabled" for k in existing)
        if has_real_config:
            console.print(
                f"[yellow]MCP server '{name}' already configured in local config. Use --force to overwrite.[/yellow]"
            )
            raise typer.Exit(1)
    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]+[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="MCP server name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove an MCP server from the configuration."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Check existence against merged config
    merged_cfg = _load_config_safe(str(config_path.parent))
    if name not in merged_cfg.tools.mcp_servers:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    removed_from: list[str] = []

    # Remove from local override if present
    if local_path.is_file():
        local_raw = _load_yaml(local_path)
        local_mcp = local_raw.get("tools", {}).get("mcp_servers", {})
        if name in local_mcp:
            del local_mcp[name]
            if local_mcp:
                _save_mcp_servers(local_path, local_mcp)
            else:
                # Last server removed — wipe the tools.mcp_servers key from the file
                tools_sec = local_raw.get("tools", {})
                tools_sec.pop("mcp_servers", None)
                if not tools_sec:
                    local_raw.pop("tools", None)
                from praestoclaw.config.loader import save_yaml

                save_yaml(local_path, local_raw)
            removed_from.append(str(local_path))

    # Remove from base config if present
    base_raw = _load_yaml(config_path) if config_path.is_file() else {}
    base_mcp = base_raw.get("tools", {}).get("mcp_servers", {})
    if name in base_mcp:
        del base_mcp[name]
        _save_mcp_servers(config_path, base_mcp)
        removed_from.append(str(config_path))

    if removed_from:
        console.print(
            f"  [green]+[/green] MCP server [bold]{name}[/bold] removed"
            f" from [cyan]{', '.join(removed_from)}[/cyan]"
        )
    else:
        console.print(
            f"[yellow]MCP server '{name}' exists in merged config but was not found "
            f"in any editable file (may be inherited via extends: or bundled defaults).[/yellow]"
        )


@mcp_app.command("get")
def mcp_get(
    name: str = typer.Argument(..., help="MCP server name"),
    raw_output: bool = typer.Option(False, "--raw", help="Output as JSON"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed configuration for a specific MCP server."""

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)

    if srv is None:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    if raw_output:
        console.print(json.dumps(srv.model_dump(exclude_none=True), indent=2))
        return

    # Formatted output
    if srv.command:
        transport = "stdio"
        target = f"{srv.command} {' '.join(srv.args)}"
    elif srv.url:
        transport = "http"
        target = srv.url
    else:
        transport = "unknown"
        target = ""

    console.print(f"[bold]Server:[/bold] {name}")
    if srv.description is not None:
        effective_desc = srv.description
    else:
        effective_desc = get_default_description(name, is_agency=srv.is_agency) or ""
    if effective_desc:
        console.print(f"[bold]Description:[/bold] {effective_desc}")
    console.print(f"[bold]Enabled:[/bold] {'yes' if srv.enabled else '[red]no[/red]'}")
    console.print(f"[bold]Transport:[/bold] {transport}")
    console.print(f"[bold]{'Command' if srv.command else 'URL'}:[/bold] {target}")

    if srv.is_agency:
        console.print("[bold]Agency:[/bold] yes (auto-detected)")

    if srv.timeout is not None:
        console.print(f"[bold]Timeout:[/bold] {srv.timeout}s")
    else:
        default = "120s" if srv.is_agency else "60s"
        console.print(f"[bold]Timeout:[/bold] {default} (default)")

    if srv.risk is not None:
        console.print(f"[bold]Risk:[/bold] {srv.risk}")
    else:
        console.print("[bold]Risk:[/bold] (policy/auto)")

    if srv.namespace:
        console.print(f"[bold]Namespace:[/bold] {srv.namespace}")
    else:
        console.print(f"[bold]Namespace:[/bold] {name}")

    if srv.env:
        env_str = ", ".join(f"{k}=..." for k in srv.env)
        console.print(f"[bold]Env:[/bold] {env_str}")

    if srv.command:
        console.print("[bold]Auth:[/bold] none (stdio — handled internally)")
    else:
        console.print(f"[bold]Auth:[/bold] {srv.auth.type}")


def _test_mcp_connect(
    srv_name: str,
    *,
    command: str | None = None,
    args: list[str] | None = None,
    url: str | None = None,
    headers: dict[str, str] | None = None,
    auth: httpx.Auth | None = None,
    timeout: float = 60.0,
) -> tuple[bool, str, list[dict[str, Any]]]:
    """Low-level connect test. Returns ``(ok, message, tools_list)``."""
    import asyncio as _asyncio

    async def _connect() -> tuple[bool, str, list[dict[str, Any]]]:
        from praestoclaw.mcp.client import MCPClient

        client = MCPClient(
            command=command,
            args=args,
            url=url,
            headers=headers,
            auth=auth,
            name=srv_name,
            legacy_protocol=command is not None,
        )
        try:
            async with _asyncio.timeout(2 * timeout):
                await client.connect(timeout=timeout)
            tools = await client.list_tools(timeout=timeout)
            protocol = client.protocol_version or "unknown"
            return True, f"{len(tools)} tools (protocol {protocol})", tools
        except TimeoutError:
            return False, f"timeout ({timeout:.0f}s)", []
        except Exception as exc:
            return False, str(exc), []
        finally:
            try:
                await client.disconnect()
            except Exception:
                pass

    try:
        return _asyncio.run(_connect())
    except Exception as exc:
        return False, str(exc), []


def _test_one_sync(
    name: str,
    cfg: Any,
    *,
    timeout_override: int | None = None,
) -> tuple[bool, str, list[dict[str, Any]]]:
    """Full test for one server (auth + connect + list tools).

    Runs everything synchronously (spawns its own event loop).
    Returns ``(ok, message, tools_list)``.
    """
    import asyncio as _asyncio

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        return False, "not found in config", []
    if not srv.enabled:
        return False, "disabled", []
    if not srv.command and not srv.url:
        return False, "no command or url configured", []

    # Timeout
    if timeout_override is not None:
        timeout = max(1.0, float(timeout_override))
    elif srv.timeout is not None:
        timeout = max(1.0, float(srv.timeout))
    elif srv.is_agency:
        timeout = 120.0
    else:
        timeout = 60.0

    # Resolve auth
    headers: dict[str, str] | None = None
    auth_provider = None
    if srv.url:
        try:
            resolved = _asyncio.run(_resolve_auth_headers_for_test(srv, cfg))
        except Exception:
            resolved = {}
        all_headers = {**(srv.headers or {}), **resolved}
        if any(k.lower() == "authorization" for k in all_headers):
            headers = all_headers
        else:
            # Entra-protected servers: use MSAL (silent → interactive) to
            # bypass MCP SDK OAuth which sends resource+scope that Entra
            # rejects (AADSTS9010010).
            from praestoclaw.mcp.auth import acquire_entra_token_for_server

            is_entra, entra_token = acquire_entra_token_for_server(
                srv.url, srv.headers, timeout=2.0
            )
            if entra_token:
                headers = {**(srv.headers or {}), "Authorization": f"Bearer {entra_token}"}
            elif not is_entra:
                # Non-Entra server — fall through to SDK OAuth auto-discovery
                try:
                    from praestoclaw.mcp.oauth_provider import create_oauth_auth

                    auth_provider = _asyncio.run(create_oauth_auth(name, srv, cfg.providers))
                except Exception as exc:
                    if srv.auth.type == "oauth":
                        return False, f"OAuth setup failed: {exc}", []
                    auth_provider = None
                if auth_provider is not None:
                    headers = (
                        {k: v for k, v in srv.headers.items() if k.lower() != "authorization"}
                        if srv.headers
                        else None
                    )
                else:
                    headers = dict(srv.headers) if srv.headers else None
            else:
                # Entra server but login failed — still attempt connect (will get 401)
                headers = dict(srv.headers) if srv.headers else None

    return _test_mcp_connect(
        name,
        command=srv.command,
        args=srv.args if srv.args else None,
        url=srv.url,
        headers=headers,
        auth=auth_provider,
        timeout=timeout,
    )


def _test_single_server(
    name: str,
    cfg: Any,
    *,
    show_tools: bool = False,
    timeout_override: int | None = None,
) -> tuple[bool, str]:
    """Test one server with spinner + result display. Returns (ok, message)."""
    import threading

    from rich.live import Live
    from rich.spinner import Spinner
    from rich.text import Text

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        return False, "not found"

    label = srv.url or (f"{srv.command} {' '.join(srv.args)}" if srv.command else "?")
    spinner = Spinner("dots", text=Text.assemble(("  ", ""), (name, "bold"), f"  {label}"))

    result_holder: list[tuple[bool, str, list[dict[str, Any]]]] = []

    def _run() -> None:
        try:
            result_holder.append(_test_one_sync(name, cfg, timeout_override=timeout_override))
        except Exception as exc:
            result_holder.append((False, str(exc), []))

    t = threading.Thread(target=_run, daemon=True)
    t.start()
    with Live(spinner, console=console, refresh_per_second=12, transient=True):
        t.join()

    ok, msg, tools = result_holder[0] if result_holder else (False, "no result", [])
    icon = "[green]+[/green]" if ok else "[red]x[/red]"
    console.print(f"{icon}  [bold]{name}[/bold]  {msg}")
    if ok and show_tools and tools:
        from rich.table import Table as RichTable

        tbl = RichTable(title=f"Tools ({len(tools)})")
        tbl.add_column("Name", style="bold")
        tbl.add_column("Description")
        for tool in tools:
            tbl.add_row(tool.get("name", "?"), tool.get("description", "")[:80])
        console.print(tbl)
    return ok, msg


def _test_servers_live(
    targets: list[str],
    cfg: Any,
    *,
    show_tools: bool = False,
    timeout_override: int | None = None,
) -> int:
    """Test multiple servers concurrently with live per-server spinners.

    Returns number of servers that passed.
    """
    import threading
    import time

    from rich.live import Live
    from rich.spinner import Spinner
    from rich.table import Table as RichTable
    from rich.text import Text

    # Shared state
    lock = threading.Lock()
    status: dict[str, str] = {n: "waiting" for n in targets}
    results: dict[str, tuple[bool, str, list[dict[str, Any]]]] = {}

    def run_one(name: str) -> None:
        with lock:
            status[name] = "testing"
        try:
            result = _test_one_sync(name, cfg, timeout_override=timeout_override)
        except Exception as exc:
            result = (False, str(exc), [])
        with lock:
            results[name] = result
            status[name] = "done"

    # Build the live display
    spinner_frames = Spinner("dots")

    def render() -> RichTable:
        with lock:
            snap_status = status.copy()
            snap_results = results.copy()
        tbl = RichTable(box=None, show_header=False, padding=(0, 1))
        tbl.add_column(width=2)  # status icon
        tbl.add_column(min_width=18)  # name
        tbl.add_column()  # message
        for name in targets:
            st = snap_status.get(name, "waiting")
            if st == "done":
                ok, msg, _ = snap_results.get(name, (False, "", []))
                icon = "[green]+[/green]" if ok else "[red]x[/red]"
                tbl.add_row(icon, f"[bold]{name}[/bold]", msg)
            elif st == "testing":
                tbl.add_row(
                    spinner_frames,
                    Text(name, style="bold"),
                    Text("connecting...", style="dim"),
                )
            else:
                tbl.add_row("", f"[dim]{name}[/dim]", "")
        return tbl

    # Launch threads
    threads = [threading.Thread(target=run_one, args=(n,), daemon=True) for n in targets]
    for t in threads:
        t.start()

    with Live(render(), console=console, refresh_per_second=12) as live:
        while any(t.is_alive() for t in threads):
            time.sleep(0.08)
            live.update(render())
        live.update(render())

    # Show tool details after live display
    if show_tools:
        for name in targets:
            ok, _, tools = results.get(name, (False, "", []))
            if ok and tools:
                tbl = RichTable(title=f"{name} — Tools ({len(tools)})")
                tbl.add_column("Name", style="bold")
                tbl.add_column("Description")
                for tool in tools:
                    tbl.add_row(tool.get("name", "?"), tool.get("description", "")[:80])
                console.print(tbl)

    return sum(1 for ok, _, _ in results.values() if ok)


@mcp_app.command("test")
def mcp_test(
    name: str | None = typer.Argument(None, help="MCP server name (omit for all enabled)"),
    show_tools: bool = typer.Option(False, "--tools", "-t", help="List discovered tools"),
    timeout_override: int | None = typer.Option(
        None, "--timeout", help="Override timeout in seconds"
    ),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Test connectivity and auth for MCP servers.

    Without a name: test all enabled servers with cached tokens.
    With a name: test a specific server.
    """
    cfg = _load_config_safe(config)

    if name is not None:
        ok, _msg = _test_single_server(
            name, cfg, show_tools=show_tools, timeout_override=timeout_override
        )
        if not ok:
            raise typer.Exit(1)
        return

    # Batch mode: test all enabled servers with cached tokens
    from praestoclaw.mcp.auth import has_cached_token

    targets = []
    for srv_name, srv in cfg.tools.mcp_servers.items():
        if srv.enabled is False:
            continue
        if srv.enabled == "auto" and not has_cached_token(srv_name, srv):
            continue
        targets.append(srv_name)

    if not targets:
        console.print("[dim]No testable servers (all disabled or no cached tokens).[/dim]")
        return

    passed = _test_servers_live(
        targets, cfg, show_tools=show_tools, timeout_override=timeout_override
    )
    console.print(f"\n[bold]Result:[/bold] {passed}/{len(targets)} passed")
    if passed < len(targets):
        raise typer.Exit(1)


async def _resolve_auth_headers_for_test(srv: Any, cfg: Any) -> dict[str, str]:
    """Resolve auth headers for the test command."""
    from praestoclaw.mcp.auth import resolve_auth_headers

    return await resolve_auth_headers(srv, cfg.providers)


def _refresh_path() -> None:
    """Refresh PATH so a just-installed binary can be found."""

    if sys.platform == "win32":
        try:
            r = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    '[System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + '
                    '[System.Environment]::GetEnvironmentVariable("Path","User")',
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                os.environ["PATH"] = r.stdout.strip()
        except Exception:
            pass
    else:
        # Append common install directories if not already in PATH
        for d in (
            "~/.local/bin",
            "~/bin",
            "/usr/local/bin",
            "~/.config/agency/CurrentVersion",  # Agency CLI default install location
        ):
            expanded = os.path.expanduser(d)
            if os.path.isdir(expanded) and expanded not in os.environ.get("PATH", ""):
                os.environ["PATH"] = expanded + os.pathsep + os.environ.get("PATH", "")


def _ensure_agency_installed(raise_on_failure: bool = True) -> str | None:
    """Check for Agency CLI binary (no auto-install).

    Returns binary path if found, else prints install instructions.
    """
    agency_bin = shutil.which("agency")
    if agency_bin:
        return agency_bin

    if sys.platform == "win32":
        install_cmd = 'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"'
    else:
        install_cmd = "curl -sSfL https://aka.ms/InstallTool.sh | sh -s agency"

    console.print(
        "[yellow]Agency CLI not found.[/yellow]\n"
        f"  Install: [cyan]{install_cmd}[/cyan]\n"
        "  [dim]Most servers are available via HTTP without Agency."
        " Use [bold]pc mcp setup[/bold] instead.[/dim]"
    )
    if raise_on_failure:
        raise typer.Exit(1)
    return None


def _try_install_agency(*, quick: bool = False) -> str | None:
    """Attempt to install the Agency CLI automatically.

    Runs the official ``aka.ms/InstallTool`` bootstrap script. On Linux/macOS
    uses ``curl | sh``, on Windows uses ``iex(irm ...)``. In interactive
    (non-quick) mode prompts before running. Returns the resolved binary
    path on success, ``None`` on failure / decline.

    Security / supply-chain notes:
      - Piping a remote bootstrap script into a shell is an inherent
        supply-chain risk. We mitigate (not eliminate) by:
          * pinning HTTPS + TLS 1.2 on the download (``--proto =https
            --tlsv1.2``);
          * fetching only from a Microsoft-owned ``aka.ms`` redirect URL;
          * never running the installer without a real TTY attached
            (no silent installs in CI / piped stdin), and prompting
            explicitly in interactive mode;
          * displaying the exact command before running so the user can
            audit / copy-paste it elsewhere.
      - Users (or org policy) can opt out of auto-install entirely by
        setting ``PRAESTOCLAW_NO_AGENCY_AUTO_INSTALL=1`` in the
        environment; we then print the install command but never
        execute it.
    """
    existing = shutil.which("agency")
    if existing:
        return existing

    # Refresh PATH in case agency was installed by a prior step in this run
    _refresh_path()
    existing = shutil.which("agency")
    if existing:
        return existing

    # Explicit org/user opt-out: never invoke the remote bootstrap.
    if os.environ.get("PRAESTOCLAW_NO_AGENCY_AUTO_INSTALL", "").lower() in {
        "1",
        "true",
        "yes",
    }:
        # Compute display_cmd before returning so opted-out users still get
        # an actionable manual-install hint.
        if sys.platform == "win32":
            opt_out_cmd = 'iex "& { $(irm https://aka.ms/InstallTool.ps1) } agency"'
        else:
            opt_out_cmd = (
                "curl --proto '=https' --tlsv1.2 -sSfL https://aka.ms/InstallTool.sh | sh -s agency"
            )
        console.print(
            "  [dim]Agency CLI not found; auto-install disabled by "
            f"PRAESTOCLAW_NO_AGENCY_AUTO_INSTALL. Install manually:[/dim] "
            f"[cyan]{opt_out_cmd}[/cyan]"
        )
        return None

    is_windows = sys.platform == "win32"
    if is_windows:
        install_cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            'iex "& { $(irm https://aka.ms/InstallTool.ps1) } agency"',
        ]
        display_cmd = 'iex "& { $(irm https://aka.ms/InstallTool.ps1) } agency"'
    else:
        # We'll pipe two separate processes (curl -> sh) below instead of
        # invoking a shell to interpret the `|` — keeps shell=True out of
        # this high-impact init code path. ``--proto =https`` / ``--tlsv1.2``
        # harden the transport before piping remote bytes into a shell.
        display_cmd = (
            "curl --proto '=https' --tlsv1.2 -sSfL https://aka.ms/InstallTool.sh | sh -s agency"
        )
        install_cmd = display_cmd  # type: ignore[assignment]

    if not quick:
        from praestoclaw.utils.input import flush_stdin, is_tty, read_key_blocking
    else:
        from praestoclaw.utils.input import is_tty

    # Refuse to launch a network installer when there's no real terminal
    # attached, even in --quick mode. CI runs (pytest, scripted invocations,
    # piped stdin) hit this path too, and ``iex(irm InstallTool.ps1)`` /
    # ``curl | sh`` can hang for minutes without a tty, timing out the job.
    if not is_tty():
        console.print(
            "  [dim]Agency CLI not found; skipped auto-install (non-interactive). "
            "Install manually:[/dim] "
            f"[cyan]{display_cmd}[/cyan]"
        )
        return None

    if not quick:
        console.print(
            "  [yellow]Agency CLI not found.[/yellow] "
            "It's required for Microsoft internal MCP servers."
        )
        console.print(f"  [dim]Will run:[/dim] [cyan]{display_cmd}[/cyan]")
        console.print("  [dim]Install now? [Y/n][/dim] ", end="")
        flush_stdin()
        try:
            key = read_key_blocking()
        except (KeyboardInterrupt, EOFError):
            key = "n"
        console.print()
        # Only Y / y / Enter installs; everything else (n, Esc, space, any
        # other key) declines so an accidental keypress doesn't trigger a
        # network install.
        if key.lower() != "y" and key not in ("enter", "\r", "\n"):
            console.print(
                f"  [dim]Skipped — you can install later with:[/dim] [cyan]{display_cmd}[/cyan]"
            )
            return None
    else:
        console.print(f"  [dim]Installing Agency CLI:[/dim] [cyan]{display_cmd}[/cyan]")

    # Snapshot terminal state so we can restore it if the installer
    # script leaves the terminal in a weird mode (raw, hidden cursor, etc).
    saved_termios = None
    if not is_windows:
        try:
            import termios

            saved_termios = (sys.stdin.fileno(), termios.tcgetattr(sys.stdin.fileno()))
        except Exception:
            saved_termios = None

    try:
        if is_windows:
            result = subprocess.run(install_cmd, check=False, timeout=300)
        else:
            # Run curl and sh as separate processes connected by an explicit
            # pipe (no shell=True). curl flags pin TLS 1.2+/https-only before
            # the remote payload is fed into a fresh sh process.
            curl_proc = subprocess.Popen(
                [
                    "curl",
                    "--proto",
                    "=https",
                    "--tlsv1.2",
                    "-sSfL",
                    "https://aka.ms/InstallTool.sh",
                ],
                stdout=subprocess.PIPE,
            )
            try:
                sh_proc = subprocess.Popen(
                    ["sh", "-s", "agency"],
                    stdin=curl_proc.stdout,
                )
            except Exception:
                curl_proc.kill()
                with contextlib.suppress(Exception):
                    curl_proc.wait(timeout=5)
                raise
            # Close our handle so curl gets SIGPIPE if sh exits early.
            assert curl_proc.stdout is not None
            curl_proc.stdout.close()
            try:
                sh_rc = sh_proc.wait(timeout=300)
            except subprocess.TimeoutExpired:
                sh_proc.kill()
                curl_proc.kill()
                with contextlib.suppress(Exception):
                    sh_proc.wait(timeout=5)
                with contextlib.suppress(Exception):
                    curl_proc.wait(timeout=5)
                raise
            except BaseException:
                # Ctrl+C (KeyboardInterrupt) or any other base exception
                # mid-wait must not orphan the installer subprocesses.
                sh_proc.kill()
                curl_proc.kill()
                with contextlib.suppress(Exception):
                    sh_proc.wait(timeout=5)
                with contextlib.suppress(Exception):
                    curl_proc.wait(timeout=5)
                raise
            try:
                curl_rc = curl_proc.wait(timeout=10)
            except BaseException:
                curl_proc.kill()
                with contextlib.suppress(Exception):
                    curl_proc.wait(timeout=5)
                raise
            rc = sh_rc if curl_rc == 0 else curl_rc

            class _Result:
                returncode = rc

            result = _Result()  # type: ignore[assignment]
        if result.returncode != 0:
            console.print(
                f"  [red]Agency install failed[/red] (exit code {result.returncode}). "
                f"Try manually: [cyan]{display_cmd}[/cyan]"
            )
            return None
    except subprocess.TimeoutExpired:
        console.print("  [red]Agency install timed out[/red] after 5 minutes.")
        return None
    except Exception as exc:
        console.print(f"  [red]Agency install error:[/red] {exc}")
        return None
    finally:
        # Restore termios + ensure cursor visible (installer scripts can
        # leave the terminal in a broken state).
        if saved_termios is not None:
            try:
                import termios

                fd, old = saved_termios
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            except Exception:
                pass
        try:
            if sys.stdout.isatty():
                sys.stdout.write("\033[?25h")  # show cursor
                sys.stdout.flush()
        except Exception:
            pass

    # Refresh PATH then re-check (installer typically writes to ~/.local/bin)
    _refresh_path()
    agency_bin = shutil.which("agency")
    if agency_bin:
        console.print(f"  [green]+[/green] Agency installed at [cyan]{agency_bin}[/cyan]")
        return agency_bin

    console.print(
        "  [yellow]Agency installed but not on PATH.[/yellow] "
        "Restart your terminal and re-run [cyan]pc init[/cyan]."
    )
    return None


def _is_recommended(name: str) -> bool:
    """True if server should be pre-selected in --all / interactive default.

    Uses detected user profile: core + office always, engineering/data
    only when relevant tools are detected.
    """
    recommended = _get_recommended_servers()
    return name in recommended


# Cache so detection runs once per process.
_recommended_cache: set[str] | None = None


def _get_recommended_servers() -> set[str]:
    """Return the set of server names to pre-select, based on environment detection."""
    global _recommended_cache  # noqa: PLW0603
    if _recommended_cache is not None:
        return _recommended_cache

    from praestoclaw.mcp.defaults import (
        GROUP_DATA,
        GROUP_ENGINEERING,
        GROUP_OFFICE,
        NOT_RECOMMENDED,
    )

    recommended = set(GROUP_OFFICE)

    if _detect_engineering_context():
        recommended |= GROUP_ENGINEERING
    if _detect_data_context():
        recommended |= GROUP_DATA

    recommended -= NOT_RECOMMENDED
    _recommended_cache = recommended
    return recommended


def _detect_engineering_context() -> bool:
    """True if dev/engineering tools are detected."""
    import shutil

    # git, gh CLI, az CLI
    for tool in ("git", "gh", "az"):
        if shutil.which(tool):
            return True
    # ADO remote in .git/config
    try:
        ado_org, _ = _detect_ado_remote()
        if ado_org:
            return True
    except Exception:
        pass
    # GITHUB_TOKEN or AZURE_DEVOPS_EXT_PAT
    if os.environ.get("GITHUB_TOKEN") or os.environ.get("AZURE_DEVOPS_EXT_PAT"):
        return True
    # .git directory
    cwd = Path.cwd()
    for p in [cwd, *list(cwd.parents)[:3]]:
        if (p / ".git").exists():
            return True
    return False


def _detect_data_context() -> bool:
    """True if Kusto/KQL tools or files are detected."""
    import shutil

    # kusto CLI or fabric-rti-mcp
    if shutil.which("kusto") or shutil.which("fabric-rti-mcp"):
        return True
    # .kql files in cwd
    cwd = Path.cwd()
    if any(cwd.glob("*.kql")) or any(cwd.glob("*/*.kql")):
        return True
    # KUSTO_SERVICE_URI set
    if os.environ.get("KUSTO_SERVICE_URI"):
        return True
    return False


def _detect_ado_remote() -> tuple[str | None, str | None]:
    """Try to detect ADO org and project from current git remote.

    Returns ``(org, project)`` — either may be ``None``.
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        url = result.stdout.strip()
        if not url:
            return None, None

        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        path = parsed.path.lstrip("/") if parsed.path else ""

        # Handle SCP-like SSH remotes: git@ssh.dev.azure.com:v3/org/project/repo
        if not hostname and ":" in url:
            try:
                _, host_path = url.rsplit("@", 1)
                host, raw_path = host_path.split(":", 1)
                hostname = host.lower()
                path = raw_path.lstrip("/")
            except ValueError:
                hostname, path = "", ""

        parts = path.split("/") if path else []

        # https://dev.azure.com/org/project/_git/repo
        if hostname == "dev.azure.com":
            org = parts[0] if len(parts) >= 1 else None
            project = parts[1] if len(parts) >= 2 else None
            return org or None, project or None
        # git@ssh.dev.azure.com:v3/org/project/repo
        if hostname == "ssh.dev.azure.com":
            if len(parts) >= 2 and parts[0] == "v3":
                org = parts[1] if len(parts) >= 2 else None
                project = parts[2] if len(parts) >= 3 else None
                return org or None, project or None
        # https://org.visualstudio.com/project/_git/repo
        if hostname.endswith(".visualstudio.com"):
            org = hostname.split(".")[0] if hostname else None
            project = parts[0] if len(parts) >= 1 else None
            return org or None, project or None
    except Exception:
        pass
    return None, None


def _prompt_optional_params(name: str, params: set[str]) -> dict[str, str]:
    """Prompt user for optional server params.

    *params*: set of parameter names (from ``extract_params``).
    Enter = confirm default / skip if no default.
    Ctrl+C / ESC = skip all params (no config).

    Returns dict of param→value for params the user provided.
    """
    from praestoclaw.cli.init import _is_tty

    if not _is_tty():
        return {}

    defaults: dict[str, str] = {}

    # Auto-detect ADO org/project from git remote.
    #
    # Two sources, in priority order:
    #
    # 1. The shared project-detection snapshot (``DetectionEnv.ado_repos``)
    #    populated earlier in ``pc init``. This sees every ADO repo under
    #    the user's workspace roots, not just cwd, so a user running
    #    ``pc init`` from ``~`` still gets a sensible default.
    # 2. ``_detect_ado_remote()`` cwd-only fallback for standalone
    #    ``pc mcp add`` invocations where init never ran.
    if name in ("ado", "bluebird"):
        detected_org: str | None = None
        detected_project: str | None = None
        try:
            from praestoclaw.projects.detector import _CACHED_ENV

            if _CACHED_ENV is not None and _CACHED_ENV.ado_repos:
                org, proj, _repo = _CACHED_ENV.ado_repos[0]
                detected_org = org or None
                detected_project = proj or None
        except Exception:
            pass
        if detected_org is None and detected_project is None:
            detected_org, detected_project = _detect_ado_remote()
        if detected_org:
            defaults["organization"] = detected_org
        if detected_project:
            defaults["project"] = detected_project
        detected = {
            k: v for k, v in [("organization", detected_org), ("project", detected_project)] if v
        }
        if detected:
            console.print(f"    [dim]Detected from git remote: {detected}[/dim]")

    console.print("    [dim]Esc skip param, Ctrl+C skip all[/dim]")
    resolved: dict[str, str] = {}
    try:
        from prompt_toolkit import prompt as pt_prompt
        from prompt_toolkit.key_binding import KeyBindings
        from prompt_toolkit.keys import Keys

        _ESC_SENTINEL = "\x1b__skip__"
        bindings = KeyBindings()

        @bindings.add(Keys.Escape)
        def _esc(event: object) -> None:
            buf = getattr(event, "app", None)
            if buf:
                buf.current_buffer.text = _ESC_SENTINEL
                buf.current_buffer.validate_and_handle()

        for param in sorted(params):
            default = defaults.get(param, "")
            label = f"    {param}: "
            val = pt_prompt(label, default=default, key_bindings=bindings).strip()
            if val == _ESC_SENTINEL:
                continue  # Esc → skip this param
            if val:
                resolved[param] = val
            # cleared → skip, leave for runtime
    except (KeyboardInterrupt, EOFError):
        console.print("\n    [dim]skipped[/dim]")
        return {}
    except Exception:
        # prompt_toolkit unavailable or terminal incompatible — skip prompting
        return {}

    return resolved


def _resolve_server_args(name: str) -> list[str]:
    """Prompt user for required server args, using defaults where available."""
    from praestoclaw.mcp.defaults import SERVER_REGISTRY

    entry = SERVER_REGISTRY.get(name)
    if not entry or not entry.params:
        return []
    defaults: dict[str, str] = {}
    args: list[str] = []

    # Special handling for ADO: auto-detect org/project from git remote
    if name in ("ado", "bluebird"):
        detected_org, detected_project = _detect_ado_remote()
        if detected_org:
            defaults["organization"] = detected_org
        if detected_project:
            defaults["project"] = detected_project

    for param in sorted(entry.params):
        flag = f"--{param.replace('_', '-')}"
        default = defaults.get(param, "")
        prompt = f"    {flag}"
        if default:
            prompt += f" [{default}]"
        prompt += ": "
        val = console.input(prompt).strip() or default
        if val:
            args.extend([flag, val])
        else:
            return []  # user skipped

    return args


def _server_tag(name: str, servers: dict[str, Any] | None) -> str:
    """Short tag: ``http - entra - on`` or ``stdio - auto``."""
    if not servers or name not in servers:
        return ""
    srv = servers[name]
    kind = "http" if getattr(srv, "url", None) else "stdio"
    auth = _auth_label(srv)
    enabled = getattr(srv, "enabled", True)
    if enabled is False:
        state = "off"
    elif enabled == "auto":
        state = "auto"
    else:
        state = "on"
    parts = [kind]
    if auth != "none":
        parts.append(auth)
    parts.append(state)
    return " - ".join(parts)


def _group_servers(
    items: list[tuple[str, str]],
) -> list[tuple[str, list[tuple[str, str]]]]:
    """Organize servers into display groups. Returns (group_label, servers) pairs."""
    from praestoclaw.mcp.defaults import (
        GROUP_DATA,
        GROUP_ENGINEERING,
        GROUP_OFFICE,
        GROUP_SECURITY,
    )

    groups: dict[str, list[tuple[str, str]]] = {
        "Office": [],
        "Engineering": [],
        "Security": [],
        "Data": [],
        "Custom": [],
    }
    for name, desc in items:
        if name in GROUP_OFFICE:
            groups["Office"].append((name, desc))
        elif name in GROUP_ENGINEERING:
            groups["Engineering"].append((name, desc))
        elif name in GROUP_SECURITY:
            groups["Security"].append((name, desc))
        elif name in GROUP_DATA:
            groups["Data"].append((name, desc))
        else:
            groups["Custom"].append((name, desc))
    return [(label, servers) for label, servers in groups.items() if servers]


def _interactive_select(
    available: list[tuple[str, str]],
    known: set[str] | None = None,
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Show interactive checkbox for server selection.

    Pre-selects recommended servers based on detected user profile.
    Servers are displayed in groups (Office, Engineering, Security, Data, Custom).
    Uses arrow-key navigation in a real terminal, numbered fallback otherwise.

    Args:
        servers: merged server configs — used to show type/status tags.
    """
    known = known or set()
    items = [(n, d) for n, d in available]
    selected: set[str] = set()
    for n, _ in items:
        # User already configured and enabled → always pre-select.
        srv = servers.get(n) if servers else None
        if srv and getattr(srv, "enabled", None) is True:
            selected.add(n)
            continue
        if n in known:
            continue
        if not _is_recommended(n):
            continue
        selected.add(n)

    from praestoclaw.cli.init import _is_tty

    if _is_tty():
        # Fall back to numbered mode when the terminal is too short OR too
        # narrow to hold the full menu — in-place ANSI cursor refresh
        # corrupts the screen once content scrolls past the visible region
        # or wraps horizontally (cursor up by N lines counts terminal rows,
        # not logical lines).
        import shutil

        try:
            term_size = shutil.get_terminal_size((80, 24))
            term_rows, term_cols = term_size.lines, term_size.columns
        except Exception:
            term_rows, term_cols = 24, 80
        try:
            grouped_for_height = _group_servers(items)
            est_lines = sum(1 + len(gi) for _, gi in grouped_for_height) + 4 + 4
        except Exception:
            est_lines = len(items) + 8

        # Width budget: "  [+] " (6) + max_name + "  " (2) + desc + tags
        try:
            max_name = max(len(n) for n, _ in items)
            max_line = max(6 + max_name + 2 + len(d) + 30 for _, d in items)
        except Exception:
            max_line = 80

        if term_rows >= est_lines and term_cols >= max_line:
            try:
                return _multiselect_arrows(items, selected, known, servers)
            except Exception:
                pass
    return _multiselect_numbered(items, selected, known, servers)


def _multiselect_arrows(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Arrow-key multi-select with space-to-toggle. Returns list of selected names."""
    import sys

    from praestoclaw.cli.init import _read_key

    max_name = max(len(name) for name, _ in items)

    # Build grouped display: list of (is_header, label, item_index).
    grouped = _group_servers(items)
    item_index = {name: i for i, (name, _) in enumerate(items)}
    display_rows: list[tuple[bool, str, int]] = []  # (is_header, label, item_idx)
    selectable_indices: list[int] = []  # indices into display_rows that are items
    for group_label, group_items in grouped:
        display_rows.append((True, group_label, -1))
        for name, _desc in group_items:
            idx = item_index[name]
            row_idx = len(display_rows)
            display_rows.append((False, name, idx))
            selectable_indices.append(row_idx)

    sel_pos = 0  # index into selectable_indices

    # lines: header + blank + display_rows + blank + hint = len(display_rows) + 4
    total_lines = len(display_rows) + 4

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        count = len(selected)
        out.write(f"\033[2K  \033[1mMCP servers\033[0m \033[90m({count} selected)\033[0m\n")
        out.write("\n")
        cur_row = selectable_indices[sel_pos] if sel_pos < len(selectable_indices) else -1
        for row_i, (is_header, label, item_idx) in enumerate(display_rows):
            if is_header:
                out.write(f"\033[2K  \033[2;90m--- {label} ---\033[0m\n")
            else:
                name, desc = items[item_idx]
                check = "\033[32m+\033[0m" if name in selected else " "
                pad = name.ljust(max_name)
                tag = _server_tag(name, servers)
                tags = f"  \033[90m{tag}\033[0m" if tag else ""
                if name in known:
                    tags += "  \033[90m(installed)\033[0m"
                if row_i == cur_row:
                    line = f"  [{check}] \033[1;36m{pad}\033[0m  \033[1m{desc}\033[0m{tags}"
                else:
                    line = f"  [{check}] {pad}  \033[37m{desc}\033[0m{tags}"
                out.write(f"\033[2K{line}\n")
        out.write("\n")
        out.write(
            "\033[2K  \033[90mUp/Down switch  Space toggle"
            "  a all  n none  Enter confirm  Esc skip\033[0m\n"
        )
        out.flush()

    n_sel = len(selectable_indices)

    # Discard any stale keystrokes (Enter typed while previous step was
    # running) before showing the menu, so we don't auto-confirm.
    from praestoclaw.utils.input import flush_stdin

    flush_stdin()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                sel_pos = (sel_pos - 1) % n_sel
                _render()
            elif key in ("down", "j"):
                sel_pos = (sel_pos + 1) % n_sel
                _render()
            elif key in (" ", "space"):
                row_idx = selectable_indices[sel_pos]
                item_idx = display_rows[row_idx][2]
                name = items[item_idx][0]
                selected ^= {name}
                _render()
            elif key == "a":
                selected.clear()
                selected.update(name for name, _ in items if name not in known)
                _render()
            elif key == "n":
                selected.clear()
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                result = [name for name, _ in items if name in selected]
                if result:
                    console.print(
                        f"  [green]+[/green] {len(result)} server(s): {', '.join(result)}"
                    )
                else:
                    console.print("  [dim]No servers selected[/dim]")
                return result
            elif key in ("esc", "\x1b", "q"):
                # Esc or q = skip
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                console.print("  [dim]Skipped[/dim]")
                return []
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n_sel:
                    sel_pos = idx
                    row_idx = selectable_indices[sel_pos]
                    item_idx = display_rows[row_idx][2]
                    selected ^= {items[item_idx][0]}
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")
        sys.stdout.flush()


def _multiselect_numbered(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
    servers: dict[str, Any] | None = None,
) -> list[str]:
    """Numbered checkbox fallback for non-TTY. Returns list of selected names."""
    console.print(f"\nAvailable MCP servers ({len(items)}):")
    console.print(
        "[dim]Enter numbers to toggle, 'a' for all new, 'n' for none, Enter to confirm.[/dim]"
    )
    if known:
        console.print("[dim]To remove an installed server:  pc mcp remove <name>[/dim]\n")
    else:
        console.print()

    while True:
        for i, (n, d) in enumerate(items, 1):
            mark = "[green]x[/green]" if n in selected else " "
            tag = _server_tag(n, servers)
            type_tag = f" [dim]{tag}[/dim]" if tag else ""
            installed_tag = " [dim](installed)[/dim]" if n in known else ""
            console.print(f"  [{mark}] {i:2d}. {n:20s} [bold]{d}[/bold]{type_tag}{installed_tag}")

        choice = (
            console.input(
                f"\n[bold]Toggle ([cyan]1-{len(items)}[/cyan],"
                f" [cyan]a[/cyan]ll, [cyan]n[/cyan]one) or Enter:[/bold] "
            )
            .strip()
            .lower()
        )

        if not choice:
            break
        elif choice == "a":
            selected.clear()
            selected.update(n for n, _ in items if n not in known)
        elif choice == "n":
            selected.clear()
        else:
            for p in choice.replace(",", " ").split():
                try:
                    idx = int(p) - 1
                    if 0 <= idx < len(items):
                        selected ^= {items[idx][0]}
                except ValueError:
                    pass
        console.print()

    return [n for n, _ in items if n in selected]


def _bulk_login(cfg: Any) -> None:
    """Login to all auth providers needed by configured servers."""
    from praestoclaw.mcp.auth import _is_github_url, _resolve_github_token, has_msal_account
    from praestoclaw.mcp.defaults import GH_CLI_CLIENT_ID, GH_MCP_SCOPE, SHARED_ENTRA_CLIENT_ID

    needs_github = any(
        _is_github_url(srv.url) and srv.enabled is not False
        for srv in cfg.tools.mcp_servers.values()
    )
    needs_entra = any(
        srv.auth.client_id == SHARED_ENTRA_CLIENT_ID and srv.enabled is not False
        for srv in cfg.tools.mcp_servers.values()
    )

    if not needs_github and not needs_entra:
        console.print("[dim]No servers require login.[/dim]")
        return

    if needs_github:
        if _resolve_github_token():
            console.print("[green]+[/green] [bold]GitHub[/bold]  token already cached")
        else:
            console.print(
                "[yellow]o[/yellow] [bold]GitHub[/bold]  no token \u2014 device code login required"
            )
            try:
                input("  Press Enter to continue (Ctrl+C to skip) ")
                from praestoclaw.security.github_auth import github_device_login

                token = github_device_login(
                    client_id=GH_CLI_CLIENT_ID, scope=GH_MCP_SCOPE, console=console
                )
                try:
                    from praestoclaw.security.secrets import get_secret_store

                    get_secret_store().set("GITHUB_TOKEN", token)
                    console.print("[green]+[/green] [bold]GitHub[/bold]  token saved")
                except Exception:
                    pass
            except (EOFError, KeyboardInterrupt):
                console.print("\n  [dim]skipped[/dim]")
            except Exception as exc:
                console.print(f"[red]x[/red] [bold]GitHub[/bold]  {exc}")

    if needs_entra:
        if has_msal_account(SHARED_ENTRA_CLIENT_ID):
            console.print("[green]+[/green] [bold]Entra[/bold]   session already cached")
        else:
            first_scope: list[str] = ["openid"]
            for srv in cfg.tools.mcp_servers.values():
                if srv.auth.client_id == SHARED_ENTRA_CLIENT_ID and srv.auth.scopes:
                    first_scope = srv.auth.scopes
                    break
            console.print(
                "[yellow]o[/yellow] [bold]Entra[/bold]   "
                "login required \u2014 a browser window will open"
            )
            try:
                input("  Press Enter to continue (Ctrl+C to skip) ")
                from praestoclaw.utils.auth import acquire_entra_token

                entra_token = acquire_entra_token(
                    tenant_id="organizations",
                    client_id=SHARED_ENTRA_CLIENT_ID,
                    scopes=first_scope,
                )
                if entra_token:
                    console.print("[green]+[/green] [bold]Entra[/bold]   authenticated")
                else:
                    console.print("[red]x[/red] [bold]Entra[/bold]   login failed")
            except (EOFError, KeyboardInterrupt):
                console.print("\n  [dim]skipped[/dim]")
            except Exception as exc:
                console.print(f"[red]x[/red] [bold]Entra[/bold]   {exc}")


@mcp_app.command("login")
def mcp_login(
    name: str | None = typer.Argument(None, help="MCP server name (omit for bulk login)"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Authenticate with MCP servers.

    Without a name: bulk login to all auth providers (Entra + GitHub).
    With a name: login to a specific server.
    """
    import asyncio as _asyncio

    cfg = _load_config_safe(config)

    if name is None:
        _bulk_login(cfg)
        return

    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        raise typer.Exit(1)
    if not srv.url:
        console.print(
            f"[red]MCP server '{name}' uses stdio \u2014 OAuth login is not applicable.[/red]"
        )
        raise typer.Exit(1)

    async def _login() -> None:
        auth = srv.auth
        # MSAL path — Entra servers with client_id + scopes
        if auth.client_id and auth.scopes:
            from praestoclaw.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id="organizations",
                client_id=auth.client_id,
                scopes=auth.scopes,
            )
            if token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token cached via MSAL.")
            else:
                console.print(f"[red]MSAL login failed for '{name}'.[/red]")
            return

        # Discover Entra auth from resource metadata (probe → 401 → metadata)
        import asyncio as _aio

        from praestoclaw.mcp.auth import discover_entra_auth

        entra_info = await _aio.to_thread(discover_entra_auth, srv.url, srv.headers)  # type: ignore[arg-type]  # checked above
        if entra_info:
            client_id, scopes, tenant_id = entra_info
            from praestoclaw.utils.auth import acquire_entra_token

            token = acquire_entra_token(
                tenant_id=tenant_id,
                client_id=client_id,
                scopes=scopes,
            )
            if token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token cached via MSAL.")
            else:
                console.print(f"[red]MSAL login failed for '{name}'.[/red]")
            return

        # SDK OAuth path — generic non-Entra OAuth servers
        import httpx

        from praestoclaw.mcp.oauth_provider import create_oauth_auth

        provider = await create_oauth_auth(name, srv, cfg.providers)
        if provider is None:
            console.print(
                f"[yellow]MCP server '{name}' uses static bearer auth. "
                "No OAuth login needed.[/yellow]"
            )
            return

        srv_headers = {k: v for k, v in (srv.headers or {}).items() if k.lower() != "authorization"}
        probe_payload = {
            "jsonrpc": "2.0",
            "id": "mcp-login-probe",
            "method": "initialize",
            "params": {"capabilities": {}},
        }
        async with httpx.AsyncClient(auth=provider, headers=srv_headers, timeout=60.0) as client:
            resp = await client.post(srv.url, json=probe_payload)  # type: ignore[arg-type]
            from praestoclaw.mcp.oauth_storage import MCPTokenStorage

            has_token = await MCPTokenStorage(name).get_tokens() is not None
            if has_token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token stored.")
            elif resp.status_code < 400:
                console.print(
                    f"[dim]Server returned {resp.status_code} without requiring auth. "
                    "No OAuth token needed.[/dim]"
                )
            else:
                console.print(
                    f"[yellow]Server returned {resp.status_code}. "
                    "Authentication may have failed — try 'mcp test'.[/yellow]"
                )

    try:
        _asyncio.run(_login())
    except Exception as exc:
        console.print(f"[red]OAuth login failed: {exc}[/red]")
        raise typer.Exit(1)


@mcp_app.command("logout")
def mcp_logout(
    name: str | None = typer.Argument(None, help="MCP server name (omit for all)"),
) -> None:
    """Remove stored OAuth tokens for MCP servers.

    Without a name: clear all cached MCP tokens.
    With a name: clear tokens for a specific server.
    """
    from praestoclaw.mcp.oauth_storage import MCPTokenStorage

    if name is not None:
        MCPTokenStorage(name).clear()
        console.print(f"[green]Removed OAuth tokens for '{name}'.[/green]")
        return

    # Clear all — MSAL cache + per-server token stores
    count = 0
    try:
        from praestoclaw.utils.helpers import get_auth_dir

        for cache_file in get_auth_dir().glob("token_cache_*.bin"):
            cache_file.unlink(missing_ok=True)
            count += 1
    except Exception:
        pass
    try:
        from praestoclaw.security.secrets import get_secret_store

        store = get_secret_store()
        if store.get("GITHUB_TOKEN"):
            store.delete("GITHUB_TOKEN")
            count += 1
    except Exception:
        pass
    console.print(f"[green]Cleared {count} cached token(s).[/green]")


# ── Unified MCP setup ───────────────────────────────────────────────────────


# Map: uvx package → (pip package, python module) for fallback
_UVX_FALLBACKS: dict[str, str] = {
    "microsoft-fabric-rti-mcp": "fabric_rti_mcp.server",
}


def _resolve_stdio_command(entry: Any) -> tuple[str, list[str]]:
    """Resolve the actual command + args for a stdio server.

    If the command is ``uvx`` and it's available, use it directly.
    Otherwise, fall back to ``python -m <module>`` after pip-installing
    the package if needed.
    """
    if entry.command != "uvx" or shutil.which("uvx"):
        return entry.command, list(entry.command_args)

    # uvx not available — fall back to pip install + python -m
    pkg_name = entry.command_args[0] if entry.command_args else ""
    module = _UVX_FALLBACKS.get(pkg_name)
    if not module:
        console.print("  [yellow]uvx not found. Install: pip install uv[/yellow]")
        return entry.command, list(entry.command_args)

    # Check if the package is already importable
    try:
        __import__(module.split(".")[0])
    except ImportError:
        console.print(f"  [dim]Installing {pkg_name}...[/dim]")
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg_name, "-q"],
                check=True,
                capture_output=True,
                timeout=120,
            )
        except subprocess.CalledProcessError:
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", pkg_name, "-q", "--user"],
                    check=True,
                    capture_output=True,
                    timeout=120,
                )
            except subprocess.CalledProcessError:
                console.print(f"  [yellow]Failed to install {pkg_name}[/yellow]")
                console.print(f"  [dim]Install manually: pip install {pkg_name}[/dim]")
                return entry.command, list(entry.command_args)
        console.print(f"  [green]+[/green] {pkg_name} installed")

    return sys.executable, ["-m", module]


# Common Microsoft Azure DevOps organizations shown as quick-pick options
# in the init wizard. Users can also type any custom org name.
_COMMON_ADO_ORGS: list[tuple[str, str]] = [
    ("microsoft", "Edge, Windows, Office shared"),
    ("o365exchange", "Exchange / O365 Core"),
    ("msasg", "Bing / Ads / Search"),
]

# Re-used by both interactive and quick paths to recognize an ADO remote URL.
_ADO_REMOTE_RE = re.compile(
    r"(?:"
    r"https?://(?:[^/@]+@)?dev\.azure\.com/(?P<org1>[^/\s]+)"  # https
    r"|https?://(?:[^/@]+@)?(?P<org2>[^/.\s]+)\.visualstudio\.com"  # legacy https
    r"|git@ssh\.dev\.azure\.com:v3/(?P<org3>[^/\s]+)"  # SSH new
    r"|git@(?P<org4>[^/.\s]+)\.visualstudio\.com:"  # SSH legacy
    r")",
    re.IGNORECASE,
)


def _scan_dir_for_ado_orgs(root: Path, *, max_depth: int = 2) -> list[str]:
    """Walk ``root`` up to ``max_depth`` levels and yield ADO org names found
    in any ``.git/config`` file (one per repo, deduplicated within the file).

    Cheap best-effort scan — bounded depth, swallows all I/O errors. Returns
    a list (not a set) so the caller can take the *most-common* org via
    ``Counter``.
    """
    found: list[str] = []
    if not root.is_dir():
        return found
    try:
        # Depth-limited walk: only check first-level and second-level subdirs
        # for a .git folder. Keeps the scan to <100 stat calls on a typical
        # source folder with ~30 child repos.
        candidates: list[Path] = [root]
        if max_depth >= 1:
            try:
                candidates.extend(p for p in root.iterdir() if p.is_dir())
            except OSError:
                pass
        if max_depth >= 2:
            for child in list(candidates):
                if child is root:
                    continue
                try:
                    candidates.extend(p for p in child.iterdir() if p.is_dir())
                except OSError:
                    pass
        for d in candidates:
            cfg = d / ".git" / "config"
            if not cfg.is_file():
                continue
            try:
                text = cfg.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            seen_in_file: set[str] = set()
            for m in _ADO_REMOTE_RE.finditer(text):
                org = (
                    m.group("org1") or m.group("org2") or m.group("org3") or m.group("org4") or ""
                ).lower()
                if org and org not in seen_in_file:
                    seen_in_file.add(org)
                    found.append(org)
    except Exception:
        pass
    return found


def _detect_most_common_ado_org() -> str | None:
    """Best-effort scan of common repo roots to pick the user's most-used
    Azure DevOps organization. Returns ``None`` if nothing is found.

    Searches: current working directory, ``~/source/repos`` (VS default),
    ``~/src``, ``C:\\src``, and ``C:\\repos``. Cheap (<200ms typical),
    silent on failure.
    """
    from collections import Counter

    roots: list[Path] = []
    try:
        roots.append(Path.cwd())
    except OSError:
        pass
    home = Path.home()
    for sub in ("source/repos", "src", "repos"):
        roots.append(home / sub)
    if os.name == "nt":
        roots.extend([Path("C:/src"), Path("C:/repos")])

    seen_roots: set[str] = set()
    orgs: list[str] = []
    for root in roots:
        try:
            key = str(root.resolve())
        except OSError:
            continue
        if key in seen_roots:
            continue
        seen_roots.add(key)
        orgs.extend(_scan_dir_for_ado_orgs(root))

    if not orgs:
        return None
    return Counter(orgs).most_common(1)[0][0]


def _set_ado_org_arg(args: list[str] | None, org: str) -> list[str]:
    """Return ``args`` with ``--organization <org>`` set (replacing any prior value).

    Preserves leading positional args (e.g. ``["mcp", "ado"]``) and any
    other flags (e.g. ``--toolsets all``). Idempotent.
    """
    base = list(args or [])
    out: list[str] = []
    skip_next = False
    for a in base:
        if skip_next:
            skip_next = False
            continue
        if a in ("--organization", "--org"):
            skip_next = True  # drop the value too
            continue
        out.append(a)
    out.extend(["--organization", org])
    return out


def _apply_ado_org_to_servers(targets: list[str], mcp_section: dict[str, Any], org: str) -> None:
    """Write ``--organization <org>`` into the args of each named server."""
    for name in targets:
        entry = mcp_section.setdefault(name, {})
        if not isinstance(entry, dict):
            entry = {}
            mcp_section[name] = entry
        entry["command"] = entry.get("command") or "agency"
        entry["args"] = _set_ado_org_arg(entry.get("args"), org)
        entry["enabled"] = True


def _maybe_set_ado_fallback_org(
    selected: list[str],
    mcp_section: dict[str, Any],
    *,
    quick: bool,
    step: int | None,
) -> None:
    """Configure a fallback ADO organization for ``ado`` / ``bluebird``.

    Behavior:
      - If neither ``ado`` nor ``bluebird`` is selected → no-op.
      - Try to auto-detect the user's most-common ADO org by scanning a few
        well-known repo roots. If found → use it silently.
      - In ``quick`` mode without an auto-detected org → ask the user once
        (this is the one prompt we keep in quick mode because every other
        path just produces a confusing "transport not available" later).
      - In interactive mode → always show the menu, but pre-fill the
        detected org as the default so most users can just press Enter.
    """
    # Only ``ado`` accepts ``--organization`` standalone — ``bluebird``
    # additionally requires ``--project`` (and a ``--repository`` to be
    # useful), so passing org-only would make it crash with a clearer
    # "missing --project" error than its default git-remote auto-detect
    # failure. Apply the org only to ``ado``; ``bluebird`` falls back to
    # its native git auto-detect path, which the manager downgrades to
    # an INFO line when no ADO repo is around.
    targets = ["ado"] if "ado" in selected else []
    if not targets:
        return

    detected = _detect_most_common_ado_org()
    _p = f"{step}." if step else ""

    # ── quick mode: prefer auto-detect, prompt only if needed ────────
    if quick:
        if detected:
            _apply_ado_org_to_servers(targets, mcp_section, detected)
            console.print(
                f"  [dim]auto-detected ADO org: [bold]{detected}[/bold] (applied to ado)[/dim]"
            )
            return
        # No auto-detect → ask once, even in quick mode, since otherwise
        # ado/bluebird will silently fail to start later. Skip silently
        # in non-TTY contexts (CI, scripted invocations) to avoid
        # ``OSError: reading from stdin while output is captured``.
        from praestoclaw.cli.init import _is_tty

        if not _is_tty():
            return
        console.print(f"  [dim]({_p}3) Azure DevOps organization[/dim]")
        console.print("  [dim]ado needs an ADO org to start outside an ADO repo.[/dim]")
        for i, (name, desc) in enumerate(_COMMON_ADO_ORGS, start=1):
            console.print(f"    [cyan]{i})[/cyan] [bold]{name:<14}[/bold] [dim]\u2014 {desc}[/dim]")
        console.print("  [dim]Enter number, custom org name, or leave empty to skip[/dim]")
        try:
            raw = console.input("  ADO org [skip]: ").strip()
        except (KeyboardInterrupt, EOFError, OSError):
            console.print()
            return
        if not raw:
            console.print("  [dim]skipped \u2014 ado will only work inside an ADO repo[/dim]")
            return
        org = (
            _COMMON_ADO_ORGS[int(raw) - 1][0]
            if raw.isdigit() and 1 <= int(raw) <= len(_COMMON_ADO_ORGS)
            else raw
        )
        _apply_ado_org_to_servers(targets, mcp_section, org)
        console.print(
            f"  [green]+[/green] {', '.join(targets)} will use organization "
            f"[bold cyan]{org}[/bold cyan]"
        )
        return

    # ── interactive mode: full menu, with detected as default ────────
    # Skip silently in non-TTY contexts (CI, scripted runs).
    from praestoclaw.cli.init import _is_tty

    if not _is_tty():
        if detected:
            _apply_ado_org_to_servers(targets, mcp_section, detected)
        return
    console.print(f"  [dim]({_p}3) Azure DevOps organization[/dim]")
    console.print(
        "  [dim]ado auto-detects the org from your git remote.\n"
        "  Set one here so it also works outside an ADO repo.[/dim]"
    )
    for i, (name, desc) in enumerate(_COMMON_ADO_ORGS, start=1):
        console.print(f"    [cyan]{i})[/cyan] [bold]{name:<14}[/bold] [dim]\u2014 {desc}[/dim]")
    if detected:
        console.print(
            f"  [dim]Detected from your local repos: [bold cyan]{detected}[/bold cyan] "
            "(press Enter to use)[/dim]"
        )
        prompt_default = detected
    else:
        console.print("  [dim]Enter number, custom org name, or leave empty to skip[/dim]")
        prompt_default = ""
    try:
        raw = console.input(f"  ADO org [{prompt_default or 'skip'}]: ").strip()
    except (KeyboardInterrupt, EOFError, OSError):
        console.print()
        return
    if not raw:
        if prompt_default:
            org = prompt_default
        else:
            console.print("  [dim]skipped \u2014 ado will only work inside an ADO repo[/dim]")
            return
    elif raw.isdigit() and 1 <= int(raw) <= len(_COMMON_ADO_ORGS):
        org = _COMMON_ADO_ORGS[int(raw) - 1][0]
    else:
        org = raw

    _apply_ado_org_to_servers(targets, mcp_section, org)
    console.print(
        f"  [green]+[/green] {', '.join(targets)} will use organization "
        f"[bold cyan]{org}[/bold cyan]"
    )


def _mcp_setup(
    config_dir: Path,
    local_config: dict | None = None,
    *,
    select_all: bool = False,
    quick: bool = False,
    skip_test: bool = False,
    step: int | None = None,
) -> dict[str, Any]:
    """Unified MCP server setup: select -> authenticate -> write config -> verify.

    Called by ``pc mcp setup`` (standalone) and ``pc init`` step [5/5].

    When *local_config* is provided (init path), modifies it in-place.
    When ``None`` (standalone), reads/writes praestoclaw.local.yaml directly.
    Returns dict of added servers (for summary).
    """

    from praestoclaw.mcp.defaults import SERVER_REGISTRY

    # Determine config target
    standalone = local_config is None
    if standalone:
        local_path = next(
            (
                config_dir / c
                for c in ("praestoclaw.local.yaml", "praestoclaw.local.yml")
                if (config_dir / c).exists()
            ),
            config_dir / "praestoclaw.local.yaml",
        )
        local_config = (_load_yaml(local_path) if local_path.is_file() else {}) or {}

    assert local_config is not None  # always assigned above
    mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
    # Sub-step prefix: e.g. "5." when called from init step 5.
    _p = f"{step}." if step else ""

    # ── Build server list from merged yaml config ────────────────────
    try:
        merged_cfg = _load_config_safe(str(config_dir))
        merged_servers = merged_cfg.tools.mcp_servers
    except Exception:
        merged_servers = {}

    all_servers: list[tuple[str, str]] = []
    for name, srv in merged_servers.items():
        desc = srv.description or ""
        if not desc:
            reg = SERVER_REGISTRY.get(name)
            if reg:
                desc = reg.description
        all_servers.append((name, desc))
    # Append registry-only servers (e.g. kusto — stdio, not in yaml)
    # Skip legacy/not-recommended entries (workiq, enghub).
    yaml_names = set(merged_servers)
    for name, entry in SERVER_REGISTRY.items():
        if name not in yaml_names and entry.recommended:
            all_servers.append((name, entry.description))

    # ── Select ───────────────────────────────────────────────────────
    if not quick:
        console.print(f"  [dim]({_p}1) Select servers[/dim]")
    if select_all:
        selected = [n for n, _ in all_servers if _is_recommended(n)]
    else:
        selected = _interactive_select(all_servers, servers=merged_servers)

    if not selected:
        console.print("  [dim]No servers selected.[/dim]")
        return {}

    # ── Ensure Agency CLI installed if any selected server needs it ──
    # Agency-backed servers spawn the `agency` binary via stdio. Without
    # it, auth_and_verify() fails with `[Errno 2] No such file: 'agency'`
    # for every entry. Auto-install is best-effort — failures don't abort
    # init; non-agency servers still work.
    needs_agency = any(
        (SERVER_REGISTRY.get(n) and SERVER_REGISTRY[n].command == "agency")
        or (merged_servers.get(n) and merged_servers[n].command == "agency")
        for n in selected
    )
    if needs_agency and not shutil.which("agency"):
        _try_install_agency(quick=quick)

    # ── Write config ─────────────────────────────────────────────────
    # Write config first so verify can read it from disk.
    if not quick:
        console.print(f"  [dim]({_p}2) Write config[/dim]")
    added: dict[str, Any] = {}
    all_http_names = {n for n, srv in merged_servers.items() if srv.url}

    for name in selected:
        reg_entry = SERVER_REGISTRY.get(name)
        merged_srv = merged_servers.get(name)
        if reg_entry and reg_entry.command:
            # Stdio server (e.g. kusto via uvx) — merge into existing
            # to preserve user-modified env values.
            existing = mcp_section.get(name, {})
            if not isinstance(existing, dict):
                existing = {}
            cmd, cmd_args = _resolve_stdio_command(reg_entry)
            existing["enabled"] = True
            existing["command"] = cmd
            existing["args"] = cmd_args
            if reg_entry.env:
                env = existing.get("env")
                if not isinstance(env, dict):
                    env = {}
                    existing["env"] = env
                env.update({k: v for k, v in reg_entry.env.items() if k not in env})
            mcp_section[name] = existing
        elif merged_srv and merged_srv.url:
            # HTTP server — merge into existing local entry to preserve
            # user-added fields (url, headers, env, etc.).
            existing = mcp_section.get(name, {})
            if not isinstance(existing, dict):
                existing = {}
            existing["enabled"] = True
            # Promote implicit → oauth now that the user has set up auth.
            if merged_srv.auth.type == "implicit" and merged_srv.auth.client_id:
                existing.setdefault("auth", {})["type"] = "oauth"
            mcp_section[name] = existing
        added[name] = mcp_section.get(name, {})

    # Unselected HTTP servers → disabled
    for name in all_http_names - set(selected):
        mcp_section.setdefault(name, {})["enabled"] = False

    # Save (standalone mode)
    if standalone:
        _save_mcp_servers(local_path, mcp_section)  # type: ignore[possibly-undefined]

    # Summary
    console.print(
        f"  [green]+[/green] [bold]{len(selected)}[/bold] server(s) configured: "
        f"[cyan]{', '.join(selected)}[/cyan]"
    )

    # ── Optional: ADO fallback organization ──────────────────────────
    # ado / bluebird auto-detect the ADO org from the current dir's git
    # remote. Outside an ADO repo they fail to start. Let the user pick
    # a fallback org now so `pc s` works from any directory.
    _maybe_set_ado_fallback_org(selected, mcp_section, quick=quick, step=step)
    if standalone:
        _save_mcp_servers(local_path, mcp_section)  # type: ignore[possibly-undefined]

    # ── Authenticate + Verify (grouped, interleaved) ─────────────────
    if not quick and not skip_test and selected:
        console.print(f"  [dim]({_p}4) Authenticate MCP servers & verify tools[/dim]")
        from praestoclaw.cli.mcp_setup import auth_and_verify

        selected = auth_and_verify(
            selected,
            merged_servers,
            config_dir,
            quick=quick,
        )

        # Sync config: disable servers that were skipped during auth.
        selected_set = set(selected)
        for name in all_http_names - selected_set:
            mcp_section.setdefault(name, {})["enabled"] = False
        if standalone:
            _save_mcp_servers(local_path, mcp_section)  # type: ignore[possibly-undefined]

    if not selected:
        console.print("  [dim]No servers authenticated.[/dim]")

    return added


@mcp_app.command("setup")
def mcp_setup_cmd(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    all_servers: bool = typer.Option(False, "--all", help="Select all recommended servers"),
    skip_test: bool = typer.Option(False, "--skip-test", help="Skip connectivity verification"),
) -> None:
    """Interactive MCP server setup: select, authenticate, verify.

    Unified entry point for configuring GitHub, Entra, and Agency MCP servers.
    """
    console.print("\n[bold]MCP Server Setup[/bold]")
    console.print("[dim]Select servers, authenticate, and verify connectivity.[/dim]\n")
    config_path = _resolve_config_path(config)
    _mcp_setup(
        config_dir=config_path.parent,
        select_all=all_servers,
        skip_test=skip_test,
    )
    console.print()
