"""Minimal process watchdog for the local agent host."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from filelock import FileLock, Timeout


def _paths() -> tuple[Path, Path]:
    from praestoclaw.utils.helpers import get_data_dir

    data_dir = get_data_dir()
    return data_dir / "watchdog.lock", data_dir / "watchdog.pid"


def _read_pid(path: Path) -> int | None:
    try:
        pid = int(json.loads(path.read_text(encoding="utf-8"))["pid"])
    except (FileNotFoundError, KeyError, TypeError, ValueError, json.JSONDecodeError):
        return None
    return pid if pid >= 1 else None


def _unlink(path: Path) -> None:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def current_cli_prefix() -> list[str]:
    """Return the launcher prefix for the current production or staging CLI."""
    entry = Path(sys.argv[0]).stem.lower() if sys.argv else ""
    if entry in {"pc", "praestoclaw", "pc-staging", "praestoclaw-staging"}:
        return [sys.argv[0]]
    return [sys.executable, "-m", "praestoclaw"]


def run_watchdog(agent_argv: Sequence[str]) -> None:
    """Watch one agent process for the currently selected data directory."""
    from praestoclaw.cli.commands import console
    from praestoclaw.cli.serve import _check_agent_running, _is_pid_running
    from praestoclaw.utils.helpers import get_data_dir

    lock_path, pid_path = _paths()
    lock = FileLock(lock_path)
    try:
        lock.acquire(timeout=0)
    except Timeout:
        existing_pid = _read_pid(pid_path)
        console.print(f"[watchdog] already running pid={existing_pid or 'unknown'}")
        return

    child: subprocess.Popen[bytes] | None = None
    watched_pid: int | None = None
    stopping = False
    old_handlers: dict[signal.Signals, Any] = {}

    def _stop(_signum: int, _frame: object) -> None:
        nonlocal stopping
        if stopping:
            return
        stopping = True
        if watched_pid is not None:
            console.print(f"[watchdog] stopping agent pid={watched_pid}")
            try:
                if child is not None:
                    child.terminate()
                else:
                    os.kill(watched_pid, signal.SIGTERM)
            except OSError:
                pass

    try:
        pid_path.write_text(json.dumps({"pid": os.getpid()}), encoding="utf-8")
        console.print(f"[watchdog] started pid={os.getpid()} data_dir={get_data_dir()}")
        for signum in (signal.SIGINT, signal.SIGTERM):
            old_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, _stop)

        watched_pid = _check_agent_running()
        if watched_pid is not None:
            console.print(f"[watchdog] watching existing agent pid={watched_pid}")
            while _is_pid_running(watched_pid):
                time.sleep(1)
            watched_pid = None

        while not stopping:
            child = subprocess.Popen(list(agent_argv))
            watched_pid = child.pid
            console.print(f"[watchdog] agent started pid={watched_pid}")
            if stopping:
                child.terminate()
            return_code = child.wait()
            child = None
            watched_pid = None
            if stopping:
                break
            console.print(f"[watchdog] agent exited code={return_code}; restarting in 1s")
            time.sleep(1)
    finally:
        for signum, handler in old_handlers.items():
            signal.signal(signum, handler)
        _unlink(pid_path)
        lock.release()
        console.print("[watchdog] stopped")


def stop_watchdog_if_running(data_dir: str | Path | None = None) -> bool:
    """Stop the watchdog for *data_dir* and wait until it releases its lock."""
    if data_dir is not None:
        from praestoclaw.utils.helpers import set_data_dir

        set_data_dir(str(data_dir))

    lock_path, pid_path = _paths()
    lock = FileLock(lock_path)
    try:
        lock.acquire(timeout=0)
    except Timeout:
        pid = _read_pid(pid_path)
        if pid is not None:
            try:
                os.kill(pid, signal.SIGTERM)
            except OSError:
                pass
        with FileLock(lock_path):
            pass
        return True
    else:
        lock.release()
        return False
