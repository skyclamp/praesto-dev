"""Init CLI command — praestoclaw init."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer
from rich.panel import Panel
from rich.table import Table

from praestoclaw.cli.commands import (
    app,
    console,
)

if TYPE_CHECKING:
    from praestoclaw.security.github_auth import ExistingGitHubToken

_TOTAL_STEPS = 7


# ── Modern interactive selection ──────────────────────────────────────────────


def _step_header(n: int, label: str) -> None:
    """Print step header: ``[1/7] Label``."""
    console.print(
        f"\n[bold]\\[{n}/{_TOTAL_STEPS}] {label}[/bold]",
        highlight=False,
    )


def _step_done(value: str) -> None:
    """Print a completed step result with green checkmark (Teams-style)."""
    console.print(f"  [green]+[/green] {value}")


def _step_auto(value: str) -> None:
    """Print a quick-mode auto-applied result. Same visual as ``_step_done``
    but with a dim ``(auto)`` suffix so users can tell apart explicit picks
    from defaults applied silently. Matches the Teams [N/3] step style.
    """
    console.print(f"  [green]+[/green] {value} [dim](auto)[/dim]")


def _is_tty() -> bool:
    """Return True if running in a real terminal (not piped/test)."""
    from praestoclaw.utils.input import is_tty

    return is_tty()


def _read_key() -> str:
    """Read a single keypress. Returns ``'up'``, ``'down'``, ``'enter'``, or the character."""
    from praestoclaw.utils.input import read_key_blocking

    return read_key_blocking()


def _select(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Show a selection menu and return the 1-based chosen index.

    Uses arrow-key navigation in a real terminal. Falls back to numbered
    input in non-TTY environments (tests, piped stdin), when the terminal
    is too short, or when an option line would wrap horizontally — the
    in-place ANSI cursor refresh assumes one logical line == one terminal
    row, which breaks under wrapping or scrolling.
    """
    if _is_tty():
        try:
            import shutil

            term_size = shutil.get_terminal_size((80, 24))
            term_rows, term_cols = term_size.lines, term_size.columns
        except Exception:
            term_rows, term_cols = 24, 80

        # Required height: blank + options + blank + hint + small safety margin
        needed_rows = len(options) + 4
        # Required width per line: "  * " (4) + max_label + "  — " (4) + desc
        max_label = max(len(label) for label, _ in options)
        max_line_width = max(
            4 + max_label + (4 + len(desc) if desc else 0) for label, desc in options
        )

        if term_rows >= needed_rows and term_cols >= max_line_width + 2:
            try:
                return _select_arrows(options, default=default - 1) + 1
            except Exception:
                pass
    return _select_numbered(options, default=default)


def _select_arrows(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
) -> int:
    """Inline arrow-key radio selector. Returns 0-based index.

    Renders options with ``*`` / ``o`` markers, then erases itself
    after the user presses Enter — leaving the cursor right below the
    step header so the caller can print a result line.
    """
    cur = default
    n = len(options)
    max_label = max(len(label) for label, _ in options)
    # lines rendered: blank + n options + blank + hint = n + 3
    total_lines = n + 3

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        out.write("\n")
        for i, (label, desc) in enumerate(options):
            pad = label.ljust(max_label)
            if i == cur:
                line = f"  \033[36m*\033[0m \033[1m{pad}\033[0m"
            else:
                line = f"  \033[90mo {pad}\033[0m"
            if desc:
                line += f"  \033[90m\u2014 {desc}\033[0m"
            out.write(f"\033[2K{line}\n")
        out.write("\n\033[2K  \033[90mUp/Down switch  Enter confirm  Esc skip\033[0m\n")
        out.flush()

    # Discard any stale keystrokes (Enter typed while previous step was
    # running) before showing the menu, so we don't auto-confirm.
    from praestoclaw.utils.input import flush_stdin

    flush_stdin()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                cur = (cur - 1) % n
                _render()
            elif key in ("down", "j"):
                cur = (cur + 1) % n
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key == "esc":
                # ESC = select last option (skip/default)
                cur = n - 1
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n:
                    cur = idx
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")  # show cursor, reset attrs
        sys.stdout.flush()


def _select_numbered(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Numbered fallback for non-TTY (tests, piped input). Returns 1-based index."""
    for i, (label, desc) in enumerate(options, 1):
        marker = " *" if i == default else ""
        if desc:
            console.print(f"  [bold]{i}.[/bold] {label}  [dim]\u2014 {desc}[/dim]{marker}")
        else:
            console.print(f"  [bold]{i}.[/bold] {label}{marker}")
    while True:
        raw = typer.prompt(f"Select [1-{len(options)}]", default=str(default))
        try:
            choice = int(raw)
            if 1 <= choice <= len(options):
                return choice
        except ValueError:
            pass
        console.print(f"  [yellow]Please enter 1\u2013{len(options)}[/yellow]")


# ── Utilities ─────────────────────────────────────────────────────────────────


def _check_connectivity() -> bool:
    """Return True if github.com is reachable (quick HEAD check)."""
    try:
        import httpx

        with httpx.Client(timeout=5) as http:
            resp = http.head("https://github.com")
            return resp.status_code < 500
    except Exception:
        return False


def _trigger_repo_analysis_auto_subscribe(subscribed: list[str], env) -> None:
    """Best-effort: if Societas is subscribed, register a silent KB build +
    2h refresh cycle. Uses the local clone when one was found during
    detection; otherwise falls back to the canonical clone target
    (``~/repos/Societas``) so the analyzer's first run can ``git clone`` it.
    Never raises — FRE must keep running on any error."""
    try:
        from praestoclaw.skills.bundled.repo_analysis import (
            maybe_schedule_silent_analysis,
        )

        repo_paths = getattr(env, "repo_paths", ()) if env is not None else ()
        scheduled_path = maybe_schedule_silent_analysis(subscribed, repo_paths)
        if scheduled_path:
            console.print(
                f"  [dim]Societas knowledge base will build silently in the "
                f"background for[/dim] [cyan]{scheduled_path}[/cyan] "
                f"[dim](refresh every 2h).[/dim]"
            )
    except Exception as exc:
        from loguru import logger

        logger.debug("repo-analysis auto-subscribe skipped: {}", exc)


def _detect_and_subscribe_teams(*, quick: bool) -> tuple[list[str], dict[str, list[str]]]:
    """Run team detection, persist the snapshot, return ``(subscribed, signals)``.

    Behaviour:

    * In ``--quick`` mode we auto-subscribe to every detected project plus
      ``default``. No prompts.
    * In interactive (TTY) mode we show what was detected and let the user
      confirm / customize.
    * In non-interactive non-quick mode (piped stdin, CI) we behave like
      quick mode but skip the visual summary so the test harness output
      stays terse.

    Detection itself is wall-clock bounded by
    :mod:`praestoclaw.projects.detector` so we never block the wizard for
    more than a few seconds.
    """
    from praestoclaw.projects import (
        BUILTIN_PROJECTS,
        detect_projects,
        get_detection_env,
    )
    from praestoclaw.projects.registry import default_project
    from praestoclaw.utils.fre_state import (
        get_subscribed_projects,
        record_project_detection,
        set_subscribed_projects,
    )

    env = None
    try:
        env = get_detection_env()
        signals = detect_projects(env)
    except Exception as exc:
        # Detection is best-effort — never fail init over it.
        from loguru import logger

        logger.debug("Project detection skipped: {}", exc)
        signals = {default_project().id: []}

    detected_ids = [pid for pid, sigs in signals.items() if sigs]
    record_project_detection(detected_ids, signals)

    # Always include the default project so the user gets baseline assets.
    auto = [default_project().id, *[pid for pid in detected_ids if pid != default_project().id]]

    existing = get_subscribed_projects()
    if existing and not quick and _is_tty():
        # Returning user — don't overwrite their explicit choice silently.
        # We still re-record detection (above) so the Portal's "why" panel
        # is fresh, but we keep the existing subscription as the default.
        proposed = existing
    else:
        proposed = auto

    if quick or not _is_tty():
        set_subscribed_projects(proposed)
        _trigger_repo_analysis_auto_subscribe(proposed, env)
        return proposed, signals

    # Interactive: show detection result and let the user confirm.
    detected_project_objs = [p for p in BUILTIN_PROJECTS if p.id in detected_ids]
    if detected_project_objs:
        labels = ", ".join(f"[cyan]{p.label}[/cyan]" for p in detected_project_objs)
        console.print(f"  [dim]Detected project(s):[/dim] {labels}")
        # Surface the strongest signal per project so the user can sanity-check.
        for p in detected_project_objs:
            sample = signals.get(p.id, [])
            if sample:
                console.print(f"    [dim]\u2022 {p.label}: {sample[0]}[/dim]")
    else:
        console.print(
            "  [dim]No project-specific signals found \u2014 using General defaults.[/dim]"
        )

    confirm_opts: list[tuple[str, str]] = [
        ("Use detected", "subscribe to General + detected project(s)"),
        ("Customize", "pick projects manually"),
        ("General only", "skip project-specific recommendations"),
    ]
    choice = _select(confirm_opts, default=1)
    if choice == 1:
        chosen = proposed
    elif choice == 3:
        chosen = [default_project().id]
    else:
        # Manual picker — one prompt per non-default project.
        chosen = [default_project().id]
        for p in BUILTIN_PROJECTS:
            if p.is_default:
                continue
            opts: list[tuple[str, str]] = [
                (f"Subscribe to {p.label}", p.description),
                ("Skip", ""),
            ]
            default_idx = 1 if p.id in detected_ids else 2
            sub = _select(opts, default=default_idx)
            if sub == 1:
                chosen.append(p.id)

    set_subscribed_projects(chosen)
    chosen_labels = ", ".join(
        next((p.label for p in BUILTIN_PROJECTS if p.id == tid), tid) for tid in chosen
    )
    _step_done(f"subscribed: {chosen_labels}")
    _trigger_repo_analysis_auto_subscribe(chosen, env)
    return chosen, signals


def _ensure_github_signin_at_step_six_start(*, quick: bool) -> bool:
    """Run *unconditionally* at the very top of step 6, before any
    project detection, marketplace clone, or team .claude scan.

    Why up-front (before detection):
        ``praestoclaw.projects.detector.get_detection_env()`` memoizes
        its full ``DetectionEnv`` snapshot in ``_CACHED_ENV`` after the
        first call (which happens during step 5's MCP warm-up). If we
        wait until after marketplace selection to drive sign-in, the
        cached snapshot reflects the pre-sign-in state and the team
        ``.claude`` scan stays blind. By driving the GCM popup at the
        top of step 6 *before* detection re-runs, and then dropping
        the cached snapshot, we guarantee the next
        ``get_detection_env()`` rebuilds against the now-cached
        github.com credential.

    Why unconditionally (not gated on private marketplace):
        We don't yet know which marketplaces the user will pick \u2014
        chicken-and-egg. ``git credential fill`` is fast (sub-100\u202fms)
        when GCM already has a credential, so already-signed-in users
        see no UI and no perceptible delay. Only fresh machines see
        the GCM browser popup, and they typically need it anyway
        (every recommended bundle except ``opc`` sits behind
        GitHub-EMU internal repos).

    Returns ``True`` if a github.com credential is now cached, ``False``
    otherwise (git missing, helper missing, user cancelled, timeout).
    Callers must treat ``False`` as best-effort failure and continue
    \u2014 the downstream paths each surface their own clear error if
    they need a credential and don't have one.
    """
    import shutil as _shutil

    # Without git, ``git credential fill`` cannot run and the rest of
    # step 6 (marketplace clone) is already going to be skipped by the
    # ``which("git")`` guard further down. Keep this call quiet so the
    # user doesn't see a misleading "GCM will open a browser" notice
    # followed by a sign-in failure for a tool they don't have.
    if _shutil.which("git") is None:
        return False

    # GCM's sign-in window needs a human to complete it, so don't drive
    # it in non-TTY contexts (CI, piped stdin, test harness). Quick mode
    # in a real terminal still gets the popup \u2014 the user is sitting
    # there and can click through. Quick mode in CI is the case Copilot
    # flagged: we'd otherwise block up to 180 s waiting for a browser
    # nobody can open.
    if not _is_tty():
        return False

    from praestoclaw.projects.detector import invalidate_detection_env_cache
    from praestoclaw.security.github_auth import ensure_github_credential_cached

    icon = "[bold yellow]![/bold yellow]" if quick else "[dim]\u2022[/dim]"
    console.print(
        f"  {icon} [dim]Checking github.com sign-in for skills setup. "
        "If no credential is cached yet, [bold]Git Credential Manager[/bold] "
        "will open a browser \u2014 sign in once to cover the marketplace "
        "clone and team .claude scan that follow.[/dim]"
    )

    result = ensure_github_credential_cached(timeout=180.0)

    # The previously-cached DetectionEnv (built during step 5's MCP
    # warm-up, before GCM had a credential) is now stale. Drop it so
    # the next ``get_detection_env()`` rebuilds the snapshot and picks
    # up any GitHub activity that's now reachable.
    invalidate_detection_env_cache()

    if result.ok and result.persisted:
        # Approve succeeded \u2014 the credential lives in a known-secure
        # OS store now, so this really is "cached for all future clones".
        console.print(
            "  [dim]\u2713 github.com sign-in cached \u2014 marketplace clone "
            "and team .claude scan will use it.[/dim]"
        )
    elif result.ok:
        # We got the credential but skipped ``approve`` (insecure helper
        # chain). Persistence is not guaranteed, so soften the wording.
        console.print(
            "  [dim]\u2713 github.com sign-in available for this run. "
            "Configure a secure git credential helper "
            "(manager-core / wincred / osxkeychain / libsecret) to avoid "
            "re-prompting on each clone.[/dim]"
        )
    else:
        console.print(
            "  [dim yellow]\u26a0 github.com sign-in not available. "
            "Marketplace clones of internal repos may fail and the remote "
            "team .claude scan will be skipped; you can sign in later via "
            "``git credential-manager github login`` and re-run "
            "``pc init``.[/dim yellow]"
        )
    return result.ok


def _skill_marketplace_setup(
    local_config: dict[str, Any],
    *,
    quick: bool,
    local_config_path: str | None = None,
) -> dict[str, Any]:
    """Clone & bulk-install skill marketplaces recommended by the user's projects.

    The set of marketplaces to install is derived from the user's
    ``projects.subscribed`` list (see :func:`_detect_and_subscribe_teams`),
    which is populated from auto-detection + user confirmation earlier in
    the wizard. Returns a summary dict:
    ``{source_id: {"installed": int, "skipped": int, "errors": int}}``.

    In ``--quick`` mode the actual ``git clone`` + bulk-install runs in a
    background thread (see :func:`praestoclaw.cli.init_async.fire_marketplace_install`).
    The wizard's [6/7] step queues marketplace install and external imports
    in background threads; the Web Portal status bar polls ``/api/fre/state``
    to render progress. The summary returned by quick mode reflects what was
    *queued*, not what was installed (the Quick Setup Summary panel shows
    "installing in background" so the user isn't misled).
    """
    import shutil as _shutil

    from praestoclaw.projects import resolve_assets
    from praestoclaw.skills.marketplace import BUILTIN_MARKETPLACES

    summary: dict[str, Any] = {}
    known_ids = {m.id for m in BUILTIN_MARKETPLACES}

    _step_header(6, "Skills (Profiles, Marketplace, Imports)")

    # Drive github.com sign-in *before* anything in this step touches
    # GitHub. The downstream calls (project detection's repo activity
    # probe, marketplace ``git clone``, team .claude scan) all depend
    # on a credential being cached in GCM. The detector also memoizes
    # the resulting ``DetectionEnv`` snapshot in ``_CACHED_ENV`` after
    # the first call, so if detection ran before sign-in the snapshot
    # would record an empty ``github_activity_repos`` and the team
    # .claude scan would stay blind for the rest of the process. Drive
    # the popup up-front, not after marketplace selection. Always safe
    # to call: instant return for users who are already signed in, GCM
    # browser popup only on fresh machines.
    _ensure_github_signin_at_step_six_start(quick=quick)

    # 1. Run project detection (also persists the snapshot).
    subscribed, _signals = _detect_and_subscribe_teams(quick=quick)

    def run_profile_imports() -> None:
        from praestoclaw.cli.import_external import run_import_setup

        if quick:
            summary["external_import"] = {
                "skills_imported": 0,
                "queued": True,
                "subscribed_projects": list(subscribed),
                "local_config_path": local_config_path,
            }
            return

        import_summary = run_import_setup(
            local_config,
            quick=quick,
            subscribed_projects=subscribed,
            step_number=None,
        )
        if import_summary:
            summary["external_import"] = import_summary

    # In quick / non-TTY mode ``_detect_and_subscribe_teams`` doesn't
    # print anything (it's meant to be silent). Surface the auto-detected
    # projects here so users see *why* the marketplace bundle below was
    # picked — mirrors step 5's ``auto-detected ADO org`` line.
    if quick:
        from praestoclaw.projects import BUILTIN_PROJECTS
        from praestoclaw.projects.registry import default_project

        non_default = [pid for pid in subscribed if pid != default_project().id]
        if non_default:
            labels = []
            for pid in non_default:
                proj = next((p for p in BUILTIN_PROJECTS if p.id == pid), None)
                labels.append(proj.label if proj else pid)
            console.print(
                f"  [dim]auto-detected project(s): [bold]{', '.join(labels)}[/bold] "
                f"(applied to skill marketplace)[/dim]"
            )
        else:
            console.print("  [dim]no project-specific signals \u2014 using General defaults[/dim]")

    if _shutil.which("git") is None:
        if quick:
            _step_auto("marketplace skipped \u2014 git not found")
        else:
            console.print("  [yellow]git not found \u2014 skipping marketplace install.[/yellow]")
        run_profile_imports()
        return summary

    # 2. Resolve subscribed projects + detected role → ordered marketplace ids.
    #    Role is best-effort (Graph /me); when unset it contributes nothing
    #    and the bundle is identical to the project-only resolution.
    from praestoclaw.utils.fre_state import get_user_role

    user_role = get_user_role()
    assets = resolve_assets(subscribed, role=user_role)
    selected_ids = [mid for mid in assets.marketplaces if mid in known_ids]

    # Surface role-derived marketplaces in quick mode for symmetry with
    # the project line above. Role detection ran during the earlier
    # identity-capture step; here we just show what it found and which
    # bundles it pulled in. We only print this when (a) we got a usable
    # role and (b) it actually pulled in a marketplace — otherwise the
    # line is noise.
    if quick and user_role and user_role not in ("unknown", "other"):
        from praestoclaw.projects.role_assets import marketplaces_for_role

        role_mps = [m for m in marketplaces_for_role(user_role) if m in known_ids]
        if role_mps:
            role_labels = []
            for mid in role_mps:
                m = next((b for b in BUILTIN_MARKETPLACES if b.id == mid), None)
                role_labels.append(m.label if m else mid)
            console.print(
                f"  [dim]auto-detected role: [bold]{user_role}[/bold] "
                f"(added {', '.join(role_labels)})[/dim]"
            )

    if not selected_ids:
        if quick:
            _step_auto("no marketplaces recommended for current projects")
        else:
            console.print(
                "  [dim]No marketplaces recommended for current projects. "
                "Manage later via [cyan]wp[/cyan] Portal > Skills > Marketplace.[/dim]"
            )
        run_profile_imports()
        return summary

    bundle_labels = []
    for mid in selected_ids:
        m = next((b for b in BUILTIN_MARKETPLACES if b.id == mid), None)
        if m is not None:
            bundle_labels.append(m.label)

    if quick:
        # Quick mode: fire-and-forget. Cloning ~3 GitHub repos and walking
        # ~230 SKILL.md files takes 15\u201360 s on a typical corporate
        # network \u2014 way too long to gate the wizard's [6/7] step on.
        # The Web Portal's FRE status bar polls pending.marketplace_install
        # to surface progress; the user can keep typing.
        #
        # We deliberately do NOT spawn the background worker here: it would
        # race with the main init's final ``save_yaml(local_config)`` and
        # could overwrite a registration the worker just persisted. The
        # main init flow spawns the worker AFTER the final save by reading
        # ``summary["_marketplace_install"]`` (see init() below).
        _step_auto(
            f"queued in background: {', '.join(bundle_labels)} "
            f"\u2014 watch progress in the Portal status bar"
        )
        # Pre-register entries in local_config so the on-disk yaml mentions
        # the marketplaces immediately even before the clone finishes; the
        # background worker will rewrite them with the actual path once
        # cloning succeeds. We pre-fill the *expected* path now (the same
        # deterministic ``cache_dir / owner__name / subpath`` the worker
        # will use) so ``MarketplaceSourceConfig`` validation succeeds
        # when the user starts the server before the clone finishes.
        from praestoclaw.skills.marketplace import get_marketplace_cache_dir

        cache_dir = get_marketplace_cache_dir()
        mp_section = local_config.setdefault("skills", {}).setdefault("marketplaces", {})
        for m in BUILTIN_MARKETPLACES:
            if m.id in selected_ids:
                expected_repo_path = cache_dir / m.repo.replace("/", "__")
                expected_path = expected_repo_path / m.subpath if m.subpath else expected_repo_path
                mp_section.setdefault(
                    m.id,
                    {
                        "label": m.label,
                        "path": str(expected_path),
                        "format": m.format,
                        "pending": True,
                    },
                )
                # Mirror the queued state in the summary so the Quick
                # Setup Summary panel can show a sensible line.
                summary[m.id] = {"installed": 0, "skipped": 0, "errors": 0, "queued": True}
        # Defer the actual ``fire_marketplace_install`` spawn until after
        # the main ``save_yaml(local_config)`` so the worker's per-bundle
        # ``_register_marketplace_in_local_config`` writes can never be
        # clobbered by the main thread's final write.
        summary["_marketplace_install"] = {
            "selected_ids": list(selected_ids),
            "local_config_path": local_config_path,
        }
        run_profile_imports()
        return summary

    if not _is_tty():
        # Non-TTY non-quick (e.g. test harness with stdin piped). Skip the
        # network call to keep tests fast and deterministic; users running
        # ``pc init`` for real will hit one of the other branches.
        console.print(
            "  [dim]Non-interactive mode \u2014 skipping marketplace install. "
            "Run later via [cyan]wp[/cyan] Portal > Skills > Marketplace.[/dim]"
        )
        run_profile_imports()
        return summary

    console.print(f"  [dim]Will install:[/dim] {', '.join(bundle_labels)}")
    confirm: list[tuple[str, str]] = [
        ("Install recommended", f"clone {len(selected_ids)} repo(s) from GitHub"),
        ("Customize", "pick marketplaces manually"),
        ("Skip", "configure later via 'wp' Portal > Skills > Marketplace"),
    ]
    choice = _select(confirm, default=1)
    if choice == 3:
        _step_done("skipped")
        run_profile_imports()
        return summary
    if choice == 2:
        # Per-marketplace toggle.
        chosen: list[str] = []
        for m in BUILTIN_MARKETPLACES:
            opts = [(f"Install {m.label}", m.description), ("Skip", "")]
            default_idx = 1 if m.id in selected_ids else 2
            sub = _select(opts, default=default_idx)
            if sub == 1:
                chosen.append(m.id)
        selected_ids = chosen

    if not selected_ids:
        _step_done("nothing selected")
        run_profile_imports()
        return summary

    _install_marketplace_bundles(local_config, set(selected_ids), summary, verbose=True)
    total_installed = sum(v.get("installed", 0) for v in summary.values())
    _step_done(f"{total_installed} skill(s) installed from {len(summary)} source(s)")

    # ``git clone`` of an EMU/internal repo can trigger a fresh OAuth
    # round-trip whenever the credential we cached at the top of step 6
    # doesn't have access to the target repo (most commonly: the user's
    # first GCM sign-in picked a personal GitHub account rather than
    # the EMU one). After that, GCM has rotated the cached credential
    # and the previously-built ``DetectionEnv`` snapshot is stale.
    # Invalidate so the downstream team .claude scan rebuilds env with
    # the new credential.
    from praestoclaw.projects.detector import invalidate_detection_env_cache

    invalidate_detection_env_cache()

    run_profile_imports()
    return summary


def _install_marketplace_bundles(
    local_config: dict[str, Any],
    selected_ids: set[str],
    summary: dict[str, Any],
    *,
    verbose: bool,
) -> None:
    """Clone selected marketplace repos and bulk-install their skills.

    Shared by the interactive and ``--quick`` paths. When ``verbose`` is
    False, all per-bundle Rich output is suppressed so the quick flow
    stays clean (the Quick Setup Summary panel will surface the totals).
    """
    from praestoclaw.skills.marketplace import (
        BUILTIN_MARKETPLACES,
        bulk_install_from_source,
        clone_or_update_github_repo,
        get_install_dir,
        get_marketplace_cache_dir,
    )

    cache_dir = get_marketplace_cache_dir()
    install_dir = get_install_dir()
    mp_section = local_config.setdefault("skills", {}).setdefault("marketplaces", {})

    for m in BUILTIN_MARKETPLACES:
        if m.id not in selected_ids:
            continue
        if verbose:
            console.print(f"  [dim]-> {m.label} ({m.repo})[/dim]")
        try:
            repo_path = clone_or_update_github_repo(m.repo, cache_dir)
        except Exception as exc:
            if verbose:
                console.print(f"    [red]clone failed:[/red] {exc}")
            summary[m.id] = {"installed": 0, "skipped": 0, "errors": 1}
            continue

        source_path = repo_path / m.subpath if m.subpath else repo_path
        if not source_path.is_dir():
            if verbose:
                console.print(
                    f"    [yellow]expected path not found:[/yellow] {source_path} "
                    "(skipping install; you can reconfigure in praestoclaw.local.yaml)"
                )
            summary[m.id] = {"installed": 0, "skipped": 0, "errors": 1}
            # still register the marketplace pointing at repo root
            source_path = repo_path

        installed, skipped, errors = bulk_install_from_source(
            source_path,
            m.id,
            m.label,
            m.format,
            install_dir,
            skill_file=m.skill_file,
            recommended=m.recommended,
        )
        if verbose:
            console.print(
                f"    [green]installed:[/green] {installed}  "
                f"[yellow]skipped:[/yellow] {skipped}  "
                f"[red]errors:[/red] {len(errors)}"
            )
            if errors and len(errors) <= 3:
                for n, msg in errors:
                    console.print(f"      [dim]- {n}: {msg[:120]}[/dim]")
        summary[m.id] = {
            "installed": installed,
            "skipped": skipped,
            "errors": len(errors),
        }

        # Register in config so Portal UI can manage it
        mp_section[m.id] = {
            "label": m.label,
            "path": str(source_path),
            "format": m.format,
        }


def _show_environment(shutil: Any) -> None:
    """Detect and display installed tools during init."""
    import platform

    tools = ["git", "gh", "node", "az", "claude"]

    detected: list[str] = []
    for tool_name in tools:
        if shutil.which(tool_name):
            detected.append(f"[green]{tool_name}[/green]")

    plat = f"{platform.system()} {platform.machine()}"
    console.print(f"[bold]Environment:[/bold] {plat}\n[bold]Tools:[/bold] {', '.join(detected)}\n")


def _detect_github_context() -> tuple[bool, list[str]]:
    """Detect whether the user likely uses GitHub.

    Returns ``(is_developer, reasons)`` where *reasons* lists what was found.
    """
    import shutil

    reasons: list[str] = []

    # 1. git / gh CLI installed
    if shutil.which("git"):
        reasons.append("git installed")
    if shutil.which("gh"):
        reasons.append("gh CLI installed")

    # 2. GITHUB_TOKEN set
    if os.environ.get("GITHUB_TOKEN"):
        reasons.append("$GITHUB_TOKEN set")

    # 3. gh auth token available (check even if git/gh CLI found)
    if not any("gh CLI" in r for r in reasons):
        try:
            import subprocess

            r = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0 and r.stdout.strip():
                reasons.append("gh auth token available")
        except Exception:
            pass

    # 4. .git in cwd or parents
    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        if (p / ".git").exists():
            reasons.append(f".git found in {p}")
            break
        if p == p.parent:
            break

    # 5. Dev project files in cwd
    dev_files = ["package.json", "pyproject.toml", "Cargo.toml", "go.mod", "pom.xml", "Makefile"]
    for f in dev_files:
        if (cwd / f).exists():
            reasons.append(f"{f} in cwd")
            break

    # 6. ~/.gitconfig
    if (Path.home() / ".gitconfig").exists():
        reasons.append("~/.gitconfig exists")

    return bool(reasons), reasons


def _discover_existing_copilot_login() -> ExistingGitHubToken | None:
    """Return the Copilot LLM token if the user has one in $GITHUB_COPILOT_TOKEN.

    The only non-interactive source we adopt as the Copilot LLM token —
    GCM / ``gh`` CLI / ``$GITHUB_TOKEN`` are intentionally excluded
    because their tokens have unknown scopes and silently adopting them
    leaks user-assigned git credentials to the Copilot endpoint and
    causes 401s. See :func:`discover_existing_copilot_token`.
    """
    try:
        from praestoclaw.security.github_auth import discover_existing_copilot_token

        return discover_existing_copilot_token()
    except Exception as exc:
        from loguru import logger

        logger.debug("Copilot token discovery failed: {}", exc)
        return None


def _store_github_login_for_git(token: str) -> None:
    """Best-effort bridge from init GitHub sign-in to Git Credential Manager."""
    try:
        from praestoclaw.security.github_auth import store_github_token_in_git_credential

        stored = store_github_token_in_git_credential(token)
    except Exception:
        stored = False
    if stored:
        console.print("  [green]+[/green] Git credential updated for GitHub repo access")
    else:
        console.print(
            "  [dim]Git credential was not updated; GitHub repo access may use an existing Git sign-in.[/dim]"
        )


def _should_store_github_login_for_git(source: str) -> bool:
    """Return whether an existing token source should be bridged to git-credential.

    By policy, **detected** existing tokens are never auto-bridged. Bridging is
    reserved for the explicit device-code login flow, which calls
    :func:`_store_github_login_for_git` directly. This avoids:

    * persisting an env-supplied token (``$GITHUB_TOKEN``,
      ``$GITHUB_COPILOT_TOKEN``) into the user's git credential store,
      where it would outlive the shell session;
    * persisting a ``gh``-issued token (which is managed by the GitHub CLI's
      own keyring) into a separate store the user didn't ask for; and
    * round-tripping a token that is already in Git Credential Manager
      back through ``git credential approve`` for no benefit.
    """
    return source not in {
        "git-credential-manager",
        "env:GITHUB_COPILOT_TOKEN",
        "env:GITHUB_TOKEN",
        "gh",
    }


def _cloud_login_if_needed() -> str | None:
    """If cloud is enabled, run the Azure CLI login menu.

    Called during ``init`` so the user can authenticate before first use.
    Returns ``"azure_cli"`` when sign-in succeeds, or ``None`` when the menu
    was skipped / failed. The caller is expected to persist the returned
    value to ``channels.cloud.auth_provider`` in the local yaml so the
    runtime silent path uses the same provider.
    """
    from praestoclaw.config.loader import load_config

    try:
        cfg = load_config(".")
    except Exception:
        return None

    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
        return None
    if not cloud_cfg.scope:
        cloud_cfg.scope = f"{cloud_cfg.client_id}/.default"

    try:
        from praestoclaw.auth.factory import all_providers, build_auth_provider
        from praestoclaw.auth.menu import show_login_menu

        try:
            default_provider = build_auth_provider(cloud_cfg)
        except Exception:
            default_provider = None

        available = all_providers(cloud_cfg)
        chosen = show_login_menu(available, default=default_provider)
        if chosen is None:
            console.print("  [dim]Cloud sign-in skipped.[/dim]")
            return None

        result = chosen.interactive_login()
        return str(chosen.name) if result.token else None
    except RuntimeError as exc:
        if "skipped" in str(exc).lower():
            console.print("  [dim]Cloud sign-in skipped.[/dim]")
        else:
            console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")
    except KeyboardInterrupt:
        console.print("  [dim]Cloud sign-in skipped.[/dim]")
    except Exception as exc:
        console.print(f"  [yellow]Warning:[/yellow] Cloud sign-in failed: {exc}")
    return None


def _cloud_login_quick() -> str | None:
    """Quick-mode cloud sign-in — Azure CLI only, auto-login if needed.

    Pipeline: ensure az installed → ensure az logged in (auto ``az login``
    when a tty is available) → return ``"azure_cli"`` on success. Prints a
    single status line per outcome. Never prompts a menu.
    """
    from praestoclaw.config.loader import load_config

    try:
        cfg = load_config(".")
    except Exception:
        return None

    cloud_cfg = cfg.channels.cloud
    if not cloud_cfg.url or not cloud_cfg.tenant_id:
        return None

    from praestoclaw.auth.azure_cli.installer import (
        detect_install_plan,
        install_az,
        is_az_installed,
    )
    from praestoclaw.auth.azure_cli.login import interactive_login, is_logged_in

    if not is_az_installed():
        plan = detect_install_plan()
        if plan is None or not install_az(plan, console=console):
            console.print(
                "  [yellow]Azure CLI not installed.[/yellow]"
                " Install az then run [cyan]pc cloud[/cyan] to enable Teams."
            )
            return None

    if is_logged_in():
        console.print("  [green]+[/green] reusing az session")
        return "azure_cli"

    # Only stdin needs to be a tty for `az login` to work — az opens its
    # own browser, so a piped stdout (e.g. install.ps1's
    # `... | ForEach-Object { Write-Host ...}`) shouldn't disqualify us.
    from praestoclaw.utils.input import stdin_is_tty

    if not stdin_is_tty():
        console.print(
            "  [yellow]Not signed in to Azure CLI.[/yellow]"
            " Run [cyan]az login[/cyan] then [cyan]pc cloud[/cyan] to enable Teams."
        )
        return None

    console.print("  [dim]Not signed in. Running [cyan]az login[/cyan]…[/dim]")
    if interactive_login(tenant_id=cloud_cfg.tenant_id or None, console=console):
        console.print("  [green]+[/green] signed in via az")
        return "azure_cli"

    console.print(
        "  [yellow]az login failed or cancelled.[/yellow] Run [cyan]pc cloud[/cyan] later to retry."
    )
    return None


# ── Main init command ─────────────────────────────────────────────────────────


@app.command()
def init(
    directory: str | None = typer.Option(
        None, "--dir", "-d", help="Target directory (default: ~/.praestoclaw)"
    ),
    name: str | None = typer.Option(
        None, "--name", "-n", help="Project name (sets top-level 'name' in config)"
    ),
    quick: bool = typer.Option(False, "--quick", "-q", help="Accept all defaults, no prompts"),
) -> None:
    """Create or update the local config override (praestoclaw.local.yaml).

    By default this writes to ``~/.praestoclaw/praestoclaw.local.yaml``.
    Safe to run multiple times \u2014 existing values are shown as defaults
    so you only change what you want. Use --quick to accept all defaults.
    """
    import shutil
    import sys

    import yaml
    from loguru import logger

    from praestoclaw.utils.helpers import get_data_dir

    # init renders a guided wizard via rich panels; INFO logs from the
    # wider stack would interleave with the panels and confuse first-run
    # users. Quiet stderr to WARNING for this command only \u2014 real
    # problems still surface, info noise doesn't. Other CLI commands
    # keep the default INFO level set in cli/commands.py.
    logger.remove()
    logger.add(sys.stderr, level="WARNING")

    dir_path = get_data_dir() if directory is None else Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "praestoclaw.local.yaml"

    # Load existing config to use as defaults
    existing: dict = {}
    is_update = local_path.exists()
    if is_update:
        try:
            loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
            existing = loaded if isinstance(loaded, dict) else {}
        except Exception:
            existing = {}

    # ── Environment detection ─────────────────────────────────────────
    _show_environment(shutil)

    # Single-line banner — matches the Teams installer style
    # (`>> Installing PraestoClaw into Microsoft Teams ...`).
    verb = "Updating" if is_update else "Creating"
    console.print(f"\n[bold cyan]>>[/bold cyan] [bold]{verb} PraestoClaw configuration[/bold]")
    console.print(f"  [dim]{local_path}[/dim]")
    if quick:
        console.print("  [dim]--quick mode: accepting all defaults[/dim]")

    # ── [1/5] GitHub token ────────────────────────────────────────────
    raw_token: str = (existing.get("providers") or {}).get("github_copilot", {}).get(
        "token", ""
    ) or ""
    # Legacy migration: pre-#176 init wrote "${GITHUB_TOKEN}" as the default
    # token reference for users who skipped sign-in. That env var is now
    # explicitly NOT a Copilot fallback — preserving such a stale value
    # would re-introduce the trust-boundary leak / 401 confusion this PR
    # is meant to eliminate. Treat it as if no token were configured so
    # the user goes through sign-in/skip again and the new default
    # ("${GITHUB_COPILOT_TOKEN}") is written.
    if raw_token == "${GITHUB_TOKEN}":
        raw_token = ""
    # A SECRET[…] or ${…} reference means a token is configured but resolved at runtime.
    has_configured_token = bool(raw_token)
    current_token = "" if raw_token.startswith(("${", "SECRET[")) else raw_token

    github_token: str | None = None
    if quick:
        if raw_token:
            # Preserve existing token reference (SECRET[…] / ${…} / plaintext) as-is
            github_token = None
            _step_header(1, "GitHub Copilot (LLM Provider)")
            _step_auto("token already configured \u2014 keeping as-is")
        else:
            existing_login = _discover_existing_copilot_login()
            if existing_login:
                _step_header(1, "GitHub Copilot (LLM Provider)")
                # Env-var sourced tokens are process-scoped by intent —
                # write a "${GITHUB_COPILOT_TOKEN}" reference into the
                # config so the resolver re-reads $GITHUB_COPILOT_TOKEN
                # at runtime, instead of persisting the literal token
                # value into the SecretStore. The "elif github_token:"
                # branch below picks this up unchanged.
                github_token = "${GITHUB_COPILOT_TOKEN}"
                _step_auto(f"using {existing_login.label} (env-var reference)")
                # No bridge to Git Credential Manager either — same
                # process-scoped policy. See `_should_store_github_login_for_git`.
            else:
                # No token configured and no existing local sign-in — run
                # interactive device-code login. Print the step header so the
                # device-code prompt appears under a numbered section,
                # consistent with the other [N/7] steps.
                _step_header(1, "GitHub Copilot (LLM Provider)")
                console.print(
                    "  [dim]Sign in once so PraestoClaw can call GitHub Copilot "
                    "and fetch GitHub repo skills. GitHub may ask for repository access.[/dim]"
                )
                with console.status("[bold cyan]Checking connectivity\u2026"):
                    online = _check_connectivity()
                if online:
                    from praestoclaw.security.github_auth import github_device_login

                    try:
                        github_token = github_device_login(console=console)
                        if github_token:
                            _store_github_login_for_git(github_token)
                            _step_done("signed in with GitHub")
                    except Exception as exc:
                        console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                else:
                    console.print(
                        "  [yellow]Cannot reach github.com \u2014 skipping GitHub auth.[/yellow]\n"
                        "  Run [bold]praestoclaw init[/bold] again when online."
                    )
    elif current_token:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        console.print("  [dim]PraestoClaw uses GitHub Copilot as its AI engine.[/dim]")
        _GH_REAUTH_OPTS: list[tuple[str, str]] = [
            ("Keep current token", f"{current_token[:8]}..."),
            (
                "Re-authenticate with GitHub",
                "opens browser; GitHub may request repository access",
            ),
        ]
        choice = _select(_GH_REAUTH_OPTS, default=1)
        _step_done(_GH_REAUTH_OPTS[choice - 1][0])
        if choice == 2:
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                from praestoclaw.security.github_auth import github_device_login

                try:
                    github_token = github_device_login(console=console)
                    _store_github_login_for_git(github_token)
                except Exception as exc:
                    console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                    github_token = current_token
            else:
                console.print(
                    "  [yellow]Cannot reach github.com \u2014 keeping current token[/yellow]"
                )
                github_token = current_token
        else:
            github_token = current_token
    else:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        console.print("  [dim]PraestoClaw uses GitHub Copilot as its AI engine.[/dim]")

        existing_login = None if has_configured_token else _discover_existing_copilot_login()
        if existing_login:
            # Same process-scoped policy as the quick-mode branch above:
            # write a reference to $GITHUB_COPILOT_TOKEN, do NOT persist
            # the literal env-var value into the SecretStore.
            github_token = "${GITHUB_COPILOT_TOKEN}"
            _step_auto(f"using {existing_login.label} (env-var reference)")
        else:
            if raw_token.startswith("SECRET["):
                _skip_desc = "already configured (SecretStore)"
            elif raw_token.startswith("${"):
                _skip_desc = "already configured (environment variable)"
            elif has_configured_token:
                _skip_desc = "already configured"
            else:
                _skip_desc = "configure later"
            _GH_NEW_ACTIONS: list[tuple[str, str, str]] = [
                ("sign-in", "Sign in with GitHub", "opens browser; may request repository access"),
                ("skip", "Skip", _skip_desc),
            ]
            choice = _select(
                [(label, desc) for _, label, desc in _GH_NEW_ACTIONS],
                default=2 if has_configured_token else 1,
            )
            action, label, _ = _GH_NEW_ACTIONS[choice - 1]
            _step_done(label)
            if action == "sign-in":
                with console.status("[bold cyan]Checking connectivity\u2026"):
                    online = _check_connectivity()
                if online:
                    from praestoclaw.security.github_auth import github_device_login

                    try:
                        github_token = github_device_login(console=console)
                        _store_github_login_for_git(github_token)
                    except Exception as exc:
                        console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                else:
                    console.print(
                        "  [yellow]Cannot reach github.com \u2014 skipping GitHub auth.[/yellow]\n"
                        "  Run [bold]pc init[/bold] again when online."
                    )
            # skip: github_token stays None

    # ── [2/7] Security profile ────────────────────────────────────────
    _PROFILES: list[tuple[str, str]] = [
        ("open", "AI runs freely, no confirmations needed"),
        ("standard", "AI asks before risky actions (recommended)"),
        ("controlled", "AI asks before most actions"),
        ("restricted", "AI asks before every action"),
    ]
    _PROFILE_NAMES = [p[0] for p in _PROFILES]

    current_profile: str = (existing.get("security") or {}).get("profile", "standard") or "standard"
    if quick:
        security_profile = current_profile
        _step_header(2, "Security Profile")
        _step_auto(f"profile = {security_profile}")
    else:
        _step_header(2, "Security Profile")
        console.print("  [dim]Controls how much autonomy the AI agent has.[/dim]")
        default_idx = (
            (_PROFILE_NAMES.index(current_profile) + 1) if current_profile in _PROFILE_NAMES else 2
        )
        choice = _select(_PROFILES, default=default_idx)
        security_profile = _PROFILE_NAMES[choice - 1]
        _step_done(security_profile)

    # ── [3/7] Web channel (web server) ────────────────────────────────
    current_gw: dict = (existing.get("channels") or {}).get("web") or existing.get("gateway") or {}
    current_gw_enabled: bool = bool(current_gw.get("enabled", True))
    web_port = current_gw.get("port", 3004)
    if quick:
        enable_web = current_gw_enabled
        _step_header(3, f"Web UI (localhost:{web_port})")
        _step_auto("enabled" if enable_web else "disabled")
    else:
        _step_header(3, f"Web UI (localhost:{web_port})")
        console.print(f"  [dim]A local web chat interface at http://localhost:{web_port}[/dim]")
        _WEB_OPTS: list[tuple[str, str]] = [
            ("Enable", "access PraestoClaw from your browser"),
            ("Disable", "CLI only, no web interface"),
        ]
        choice = _select(_WEB_OPTS, default=1 if current_gw_enabled else 2)
        enable_web = choice == 1
        _step_done("enabled" if enable_web else "disabled")

    # ── [4/7] Cloud channel (Teams, Web Chat) ─────────────────────────
    current_cloud: dict = (existing.get("channels") or {}).get("cloud") or {}
    current_cloud_enabled: bool = bool(current_cloud.get("enabled", True))
    if quick:
        enable_cloud = current_cloud_enabled
        _step_header(4, "Cloud Connection (Teams, Web Chat)")
        _step_auto("enabled" if enable_cloud else "disabled")
    else:
        _step_header(4, "Cloud Connection (Teams, Web Chat)")
        console.print("  [dim]Connect to Microsoft Teams and Web Chat via cloud relay.[/dim]")
        _CLOUD_OPTS: list[tuple[str, str]] = [
            ("Enable", "chat with PraestoClaw from Teams or browser"),
            ("Disable", "local only, no cloud connection"),
        ]
        choice = _select(_CLOUD_OPTS, default=1 if current_cloud_enabled else 2)
        enable_cloud = choice == 1
        _step_done("enabled" if enable_cloud else "disabled")

    # Sub-steps when cloud is enabled (not quick).
    if enable_cloud and not quick:
        pass  # 4.1 Cloud sign-in and 4.2 Teams app run after config write below.

    # ── Build config (deep-merge: preserve existing keys, update changed ones) ──
    local_config: dict = dict(existing)  # start from existing

    if name:
        local_config["name"] = name

    local_config.setdefault("providers", {}).setdefault("github_copilot", {})
    if github_token and not github_token.startswith("${"):
        # New real token — store in SecretStore, write reference in YAML
        try:
            from praestoclaw.security.secrets import set_secret

            set_secret("GITHUB_COPILOT_TOKEN", github_token)
            local_config["providers"]["github_copilot"]["token"] = "SECRET[GITHUB_COPILOT_TOKEN]"
            console.print("  [green]+[/green] Token stored in SecretStore")
        except Exception as exc:
            console.print(
                f"  [yellow]Warning:[/yellow] SecretStore unavailable ({exc}).\n"
                "  Token will be stored as plaintext in praestoclaw.local.yaml."
            )
            local_config["providers"]["github_copilot"]["token"] = github_token
    elif github_token:
        # Explicit env-var reference (e.g. "${GITHUB_COPILOT_TOKEN}")
        local_config["providers"]["github_copilot"]["token"] = github_token
    elif raw_token:
        # User skipped — preserve existing reference (SECRET[…] / ${…} / plaintext)
        local_config["providers"]["github_copilot"]["token"] = raw_token
    else:
        # No token at all — fallback to env-var reference. Use the
        # Copilot-specific name; $GITHUB_TOKEN is intentionally NOT
        # an accepted fallback because it's the credential users
        # assign to git push (typically without Copilot scope).
        local_config["providers"]["github_copilot"]["token"] = "${GITHUB_COPILOT_TOKEN}"

    local_config.setdefault("security", {})
    local_config["security"]["profile"] = security_profile

    local_config.setdefault("logging", {"level": "INFO", "format": "pretty"})

    gw = local_config.setdefault("channels", {}).setdefault("web", {})
    gw["enabled"] = enable_web
    if enable_web:
        gw.setdefault("host", "localhost")
        gw.setdefault("port", current_gw.get("port", 3004))

    cloud = local_config.setdefault("channels", {}).setdefault("cloud", {})
    cloud["enabled"] = enable_cloud

    # ── Cloud sub-steps ────────────────────────────────────────────────
    # quick: silent az sign-in (auto `az login` if a tty is available);
    # interactive: full menu sign-in + Teams app sideload.
    if enable_cloud and quick:
        chosen_provider = _cloud_login_quick()
        if chosen_provider:
            cloud["auth_provider"] = chosen_provider

    if enable_cloud and not quick:
        console.print("  [dim](4.1) Cloud sign-in[/dim]")
        chosen_provider = _cloud_login_if_needed()
        if chosen_provider:
            cloud["auth_provider"] = chosen_provider
            console.print(f"  [dim]auth_provider set to {chosen_provider}[/dim]")

        console.print("  [dim](4.2) Teams app[/dim]")
        from praestoclaw.cli.teams import is_teams_installed

        if is_teams_installed():
            console.print("  [green]+[/green] Teams app already installed")
        elif not _is_tty():
            console.print(
                "  [dim]Teams app not detected; run"
                " [cyan]pc teams install[/cyan] to install it later.[/dim]"
            )
        else:
            # Async fan-out: the wizard moves on immediately, the Web
            # Portal status bar shows progress, and the Teams welcome
            # card waits for ``pending.teams_sideload.status == 'done'``
            # before firing.
            from praestoclaw.cli.init_async import fire_teams_sideload

            fire_teams_sideload()
            console.print(
                "  [dim]Teams app installing in background — "
                "check status with [cyan]pc doctor[/cyan].[/dim]"
            )

    # ── Identity capture (works in both interactive and --quick modes) ──
    # Best-effort — reads any pre-existing MSAL/m365/az cache on the
    # machine and persists the user's Entra claims into ``.fre-state.json``
    # so the Web Portal status bar and the Teams welcome card can greet
    # them by name on the very first message. Sits *outside* the
    # ``not quick`` guard above because the install.ps1 / install.sh
    # one-click path runs ``init --quick`` and we still want
    # personalization to work for those users (most corporate Windows
    # boxes already have an ``az login`` session, for example).
    if enable_cloud:
        try:
            from praestoclaw.cli.init_async import try_capture_user_best_effort
            from praestoclaw.config.loader import load_config

            try:
                _full_cfg = load_config(".")
                _cloud_client_id = _full_cfg.channels.cloud.client_id or ""
            except Exception:
                _cloud_client_id = ""

            captured = try_capture_user_best_effort(
                auth_provider=cloud.get("auth_provider"),
                cloud_client_id=_cloud_client_id,
            )
            if captured and captured.get("first_name") and not quick:
                # Only echo in interactive mode where the [4.1] Cloud
                # sign-in header above gives this line meaningful
                # context. In quick mode there's no cloud header
                # printed (everything is silent except step 1's
                # GitHub Copilot device-code flow), so an unattributed
                # "Signed in as Alice" line right under "[1/7] GitHub
                # Copilot" reads as if Alice were the GitHub username.
                # The captured identity is still persisted for the
                # Web Portal / Teams welcome card to use.
                console.print(
                    f"  [green]+[/green] Signed in as [cyan]{captured['first_name']}[/cyan]"
                )
        except Exception:
            # Purely cosmetic — never block init.
            pass

    # ── [5/7] MCP Servers ─────────────────────────────────────────────
    from praestoclaw.cli.mcp import _mcp_setup

    # Pre-warm the project-detection cache before MCP setup runs. ADO and
    # bluebird MCP servers ask the user for ``organization`` / ``project``
    # defaults, and we'd rather pull those from the same workspace scan
    # the marketplace step uses than spawn a second ``git remote`` call.
    # Best-effort — failures here just mean MCP falls back to its own
    # cwd-only ``_detect_ado_remote()`` heuristic.
    try:
        from praestoclaw.projects import get_detection_env

        get_detection_env()
    except Exception:
        pass

    _step_header(5, "MCP Servers (Teams, Mail, Calendar, ADO, \u2026)")
    mcp_added: dict[str, Any] = {}
    if quick:
        _step_auto("installing all recommended servers")
        mcp_added = _mcp_setup(dir_path, local_config, select_all=True, quick=True, step=5)
    else:
        mcp_added = _mcp_setup(dir_path, local_config, step=5)

    # Warm the MSAL token cache for every MCP server in the background.
    # The wizard's runtime startup later in this session — and the user's
    # very first chat message — both benefit from a hot cache. Failures
    # here are silent: per-request acquire still works on a cold cache.
    if mcp_added:
        try:
            from praestoclaw.cli.init_async import fire_mcp_silent_acquire
            from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

            # Each MCP server entry may carry its own ``client_id``; fall
            # back to the shared Entra app for servers that don't.
            client_ids: set[str] = set()
            for srv in mcp_added.values():
                if isinstance(srv, dict):
                    cid = srv.get("client_id") or SHARED_ENTRA_CLIENT_ID
                    if cid:
                        client_ids.add(cid)
            if not client_ids:
                client_ids.add(SHARED_ENTRA_CLIENT_ID)
            fire_mcp_silent_acquire(sorted(client_ids))
        except Exception:
            pass

    # ── [6/7] Skills: profiles, marketplace, imports ──────────────────
    skills_summary = _skill_marketplace_setup(
        local_config, quick=quick, local_config_path=str(local_path)
    )
    import_summary = (skills_summary or {}).get("external_import", {})

    # ── [7/7] Autostart on Login ──────────────────────────────────────
    from praestoclaw.cli.autostart import enable_autostart, is_autostart_enabled

    autostart_enabled = is_autostart_enabled()
    if quick:
        # Always rewrite the definition so upgrades remove obsolete service-manager
        # restart/logging settings even when autostart is already enabled.
        _step_header(7, "Autostart on Login")
        if enable_autostart():
            autostart_enabled = True
            _step_done("autostart enabled")
        elif autostart_enabled:
            _step_auto("refresh failed (still enabled)")
        else:
            _step_auto("enable failed (still disabled)")
    else:
        _step_header(7, "Autostart on Login")
        console.print(
            "  [dim]Start PraestoClaw automatically when you log in to your computer.[/dim]"
        )
        _AUTOSTART_OPTS: list[tuple[str, str]] = [
            ("Enable", "start PraestoClaw server on login (recommended)"),
            ("Disable", "start manually with pc s"),
        ]
        choice = _select(_AUTOSTART_OPTS, default=1)
        if choice == 1:
            if enable_autostart():
                autostart_enabled = True
                _step_done("autostart enabled")
            else:
                console.print("  [yellow]Warning:[/yellow] Failed to enable autostart.")
                console.print("  [dim]Run [cyan]pc autostart enable[/cyan] to retry.[/dim]")
        else:
            autostart_enabled = False
            _step_done("skipped")

    from praestoclaw.config.loader import LOCAL_CONFIG_HEADER, save_yaml

    save_yaml(local_path, local_config, header=LOCAL_CONFIG_HEADER)

    if quick:
        # Spawn deferred background workers AFTER the main save so the
        # workers' read-modify-write of ``praestoclaw.local.yaml`` cannot
        # be clobbered by the main thread's final write.
        marketplace_install = (skills_summary or {}).get("_marketplace_install") or {}
        if marketplace_install.get("selected_ids"):
            try:
                from praestoclaw.cli.init_async import fire_marketplace_install

                fire_marketplace_install(
                    list(marketplace_install["selected_ids"]),
                    local_config_path=marketplace_install.get("local_config_path"),
                )
            except Exception:
                pass

        if (import_summary or {}).get("queued"):
            try:
                from praestoclaw.cli.init_async import fire_external_import

                queued_projects = (import_summary or {}).get("subscribed_projects", [])
                fire_external_import(
                    local_config,
                    subscribed_projects=list(queued_projects),
                    local_config_path=str(local_path),
                )
            except Exception:
                pass

    verb = "Updated" if is_update else "Created"
    console.print(f"  [green]+[/green] [bold]{verb}[/bold] {local_path}")

    # Persist the completion marker + a snapshot of the most useful
    # config knobs so the Web Portal and Teams bot can short-circuit
    # any "have you finished init?" checks. Best-effort — never fails.
    try:
        from praestoclaw.utils.fre_state import mark_completed

        mark_completed(
            "init",
            value={
                "web_enabled": enable_web,
                "cloud_enabled": enable_cloud,
                "profile": security_profile,
            },
        )
    except Exception:
        pass

    # ── Summary (especially useful for --quick mode) ──────────────────
    if quick:
        console.print()
        summary = Table(show_header=False, box=None, padding=(0, 2))
        summary.add_column(style="bold")
        summary.add_column()

        token_ref = local_config.get("providers", {}).get("github_copilot", {}).get("token", "")
        if token_ref == "SECRET[GITHUB_COPILOT_TOKEN]":
            provider_desc = "GitHub Copilot (SecretStore)"
        elif token_ref.startswith("${"):
            provider_desc = f"GitHub Copilot ({token_ref})"
        elif token_ref:
            provider_desc = "GitHub Copilot (token set)"
        else:
            provider_desc = "not configured"
        summary.add_row("Provider", provider_desc)
        summary.add_row("Profile", security_profile)
        web_port = gw.get("port", 3004)
        summary.add_row("Web UI", f"enabled (:{web_port})" if enable_web else "disabled")
        summary.add_row("Cloud", "enabled" if enable_cloud else "disabled")
        summary.add_row("MCP", f"{len(mcp_added)} server(s) added" if mcp_added else "none added")
        # Quick mode fires marketplace install in the background, so
        # ``skills_summary`` reports queued bundles rather than installed
        # counts. Distinguish so users don't read "0 installed" as failure.
        marketplace_summary = {
            k: v
            for k, v in (skills_summary or {}).items()
            if k not in {"external_import", "_marketplace_install"}
        }
        queued_bundles = [k for k, v in marketplace_summary.items() if v.get("queued")]
        if queued_bundles:
            skills_line = (
                f"{len(queued_bundles)} bundle(s) installing in background (see Portal status bar)"
            )
        else:
            skills_total = sum(v.get("installed", 0) for v in marketplace_summary.values())
            skills_line = (
                f"{skills_total} installed from {len(marketplace_summary)} source(s)"
                if marketplace_summary
                else "none added"
            )
        summary.add_row("Skills", skills_line)
        imp_skills = (import_summary or {}).get("skills_imported", 0)
        import_line = (
            "queued in background"
            if (import_summary or {}).get("queued")
            else (f"{imp_skills} skill(s) from Claude/Copilot" if imp_skills else "none found")
        )
        summary.add_row(
            "Import",
            import_line,
        )
        summary.add_row(
            "Autostart",
            "enabled" if autostart_enabled else "disabled",
        )

        console.print(
            Panel(
                summary,
                title="Quick Setup Summary",
                border_style="cyan",
                padding=(1, 2),
            )
        )

    # ── Bounded-join background workers ───────────────────────────────
    # Daemon threads that haven't finished by the time the wizard exits
    # get killed mid-write, leaving ``pending.*.status == "running"``
    # forever. Wait up to 60 s for fast workers (MCP token cache,
    # small marketplaces) to finish cleanly. Slower ones survive as
    # daemons and the web server's stale-pending sweep will surface
    # them as ``failed`` with a Retry button.
    try:
        from praestoclaw.cli.init_async import await_outstanding, has_outstanding

        if has_outstanding():
            # Workers are still running (typically the marketplace
            # ``git clone`` worker — which can take 15-60 s on a
            # corporate network and may also trigger a one-time GCM
            # browser sign-in for github.com). Show a spinner so
            # [7/7] doesn't look like the end of the run while GCM's
            # own ``info: please complete authentication…`` output
            # and any browser popup happen in parallel.
            with console.status(
                "[bold cyan]Finishing background tasks "
                "(marketplace clone, MCP token cache)\u2026[/bold cyan]",
                spinner="dots",
            ):
                joined, still_alive = await_outstanding(timeout=60.0)
        else:
            joined, still_alive = await_outstanding(timeout=60.0)
        if still_alive:
            from loguru import logger

            logger.debug(
                "[init] {} background worker(s) still running after 60s join "
                "— left for stale-sweep / retry from Portal",
                still_alive,
            )
    except Exception:
        pass

    # ── Completion ────────────────────────────────────────────────────
    # Surface a non-blocking hint when ``gh`` is installed but
    # unauthenticated. We deliberately do **NOT** sign the user in
    # ourselves: ``gh`` lives in their shell and managing its keyring is
    # the user's job. The PraestoClaw device-code login uses a GitHub
    # App client whose tokens are scope-empty (validated empirically —
    # ``X-OAuth-Scopes: ``), so injecting them into ``gh`` would make
    # ``gh auth status`` pass while every mutating command still 403s.
    # An explicit ask is honest and unambiguous.
    try:
        import shutil as _shutil
        import subprocess as _subprocess

        if _shutil.which("gh") is not None:
            r = _subprocess.run(
                ["gh", "auth", "status", "--hostname", "github.com"],
                capture_output=True,
                timeout=5,
                check=False,
            )
            if r.returncode != 0:
                console.print(
                    "  [yellow]⚠[/yellow] [dim]gh CLI is installed but not signed in. "
                    "Run [bold]gh auth login[/bold] in your shell to enable PR / issue "
                    "commands and direct [bold]/feedback[/bold] submission.[/dim]"
                )
    except Exception:
        pass

    # Surface any background work the user should be aware of so they
    # know why ``pc doctor`` may show transient "running" entries.
    pending_lines: list[str] = []
    try:
        from praestoclaw.utils.fre_state import load_fre_state

        for key, entry in (load_fre_state().get("pending") or {}).items():
            status = entry.get("status") if isinstance(entry, dict) else None
            if status in ("pending", "running"):
                pending_lines.append(f"  [dim]\u23f3 {key}: {status}[/dim]")
    except Exception:
        pass

    body = (
        "[bold]Next steps:[/bold]\n"
        "  pc s            \u2014 start the server\n"
        "  pc chat         \u2014 start chatting\n"
        "  pc doctor       \u2014 verify setup\n"
        "  pc mcp setup    \u2014 reconfigure MCP servers"
    )
    if pending_lines:
        body += "\n\n[bold]Background tasks:[/bold]\n" + "\n".join(pending_lines)

    console.print(
        Panel(
            body,
            title="Setup Complete",
            border_style="cyan",
            padding=(1, 2),
        )
    )


# Backward-compat alias (hidden, not in help)
app.command("onboard", hidden=True)(init)
