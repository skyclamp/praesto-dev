"""Helper for emitting AUTH_SUCCEEDED / AUTH_FAILED telemetry.

Lives next to the auth subsystem rather than inside praesto_telemetry so
the package stays narrow (5 public API surface) and auth-specific shaping
(splitting success vs failure into two event names) is owned by the auth
layer.
"""

from __future__ import annotations


def emit_auth_outcome(
    *,
    provider: str,
    mode: str,
    success: bool,
    duration_ms: int,
    error_type: str | None = None,
) -> None:
    """Fire-and-forget emit. Splits on ``success`` into two event names so
    KQL doesn't need ``where success == true``.

    Args:
        provider: ``azure_cli`` / ``m365`` / ``os_account`` / ``browser``.
        mode: ``silent`` (cache-only, no UI) or ``interactive`` (UI flow).
        success: Whether a token was obtained.
        duration_ms: Wall time of the auth attempt.
        error_type: Optional. Exception class name, or ``"no_token"`` when
            silent acquisition returned ``None`` without raising. Ignored
            on success.
    """
    try:
        from praesto_telemetry import Events, emit

        props: dict[str, object] = {
            "provider": provider,
            "mode": mode,
            "duration_ms": duration_ms,
        }
        if success:
            emit(Events.AUTH_SUCCEEDED, **props)
        else:
            if error_type:
                props["error_type"] = error_type
            emit(Events.AUTH_FAILED, **props)
    except Exception:  # pragma: no cover - telemetry must never break auth
        pass
