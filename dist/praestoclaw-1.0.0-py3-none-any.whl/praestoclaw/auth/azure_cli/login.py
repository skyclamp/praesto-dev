"""`az login` / `az account show` helpers.

The interactive login runs in the foreground during ``praestoclaw init`` so
the user sees the browser popup, completes the flow, and the wizard can
immediately verify that token acquisition works before persisting the
choice. While the subprocess is in flight, ``interactive_login`` also
polls ``is_logged_in()`` so that if the user happens to complete sign-in
in another terminal (or via a previously-open browser session), we detect
it and terminate the in-flight ``az login`` cleanly instead of leaving the
wizard wedged on a dead browser tab.

We never call ``az login`` from the running daemon — token expiry there
turns into a notify + degraded state, never an autonomous re-login (it
would hang waiting on browser interaction).
"""

from __future__ import annotations

import contextlib
import os
import shutil
import subprocess
import sys
from typing import Any

from loguru import logger


def _resolve_az() -> str | None:
    """Return the absolute path to the ``az`` binary, or None.

    On Windows, ``az`` is ``az.cmd`` — ``subprocess`` does not consult
    ``PATHEXT`` when launching directly (it does when ``shell=True``, but
    that introduces quoting hazards). ``shutil.which`` does honor
    ``PATHEXT``, so we resolve once here and pass the absolute path to
    ``subprocess`` everywhere.

    Falls through to a probe of well-known install directories when az is
    on disk but not yet on this process's PATH (e.g. winget just installed
    it, or this Python process started before the install).
    """
    found = shutil.which("az")
    if found is not None:
        return found
    from praestoclaw.auth.azure_cli.installer import _try_fixup_path_for_az

    _try_fixup_path_for_az()
    return shutil.which("az")


def is_logged_in() -> bool:
    """Return True when ``az account show`` succeeds (a session exists)."""
    az = _resolve_az()
    if az is None:
        return False
    try:
        result = subprocess.run(
            [az, "account", "show", "--output", "none"],
            check=False,
            capture_output=True,
            timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        logger.debug("[azure_cli] account show probe failed: {}", exc)
        return False
    return result.returncode == 0


def _active_tenant_id() -> str | None:
    """Return the tenantId of the current `az account show`, or None."""
    az = _resolve_az()
    if az is None:
        return None
    try:
        result = subprocess.run(
            [az, "account", "show", "--query", "tenantId", "--output", "tsv"],
            check=False,
            capture_output=True,
            timeout=10,
            text=True,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    tid = (result.stdout or "").strip()
    return tid or None


def _logged_in_for(tenant_id: str | None) -> bool:
    """Return True if `az` has a session (and, when requested, for `tenant_id`).

    Uses a single ``az account show --query tenantId`` invocation so the
    polling loop in ``interactive_login`` doesn't pay for two ``az`` calls
    per tick.
    """
    active = _active_tenant_id()
    if active is None:
        return False
    if not tenant_id:
        return True
    return active.lower() == tenant_id.lower()


def interactive_login(tenant_id: str | None = None, *, console: Any | None = None) -> bool:
    """Run ``az login`` interactively. Return True on success.

    Polls in parallel — if the user signs in via another terminal (e.g.
    because the browser opened with the wrong profile), the helper detects
    success and returns even if its own ``az login`` subprocess is still
    waiting on a callback. Press Ctrl+C to skip.
    """
    if not sys.stdin.isatty():
        logger.warning("[azure_cli] no tty — refusing to run `az login`")
        return False

    az = _resolve_az()
    if az is None:
        logger.error("[azure_cli] `az` not found on PATH")
        return False

    cmd = [az, "login", "--output", "none", "--only-show-errors"]
    if tenant_id:
        cmd.extend(["--tenant", tenant_id])

    if console is not None:
        try:
            console.print(f"  [dim]Running:[/dim] az login {' '.join(cmd[2:])}")
            console.print("  [dim]A browser will open. Complete sign-in, then return here.[/dim]")
            console.print(
                "  [dim]Tip: if the browser opens with the wrong profile, run "
                "[cyan]az login[/cyan] in another terminal — we'll detect it.[/dim]"
            )
            console.print("  [dim]Press Ctrl+C to skip.[/dim]")
        except Exception:
            pass

    # az 2.61+ ships a "v2 login experience" that, when the tenant has
    # multiple subscriptions, lists them all and prompts the user to pick a
    # default. We don't care which subscription is default — we only need a
    # token — and on tenants with hundreds of subs the picker is overwhelming.
    # Disable v2 so az falls back to picking the first subscription silently.
    env = os.environ.copy()
    env["AZURE_CORE_LOGIN_EXPERIENCE_V2"] = "off"

    try:
        proc = subprocess.Popen(cmd, env=env)
    except FileNotFoundError:
        logger.error("[azure_cli] `az` not found on PATH")
        return False

    poll_interval = 2.0  # seconds between is_logged_in() checks
    try:
        try:
            while True:
                try:
                    rc = proc.wait(timeout=poll_interval)
                except subprocess.TimeoutExpired:
                    # Subprocess still running — check if user signed in elsewhere.
                    # When a tenant was requested, only treat the existing session
                    # as a hit if its tenantId matches; otherwise we'd return
                    # success for a session belonging to a different tenant.
                    if _logged_in_for(tenant_id):
                        logger.info(
                            "[azure_cli] detected sign-in via external session; "
                            "terminating in-flight `az login`"
                        )
                        if console is not None:
                            try:
                                console.print(
                                    "  [green]+[/green] detected sign-in via another terminal"
                                )
                            except Exception:
                                pass
                        return True
                    continue

                if rc != 0:
                    logger.warning("[azure_cli] `az login` exited with code {}", rc)
                    return False
                return _logged_in_for(tenant_id)
        except KeyboardInterrupt:
            logger.warning("[azure_cli] login interrupted by user")
            return False
    finally:
        # Always make sure the child `az login` is reaped — KeyboardInterrupt,
        # an unexpected exception from `_logged_in_for()`, or even a normal
        # external-session return all need the subprocess torn down so it
        # doesn't outlive the wizard.
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
                with contextlib.suppress(Exception):
                    proc.wait(timeout=3)
