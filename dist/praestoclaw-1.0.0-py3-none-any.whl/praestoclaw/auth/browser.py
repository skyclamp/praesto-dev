"""Browser PKCE auth provider (MSAL).

Silent path uses the browser refresh-token cache under
``~/.praestoclaw/auth/token_cache_<cid8>.bin`` (no broker) with the
configured app scope. Interactive path opens the system default
browser, completes the authorization-code + PKCE flow, and persists
the refresh token for future silent acquires.

Like :class:`OsAccountProvider`, this provider delegates the heavy
MSAL plumbing to :class:`CloudChannel` for this refactor step;
ownership will invert once the channel's MSAL state machine is fully
isolated.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from loguru import logger

from praestoclaw.auth.base import AuthResult

if TYPE_CHECKING:
    from praestoclaw.channels.cloud import CloudChannel


class BrowserProvider:
    name: ClassVar[str] = "browser"
    display_label: ClassVar[str] = "Browser sign-in"
    supports_interactive: ClassVar[bool] = True

    def __init__(self, channel: CloudChannel) -> None:
        self._channel = channel

    def has_cached_credentials(self) -> bool:
        import msal

        from praestoclaw.auth.persist import encrypted_cache_path, load_msal_cache
        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        for cid in (self._channel._client_id, SHARED_ENTRA_CLIENT_ID):
            path = encrypted_cache_path(cid, broker=False)
            if not path.exists():
                continue
            cache = load_msal_cache(path)
            try:
                app = msal.PublicClientApplication(cid, token_cache=cache)
                if app.get_accounts():
                    return True
            except Exception:  # noqa: S112
                continue
        return False

    def try_silent(self) -> str | None:
        from praestoclaw.auth.persist import encrypted_cache_path
        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        ch = self._channel
        client_ids = [ch._client_id]
        if not ch._using_shared_app:
            client_ids.append(SHARED_ENTRA_CLIENT_ID)

        for cid in client_ids:
            authority = (
                f"https://login.microsoftonline.com/{ch._tenant_id}"
                if cid == ch._client_id
                else "https://login.microsoftonline.com/organizations"
            )
            scope = ch._scope or f"{cid}/.default"
            try:
                token = ch._try_silent_one(
                    cid,
                    authority,
                    {},
                    encrypted_cache_path(cid, broker=False),
                    scopes=[scope],
                )
            except Exception as exc:  # noqa: BLE001 — defensive
                logger.debug("[browser] silent probe failed: {}", exc)
                continue
            if token:
                if cid != ch._client_id:
                    ch._switch_to_shared_app()
                return token
        return None

    def interactive_login(self) -> AuthResult:
        ch = self._channel
        token = ch._browser_flow(try_wam=False)
        return AuthResult(token=token, claims=ch._last_msal_claims())
