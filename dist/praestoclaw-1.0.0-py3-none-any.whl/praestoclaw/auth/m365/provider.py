"""M365 auth provider — Teams Web RT borrowing (DEPRECATED).

Wraps the existing :class:`M365AuthStrategy` (still living under
``security/m365_auth/``) into the :class:`AuthProvider` protocol so the
cloud channel can treat it uniformly with the other three providers.

The underlying strategy will be moved into this package fully in a
follow-up cleanup; for this refactor we keep the original location so
the 52 existing tests under ``tests/test_m365_auth_*.py`` continue to
pass without modification.

Path: borrow Teams Web's MSAL refresh token via a managed Edge profile,
swap for a Graph access token at the OAuth2 endpoint. Used by tenants
with strict Conditional Access on custom client_ids; superseded by the
Azure CLI provider in most cases.
"""

from __future__ import annotations

import asyncio
from typing import Any, ClassVar

from loguru import logger

from praestoclaw.auth.base import AuthResult

# Same target scope the legacy strategy uses; gateway accepts any token
# with an `oid` claim, so the resource value mostly determines whether
# AAD will issue the token at all.
M365_TARGET_SCOPE = "https://graph.microsoft.com/.default"


class M365Provider:
    """``AuthProvider`` adapter around the legacy m365_auth strategy.

    Constructed from a fully-built :class:`M365AuthStrategy` instance
    rather than re-deriving config here — see ``auth.factory`` for the
    factory that builds the strategy from ``CloudChannelConfig``.
    """

    name: ClassVar[str] = "m365"
    display_label: ClassVar[str] = "Microsoft 365 sign-in (Legacy)"
    supports_interactive: ClassVar[bool] = True

    def __init__(self, strategy: Any) -> None:
        """*strategy* is an :class:`M365AuthStrategy` (or compatible)."""
        self._strategy = strategy

    def has_cached_credentials(self) -> bool:
        """Probe the strategy's cache file existence (no decryption)."""
        cache = getattr(self._strategy, "_cache", None)
        if cache is None:
            return False
        path = getattr(cache, "_path", None)
        if path is None:
            return False
        try:
            return bool(path.exists())
        except Exception:
            return False

    def try_silent(self) -> str | None:
        """Run the strategy's silent path, bridging async to sync."""
        try:
            result = _run_async_sync(self._strategy.try_silent(M365_TARGET_SCOPE))
            return str(result) if isinstance(result, str) else None
        except Exception as exc:  # noqa: BLE001 — defensive
            logger.warning("[m365] silent acquisition failed: {}", exc)
            return None

    def interactive_login(self) -> AuthResult:
        """Run the strategy's interactive path (visible Edge launch)."""
        token = _run_async_sync(self._strategy.try_interactive(M365_TARGET_SCOPE))
        if not token:
            raise RuntimeError("Microsoft 365 sign-in returned no token.")
        return AuthResult(token=str(token), claims={})


def _run_async_sync(coro: Any) -> Any:
    """Run an awaitable from a synchronous context, even when an event loop is already running.

    Used to bridge :class:`M365AuthStrategy`'s async API to the synchronous
    ``AuthProvider`` protocol. Mirrors the bridge previously inlined in
    :class:`CloudChannel`.
    """
    try:
        return asyncio.run(coro)
    except RuntimeError as exc:
        if "running event loop" not in str(exc):
            raise
        loop = asyncio.get_event_loop()
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result(timeout=180)
