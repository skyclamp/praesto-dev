"""HTTP token refresh against Entra ID using Teams Web's borrowed RT.

Calls ``POST https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token``
with ``Origin: https://teams.microsoft.com`` and the ``refresh_token`` grant.
The ``Origin`` header is required because Teams Web's client_id is registered
as a Single-Page Application; without it AAD returns ``AADSTS9002327``.

The ``offline_access`` scope keeps RT rotation alive — every successful
refresh returns a *new* RT that callers must persist immediately.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass

import httpx
from loguru import logger

from praestoclaw.auth.m365.extractor import RefreshTokenRecord

TOKEN_ENDPOINT_TEMPLATE = "https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token"
TEAMS_ORIGIN = "https://teams.microsoft.com"

# Errors signalling the RT is permanently dead — caller must clear cache and
# fall back to a different silent path or interactive login. Matches the set
# Kosmos treats as fatal in HttpRefreshService.ts:75.
_INVALID_GRANT_CODES = frozenset({"invalid_grant", "interaction_required"})


class M365AuthRefreshError(Exception):
    """Base class for refresh failures."""


class RefreshTokenInvalidError(M365AuthRefreshError):
    """The cached RT is no longer accepted by AAD; cache must be wiped."""

    def __init__(self, error_code: str, description: str = "") -> None:
        super().__init__(f"{error_code}: {description}" if description else error_code)
        self.error_code = error_code


class RefreshTransientError(M365AuthRefreshError):
    """Network / 5xx / unexpected — caller may retry later."""


@dataclass(frozen=True, slots=True)
class RefreshResult:
    access_token: str
    expires_at: float  # unix epoch
    new_refresh_token: RefreshTokenRecord  # AAD always rotates RT — store this


def build_scope(target_scope: str) -> str:
    """Compose the scope string for the token request.

    *target_scope* is whatever the caller wants the AT's audience to be
    (e.g. ``https://graph.microsoft.com/.default``). We always append
    ``openid profile offline_access`` so the response carries an id_token
    and a fresh refresh_token.
    """
    parts = [target_scope.strip()] if target_scope.strip() else []
    for required in ("openid", "profile", "offline_access"):
        if required not in target_scope:
            parts.append(required)
    return " ".join(parts)


async def swap_for_access_token(
    rt: RefreshTokenRecord,
    target_scope: str,
    *,
    client: httpx.AsyncClient | None = None,
    timeout: float = 15.0,
) -> RefreshResult:
    """Swap *rt* for an access token whose ``aud`` is determined by *target_scope*.

    Raises :class:`RefreshTokenInvalidError` when AAD rejects the RT in a
    permanent way (caller should drop the cache). Raises
    :class:`RefreshTransientError` for network/server problems where retry
    makes sense.
    """
    url = TOKEN_ENDPOINT_TEMPLATE.format(tenant=rt.tenant_id)
    body = {
        "client_id": rt.client_id,
        "grant_type": "refresh_token",
        "refresh_token": rt.secret,
        "scope": build_scope(target_scope),
    }
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": TEAMS_ORIGIN,
    }

    own_client = client is None
    cli = client or httpx.AsyncClient(timeout=timeout)
    try:
        resp = await cli.post(url, data=body, headers=headers)
    except httpx.HTTPError as exc:
        raise RefreshTransientError(f"network error: {exc}") from exc
    finally:
        if own_client:
            await cli.aclose()

    return _parse_response(resp, rt)


def _decode_jwt_exp(token: str) -> float | None:
    """Decode the ``exp`` claim from a JWT, no signature check.

    The token endpoint returns ``expires_in`` (relative seconds), but the
    JWT itself carries an absolute ``exp`` claim. We prefer ``exp`` because
    it survives clock skew between this process and AAD better.
    """
    import base64

    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload = parts[1] + "=" * (-len(parts[1]) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload).decode("utf-8"))
        exp = claims.get("exp")
        return float(exp) if isinstance(exp, (int, float)) else None
    except Exception:  # noqa: BLE001
        return None


def _parse_response(resp: httpx.Response, rt: RefreshTokenRecord) -> RefreshResult:
    if resp.status_code >= 500:
        raise RefreshTransientError(f"AAD HTTP {resp.status_code}: {resp.text[:200]}")

    try:
        data = resp.json()
    except ValueError as exc:
        raise RefreshTransientError(f"non-JSON response: {resp.text[:200]}") from exc

    error = data.get("error")
    if error:
        desc = data.get("error_description", "")
        if error in _INVALID_GRANT_CODES:
            # First line of error_description carries the AADSTS code that
            # pinpoints the actual policy (50078 = sign-in frequency,
            # 70008 = RT expired, 53000 = device non-compliant, etc.)
            first_line = desc.split("\r\n", 1)[0] if desc else "(no description)"
            logger.warning(
                "[m365_auth] AAD rejected RT ({}): {} — clearing cache",
                error,
                first_line[:300],
            )
            raise RefreshTokenInvalidError(error, desc)
        # 4xx-but-recoverable (rate limit, transient policy hiccup)
        raise RefreshTransientError(f"AAD error {error}: {desc[:200]}")

    access_token = data.get("access_token")
    new_secret = data.get("refresh_token")
    if not isinstance(access_token, str) or not isinstance(new_secret, str):
        raise RefreshTransientError(f"missing token fields in response: {list(data)}")

    # Prefer the JWT's exp claim over expires_in — the absolute timestamp
    # survives clock skew between us and AAD better than a relative count.
    exp_from_jwt = _decode_jwt_exp(access_token)
    if exp_from_jwt is not None:
        expires_at = exp_from_jwt - 30  # safety margin
    else:
        expires_in = data.get("expires_in", 3600)
        expires_at = time.time() + float(expires_in) - 30

    new_rt = RefreshTokenRecord(
        client_id=rt.client_id,
        home_account_id=rt.home_account_id,
        tenant_id=rt.tenant_id,
        secret=new_secret,
        environment=rt.environment,
    )
    return RefreshResult(access_token=access_token, expires_at=expires_at, new_refresh_token=new_rt)
