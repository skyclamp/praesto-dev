"""MCP auth — Agency CLI detection, auth status check, HTTP auth resolution."""

from __future__ import annotations

import asyncio
import os
import shutil
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
from loguru import logger

if TYPE_CHECKING:
    from praestoclaw.config.schema import MCPAuthConfig, MCPServerConfig, ProvidersConfig


async def pre_connect_agency_check() -> tuple[bool, str]:
    """Check Agency CLI availability.

    Returns (ok, message). Called automatically when connecting
    any server where ``config.is_agency`` is True.

    Note: Agency CLI does not expose an auth status subcommand.
    EntraID auth is handled interactively by Agency when the MCP
    server is first used.
    """
    agency_bin = shutil.which("agency")
    if not agency_bin:
        return False, (
            "Agency CLI not found. Install via:\n"
            '  iex "& { $(irm aka.ms/InstallTool.ps1)} agency"  (Windows)\n'
            "  curl -sSfL https://aka.ms/InstallTool.sh | sh -s agency  (Linux/macOS)"
        )
    return True, f"Agency CLI found: {agency_bin}"


async def resolve_auth_headers(
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
) -> dict[str, str]:
    """Resolve auth headers for HTTP transport.

    Stdio servers handle auth internally — returns empty dict.

    Auth type behavior:
    - ``none``: try Entra resource metadata probe (if MSAL session cached);
      falls back to SDK OAuth auto-discovery if not Entra.
    - ``implicit``: try cached credential silently, never interactive.
      client_id + scopes → MSAL silent; GitHub URL → gh CLI;
      other → SDK auto-discovery with silent handlers (cached tokens only).
    - ``bearer``: static token from config / secret store / env.
    - ``oauth``: full MSAL or SDK OAuth flow (may open browser).

    Args:
        config: MCP server config.
        providers: Provider config (unused, kept for API compatibility).

    Returns:
        Dict of HTTP headers to pass to the transport.
    """
    # Stdio transport — auth handled by subprocess
    if config.command is not None:
        return {}

    match config.auth.type:
        case "none":
            # Try Entra resource metadata discovery — Entra servers don't
            # support SDK dynamic client registration, so we probe the
            # server and use MSAL with cached tokens when possible.
            # Check for ANY cached MSAL session first to avoid a network
            # probe on every request when no session exists at all.
            if config.url and _any_msal_session_cached():
                import asyncio

                token = await asyncio.to_thread(try_entra_token, config.url, config.headers)
                if token:
                    return {"Authorization": f"Bearer {token}"}
            return {}
        case "implicit":
            # Try cached credential silently — never interactive.
            # If no static token resolved, caller falls through to SDK
            # OAuth auto-discovery (passive, activates on 401 only).
            if (
                config.auth.client_id
                and config.auth.scopes
                and not config.auth.use_sdk_oauth
            ):
                token = _acquire_msal_token(config.auth.client_id, config.auth.scopes)
                if token:
                    return {"Authorization": f"Bearer {token}"}
            elif not config.auth.use_sdk_oauth and _is_github_url(config.url):
                token = _resolve_github_token()
                if token:
                    return {"Authorization": f"Bearer {token}"}
            # No static token → empty; SDK auto-discovery handles the rest
            return {}
        case "bearer":
            token = _resolve_bearer_token(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: bearer token not found (check token or token_env)")
            return {}
        case "oauth":
            if (
                config.auth.client_id
                and config.auth.scopes
                and not config.auth.use_sdk_oauth
            ):
                # Pre-configured scopes → MSAL direct token acquisition.
                # Used for Entra servers where scopes are known and stable.
                # Servers without scopes use SDK auto-discovery (PRM → PKCE).
                token = _acquire_msal_token(config.auth.client_id, config.auth.scopes)
                if token:
                    return {"Authorization": f"Bearer {token}"}
                return {}
            # Legacy client_credentials fallback
            token = await _oauth_client_credentials(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: OAuth token exchange failed")
            return {}
        case _:
            logger.warning(f"MCP auth: unknown type '{config.auth.type}'")
            return {}


@dataclass
class AuthResult:
    """Result of auth resolution for HTTP transport."""

    headers: dict[str, str] = field(default_factory=dict)
    auth: httpx.Auth | None = None


async def resolve_auth_for_transport(
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
    *,
    resolved_url: str | None = None,
    resolved_headers: dict[str, str] | None = None,
) -> AuthResult:
    """Resolve auth for HTTP transport — returns headers + optional httpx.Auth.

    For MSAL-backed paths (implicit/oauth with client_id+scopes, or Entra
    probe), returns an :class:`MSALAuth` instance so tokens refresh
    automatically on each request via ``acquire_token_silent``.

    For bearer (static), GitHub (no refresh_token), and legacy
    client_credentials, returns static headers only.

    Args:
        resolved_url: URL with ``{var}`` placeholders already resolved.
            Falls back to ``config.url`` if not provided.
        resolved_headers: Headers with ``{var}`` resolved. Used for
            Entra resource-metadata probe (``Authorization`` is stripped).
    """
    if config.command is not None:
        return AuthResult()

    effective_url = resolved_url or config.url

    match config.auth.type:
        case "none":
            if effective_url:
                # Probe for Entra resource metadata — if the server uses
                # Entra, return MSALAuth so the SDK OAuth flow (which sends
                # resource+scope that Entra rejects) is never used.
                # Short timeout (2 s) keeps the httpx calls inside the
                # thread short-lived so the threadpool isn't tied up.
                probe_headers = {
                    k: v
                    for k, v in (resolved_headers or config.headers or {}).items()
                    if k.lower() != "authorization"
                }
                try:
                    info = await asyncio.to_thread(
                        discover_entra_auth,
                        effective_url,
                        probe_headers or None,
                        timeout=2.0,
                    )
                except Exception:
                    info = None
                if info:
                    client_id, scopes, _tenant_id = info
                    return AuthResult(auth=MSALAuth(client_id, scopes))
            return AuthResult()
        case "implicit":
            if (
                config.auth.client_id
                and config.auth.scopes
                and not config.auth.use_sdk_oauth
            ):
                return AuthResult(auth=MSALAuth(config.auth.client_id, config.auth.scopes))
            elif (
                not config.auth.use_sdk_oauth
                and effective_url
                and _is_github_url(effective_url)
            ):
                token = _resolve_github_token()
                if token:
                    return AuthResult(headers={"Authorization": f"Bearer {token}"})
            return AuthResult()
        case "bearer":
            token = _resolve_bearer_token(config.auth)
            if token:
                return AuthResult(headers={"Authorization": f"Bearer {token}"})
            logger.warning("MCP auth: bearer token not found (check token or token_env)")
            return AuthResult()
        case "oauth":
            if (
                config.auth.client_id
                and config.auth.scopes
                and not config.auth.use_sdk_oauth
            ):
                return AuthResult(auth=MSALAuth(config.auth.client_id, config.auth.scopes))
            token = await _oauth_client_credentials(config.auth)
            if token:
                return AuthResult(headers={"Authorization": f"Bearer {token}"})
            logger.warning("MCP auth: OAuth token exchange failed")
            return AuthResult()
        case _:
            logger.warning(f"MCP auth: unknown type '{config.auth.type}'")
            return AuthResult()


def _resolve_bearer_token(auth: MCPAuthConfig) -> str | None:
    """Resolve bearer token from config, secret store, or environment.

    Priority: config token → SecretStore(token_env) → env var(token_env).
    Does NOT fall back to gh CLI — that's handled by ``_resolve_github_token``
    for ``type: "implicit"`` with GitHub URLs.
    """
    if auth.token is not None:
        val = auth.token.get_secret_value()
        if val and not val.startswith("SECRET["):
            return val
    if auth.token_env:
        # SecretStore first (consistent with providers/resolver.py)
        try:
            from praestoclaw.security.secrets import get_secret_store

            value = get_secret_store().get(auth.token_env)
            if value:
                return value
        except Exception as exc:
            logger.debug("Secret store unavailable for MCP token, falling back to env: {}", exc)
        # Then env var
        value = os.environ.get(auth.token_env)
        if value:
            return value
    return None


def _resolve_gh_cli_token() -> str | None:
    """Get token from GitHub CLI (``gh auth token``)."""
    import subprocess

    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            token = result.stdout.strip()
            if token:
                logger.debug("MCP GitHub token resolved from 'gh auth token'")
                return token
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


# ── MSAL-based Entra ID token acquisition ────────────────────────────────────


def _load_msal_cache(client_id: str) -> tuple[Any, Path]:
    """Load MSAL SerializableTokenCache from encrypted file.

    Returns ``(cache, cache_path)``.
    """
    import msal

    from praestoclaw.utils.helpers import get_auth_dir

    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.bin"
    cache = msal.SerializableTokenCache()
    try:
        if cache_path.exists():
            from praestoclaw.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
    except Exception:
        pass
    return cache, cache_path


def _acquire_msal_token(client_id: str, scopes: list[str]) -> str | None:
    """Acquire an Entra ID token via MSAL (silent only, no interactive).

    Reuses the shared MSAL cache — one interactive login covers all servers
    with the same ``client_id``.  Returns ``None`` if no cached session.
    """
    try:
        import msal

        cache, cache_path = _load_msal_cache(client_id)
        app = msal.PublicClientApplication(
            client_id,
            authority="https://login.microsoftonline.com/organizations",
            token_cache=cache,
        )
        accounts = app.get_accounts()
        if not accounts:
            return None

        result = app.acquire_token_silent(scopes, account=accounts[0])
        if result and "access_token" in result:
            # Best-effort cache persistence — don't lose the token if write fails
            try:
                if cache.has_state_changed:
                    from praestoclaw.security.secrets import _atomic_write_file, encrypt_at_rest

                    data = encrypt_at_rest(cache.serialize().encode("utf-8"), strict=True)
                    _atomic_write_file(cache_path, data)
            except Exception as exc:
                logger.debug("MSAL cache persist failed (token still valid): {}", exc)
            return str(result["access_token"])
        return None
    except Exception as exc:
        logger.debug("MSAL silent token failed for {}: {}", scopes, exc)
        return None


def _acquire_msal_token_with_expiry(client_id: str, scopes: list[str]) -> tuple[str, int] | None:
    """Like :func:`_acquire_msal_token` but also returns ``expires_in``.

    Returns ``(access_token, expires_in_seconds)`` or ``None``.
    """
    try:
        import msal

        cache, cache_path = _load_msal_cache(client_id)
        app = msal.PublicClientApplication(
            client_id,
            authority="https://login.microsoftonline.com/organizations",
            token_cache=cache,
        )
        accounts = app.get_accounts()
        if not accounts:
            return None

        result = app.acquire_token_silent(scopes, account=accounts[0])
        if result and "access_token" in result:
            try:
                if cache.has_state_changed:
                    from praestoclaw.security.secrets import _atomic_write_file, encrypt_at_rest

                    data = encrypt_at_rest(cache.serialize().encode("utf-8"), strict=True)
                    _atomic_write_file(cache_path, data)
            except Exception as exc:
                logger.debug("MSAL cache persist failed (token still valid): {}", exc)
            expires_in = int(result.get("expires_in", 3600))
            return str(result["access_token"]), expires_in
        return None
    except Exception as exc:
        logger.debug("MSAL silent token (with expiry) failed for {}: {}", scopes, exc)
        return None


class MSALAuth(httpx.Auth):
    """httpx Auth that calls MSAL ``acquire_token_silent`` on each request.

    Caches the token in memory and only calls MSAL when the cached token
    is within ``_REFRESH_MARGIN`` of expiry.  Uses ``asyncio.Lock`` to
    coalesce concurrent refreshes and ``asyncio.to_thread`` to avoid
    blocking the event loop (MSAL is synchronous).
    """

    _REFRESH_MARGIN: float = 120.0  # seconds before expiry to trigger refresh

    def __init__(self, client_id: str, scopes: list[str]) -> None:
        self._client_id = client_id
        self._scopes = scopes
        self._cached_token: str | None = None
        self._expires_at: float = 0.0
        self._lock: asyncio.Lock | None = None  # lazily created (event-loop bound)

    @property
    def has_token(self) -> bool:
        """True if a valid (non-expired) cached token exists."""
        import time

        return self._cached_token is not None and time.monotonic() < self._expires_at

    async def _get_lock(self) -> asyncio.Lock:
        if self._lock is None:
            self._lock = asyncio.Lock()
        return self._lock

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        import time

        now = time.monotonic()
        token = self._cached_token

        if token is None or now >= self._expires_at - self._REFRESH_MARGIN:
            lock = await self._get_lock()
            async with lock:
                # Re-check after acquiring lock (another coroutine may have refreshed)
                now = time.monotonic()
                if self._cached_token is None or now >= self._expires_at - self._REFRESH_MARGIN:
                    info = await asyncio.to_thread(
                        _acquire_msal_token_with_expiry, self._client_id, self._scopes
                    )
                    if info:
                        new_token, expires_in = info
                        self._cached_token = new_token
                        self._expires_at = now + expires_in
                    else:
                        # Refresh failed — only clear if truly expired.
                        # Within the refresh margin but not yet expired,
                        # the old token is still valid and should be used.
                        if now >= self._expires_at:
                            self._cached_token = None
                            self._expires_at = 0.0
                token = self._cached_token

        # Always overwrite Authorization to prevent stale headers from leaking
        if token:
            request.headers["Authorization"] = f"Bearer {token}"
        else:
            request.headers.pop("Authorization", None)
        yield request


def has_msal_browser_session(client_id: str) -> bool:
    """Check if the browser cache has a refresh_token (needed by MCP)."""
    try:
        import msal

        cache, _ = _load_msal_cache(client_id)
        return bool(list(cache.search(msal.TokenCache.CredentialType.REFRESH_TOKEN)))
    except Exception:
        return False


def has_msal_account(client_id: str) -> bool:
    """Check if any MSAL cache (browser or broker) has a cached account."""
    try:
        import msal

        # Check browser cache, then broker cache.
        for suffix in ("", "_broker"):
            try:
                from praestoclaw.utils.helpers import get_auth_dir

                path = get_auth_dir() / f"token_cache_{client_id[:8]}{suffix}.bin"
                if not path.exists():
                    continue
                cache = msal.SerializableTokenCache()
                from praestoclaw.security.secrets import decrypt_at_rest

                raw = decrypt_at_rest(path.read_bytes())
                if raw:
                    cache.deserialize(raw.decode("utf-8"))
                if list(cache.search(msal.TokenCache.CredentialType.REFRESH_TOKEN)):
                    return True
                if list(cache.search(msal.TokenCache.CredentialType.ACCOUNT)):
                    return True
            except Exception:  # noqa: S112 — best-effort cache check
                continue
        return False
    except Exception:
        return False


def _any_msal_session_cached() -> bool:
    """Quick check: is a browser MSAL session cached (with refresh_token)?

    Used by ``type: "none"`` to skip network probes when no session exists.
    Only checks browser cache (not broker — broker has no refresh_token,
    which MCP servers need for cross-scope silent acquisition).
    """
    try:
        import msal

        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        cache, _ = _load_msal_cache(SHARED_ENTRA_CLIENT_ID)
        return bool(list(cache.search(msal.TokenCache.CredentialType.REFRESH_TOKEN)))
    except Exception:
        return False


def discover_entra_auth(
    url: str,
    headers: dict[str, str] | None = None,
    *,
    timeout: float = 15.0,
) -> tuple[str, list[str], str] | None:
    """Probe a server for Entra resource metadata.

    Sends a probe POST; on 401 with ``resource_metadata`` in
    ``WWW-Authenticate``, fetches the metadata and extracts auth info.

    Args:
        timeout: HTTP timeout per request (seconds). Lower values
            are used by ``resolve_auth_for_transport`` to avoid
            slowing non-Entra servers.

    Returns ``(client_id, scopes, tenant_id)`` or ``None`` if:
    - server doesn't return 401
    - no ``resource_metadata`` in WWW-Authenticate
    - auth server is not Entra (login.microsoftonline.com)
    """
    import re

    import httpx

    try:
        extra = {k: v for k, v in (headers or {}).items() if k.lower() != "authorization"}
        probe = httpx.post(
            url,
            json={"jsonrpc": "2.0", "id": "probe", "method": "initialize", "params": {}},
            headers=extra,
            timeout=timeout,
        )
        if probe.status_code != 401:
            return None

        www_auth = probe.headers.get("www-authenticate", "")
        match = re.search(r'resource_metadata="([^"]+)"', www_auth)
        if not match:
            return None

        meta_url = match.group(1)
        meta_resp = httpx.get(meta_url, timeout=timeout, headers=extra)
        if meta_resp.status_code != 200:
            return None
        meta = meta_resp.json()

        auth_servers: list[str] = meta.get("authorization_servers", [])
        raw_scopes: list[str] = meta.get("scopes_supported", [])
        if not auth_servers or not raw_scopes:
            return None

        # Validate auth server is Entra (parse hostname, not substring)
        from urllib.parse import urlparse

        auth_url = auth_servers[0]
        auth_parsed = urlparse(auth_url)
        if (auth_parsed.hostname or "") not in ("login.microsoftonline.com", "login.windows.net"):
            return None

        # Prefer api:// scope for MSAL cache hits; fall back to first non-OIDC scope
        _oidc = {"openid", "profile", "offline_access"}
        scope = next(
            (s for s in raw_scopes if s.startswith("api://")),
            next((s for s in raw_scopes if s not in _oidc), raw_scopes[0]),
        )
        scopes: list[str] = [scope]

        # Extract tenant from path: /<tenant>/v2.0
        path_parts = auth_parsed.path.strip("/").split("/")
        tenant_id = path_parts[0] if path_parts[0] else "organizations"

        from praestoclaw.mcp.defaults import SHARED_ENTRA_CLIENT_ID

        return SHARED_ENTRA_CLIENT_ID, scopes, tenant_id
    except Exception as exc:
        logger.debug("Entra resource metadata probe failed for {}: {}", url, exc)
        return None


def try_entra_token(url: str, headers: dict[str, str] | None = None) -> str | None:
    """Probe server for Entra metadata and return a cached MSAL token.

    Combines :func:`discover_entra_auth` + :func:`_acquire_msal_token`.
    Returns ``None`` if discovery fails or no cached MSAL session.
    """
    info = discover_entra_auth(url, headers)
    if not info:
        return None
    client_id, scopes, _tenant_id = info
    token = _acquire_msal_token(client_id, scopes)
    if token:
        logger.debug("Entra resource metadata: acquired MSAL token for {}", url)
        return token
    return None


def acquire_entra_token_for_server(
    url: str,
    headers: dict[str, str] | None = None,
    *,
    timeout: float = 15.0,
) -> tuple[bool, str | None]:
    """Probe server for Entra metadata and acquire a token (silent only).

    Never triggers interactive login — safe to call from background threads.
    Returns a cached token if available, ``None`` otherwise.

    Args:
        timeout: HTTP timeout for the Entra probe (seconds).
            Use a lower value (e.g. 2.0) in latency-sensitive paths.

    Returns ``(is_entra, token)``:
    - ``(False, None)`` — server is not Entra-protected.
    - ``(True, token_str)`` — Entra auth succeeded (from cache).
    - ``(True, None)`` — Entra server but no cached session.
    """
    info = discover_entra_auth(url, headers, timeout=timeout)
    if not info:
        return False, None
    client_id, scopes, tenant_id = info
    # 1. Silent (cached session — fast, no browser)
    token = _acquire_msal_token(client_id, scopes)
    if token:
        logger.debug("Entra: silent token for {}", url)
        return True, token
    # 2. Try cache refresh (silent only, no interactive prompt).
    try:
        from praestoclaw.utils.auth import acquire_entra_token

        token = acquire_entra_token(
            tenant_id=tenant_id, client_id=client_id, scopes=scopes, interactive=False
        )
        if token:
            logger.debug("Entra: token for {} (from cache after refresh)", url)
            return True, token
    except Exception as exc:
        logger.warning("Entra token acquisition failed for {}: {}", url, exc)
    return True, None


def has_cached_token(name: str, config: MCPServerConfig) -> bool:
    """Check if a cached auth token exists for a server (sync, for CLI use).

    Used by ``mcp list``, ``mcp test`` batch mode, and ``MCPManager._has_cached_token``.
    """
    if (
        config.auth.type == "oauth"
        and config.auth.client_id
        and not config.auth.use_sdk_oauth
    ):
        return has_msal_account(config.auth.client_id)
    if config.auth.type == "oauth":
        try:
            import asyncio

            from praestoclaw.mcp.oauth_storage import MCPTokenStorage

            return asyncio.run(MCPTokenStorage(name).get_tokens()) is not None
        except Exception:
            return False
    if config.auth.type == "implicit":
        if (
            config.auth.client_id
            and config.auth.scopes
            and not config.auth.use_sdk_oauth
        ):
            return has_msal_account(config.auth.client_id)
        if not config.auth.use_sdk_oauth and _is_github_url(config.url):
            return _resolve_github_token() is not None
        # Check SDK OAuth token storage (from a prior `pc mcp login`)
        try:
            import asyncio

            from praestoclaw.mcp.oauth_storage import MCPTokenStorage

            return asyncio.run(MCPTokenStorage(name).get_tokens()) is not None
        except Exception:
            return False
    # none (public) / bearer — always considered available
    return True


# ── GitHub token resolution ──────────────────────────────────────────────────

_GITHUB_HOSTS = frozenset({"api.githubcopilot.com", "api.github.com"})


def _is_github_url(url: str | None) -> bool:
    """Check if a URL belongs to GitHub (exact hostname match)."""
    if not url:
        return False
    from urllib.parse import urlparse

    return urlparse(url).hostname in _GITHUB_HOSTS


def _resolve_github_token() -> str | None:
    """Resolve a GitHub token from secret store, env, or gh CLI.

    Used for ``auth.type: "none"`` to provide zero-config GitHub MCP support.
    Checks secret store first (where device code login persists tokens),
    then environment, then ``gh auth token``.
    """
    # 1. Secret store (device code login stores GITHUB_TOKEN here)
    try:
        from praestoclaw.security.secrets import get_secret_store

        val = get_secret_store().get("GITHUB_TOKEN")
        if val:
            logger.debug("GitHub token resolved from secret store")
            return val
    except Exception:
        pass
    # 2. Environment variable
    val = os.environ.get("GITHUB_TOKEN")
    if val:
        return val
    # 3. gh auth token
    return _resolve_gh_cli_token()


async def _oauth_client_credentials(auth: MCPAuthConfig) -> str | None:
    """Exchange client credentials for an OAuth2 access token.

    Uses the standard OAuth2 client_credentials grant type.
    Requires ``client_id``, ``client_secret``, and at least one scope.
    Token endpoint is always ``https://login.microsoftonline.com/common/oauth2/v2.0/token``.
    """
    if not auth.client_id or not auth.client_secret:
        logger.warning("MCP OAuth: client_id and client_secret are required")
        return None

    scopes = auth.scopes or []
    scope_str = " ".join(scopes) if scopes else ""

    # Default Azure AD token endpoint (common tenant)
    token_url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"

    try:
        import httpx

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": auth.client_id,
                    "client_secret": auth.client_secret.get_secret_value(),
                    "scope": scope_str,
                },
            )
            response.raise_for_status()
            data = response.json()
            access_token: str | None = data.get("access_token")
            if access_token:
                logger.debug("MCP OAuth: token obtained successfully")
            return access_token
    except Exception as exc:
        logger.warning(f"MCP OAuth token exchange failed: {exc}")
        return None
