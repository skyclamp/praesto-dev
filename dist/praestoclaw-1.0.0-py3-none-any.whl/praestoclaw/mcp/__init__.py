"""
MCP (Model Context Protocol) integration for PraestoClaw.

Provides client and server implementations for MCP, enabling PraestoClaw to:
- **Client**: connect to external MCP servers and use their tools
- **Server**: expose PraestoClaw tools to external MCP clients

Both transports (stdio subprocess and HTTP/SSE) are supported via
the pluggable transport layer in ``praestoclaw.mcp.transport``.
"""

from praestoclaw.mcp.adapter import MCPToolAdapter, register_mcp_tools
from praestoclaw.mcp.client import MCPClient
from praestoclaw.mcp.health import MCPHealthMonitor
from praestoclaw.mcp.manager import MCPManager
from praestoclaw.mcp.types import ConnectionState, MCPCapabilities, ServerInfo

__all__ = [
    "ConnectionState",
    "MCPCapabilities",
    "MCPClient",
    "MCPHealthMonitor",
    "MCPManager",
    "MCPToolAdapter",
    "ServerInfo",
    "register_mcp_tools",
]
