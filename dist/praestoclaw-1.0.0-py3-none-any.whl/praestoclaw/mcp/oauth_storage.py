"""MCP OAuth token storage — implements the MCP SDK's TokenStorage protocol.

Primary: OS keyring (Windows Credential Manager / macOS Keychain) via the
PraestoClaw secret store.  Falls back to ``~/.praestoclaw/auth/secrets.json.enc``
when keyring is unavailable or the value exceeds the 2.5 KB limit.
"""

from __future__ import annotations

import json
import re
from typing import Any

from loguru import logger
from mcp.client.auth.oauth2 import TokenStorage
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken


class MCPTokenStorage(TokenStorage):
    """TokenStorage backed by the PraestoClaw secret store (OS keyring first).

    Data format: ``{"tokens": {...}, "client_info": {...}}`` stored as a single
    JSON string under key ``mcp_token_<server_name>``.  The secret store uses
    OS keyring (Windows Credential Manager / macOS Keychain) when available,
    falling back to ``~/.praestoclaw/auth/secrets.json.enc`` for overflow.
    """

    def __init__(self, server_name: str) -> None:
        self._safe_name = re.sub(r"[^\w\-.]", "_", server_name)
        self._store_key = f"mcp_token_{self._safe_name}"

    # -- internal helpers (sync, called from async wrappers) -------------------

    def _load(self) -> dict[str, Any]:
        """Load from secret store (keyring-first)."""
        try:
            from praestoclaw.security.secrets import get_secret_store

            value = get_secret_store().get(self._store_key)
            if value:
                result: dict[str, Any] = json.loads(value)
                return result
        except Exception as exc:
            logger.debug("Secret store read failed for {}: {}", self._store_key, exc)
        return {}

    def _save(self, data: dict[str, Any]) -> None:
        """Write to secret store (keyring → encrypted file overflow)."""
        from praestoclaw.security.secrets import get_secret_store

        get_secret_store().set(self._store_key, json.dumps(data, ensure_ascii=False))

    # -- TokenStorage protocol -------------------------------------------------

    async def get_tokens(self) -> OAuthToken | None:
        t = self._load().get("tokens")
        return OAuthToken.model_validate(t) if t else None

    async def set_tokens(self, tokens: OAuthToken) -> None:
        data = self._load()
        data["tokens"] = tokens.model_dump(mode="json")
        self._save(data)

    async def get_client_info(self) -> OAuthClientInformationFull | None:
        c = self._load().get("client_info")
        return OAuthClientInformationFull.model_validate(c) if c else None

    async def set_client_info(self, client_info: OAuthClientInformationFull) -> None:
        data = self._load()
        data["client_info"] = client_info.model_dump(mode="json")
        self._save(data)

    # -- extra -----------------------------------------------------------------

    def clear(self) -> None:
        """Delete stored auth data (for ``mcp logout``)."""
        try:
            from praestoclaw.security.secrets import get_secret_store

            get_secret_store().delete(self._store_key)
        except Exception:
            pass
