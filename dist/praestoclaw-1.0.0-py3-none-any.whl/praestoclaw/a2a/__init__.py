"""
A2A (Agent-to-Agent) — async envelope model + identity / card seed helpers.

P1 status: schema layer only. The runtime in ``runtime.py`` still references
the old task-RPC API and will be rewritten in P3; it is intentionally not
re-exported here to avoid pulling in broken imports.
"""

from praestoclaw.a2a.card_seed import CardSeed, generate_card_seed
from praestoclaw.a2a.models import A2AEnvelope, A2AMessageType, A2AParty

__all__ = [
    "A2AEnvelope",
    "A2AMessageType",
    "A2AParty",
    "CardSeed",
    "generate_card_seed",
]
