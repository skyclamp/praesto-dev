"""Resolve a list of subscribed projects into a recommended-asset bundle."""

from __future__ import annotations

from dataclasses import dataclass, field

from praestoclaw.projects.registry import BUILTIN_PROJECTS, Project, get_project
from praestoclaw.projects.role_assets import marketplaces_for_role


@dataclass(frozen=True)
class RecommendedAssets:
    """Aggregated recommendations across all subscribed projects.

    Lists are deduplicated while preserving the order the user subscribed
    in (which itself follows :data:`BUILTIN_PROJECTS` order when populated
    by :func:`detect_projects`). ``skill_defaults`` is merged
    last-project-wins so a user who later subscribes to ``societas`` after
    ``edge`` can override a shared key cleanly.
    """

    projects: tuple[Project, ...] = ()
    marketplaces: tuple[str, ...] = ()
    workflows: tuple[str, ...] = ()
    knowledge_bases: tuple[str, ...] = ()
    mcp_bundles: tuple[str, ...] = ()
    skill_defaults: dict[str, str] = field(default_factory=dict)
    role: str = ""


def _dedupe_preserve(items: tuple[str, ...]) -> tuple[str, ...]:
    seen: set[str] = set()
    out: list[str] = []
    for x in items:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return tuple(out)


def resolve_assets(
    subscribed_project_ids: list[str] | tuple[str, ...],
    *,
    role: str | None = None,
) -> RecommendedAssets:
    """Combine ``Project.marketplaces`` / ``workflows`` / ``…`` from every
    subscribed project into a single bundle.

    Unknown ids are silently dropped (logged at debug level by callers if
    they care). Passing an empty list is valid — you get the default
    project's assets so the user is never left with zero recommendations.

    Parameters
    ----------
    subscribed_project_ids:
        Project ids the user has opted into (see
        :mod:`praestoclaw.projects.registry`). Order is preserved.
    role:
        Optional role bucket from
        :mod:`praestoclaw.utils.role_detector`. When provided, marketplaces
        listed in :data:`praestoclaw.projects.role_assets.ROLE_MARKETPLACES`
        for that role are appended *after* the project marketplaces and
        deduplicated. Roles never decide which *project* you're on — they
        only add cross-cutting marketplaces (e.g. design-skills for a
        designer regardless of team).
    """
    projects: list[Project] = []
    seen_ids: set[str] = set()
    for pid in subscribed_project_ids or []:
        if pid in seen_ids:
            continue
        project = get_project(pid)
        if project is None:
            continue
        seen_ids.add(pid)
        projects.append(project)

    if not projects:
        # Always fall back to the default baseline.
        for p in BUILTIN_PROJECTS:
            if p.is_default:
                projects.append(p)
                break

    marketplaces: list[str] = []
    workflows: list[str] = []
    knowledge_bases: list[str] = []
    mcp_bundles: list[str] = []
    skill_defaults: dict[str, str] = {}

    for p in projects:
        marketplaces.extend(p.marketplaces)
        workflows.extend(p.workflows)
        knowledge_bases.extend(p.knowledge_bases)
        mcp_bundles.extend(p.mcp_bundles)
        # Last subscription wins on overlapping keys (documented).
        skill_defaults.update(p.skill_defaults)

    # Role-derived marketplaces come last so project picks dominate the
    # ordering; dedupe drops any that a project already pulled in.
    role_value = (role or "").strip().lower()
    marketplaces.extend(marketplaces_for_role(role_value))

    return RecommendedAssets(
        projects=tuple(projects),
        marketplaces=_dedupe_preserve(tuple(marketplaces)),
        workflows=_dedupe_preserve(tuple(workflows)),
        knowledge_bases=_dedupe_preserve(tuple(knowledge_bases)),
        mcp_bundles=_dedupe_preserve(tuple(mcp_bundles)),
        skill_defaults=skill_defaults,
        role=role_value,
    )


__all__ = ["RecommendedAssets", "resolve_assets"]
