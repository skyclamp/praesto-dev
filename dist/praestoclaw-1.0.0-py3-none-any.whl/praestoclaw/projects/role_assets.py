"""Role → marketplace recommendations.

Complements :mod:`praestoclaw.projects.registry`: where a *project* maps
to marketplaces by **product/team** ("you work on Edge, you want
edge-skills"), a *role* maps to marketplaces by **kind of work**
("you're a designer, you want design-skills regardless of what team
you're on").

The two axes compose additively at resolve time — see
:func:`praestoclaw.projects.resolver.resolve_assets`.

We deliberately keep this as a flat dict rather than a registry of
``Role`` dataclasses: the role taxonomy has ~7 buckets (defined in
:mod:`praestoclaw.utils.role_detector`) and is unlikely to grow much.
A module-level constant is easier to read at a glance than a registry
class.
"""

from __future__ import annotations

#: Marketplaces to recommend for each role bucket. Keys must be drawn
#: from :data:`praestoclaw.utils.role_detector.KNOWN_ROLES`; missing keys
#: simply contribute nothing (which is the intended behaviour for
#: ``unknown`` / ``other`` — we don't second-guess users we couldn't
#: classify).
ROLE_MARKETPLACES: dict[str, tuple[str, ...]] = {
    # Product managers get Kosmos — a curated bundle of PM-shaped skills
    # (specs, market analysis, decision frameworks) shipped as a zip-archive
    # marketplace from gim-home/Kosmos-cdn.
    "pm": ("kosmos-skills",),
    # Designers and user researchers both benefit from the design-oriented
    # marketplaces. We keep them together rather than splitting because
    # the catalogues are small and the audiences overlap heavily.
    "designer": ("design-skills", "studio8research-skills"),
    "research": ("studio8research-skills", "design-skills"),
}


def marketplaces_for_role(role: str | None) -> tuple[str, ...]:
    """Return marketplaces a role implies, or ``()`` for unknown/missing roles."""
    if not role:
        return ()
    return ROLE_MARKETPLACES.get(role.strip().lower(), ())


__all__ = ["ROLE_MARKETPLACES", "marketplaces_for_role"]
