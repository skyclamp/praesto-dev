"""Praesto Tag Experiment — local per-group persistent memory.

Each Teams conversation gets an isolated local folder containing its own
``MEMORY.md``. The conversation id is converted to a stable filesystem-safe
folder name because Teams ids contain characters that are invalid on Windows.
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from loguru import logger


def _slug(value: str) -> str:
    """Return a stable, filesystem-safe folder name for a Teams conversation id."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]", "_", value).strip("_") or "group"
    digest = hashlib.sha1(value.encode("utf-8")).hexdigest()[:8]  # noqa: S324
    return f"{cleaned[:48]}-{digest}"


class PraestoTagExpGroupStore:
    """Local private memory store with one folder per Teams conversation."""

    def __init__(self, *, base_dir: Path) -> None:
        self._base_dir = base_dir
        self._base_dir.mkdir(parents=True, exist_ok=True)

    def group_dir(self, cid: str) -> Path:
        """Return the isolated local directory for ``cid``."""
        if not cid or not cid.strip():
            raise ValueError("cid is required")
        return self._base_dir / _slug(cid.strip())

    def memory_path(self, cid: str) -> Path:
        return self.group_dir(cid) / "MEMORY.md"

    def read_memory(self, cid: str) -> str:
        path = self.memory_path(cid)
        if path.is_file():
            return path.read_text(encoding="utf-8")
        return ""

    def write_memory(self, cid: str, content: str) -> None:
        group_dir = self.group_dir(cid)
        group_dir.mkdir(parents=True, exist_ok=True)

        id_path = group_dir / "GROUP_ID"
        if not id_path.exists():
            id_path.write_text(cid.strip() + "\n", encoding="utf-8")

        path = group_dir / "MEMORY.md"
        if path.is_file():
            existing = path.read_text(encoding="utf-8")
            if existing.strip():
                try:
                    path.with_suffix(".md.bak").write_text(existing, encoding="utf-8")
                except OSError as exc:
                    logger.debug("group memory backup failed for cid={}: {}", cid, exc)

        path.write_text(content, encoding="utf-8")
        logger.debug(
            "group_memory: wrote cid={} bytes={} path={}",
            cid,
            len(content.encode("utf-8")),
            path,
        )
