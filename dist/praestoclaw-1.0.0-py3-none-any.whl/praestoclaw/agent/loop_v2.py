"""AgentLoopV2 — Hermes-style run_conversation agent loop.

Replaces the nanobot-derived v1 loop with Hermes-style iteration budget,
multi-pass compression, intelligent parallel tool execution, and
provider failover — while preserving v1's hooks, approval routing,
slash commands, typing indicators, and audit logging.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import time
import traceback
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from loguru import logger

from praestoclaw.agent.attachments.preprocessor import AttachmentResolver as _AttachmentResolver
from praestoclaw.agent.attachments.preprocessor import (
    has_pending_attachments as _has_pending_attachments,
)
from praestoclaw.agent.budget import GoalTurnResult, IterationBudget, TurnExit
from praestoclaw.agent.compaction import (
    estimate_tokens,
    is_injected_runtime_context,
    strip_injected_context,
)
from praestoclaw.agent.compressor import ContextCompressor
from praestoclaw.agent.loop_detect import LoopDetector
from praestoclaw.agent.parallel import ToolParallelizer
from praestoclaw.agent.prompt_builder import MEMORY_CAP, PromptBuilder
from praestoclaw.agent.prompt_cache import apply_cache_breakpoints
from praestoclaw.agent.task_planning_preflight import (
    TaskPlanningPreflight,
    insert_task_planning_preflight_context,
    render_task_planning_preflight_context,
    run_task_planning_preflight,
    should_run_task_planning_preflight,
)
from praestoclaw.agent.tool_sanitizer import (
    is_provider_safe_tool_name,
    sanitize_tool_messages,
)
from praestoclaw.agent.truncation import truncate_tool_output
from praestoclaw.agent.workflow_protocol import SCANNER_SETUP_COMMAND
from praestoclaw.bus.events import EventType, InboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.channels.reply_dispatcher import ReplyDispatcher
from praestoclaw.config.schema import AgentConfig, ChannelType, ExecutionConfig
from praestoclaw.hooks.manager import (
    HookVerdict,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.host.execution_chains import (
    ExecutionChainCancelledError,
    ExecutionChainQueueFullError,
    ExecutionChainRunner,
    ExecutionChainStoppedError,
    ExecutionLane,
)
from praestoclaw.host.resource_locks import tool_resource_lock
from praestoclaw.providers.base import LLMProvider, LLMResponse, ToolCallRequest
from praestoclaw.providers.failover import CompressNeededError
from praestoclaw.security.audit import sanitize_diagnostic_text
from praestoclaw.security.kb_curation import (
    PRAESTO_KB_CURATION_BUILTIN_TOOLS as _PRAESTO_KB_CURATION_BUILTIN_TOOLS_SET,
)
from praestoclaw.security.kb_curation import (
    kb_curation_is_active as _kb_curation_is_active,
)
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.praesto_tag_exp import (
    PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS as _PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS_SET,
)
from praestoclaw.security.praesto_tag_exp import (
    PRAESTO_TAG_EXP_PERSONAL_TOOLS as _PRAESTO_TAG_EXP_PERSONAL_TOOLS_SET,
)
from praestoclaw.security.praesto_tag_exp import (
    praesto_tag_exp_tool_is_exposed,
)
from praestoclaw.security.sanitizer import Sanitizer
from praestoclaw.utils.helpers import (
    REPLY_QUOTE_SNIPPET_MAX,
    contains_cjk,
    truncate_ellipsis,
)

if TYPE_CHECKING:
    from praestoclaw.host.background_tasks import BackgroundTaskManager, BackgroundTaskSnapshot
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.security.audit import AuditLogger

MeetingContextProvider = Callable[[str, dict[str, Any] | None], str]

_DEFAULT_CONTEXT_LIMIT = 128_000
_MEETING_GOAL_MAX_ITERATIONS = 12
# Floor on a recipe's OWN activation score, applied only AFTER one of its declared
# patterns has already matched — keywords can never route on their own, whatever
# this value is. ``Skill.score`` halves a pattern-only hit (20 -> 10), so 10 means
# "one declared pattern hit is enough". Anything higher silently requires a keyword
# too, which drops phrasings the pattern was written to cover: "修复 societas 的问题"
# hits the pattern but contains no "societas bug" keyword, so it scored 10 and was
# discarded under the previous floor of 20.
_RECIPE_ROUTE_THRESHOLD = 10


def _is_scanner_setup_turn(recipe: str, user_message: str) -> bool:
    """Whether this is the exact fresh-turn scanner onboarding handoff."""
    normalized = " ".join(user_message.strip().split()).casefold()
    return recipe == "fix-societas-bug" and normalized == SCANNER_SETUP_COMMAND


def _recipe_route_block(name: str, user_message: str = "") -> str:
    """Per-turn note that a saved recipe covers this turn's subject.

    Two axes, and only one of them is neutral — conflating them is how an earlier
    version of this docstring overclaimed ("Deliberately NOT imperative", which the
    emitted text was not):

    * **Whether** anything should run — NEUTRAL. Matching is recall-oriented and
      answers only "is this turn about the recipe's subject". The note says so
      explicitly and hands the decision to the model, which reads the whole turn.
    * **How**, GIVEN that the user asked for the work — DIRECTIVE, deliberately.
      "run it with workflow(...) rather than reproducing its steps by hand" is the
      original fix: observed live, the model worked a recipe's steps by hand instead
      of calling the tool. Softening this to bare capability language ("the workflow
      can be used") would reintroduce that bug.

    The safety property that lets matching stay loose is about the FIRST axis only.
    A false subject match costs one tool schema and these lines because the note
    never asserts the user asked for anything — not because it stays silent about
    mechanism. Four rounds of classifying execution intent with regexes each traded
    false-positives for false-negatives, and anchoring the verb to a clause start
    dropped ordinary phrasings like "Could you fix ...?" and "请帮忙修复...", the
    exact failure this routing exists to fix.

    So the invariant is narrower than "not imperative": every execution instruction
    must sit inside a conditional on the user's own words. An UNCONDITIONAL one
    ("prefer running this", "you should run it") would put the burden of intent back
    on the matcher, which cannot carry it.
    ``test_the_injected_note_never_instructs_unconditionally`` enforces exactly that,
    structurally — a banned-phrase list passes for any wording it fails to list.
    """
    normalized = " ".join(user_message.strip().split()).casefold()
    if normalized == SCANNER_SETUP_COMMAND:
        mechanism = (
            "Decide from the user's own words: if the user's exact message is the "
            "scanner setup action, call "
            "workflow(action='setup', name='fix-societas-bug') to recover the "
            "deterministic scanner installation instructions in this fresh turn; "
            "if it is not, do not call it. In that case, do not call run and do not "
            "create a cron from memory."
        )
    elif normalized.startswith("resume workflow "):
        mechanism = (
            "Decide from the user's own words, including any later qualification or "
            "revocation: if they are still asking to resume this workflow, call "
            f"workflow(action='resume', name={name!r}, task_id=<task_id token>, "
            "params={<all other k=v tokens>}). `task_id` is a top-level workflow "
            "argument; bug_id/repo_path and other recipe inputs belong inside params. "
            "In that case, do not replace resume with run; if they are asking about "
            "the command or told you not to act, do not call it."
        )
    elif normalized.startswith("run workflow "):
        mechanism = (
            "Decide from the user's own words, including any later qualification or "
            "revocation: if they are still asking for a fresh run, call "
            f"workflow(action='run', name={name!r}, params={{<all k=v tokens>}}); "
            "if they are asking about the command or told you not to act, do not call it."
        )
    else:
        mechanism = (
            "Decide from the user's own words: if they are asking for this work to be "
            "carried out, run it with "
            f"workflow(action='run', name={name!r}, params={{...}}) rather than "
            "reproducing its steps by hand; if they are asking about it, comparing it, "
            "quoting it, or told you not to act, do not call it."
        )
    return (
        f"[Workflow note] A saved recipe named {name!r} covers this subject, and the "
        "`workflow` tool is callable on this turn. This note means only that the "
        f"subject matched — it is not a request to run anything by itself. {mechanism} "
        "Naming a recipe in "
        "plan(...) only labels the plan; it runs nothing."
    )


_SYSTEM_LANE_SOURCES: frozenset[str] = frozenset(
    {"a2a", "a2a_notify", "a2a_task", "cron", "heartbeat", "scheduler", "u2u_receipt"}
)
_LLM_HISTORY_ROLES = frozenset({"system", "user", "assistant", "tool"})
# Web routes backed by a ONE-SHOT queue that dies the moment its HTTP request
# returns. Mirrors ``_WEB_REQUEST_PREFIXES`` in hooks/handlers.py. A turn on one
# of these cannot be answered after its own request ended, which is what makes
# the approval reply-route handoff necessary (issue #661).
#
# ``local-webchat-*`` (WebSocket) is deliberately absent: that connection keeps a
# long-lived PUSH queue under the same id, so a resumed turn's reply already
# reaches it via send()'s tier 3 and needs no redirect.
_WEB_ONESHOT_ROUTE_PREFIXES = ("web-req-", "web-sse-")

# Exact phrases (after strip/lower/trailing-punctuation) that count as a
# "how's it going?" status check. Matched exactly — NOT as substrings — so a
# real question like "天气怎么样" is never swallowed. Only consulted while a turn
# is already running on the session lane.
_STATUS_QUERY_PHRASES: frozenset[str] = frozenset(
    {
        # zh
        "进度",
        "进度呢",
        "进度如何",
        "进度怎么样",
        "进展如何",
        "有进展吗",
        "有进度吗",
        "怎么样了",
        "怎样了",
        "好了吗",
        "好了没",
        "完成了吗",
        "完成了没",
        "跑完了吗",
        "还在吗",
        "还在跑吗",
        "到哪了",
        "到哪步了",
        "查到没",
        "查到了吗",
        # en
        "status",
        "progress",
        "any update",
        "any progress",
        "any news",
        "done yet",
        "are you done",
        "how's it going",
        "how is it going",
        "still there",
    }
)
_EMPTY_FINAL_RESPONSE_PROMPT = (
    "Your previous response contained no user-visible content. Do not end the turn "
    "silently. Continue the task if work remains; otherwise provide a concise final "
    "status for the user."
)
_EMPTY_FINAL_RESPONSE_FALLBACK = (
    "I couldn't produce a final response before this turn ended. The task may be "
    "incomplete; please ask me to continue if you want me to keep working."
)
# Sentinel returned from ``_drive_turn`` when the turn was promoted to a
# detached worker session. The caller surfaces it as the carrier-visible
# receipt: a placeholder string is emitted into the channel reply path (see
# ``_render_promoted_receipt`` below), but the row is NEVER persisted into
# the main session (D-receipt — the eventual fold-back is the sole assistant
# answer to the user's question in durable history).
_PROMOTED_RECEIPT = "__event_loop_promoted__"
# Receipt copy delivered to the carrier when a turn is promoted to a worker.
# UX contract (matches the IM mental model):
#   1. Make the handoff explicit — "moved to background", not "still working".
#      The latter sounds like the assistant is locked up; the former tells the
#      user the work is queued and they're free to do anything.
#   2. Invite continued chat — say "we can chat about anything else". Without
#      this, users default to "代理在忙，先别打扰" and stop using the channel
#      until they see a fold-back.
#   3. Promise proactive delivery — "I'll send the result here when it's done".
# The text is **not** persisted to durable history (D-receipt). The
# orphan-prevention ack row (``[BG task=…]``, see
# ``_PROMOTION_ACK_TEMPLATE_*`` below) is a separate, machine-readable line
# for the LLM; this string is for the human reading the chat window.
_PROMOTED_RECEIPT_ZH = "📥 这个任务我放到后台跑了，结果会发到这里来。我们可以接着聊别的，不耽误你。"
_PROMOTED_RECEIPT_EN = (
    "📥 Got it — I've moved this to the background. I'll post the result here "
    "when it's done; feel free to keep chatting about anything else in the meantime."
)
# Terse one-liner used when ``ExecutionConfig.background_task_receipt ==
# "minimal"`` — enough to signal the handoff to power users who already know
# the pattern, without the full educational copy on every promotion.
_PROMOTED_RECEIPT_MINIMAL_ZH = "⏳ 后台处理中…"
_PROMOTED_RECEIPT_MINIMAL_EN = "⏳ Working on it in the background…"
# Adaptive ramp (when ``background_task_receipt == "adaptive"``): the first
# ``_ADAPTIVE_FULL_LIMIT`` promotions a user sees
# render the full educational copy; the next batch up to
# ``_ADAPTIVE_MINIMAL_LIMIT`` (cumulative) render the minimal one-liner; every
# promotion after that is silent. The per-user count is durable (SessionStore
# ``counters`` table) so the ramp survives restarts.
_ADAPTIVE_FULL_LIMIT = 3
_ADAPTIVE_MINIMAL_LIMIT = 6

# ── Promotion ack-row sentinel (Plan A: orphan-prevention) ───────────────────
# When ``_promote_turn_to_worker`` finishes prune+adopt it appends ONE
# ``role=assistant`` row to the main session whose content begins with this
# sentinel. The sentinel is a stable, machine-readable marker meaning
# "this user request was handed off to a background worker — do not continue
# it on the next turn". The line is read by:
#   • the LLM (via system-prompt rule in defaults/AGENTS.md) — orphan-prevention
#   • the compactor (``_persist_compacted``) — preserves task=… reference
#   • a future startup reaper — finds active acks whose tasks died at restart
# Format: ``[BG task=<task_id>] <localized one-line ack>\n[Q] <snippet>``
# The sentinel itself MUST stay literal so a simple ``startswith`` (and the
# regex ``\[BG task=([0-9a-f]{6,})\]``) can identify the row anywhere it is
# read — durable history, in-memory prompt, compaction summary input.
_PROMOTION_ACK_SENTINEL_PREFIX = "[BG task="
_PROMOTION_ACK_TEMPLATE_ZH = (
    "{sentinel}{task_id}] 已收到，正在后台处理；完成后会自动以 ↩️ 形式回到这里。\n[Q] {snippet}"
)
_PROMOTION_ACK_TEMPLATE_EN = (
    "{sentinel}{task_id}] Acknowledged — handed off to a background worker; "
    "I'll post the answer back here as a ↩️ quote when it finishes.\n[Q] {snippet}"
)


# Inverse of ``_build_promotion_ack_row``: extract ``(task_id, question_snippet)``
# from a persisted ack row's content. Used by the startup reaper
# (``BackgroundTaskManager.reap_orphan_acks``) to recover the bookkeeping it
# needs to write a ``(failed: lost-on-restart) [Re: …]`` replacement when a
# worker died with the previous process. The pattern matches both zh and en
# templates because everything between ``[BG task=…]`` and ``\n[Q] …`` is
# fixed copy that we can match non-greedily.
_PROMOTION_ACK_PARSE_RE = re.compile(
    r"^\[BG task=([0-9a-f]+)\][^\n]*\n\[Q\] (.*)$",
    re.DOTALL,
)

_TRUEISH = frozenset({"1", "true", "yes", "on"})

# praesto tag exp: friendly labels for the Teams conversation types the bridge
# reports (``metadata.ctype``), used to describe the current group/meeting in the
# injected session-context block. Unknown values fall through verbatim.
_PRAESTO_TAG_EXP_CHAT_TYPE_LABELS: dict[str, str] = {
    "groupchat": "group chat",
    "channel": "channel",
    "meeting": "meeting",
    "personal": "direct message",
}

# Personal-memory tools removed from a praesto tag exp borrowed-identity group
# turn: the shared employee must persist facts via ``group_memory`` (the group's
# isolated local store), never the lending employee's private MEMORY.md/history.
# Canonical set lives in security.praesto_tag_exp so the ``tools`` meta-tool
# shares it (aliased at import as ``_PRAESTO_TAG_EXP_PERSONAL_TOOLS_SET``).
_PRAESTO_TAG_EXP_PERSONAL_TOOLS: tuple[str, ...] = tuple(
    sorted(_PRAESTO_TAG_EXP_PERSONAL_TOOLS_SET)
)


def _augment_exclude_for_praesto_tag_exp(
    exclude_tools: list[str] | None, *, active: bool
) -> list[str] | None:
    """Add the personal-memory tools to ``exclude_tools`` when ``active``.

    Returns ``exclude_tools`` unchanged for a normal turn; for a group turn it
    returns a new list with ``memory`` and ``search_history`` appended (deduped).
    """
    if not active:
        return exclude_tools
    merged = list(exclude_tools or [])
    for name in _PRAESTO_TAG_EXP_PERSONAL_TOOLS:
        if name not in merged:
            merged.append(name)
    return merged


def _clear_group_skill_turn_capabilities(metadata: dict[str, Any] | None, *, active: bool) -> None:
    """Discard caller-provided Group Skill capabilities before local matching."""
    if not active or metadata is None:
        return
    for key in (
        "group_skill_names",
        "group_skill_hashes",
        "group_skill_safe_tools",
        "group_mcp_tool_names",
    ):
        metadata.pop(key, None)


def _praesto_tag_exp_excluded_registered_tools(
    tool_registry: Any, group_mcp_tool_names: list[str] | None = None
) -> tuple[str, ...]:
    """Return registered tools that must not guide a borrowed group turn."""
    return tuple(
        sorted(
            tool.name
            for tool in tool_registry.list_tools_sorted()
            if not praesto_tag_exp_tool_is_exposed(
                tool.name, group_mcp_tool_names=group_mcp_tool_names
            )
        )
    )


def _emit_tool_invoked(
    tool_name: str,
    duration_ms: int,
    success: bool,
    blocked_by: str | None = None,
    turn_id: str | None = None,
    session_id: str | None = None,
) -> None:
    """Fire-and-forget telemetry. Defensive — never raises into the agent loop."""
    try:
        from praesto_telemetry import Events, emit

        props: dict[str, object] = {
            "tool_name": tool_name,
            "duration_ms": duration_ms,
            "success": success,
        }
        if blocked_by:
            props["blocked_by"] = blocked_by
        if turn_id:
            props["turn_id"] = turn_id
        if session_id:
            props["session_id"] = session_id
        emit(Events.TOOL_INVOKED, **props)
    except Exception:  # pragma: no cover - telemetry must never break the host
        pass


def _is_tool_error_result(result: str | None) -> bool:
    """Return True for both direct tool errors and registry-wrapped failures."""
    return isinstance(result, str) and result.startswith(("Error:", "Error executing "))


def parse_promotion_ack(content: str) -> tuple[str, str] | None:
    """Parse a persisted ack row's ``content`` into ``(task_id, snippet)``.

    Returns ``None`` if *content* is not a well-formed ack row (does not
    begin with the sentinel, missing the ``[Q] …`` tail, or task_id contains
    non-hex). Designed to be defensive: a malformed row in the wild should
    be skipped, not raise.
    """
    if not isinstance(content, str) or not content.startswith(_PROMOTION_ACK_SENTINEL_PREFIX):
        return None
    match = _PROMOTION_ACK_PARSE_RE.match(content)
    if match is None:
        return None
    return match.group(1), match.group(2)


@dataclass(frozen=True)
class OwnerSessionTarget:
    """Pointer to the owner's most recent human, interactive session.

    Captured on every human MAIN-lane turn so receiver-side a2a handling can
    persist an informational context note into the session the owner is
    actually sitting in (e.g. their Teams chat), enabling a later human
    confirmation to be understood and relayed back to the remote sender.
    """

    session_key: str
    channel: str
    sender_id: str
    # Normalized user-facing surface (e.g. "teams", "cloud_tui", "webchat").
    # Lets receiver-side a2a inject context into the SAME surface the owner's
    # heads-up notification targets, rather than whichever surface the owner
    # happened to type in most recently across all of them.
    surface: str = ""


@dataclass
class _TurnState:
    """Mutable per-turn state shared between ``_begin_turn`` and ``_drive_turn``.

    The event-loop refactor (see ``docs/design/core/event-loop/02-architecture.md``
    §2.2) splits the legacy monolithic ``_run_conversation_impl`` into a setup
    phase (``_begin_turn``) and a re-entrant loop phase (``_drive_turn``). They
    share *everything* the loop needs through this object, so ``_drive_turn``
    can be re-entered against any ``session_id`` (the future promotion path
    swaps ``state.session_id`` to a worker session) without re-plumbing every
    callsite.

    ``turn_rowids`` accumulates the rowid of every assistant / tool message
    persisted **inside** the loop body. The user row is captured separately as
    ``user_rowid`` because it is already written by ``_begin_turn`` and the
    promotion step keeps the user row on the main session while pruning only
    the in-flight tool pairs.
    """

    messages: list[dict[str, Any]]
    session_id: str
    # Canonical session that owns the visible plan card. Promotion swaps
    # ``session_id`` to a worker, but plan updates must keep targeting the
    # originating conversation's plan so the Teams card updates in place.
    plan_session_id: str
    budget: IterationBudget
    loop_detector: LoopDetector
    tool_batches: int = 0
    turn_rowids: list[int] = field(default_factory=list)
    user_rowid: int | None = None
    channel: Any = None
    channel_id: str | None = None
    thread_id: str | None = None
    route_hint: str | None = None
    user_message: str = ""
    metadata: dict[str, Any] | None = None
    exclude_tools: list[str] | None = None
    # Tools exposed for THIS turn only, without activating them in the shared
    # registry (``activate()`` would leak the schema into every later turn and
    # into concurrent sessions). Set when a first-turn recipe match wants the
    # ``workflow`` schema callable right away.
    include_inactive_tools: list[str] = field(default_factory=list)
    streamed: bool = False
    # Set by the future promotion step (D) so a re-entered ``_drive_turn``
    # against a worker session does not promote again. Safe to default off.
    promoted: bool = False
    # Carrier-visible receipt resolved at promotion time (before the worker is
    # adopted) so the only awaits on the promotion path happen pre-adopt — this
    # keeps ``_run_conversation``'s return synchronous w.r.t. worker scheduling.
    # Empty for non-promoted turns and for ``silent`` mode.
    promoted_receipt: str = ""
    # Monotonic wall-clock when ``_begin_turn`` finished assembling this state.
    # Read by the event-loop ``T-time`` trigger ("promote after N seconds of
    # elapsed turn time"). ``time.monotonic`` because it never goes backwards
    # under NTP / DST adjustments. ``None`` for legacy paths that never set it.
    started_monotonic: float | None = None
    exit: TurnExit = TurnExit.MODEL_FINISHED
    iterations_used: int = 0
    tool_successes: int = 0
    tool_failures: int = 0
    last_tool_name: str | None = None
    last_tool_succeeded: bool | None = None


class AgentLoopV2:
    """Hermes-style agent loop with streaming, parallel tools, and loop detection.

    Supports all v1 capabilities: hooks, approval routing, slash commands,
    typing indicators, audit logging.
    """

    def __init__(
        self,
        *,
        config: AgentConfig,
        provider: LLMProvider,
        tool_registry: Any,
        bus: MessageBus,
        session_store: Any,
        workspace: Path,
        audit: Any = None,
        hooks: Any = None,
        available_agents: dict[str, Any] | None = None,
        prompt_mode: Literal["full", "subagent", "minimal"] = "full",
        skill_loader: Any = None,
        group_skill_loader: Any = None,
        recipes_provider: Any = None,
        skills_config: Any = None,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        mcp_configs: Any = None,
        memory: Any = None,
        execution_runner: ExecutionChainRunner | None = None,
        execution_config: ExecutionConfig | None = None,
    ) -> None:
        self._config = config
        self._provider = provider
        self._tool_registry = tool_registry
        self._bus = bus
        self._session_store = session_store
        self._workspace = workspace
        self._audit: AuditLogger | None = audit
        self._hooks = hooks
        self._available_agents = available_agents or {}
        self._prompt_mode = prompt_mode
        self._skill_loader = skill_loader
        self._group_skill_loader = group_skill_loader
        # Callable() -> {name: recipe} for workflow recipes. Used only to decide
        # whether a turn should get the ``workflow`` schema up front; never to
        # run anything. None = first-turn recipe routing stays off.
        self._recipes_provider = recipes_provider
        self._skills_config = skills_config
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._mcp_configs = mcp_configs
        self._memory = memory
        self._flow_trace_enabled = (
            str(os.getenv("PRAESTO_TRACE_FLOW", "")).strip().lower() in _TRUEISH
        )
        # praesto tag exp: local per-group memory store, wired post-init
        # via set_praesto_tag_exp_group_store. None when the experiment is off.
        self._praesto_tag_exp_group_store: Any = None
        self._meeting_context_provider: MeetingContextProvider | None = None
        self._group_mcp_service: Any = None
        self._running = False
        exec_cfg = execution_config or ExecutionConfig()
        self._execution_runner = execution_runner or ExecutionChainRunner(
            main_max_concurrent=exec_cfg.main_max_concurrent,
            system_max_concurrent=exec_cfg.system_max_concurrent,
            subagent_max_concurrent=exec_cfg.subagent_max_concurrent,
            pending_per_session=exec_cfg.pending_per_session,
        )
        # Event-loop execution model knobs (see ``docs/design/core/event-loop/``).
        # Promotion fires at the post-persist tool-batch boundary on Teams
        # sources (``event_loop_promotion_channels``). The legacy ``Plan C``
        # carrier-detach path was removed once the event-loop model became the
        # only execution model — keeping both gated by a runtime flag created
        # an unreachable / silently-broken kill-switch.
        self._main_turn_tool_budget = exec_cfg.main_turn_tool_budget
        self._wall_clock_promote_s = exec_cfg.wall_clock_promote_s
        self._event_loop_promotion_channels = frozenset(exec_cfg.event_loop_promotion_channels)
        # Verbosity of the synchronous promotion receipt: full | minimal |
        # silent (see ``ExecutionConfig.background_task_receipt`` and
        # ``_render_promoted_receipt``). Only governs the human-visible
        # handoff message; the ack row and fold-back are mode-independent.
        self._background_task_receipt = exec_cfg.background_task_receipt
        # Channel_ids (== carrier request_id) whose current turn emitted a
        # promotion receipt. Recorded at promotion time and consulted (then
        # discarded) at the publish boundary to set ``is_promotion_receipt``
        # WITHOUT depending on the receipt's exact text — minimal/silent
        # receipts would otherwise fail a string-equality match and lose the
        # flag that protects the fold-back's stash + Teams route.
        self._promotion_receipt_routes: set[str] = set()
        # Injected by the runtime after ``BackgroundTaskManager`` is built
        # (circular wiring: the agent needs the manager for promotion, the
        # manager needs the agent's spawn function for ``start``). Optional —
        # ``None`` means promotion always degrades inline.
        self._bg_task_manager: BackgroundTaskManager | None = None
        # Resolver from ``ChannelType`` to the actual channel instance.
        # ``_TurnState.channel`` carries the enum (it's all the agent loop
        # itself needs); promotion-time stash/quote bookkeeping needs the
        # real instance to call methods like ``_remember_timeout_quote``.
        # Injected by the runtime as ``channel_manager.get``; falls back to
        # ``None`` in CLI / unit-test setups (stash silently no-ops then).
        self._channel_resolver: Callable[[ChannelType], Any] | None = None
        self._turn_tasks: set[asyncio.Task[None]] = set()
        self._pending_turn_interrupts: dict[tuple[str, str], str] = {}
        self._reply_dispatcher = ReplyDispatcher(bus)
        # Last human, interactive (MAIN-lane) session — the surface the owner
        # is actually sitting in. Used by receiver-side a2a handling to inject
        # context so a later confirmation can be relayed. See OwnerSessionTarget.
        self._last_owner_session: OwnerSessionTarget | None = None
        # Same as above, but keyed by user-facing surface so the injector can
        # pick the owner's latest *teams* session even when their most recent
        # turn overall was on another surface (e.g. cloud_tui).
        self._owner_sessions_by_surface: dict[str, OwnerSessionTarget] = {}

        # Sub-components
        self._prompt_builder = PromptBuilder(
            config,
            workspace,
            tool_registry=tool_registry,
            available_agents=self._available_agents,
            mcp_configs=mcp_configs,
            memory=memory,
            skill_loader=skill_loader,
            skills_config=skills_config,
        )
        # Learning loop counters (Hermes-style)
        self._turns_since_memory = 0
        self._memory_nudge_interval = config.memory_nudge_interval or 10
        self._compressor = ContextCompressor(
            provider,
            protect_first_n=config.compaction_v2.protect_first_n,
            protect_last_n=config.compaction_v2.protect_last_n,
            post_threshold=config.compaction_v2.post_threshold,
            pre_threshold=config.compaction_v2.pre_threshold,
            anti_thrashing_min_savings=config.compaction_v2.anti_thrashing_min_savings,
        )
        self._parallelizer = ToolParallelizer()

    def _flow_trace(self, event: str, **fields: Any) -> None:
        """Emit one structured full-process trace line when enabled."""
        if not self._flow_trace_enabled:
            return
        safe_fields: dict[str, Any] = {}
        for key, value in fields.items():
            if isinstance(value, str):
                safe_fields[key] = truncate_ellipsis(
                    redact_credentials(value).replace("\n", "\\n"),
                    240,
                )
            else:
                safe_fields[key] = value
        logger.info("flow_trace.{} {}", event, safe_fields)

    # ── Public API ───────────────────────────────────────────────────────

    async def start(self) -> None:
        """Consume inbound messages from the bus."""
        self._running = True
        logger.info("AgentLoopV2 started: {}", self._config.name)

        try:
            while self._running:
                try:
                    msg = await asyncio.wait_for(self._bus.get_inbound(), timeout=1.0)
                except asyncio.CancelledError:
                    break
                except TimeoutError:
                    continue
                await self._schedule_inbound(msg)
        finally:
            await self._execution_runner.stop()
            await self._await_turn_tasks(cancel=True)

    async def stop(self) -> None:
        """Signal the loop to stop."""
        self._running = False
        await self._execution_runner.stop()
        await self._await_turn_tasks(cancel=True)

    def interrupt(self) -> None:
        """Interrupt every active execution chain without stopping the loop."""
        self._execution_runner.interrupt_all("agent loop interrupt requested")

    def interrupt_session(
        self,
        session_key: str,
        reason: str = "agent loop interrupt",
        *,
        turn_id: str | None = None,
    ) -> bool:
        """Interrupt one execution-chain session."""
        interrupted = self._execution_runner.interrupt(session_key, reason)
        if interrupted:
            return True
        if turn_id:
            self._pending_turn_interrupts[(session_key, turn_id)] = reason
            return True
        return False

    @property
    def execution_runner(self) -> ExecutionChainRunner:
        return self._execution_runner

    def set_praesto_tag_exp_group_store(self, store: Any) -> None:
        """Wire the praesto tag exp local group memory store."""
        self._praesto_tag_exp_group_store = store

    def set_meeting_context_provider(self, provider: MeetingContextProvider | None) -> None:
        self._meeting_context_provider = provider

    def set_group_mcp_service(self, service: Any) -> None:
        self._group_mcp_service = service

    def _praesto_tag_exp_memory_section(self, metadata: dict[str, Any] | None) -> str:
        """Build the current group's persistent-memory system-prompt section.

        Like personal MEMORY.md, the entire file is injected on every turn
        (capped to the same size). Best-effort: never raises into the turn.
        """
        store = self._praesto_tag_exp_group_store
        if store is None or not metadata or not metadata.get("praesto_tag_exp"):
            return ""
        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return ""
        try:
            memory = store.read_memory(cid).strip()
        except Exception as exc:  # noqa: BLE001 — memory must never break the turn.
            logger.debug("praesto_tag_exp group memory read failed: {}", exc)
            return ""
        if not memory:
            return ""
        logger.debug(
            "praesto_tag_exp group memory injected: cid={} chars={}",
            cid,
            len(memory),
        )
        return f"## Group Memory\n\n{memory[:MEMORY_CAP]}"

    @staticmethod
    def _praesto_tag_exp_session_context_block(
        metadata: dict[str, Any] | None,
        meeting_context_provider: MeetingContextProvider | None = None,
    ) -> str:
        """Build a minimal session-context header for a praesto tag exp group turn.

        Orients the borrowed-identity shared employee with the current Teams
        group/meeting it is speaking in: chat type, title, conversation id, and
        who authored the current message. Returns "" for non-experiment turns.
        Best-effort: never raises into the turn.
        """
        if not metadata or not metadata.get("praesto_tag_exp"):
            return ""
        ctype = str(metadata.get("ctype") or metadata.get("teams_conversation_type") or "").strip()
        chat_type = _PRAESTO_TAG_EXP_CHAT_TYPE_LABELS.get(ctype.lower(), ctype) or "group chat"
        title = str(metadata.get("conversation_name") or "").strip()
        cid = str(metadata.get("cid") or "").strip()
        speaker = str(metadata.get("sender_name") or "").strip()
        bot_name = str(metadata.get("bot_display_name") or "").strip()

        lines = [f"- Chat type: {chat_type}"]
        if bot_name:
            lines.append(
                f"- Your identity: you are @[{bot_name}], this chat's shared "
                f"digital employee. Messages here are addressed to you (your own "
                f"@mention is stripped out before you see it); any @[name] that "
                f"remains refers to someone else, never you."
            )
        if title:
            lines.append(f"- Title: {title}")
        if cid and meeting_context_provider is not None:
            pending = meeting_context_provider(cid, metadata)
            if pending:
                lines.append(pending)
        if cid:
            lines.append(f"- Conversation id: {cid}")
        if speaker:
            lines.append(f"- Speaker (author of this message): {speaker}")
        # Point at the group's own local store as the natural place to persist, and
        # disclaim personal memory so the model doesn't fall back to reading/writing
        # MEMORY.md via read_file. The group_memory tool description already mirrors
        # the personal ``memory`` tool, so this stays informational — not a forced
        # "you must call it" imperative.
        lines.append(
            "- This group has its own persistent memory: call the group_memory "
            "tool DIRECTLY as a function — group_memory(action='add', "
            "content='…') to save a durable fact; use action='replace' or "
            "action='remove' to edit it. Do NOT route it through the tools() "
            "meta-tool. The group's MEMORY.md is auto-injected each turn."
        )
        lines.append(
            "- There is no personal MEMORY.md/USER.md or personal `memory` tool in "
            "this shared session; don't try to read or write personal memory files "
            "(e.g. via read_file/shell)."
        )
        lines.append(
            "- When the user asks you to mention a person, tag, or everyone, you MUST "
            "send that message with group_notify. Writing @Name or @[Name] only in "
            "your final response does not create a native Teams mention. After the "
            "tool call, give only a brief confirmation; do not repeat the sent message."
        )
        return (
            "[Session context — you are this Teams conversation's shared digital "
            "employee; the details below describe the current group/meeting]\n" + "\n".join(lines)
        )

    @staticmethod
    def _teams_group_notify_guidance_block(metadata: dict[str, Any] | None) -> str:
        """Tell ordinary Teams group turns how to create a native mention."""
        if not metadata or metadata.get("praesto_tag_exp"):
            return ""
        ctype = str(metadata.get("ctype") or metadata.get("teams_conversation_type") or "").lower()
        if ctype not in {"groupchat", "channel"}:
            return ""
        return (
            "[Teams group guidance]\n"
            "- When the user asks you to mention a person, tag, or everyone, you MUST "
            "send that message with group_notify. Writing @Name or @[Name] only in "
            "your final response does not create a native Teams mention. After the "
            "tool call, give only a brief confirmation; do not repeat the sent message."
        )

    def set_background_task_manager(self, manager: BackgroundTaskManager | None) -> None:
        """Wire the runtime's :class:`BackgroundTaskManager` after construction.

        ``AgentLoopV2`` and ``BackgroundTaskManager`` have a circular dependency
        (the agent needs the manager to adopt promotions; the manager needs the
        agent's spawn function to start sub-agents), so the runtime instantiates
        the agent first, then the manager, then injects the manager here.
        Calling with ``None`` disables event-loop promotion (it will always
        degrade inline) — useful in tests that exercise the legacy path.
        """
        self._bg_task_manager = manager

    def set_channel_resolver(self, resolver: Callable[[ChannelType], Any] | None) -> None:
        """Inject a ``ChannelType -> Channel | None`` resolver.

        Promotion needs the actual channel instance (not just the enum) to call
        ``_remember_timeout_quote`` for the ↩️ late-reply quote path. The
        runtime wires this with ``channel_manager.get`` immediately after
        ``self.channel_manager`` and the agent are both built. ``None``
        disables the lookup (CLI / unit-test setups), in which case the stash
        silently no-ops and the ↩️ envelope is skipped (acceptable for those
        environments — they don't have a Teams carrier to attribute back to).
        """
        self._channel_resolver = resolver

    async def _schedule_inbound(self, msg: InboundMessage) -> None:
        session_key = self._resolve_agent_session_key(msg)
        if await self._try_route_approval(msg):
            return

        inline_active = self._execution_runner.has_session_work(session_key)
        worker_snaps = self._list_workers_for_session(session_key)
        any_active = inline_active or bool(worker_snaps)

        # Interrupt fast-path: a ``/stop <id>`` targets a single worker; the
        # bare interrupt phrases cancel all of this conversation's work
        # (inline turn + every promoted worker).
        single_target = self._parse_stop_target(msg.content)
        if single_target is not None:
            await self._handle_single_worker_stop(msg, session_key, single_target)
            return
        if self._is_interrupt_metadata(msg.metadata) or self._is_interrupt_command(
            msg.content, active=any_active
        ):
            cancelled_workers = self._cancel_workers_for_session(session_key)
            if inline_active:
                self._execution_runner.interrupt(session_key, "user interrupt command")
            await self._publish_interrupt_command_ack(
                msg, active=any_active or cancelled_workers > 0
            )
            return

        # Status fast-path: while ANY work for this session is in flight
        # (inline turn OR promoted workers), a "how's it going?" check must
        # be answered from state (a canned ack) rather than enqueued behind
        # the very work it asks about — otherwise it would wait for that
        # work to finish (same serial lane) and could itself trigger another
        # auto-detach. Tight exact-phrase match so real questions
        # (e.g. "天气怎么样") still reach the agent.
        if any_active and self._is_status_query(msg.content):
            await self._publish_status_ack(msg, snapshot=worker_snaps)
            return

        turn_id = msg.turn_id or msg.delivery_route_id or session_key
        pending_interrupt = self._pending_turn_interrupts.pop((session_key, turn_id), None)
        if pending_interrupt:
            logger.info(
                "Dropping inbound turn cancelled before registration session={} turn_id={} reason={}",
                session_key,
                turn_id,
                pending_interrupt,
            )
            return

        task = asyncio.create_task(
            self._run_message_via_chain(msg, session_key=session_key),
            name=f"agent-chain-submit:{msg.turn_id or msg.delivery_route_id or session_key}",
        )
        self._turn_tasks.add(task)
        task.add_done_callback(self._on_turn_task_done)
        await asyncio.sleep(0)

    async def enqueue_inbound(
        self,
        msg: InboundMessage,
        *,
        deliver: bool,
        forked_child: bool = False,
    ) -> asyncio.Future[str]:
        """Put a trusted host turn directly onto the canonical session queue.

        The returned future is created only after the item is synchronously
        appended to ``ExecutionChainRunner``. Delivery callers may return after
        obtaining the handle; synchronous callers await the same handle.
        """
        session_key = self._resolve_agent_session_key(msg)
        turn_id = msg.turn_id or msg.delivery_route_id or session_key

        if deliver:
            if await self._try_route_approval(msg):
                return self._completed_turn("")
            inline_active = self._execution_runner.has_session_work(session_key)
            worker_snaps = self._list_workers_for_session(session_key)
            any_active = inline_active or bool(worker_snaps)
            single_target = self._parse_stop_target(msg.content)
            if single_target is not None:
                await self._handle_single_worker_stop(msg, session_key, single_target)
                return self._completed_turn("")
            if self._is_interrupt_metadata(msg.metadata) or self._is_interrupt_command(
                msg.content, active=any_active
            ):
                cancelled_workers = self._cancel_workers_for_session(session_key)
                if inline_active:
                    self._execution_runner.interrupt(session_key, "user interrupt command")
                await self._publish_interrupt_command_ack(
                    msg, active=any_active or cancelled_workers > 0
                )
                return self._completed_turn("")
            if any_active and self._is_status_query(msg.content):
                await self._publish_status_ack(msg, snapshot=worker_snaps)
                return self._completed_turn("")

        pending_interrupt = self._pending_turn_interrupts.pop((session_key, turn_id), None)
        if pending_interrupt:
            logger.info(
                "Dropping inbound turn cancelled before registration session={} turn_id={} reason={}",
                session_key,
                turn_id,
                pending_interrupt,
            )
            return self._completed_turn("")

        if deliver:

            async def execute() -> str:
                return await self._run_message_task(msg)
        else:
            metadata = self._conversation_metadata_for_message(msg)
            raw_exclude = metadata.get("exclude_tools")
            exclude_tools = (
                [str(tool) for tool in raw_exclude if isinstance(tool, str)]
                if isinstance(raw_exclude, list)
                else None
            )

            async def execute() -> str:
                return await self._run_once_unqueued(
                    msg.content,
                    session_id=session_key,
                    # Set only by the adapter the runtime builds for an isolated
                    # sub-agent. Return-only is not evidence of one on its own:
                    # the root runtime and the cron service use this same path
                    # and state their own bindings.
                    _forked_child=forked_child,
                    channel=ChannelType.of(msg.logical_channel),
                    channel_id=msg.delivery_route_id,
                    thread_id=str(metadata.get("thread_id") or "")
                    or msg.conversation_id
                    or msg.delivery_route_id,
                    metadata=metadata,
                    exclude_tools=exclude_tools,
                )

        return self._execution_runner.submit(
            session_key=session_key,
            turn_id=turn_id,
            lane=self._lane_for_message(msg),
            execute=execute,
        )

    @staticmethod
    def _completed_turn(content: str) -> asyncio.Future[str]:
        future: asyncio.Future[str] = asyncio.get_running_loop().create_future()
        future.set_result(content)
        return future

    def _list_workers_for_session(self, session_key: str) -> list[BackgroundTaskSnapshot]:
        """Snapshot active workers owned by *session_key* (empty when manager absent).

        Wraps the registry call so callers don't have to guard
        ``self._bg_task_manager is None`` themselves and so future managers
        with cheaper-than-O(n) lookups can be slotted in without touching the
        schedule path.
        """
        manager = self._bg_task_manager
        if manager is None:
            return []
        return manager.list_for_owner(session_key)

    def _cancel_workers_for_session(self, session_key: str) -> int:
        """Cancel every promoted worker owned by *session_key*.

        Returns 0 when no manager is wired (legacy / tests that exercise the
        non-event-loop path) so the caller can still surface the correct
        "no active task" ack.
        """
        manager = self._bg_task_manager
        if manager is None:
            return 0
        return manager.cancel_by_owner(session_key)

    async def _handle_single_worker_stop(
        self,
        msg: InboundMessage,
        session_key: str,
        target_task_id: str,
    ) -> None:
        """Cancel one promoted worker by id; leave inline turn / other workers alone.

        Uses :meth:`BackgroundTaskManager.cancel` with the originating session
        as ``owner`` so a foreign conversation cannot reach across and stop
        another user's task. The ack copy echoes the result string the
        manager returns (already localized to "Unknown task X." / "Task X
        already finished." / "Cancellation requested for task X.") so the
        user knows whether the id matched something they own.
        """
        manager = self._bg_task_manager
        if manager is None:
            await self._publish_reply_for_inbound(msg, f"Unknown task {target_task_id}.")
            return
        ack = await manager.cancel(target_task_id, owner=session_key)
        await self._publish_reply_for_inbound(msg, ack)

    def _on_turn_task_done(self, task: asyncio.Task[None]) -> None:
        self._turn_tasks.discard(task)
        try:
            exc = task.exception()
        except asyncio.CancelledError:
            return
        if exc is not None:
            logger.opt(exception=exc).error("Agent scheduled turn failed")

    async def _await_turn_tasks(self, *, cancel: bool) -> None:
        current = asyncio.current_task()
        tasks = [task for task in self._turn_tasks if task is not current and not task.done()]
        if cancel:
            for task in tasks:
                task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _run_message_via_chain(self, msg: InboundMessage, *, session_key: str) -> None:
        try:
            await self._execution_runner.run(
                session_key=session_key,
                turn_id=msg.turn_id or msg.delivery_route_id or session_key,
                lane=self._lane_for_message(msg),
                execute=lambda: self._run_message_task(msg),
            )
        except ExecutionChainQueueFullError:
            await self._publish_queue_full(msg)
        except ExecutionChainCancelledError:
            logger.info("Queued agent turn cancelled session={}", session_key)
            await self._publish_interrupted(msg)
        except ExecutionChainStoppedError:
            logger.debug("Dropped inbound because execution runner is stopping")
        except asyncio.CancelledError:
            logger.info("Agent chain submit task cancelled session={}", session_key)
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)

    async def _run_message_task(self, msg: InboundMessage) -> str:
        try:
            return await self._process_message(msg)
        except asyncio.CancelledError:
            await self._publish_interrupted(msg)
            raise
        except Exception as exc:  # noqa: BLE001 — keep loop alive
            logger.error("Agent loop error: {}", exc)
            return ""

    @staticmethod
    def _is_interrupt_command(content: str, *, active: bool) -> bool:
        text = content.strip().lower()
        slash_commands = {"/stop", "/cancel", "/interrupt"}
        if text in slash_commands:
            return True
        if not active:
            return False
        # ``停`` is the bare-verb form used in the event-loop interrupt spec
        # (see 04-runtime-behavior.md §4.3 + 06-test-plan.md T13). It is
        # safe to include because this branch only fires while work is
        # actually in flight — no risk of intercepting a casual "停" in a
        # back-and-forth conversation.
        return text in {
            "stop",
            "cancel",
            "interrupt",
            "停",
            "停止",
            "取消",
            "打断",
            "停一下",
            "先停",
        }

    @staticmethod
    def _is_interrupt_metadata(metadata: dict[str, Any] | None) -> bool:
        if not metadata:
            return False
        value = metadata.get("interrupt")
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {
                "1",
                "true",
                "yes",
                "y",
                "stop",
                "cancel",
                "interrupt",
            }
        return False

    async def _publish_reply_for_inbound(self, msg: InboundMessage, content: str) -> None:
        await self._reply_dispatcher.publish_final(
            channel=ChannelType.of(msg.logical_channel),
            channel_id=msg.delivery_route_id,
            content=content,
            thread_id=msg.conversation_id or msg.delivery_route_id,
            route_hint=msg.route_hint,
            dedupe=False,
        )

    async def _publish_interrupt_command_ack(self, msg: InboundMessage, *, active: bool) -> None:
        content = "已打断当前任务。" if active else "当前没有正在执行的任务。"
        await self._publish_reply_for_inbound(msg, content)

    @staticmethod
    def _is_status_query(content: str) -> bool:
        """Whether *content* is a bare "how's it going?" status check.

        Exact-phrase match (after strip/lower/trailing punctuation) so a real
        question that merely contains a status word (e.g. "天气怎么样") is not
        swallowed. Only meaningful while a turn is already running.
        """
        text = content.strip().lower().rstrip("?？!！。.~〜 ").strip()
        return text in _STATUS_QUERY_PHRASES

    @staticmethod
    def _parse_stop_target(content: str) -> str | None:
        """Extract a task id from ``/stop <id>`` (also /cancel /interrupt).

        Returns ``None`` for plain ``/stop`` (the "stop everything" form) or
        any non-slash interrupt phrase. A non-None return tells the inbound
        scheduler to cancel one specific promoted worker by id and leave the
        rest of the conversation (inline turn + other workers) untouched
        (see ``docs/design/core/event-loop/04-runtime-behavior.md`` §4.3 and
        06-test-plan.md T14).
        """
        text = content.strip()
        if not text.startswith("/"):
            return None
        parts = text.split(maxsplit=1)
        if len(parts) != 2:
            return None
        verb = parts[0].lower()
        if verb not in {"/stop", "/cancel", "/interrupt"}:
            return None
        target = parts[1].strip()
        return target or None

    async def _publish_status_ack(
        self,
        msg: InboundMessage,
        *,
        snapshot: list[BackgroundTaskSnapshot] | None = None,
    ) -> None:
        """Reply to a status check from live state without enqueuing work.

        ``snapshot`` (when provided) lists the caller's currently-running
        promoted workers from :meth:`BackgroundTaskManager.list_for_owner`.
        Its length is included in the user-visible copy so they know how
        many parallel lookups are still in flight. An empty / missing
        snapshot falls back to the legacy single-flight copy — the inline
        turn is the only active work.
        """
        zh = contains_cjk(msg.content)
        count = len(snapshot) if snapshot else 0
        if count > 0:
            content = (
                f"⏳ 还在处理你之前的请求（{count} 项进行中），完成后会把结果发到这里。"
                if zh
                else (
                    f"⏳ Still working on your earlier requests ({count} in progress) — "
                    "I'll post results here when they're done."
                )
            )
        else:
            content = (
                "⏳ 还在处理你之前的请求，完成后会把结果发到这里。"
                if zh
                else "⏳ Still working on your earlier request — I'll post the result here when it's done."
            )
        await self._publish_reply_for_inbound(msg, content)

    async def _publish_interrupted(self, msg: InboundMessage) -> None:
        await self._publish_reply_for_inbound(msg, "(interrupted)")

    async def _publish_queue_full(self, msg: InboundMessage) -> None:
        await self._publish_reply_for_inbound(
            msg,
            "This conversation already has too many pending messages."
            " Please wait for the current work to finish or send /stop.",
        )

    def _resolve_agent_session_key(self, msg: InboundMessage) -> str:
        channel = ChannelType.of(msg.logical_channel)
        delivery_route_id = msg.delivery_route_id
        conversation_id = msg.conversation_id or delivery_route_id
        sender_for_session = self._sender_for_session(
            msg,
            conversation_id=conversation_id,
            delivery_route_id=delivery_route_id,
        )
        return msg.agent_session_key or (
            f"{channel}:{sender_for_session}:{conversation_id or delivery_route_id}"
        )

    @staticmethod
    def _sender_for_session(
        msg: InboundMessage,
        *,
        conversation_id: str,
        delivery_route_id: str,
    ) -> str:
        session_sender = str(msg.session_sender_id or "").strip()
        return (
            session_sender or msg.sender_id or conversation_id or delivery_route_id or "anonymous"
        )

    def _maybe_capture_owner_session(
        self,
        msg: InboundMessage,
        agent_session_key: str,
        channel: ChannelType,
        sender_for_session: str,
    ) -> None:
        """Remember the owner's most recent human, interactive session.

        Only genuine human MAIN-lane turns qualify. a2a / a2a_task / cron /
        notify traffic runs in the SYSTEM lane (and is flagged
        ``initiated_by != human``), so it is excluded — we never want to point
        the owner-context injector at an isolated remote-sender session.
        """
        if self._lane_for_message(msg) != ExecutionLane.MAIN:
            return
        initiated_by = str((msg.metadata or {}).get("initiated_by") or "human").strip().lower()
        if initiated_by != "human":
            return
        surface = self._surface_for_message(msg)
        target = OwnerSessionTarget(
            session_key=agent_session_key,
            channel=str(channel),
            sender_id=sender_for_session,
            surface=surface,
        )
        self._last_owner_session = target
        if surface:
            self._owner_sessions_by_surface[surface] = target

    @staticmethod
    def _surface_for_message(msg: InboundMessage) -> str:
        """Normalize an inbound message to a user-facing surface label.

        Mirrors the vocabulary used by ``cloud._send_notify``'s ``push_target``
        (e.g. ``"teams"`` / ``"cloud_tui"``) so the owner-context injector can
        target the same surface a heads-up notification would reach. Prefers the
        granular ``turn_provenance.logical_channel`` (already normalized to
        ``LogicalChannel`` values like ``teams`` / ``cloud_tui``), falling back
        to the raw ``source`` / ``physical_ingress`` hint.
        """
        meta = msg.metadata or {}
        provenance = meta.get("turn_provenance")
        surface = ""
        if isinstance(provenance, dict):
            surface = str(provenance.get("logical_channel") or "").strip().lower()
        if not surface:
            surface = str(meta.get("source") or msg.physical_ingress or "").strip().lower()
        if surface in {"teams_bridge", "cloud_teams"}:
            return "teams"
        return surface

    def get_last_owner_session(self) -> OwnerSessionTarget | None:
        """Return the owner's most recent human interactive session, if known."""
        return self._last_owner_session

    def get_owner_session_for_surface(self, surface: str) -> OwnerSessionTarget | None:
        """Return the owner's latest human session on a specific surface."""
        return self._owner_sessions_by_surface.get(surface)

    @staticmethod
    def _resolve_lane(
        metadata: dict[str, Any] | None,
        *,
        fallback_source: str | None = None,
    ) -> ExecutionLane:
        meta = metadata or {}
        explicit = str(meta.get("execution_lane") or "").strip().lower()
        if explicit == ExecutionLane.SUBAGENT.value:
            return ExecutionLane.SUBAGENT
        if explicit == ExecutionLane.SYSTEM.value:
            return ExecutionLane.SYSTEM
        source = str(meta.get("source") or fallback_source or "").strip().lower()
        if source in _SYSTEM_LANE_SOURCES:
            return ExecutionLane.SYSTEM
        return ExecutionLane.MAIN

    @staticmethod
    def _lane_for_message(msg: InboundMessage) -> ExecutionLane:
        return AgentLoopV2._resolve_lane(msg.metadata, fallback_source=msg.physical_ingress)

    @staticmethod
    def _lane_for_run_once(metadata: dict[str, Any] | None) -> ExecutionLane:
        return AgentLoopV2._resolve_lane(metadata)

    @staticmethod
    def _conversation_metadata_for_message(msg: InboundMessage) -> dict[str, Any]:
        """Return turn metadata with normalized ingress preserved for legacy paths."""

        metadata = dict(msg.metadata or {})
        physical_ingress = str(msg.physical_ingress or "").strip()
        if physical_ingress:
            # ``InboundMessage.physical_ingress`` is the sanitized routing fact;
            # metadata can be stale or peer-supplied after compatibility rewrites.
            metadata["physical_ingress"] = physical_ingress
        return metadata

    async def run_once(
        self,
        prompt: str,
        session_id: str | None = None,
        *,
        channel: Any = None,
        channel_id: Any = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
    ) -> str:
        """Run a single turn: prompt → response."""
        if session_id:
            sid = session_id
        else:
            sid = await self._session_store.get_or_create_session(
                str(channel or ChannelType.INTERNAL),
                str(channel_id or "run_once"),
            )

        return await self._execution_runner.run(
            session_key=sid,
            turn_id=str((metadata or {}).get("turn_id") or thread_id or channel_id or sid),
            lane=self._lane_for_run_once(metadata),
            execute=lambda: self._run_once_unqueued(
                prompt,
                session_id=sid,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
            ),
        )

    async def run_meeting_goal_turn(
        self,
        prompt: str,
        session_id: str,
        *,
        metadata: dict[str, Any],
    ) -> GoalTurnResult:
        """Run one bounded meeting-goal turn in its persistent group session."""
        turn_metadata = dict(metadata)
        turn_metadata["meeting_goal_turn"] = True
        channel_id = str(turn_metadata.get("cid") or session_id)

        async def execute() -> GoalTurnResult:
            history = self._llm_history(await self._session_store.get_messages(session_id))
            state = await self._begin_turn(
                prompt,
                history,
                session_id,
                channel=ChannelType.CLOUD,
                channel_id=channel_id,
                metadata=turn_metadata,
            )
            text, _ = await self._drive_turn(state)
            return GoalTurnResult(
                text=text,
                exit=state.exit,
                iterations_used=state.iterations_used,
                tool_successes=state.tool_successes,
                tool_failures=state.tool_failures,
                last_tool_name=state.last_tool_name,
                last_tool_succeeded=state.last_tool_succeeded,
            )

        return await self._execution_runner.run(
            session_key=session_id,
            turn_id=str(turn_metadata.get("turn_id") or channel_id),
            lane=ExecutionLane.MAIN,
            execute=execute,
        )

    async def _run_once_unqueued(
        self,
        prompt: str,
        *,
        session_id: str,
        channel: Any = None,
        channel_id: Any = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        _forked_child: bool = False,
    ) -> str:
        """Execute a turn already admitted to the canonical session queue."""
        # #775's check must hold for anyone stating a real binding: an existing
        # session invoked with a different channel/sender is the wrong session,
        # and that has to raise.
        #
        # A forked sub-agent is not stating one. It runs on a session `fork()`
        # already bound to the parent's channel and sender, and the values that
        # reach here are synthetic — the canonical adapter passes
        # `channel=INTERNAL` with the child session as `delivery_route_id`, so
        # "were the arguments supplied" cannot tell the two apart.
        #
        # `_forked_child` is set by the one caller that knows, and it is a
        # parameter of this private method rather than a key in `metadata`.
        # `metadata` is a public argument of `run_once` and is forwarded here
        # unchanged, so reading provenance out of it would let any caller pass
        # a real, different binding alongside the marker and switch #775's
        # check off — a claim the comment would deny while the code allowed it.
        await self._session_store.ensure_session(
            session_id,
            str(channel or ChannelType.INTERNAL),
            str(channel_id or "run_once"),
            claim=not _forked_child,
        )
        history = self._llm_history(await self._session_store.get_messages(session_id))
        response_text, _ = await self._run_conversation(
            prompt,
            history,
            session_id,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
        )
        return response_text

    @staticmethod
    def _llm_history(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Exclude host-owned informational events from provider input."""
        return [message for message in messages if message.get("role") in _LLM_HISTORY_ROLES]

    # ── Typing indicators ───────────────────────────────────────────────

    def _start_typing(
        self,
        channel: Any,
        channel_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> asyncio.Task[None] | None:
        """Start a periodic typing indicator task. Returns the task (or None for CLI)."""
        if not channel or not channel_id or channel == ChannelType.INTERNAL:
            return None

        payload = {"channel": channel, "channel_id": channel_id, "metadata": metadata or {}}
        self._bus.events.emit(EventType.TYPING_STARTED, payload)

        async def _typing_loop() -> None:
            try:
                while True:
                    await asyncio.sleep(3.0)
                    self._bus.events.emit(EventType.TYPING_STARTED, payload)
            except asyncio.CancelledError:
                pass

        return asyncio.create_task(_typing_loop(), name="typing-indicator")

    def _stop_typing(
        self,
        task: asyncio.Task[None] | None,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Cancel the typing indicator task and emit TYPING_STOPPED."""
        if task and not task.done():
            task.cancel()
        if channel and channel_id and channel != ChannelType.INTERNAL:
            self._bus.events.emit(
                EventType.TYPING_STOPPED,
                {"channel": channel, "channel_id": channel_id},
            )

    # ── Slash commands ──────────────────────────────────────────────────

    async def _handle_slash(self, cmd: str, session_id: str, msg: InboundMessage) -> str | None:
        """Handle REPL slash commands. Returns reply string or None if not known."""
        parts = cmd.split(maxsplit=1)
        verb = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if verb == "/new":
            await self._session_store.replace_messages(session_id, [], reason="reset")
            try:
                from praestoclaw.agent.tools.plan import get_plan_store

                get_plan_store().delete(session_id)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Plan cleanup after /new failed session={} error={}", session_id, exc)
            return "Session cleared. Starting fresh."

        if verb == "/compact":
            history = self._llm_history(await self._session_store.get_messages(session_id))
            if len(history) < 10:
                return "Not enough messages to compact."
            result = await self._compressor.compress(history)
            await self._persist_compacted(session_id, result.messages)
            return (
                f"Compacted: {result.tokens_before}→{result.tokens_after} tokens "
                f"({result.savings_percent:.0f}% saved, method: {result.method})"
            )

        if verb == "/status":
            budget_info = f"Budget: {self._config.budget.max_iterations} max"
            model_info = f"Model: `{self._config.model}`"
            core_info = "Agent core: v2 (Hermes-style)"
            return f"{core_info}\n{model_info}\n{budget_info}"

        if verb == "/memory":
            if self._memory:
                content = self._memory.read() if hasattr(self._memory, "read") else ""
                return content if content and content.strip() else "_MEMORY.md is empty._"
            return "_No memory configured._"

        if verb == "/tools":
            schemas = self._tool_registry.get_schemas(self._config.tools or None)
            if not schemas:
                return "_No tools available._"
            lines = ["**Available tools:**"]
            for s in schemas:
                name = s.get("function", {}).get("name", "?")
                desc = s.get("function", {}).get("description", "")[:60]
                lines.append(f"- `{name}` — {desc}")
            return "\n".join(lines)

        if verb == "/model":
            if not arg:
                return f"Current model: `{self._config.model}`"
            old_model = self._config.model
            self._config.model = arg.strip()
            return f"Model switched: `{old_model}` → `{self._config.model}`"

        if verb == "/estop":
            reason = arg or "Manual E-stop via slash command"
            self._bus.events.emit(
                EventType.SECURITY_ESTOP,
                {"reason": reason, "actor": f"user:{msg.sender_id or 'unknown'}"},
            )
            return "**E-STOP ACTIVATED.** All agent activity halted."

        if verb == "/help":
            return (
                "**Available commands:**\n"
                "- `/new` — clear session\n"
                "- `/compact` — compress history\n"
                "- `/status` — show config\n"
                "- `/memory` — show MEMORY.md\n"
                "- `/tools` — list available tools\n"
                "- `/model [name]` — show/switch model\n"
                "- `/estop` — emergency stop\n"
            )

        # Unknown slash command — let it go to the agent
        return None

    # ── Approval routing ────────────────────────────────────────────────

    async def _try_route_approval(self, msg: InboundMessage) -> bool:
        """Intercept /approve, /deny, /always commands. Returns True if consumed."""
        if self._approval_manager is None:
            return False

        mgr = self._approval_manager
        content = msg.content.strip()
        content_lower = content.lower()
        action: str | None = None
        request_id: str | None = None

        # Check metadata first (Teams Adaptive Card / Cloud structured response)
        meta = msg.metadata if hasattr(msg, "metadata") and msg.metadata else {}
        if meta.get("approval_action"):
            action = meta["approval_action"]
            request_id = meta.get("approval_request_id")

        # Slash commands: /approve <id>, /deny <id>, /always <id>
        elif content.startswith("/approve "):
            action, request_id = "approve", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/deny "):
            action, request_id = "deny", content.split(maxsplit=1)[1].strip()
        elif content.startswith("/always "):
            action, request_id = "always", content.split(maxsplit=1)[1].strip()

        # Simple keywords — resolve against the single pending request
        else:
            pending = mgr.get_pending()
            if len(pending) == 1:
                sole = pending[0]
                if content_lower in ("yes", "y", "approve", "/approve"):
                    action, request_id = "approve", sole.id
                elif content_lower in ("no", "n", "deny", "/deny"):
                    action, request_id = "deny", sole.id
                elif content_lower in ("always", "a", "/always"):
                    action, request_id = "always", sole.id

        if not action or not request_id:
            return False

        # Install the reply-route handoff BEFORE resolving: ``_finish()`` sets the
        # waiter Event, so the blocked turn resumes on the next event-loop tick
        # and may publish its answer immediately.
        request = mgr.get_request(request_id)
        redirected = self._redirect_web_reply_route(request, msg)
        resolved_ok = True

        try:
            approved = action in ("approve", "always")
            mgr.resolve(
                request_id, approved=approved, resolver=msg.sender_id or "user", action=action
            )

            if action == "always" and self._allowlist is not None:
                resolved_req = mgr.get_request(request_id)
                if resolved_req:
                    self._allowlist.add(
                        resolved_req.tool_name,
                        resolved_req.args if hasattr(resolved_req, "args") else None,
                        added_by=msg.sender_id or "user",
                    )

            status = "approved" if approved else "denied"
            logger.info("Approval {} for request {}", status, request_id)
            if self._audit:
                self._audit.log_event(
                    action="agent:approval",
                    data={
                        "status": status,
                        "session_id": self._resolve_agent_session_key(msg),
                        "conversation_session_id": self._resolve_agent_session_key(msg),
                    },
                )
        except Exception as exc:
            logger.error("Approval routing error: {}", exc)
            resolved_ok = False
            if redirected:
                # No turn will resume, so nothing will ever claim the approver's
                # queue. Roll back and acknowledge instead of stranding that
                # request until its timeout (the pre-#661 behaviour on this path:
                # the exception was swallowed and nothing was ever published).
                self._cancel_web_reply_redirect(request)
                redirected = False

        # Exactly one of the two: the redirect hands the turn's real answer to
        # the approver's request, which holds a single slot. Acking as well would
        # take that slot and the answer would be lost again.
        if not redirected:
            await self._ack_approval_to_web_requester(msg, action=action, ok=resolved_ok)

        return True

    def _redirect_web_reply_route(self, request: Any, msg: InboundMessage) -> bool:
        """Point the blocked turn's replies at the approver's live request.

        Returns ``True`` only when a redirect is actually in place. Every guard
        below is a case where redirecting would be wrong rather than merely
        unhelpful — most importantly a non-web turn, whose answer belongs on its
        own surface and must not be diverted into a web HTTP body.
        """
        if request is None:
            return False
        if ChannelType.of(msg.logical_channel) is not ChannelType.WEB:
            return False
        source = str(getattr(request, "channel_id", "") or "")
        if not source or source == msg.delivery_route_id:
            return False
        if not source.startswith(_WEB_ONESHOT_ROUTE_PREFIXES):
            return False
        channel = self._resolve_web_channel()
        redirect = getattr(channel, "redirect_request", None) if channel else None
        if not callable(redirect):
            return False
        try:
            return bool(redirect(source, msg.delivery_route_id))
        except Exception as exc:  # noqa: BLE001 — never break approval routing
            logger.debug("Reply-route redirect failed: {}", exc)
            return False

    def _cancel_web_reply_redirect(self, request: Any) -> None:
        """Undo :meth:`_redirect_web_reply_route` when the resume never happens."""
        source = str(getattr(request, "channel_id", "") or "")
        if not source:
            return
        channel = self._resolve_web_channel()
        cancel = getattr(channel, "cancel_redirect", None) if channel else None
        if not callable(cancel):
            return
        try:
            cancel(source)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Reply-route redirect rollback failed: {}", exc)

    def _resolve_web_channel(self) -> Any | None:
        """The live WebChannel, or ``None`` in CLI / unit-test setups."""
        if self._channel_resolver is None:
            return None
        try:
            return self._channel_resolver(ChannelType.WEB)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Web channel resolution failed: {}", exc)
            return None

    async def _ack_approval_to_web_requester(
        self, msg: InboundMessage, *, action: str, ok: bool
    ) -> None:
        """Answer the request that carried the approval when nothing else will.

        Only for one-shot web requests: they block a real HTTP caller, and
        without this the caller waits out ``request_timeout`` for a response
        nobody is going to write. CLI / Teams / cron approvals are unchanged.

        ``ok`` is False when ``resolve()`` raised — an unknown id, or a request
        somebody already answered. Claiming "已批准" there would tell the user
        their decision took effect when it did not.
        """
        if ChannelType.of(msg.logical_channel) is not ChannelType.WEB:
            return
        if not msg.delivery_route_id.startswith(_WEB_ONESHOT_ROUTE_PREFIXES):
            return
        if not ok:
            content = "该审批已失效或已被处理，未生效。"
        elif action in ("approve", "always"):
            content = "已批准，正在继续原任务。"
        elif action == "deny":
            content = "已拒绝。"
        else:
            content = "该审批已处理。"
        await self._publish_reply_for_inbound(msg, content)

    # ── Core conversation loop ───────────────────────────────────────────

    async def _run_conversation(
        self,
        *args: Any,
        **kwargs: Any,
    ) -> tuple[str, bool]:
        """Run the agentic conversation loop."""
        return await self._run_conversation_impl(*args, **kwargs)

    async def _run_conversation_impl(
        self,
        user_message: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        route_hint: str | None = None,
    ) -> tuple[str, bool]:
        """Run the agentic conversation loop. Returns (response_text, streamed).

        Splits into a setup phase (:meth:`_begin_turn`) that prepares a
        :class:`_TurnState`, and a reentrant loop phase (:meth:`_drive_turn`)
        that consumes it. The split is byte-for-byte equivalent to the legacy
        monolithic implementation when the event-loop flag is OFF
        (locked by ``test_loop_v2.py::test_drive_turn_inline_equivalence``).
        See ``docs/design/core/event-loop/02-architecture.md`` §2.2.
        """
        state = await self._begin_turn(
            user_message,
            history,
            session_id,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
            route_hint=route_hint,
        )
        return await self._drive_turn(state)

    async def _begin_turn(
        self,
        user_message: str,
        history: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        route_hint: str | None = None,
    ) -> _TurnState:
        """Setup phase: provider restore → budget → system prompt → skill match
        → attachment block → persist USER row → enriched messages → plan block
        → preflight compression. Returns a fully-prepared :class:`_TurnState`
        ready to be consumed by :meth:`_drive_turn`.
        """
        # 1. Restore primary provider if failover was active
        if hasattr(self._provider, "restore_primary"):
            self._provider.restore_primary()  # type: ignore[attr-defined]

        # 2. Create budget + fresh loop detector per conversation
        meeting_goal_turn = bool(metadata and metadata.get("meeting_goal_turn"))
        if meeting_goal_turn and metadata is not None:
            max_iterations = int(
                metadata.get("meeting_goal_max_iterations") or _MEETING_GOAL_MAX_ITERATIONS
            )
        else:
            max_iterations = (
                self._config.budget.subagent_max_iterations
                if self._prompt_mode == "subagent"
                else self._config.budget.max_iterations
            )
        budget = IterationBudget(max_total=max_iterations)
        loop_detector = LoopDetector()
        self._turns_since_memory += 1

        # 3. Build system prompt. praesto tag exp: a borrowed-identity group turn
        # is the group's shared digital employee, so it must NOT carry the lending
        # employee's personal context (SOUL/USER/MEMORY). Strip it for these turns;
        # the group's own private local memory is injected separately below.
        praesto_tag_exp_active = bool(metadata and metadata.get("praesto_tag_exp"))
        # Group Skill capabilities are derived locally from the current chat's
        # registry below. Never accept a wire-, scheduler-, or caller-provided
        # capability snapshot: otherwise a crafted inbound frame could expose
        # arbitrary tools before any Group Skill match.
        _clear_group_skill_turn_capabilities(metadata, active=praesto_tag_exp_active)
        if praesto_tag_exp_active and self._group_mcp_service and metadata is not None:
            cid = str(metadata.get("cid") or "").strip()
            if cid:
                metadata["group_mcp_tool_names"] = await self._group_mcp_service.prepare_chat(cid)
        praesto_tag_exp_excluded_guidance = (
            _praesto_tag_exp_excluded_registered_tools(
                self._tool_registry,
                metadata.get("group_mcp_tool_names") if metadata else None,
            )
            if praesto_tag_exp_active
            else None
        )
        system_prompt = self._build_system_prompt(
            include_personal_context=not praesto_tag_exp_active,
            exclude_tool_guidance=praesto_tag_exp_excluded_guidance,
            include_skills=not praesto_tag_exp_active,
            include_confirm_gate_guidance=not praesto_tag_exp_active,
        )
        if praesto_tag_exp_active and self._group_skill_loader:
            cid = str((metadata or {}).get("cid") or "")
            group_skills_section = self._group_skill_loader.prompt_section(cid)
            if group_skills_section:
                system_prompt = f"{system_prompt}\n\n---\n\n{group_skills_section}"
        group_memory_section = self._praesto_tag_exp_memory_section(metadata)
        if group_memory_section:
            system_prompt = f"{system_prompt}\n\n---\n\n{group_memory_section}"

        # praesto tag exp: the borrowed-identity group turn must not touch the
        # lending employee's PERSONAL memory. Remove the personal memory
        # read/write tools so the model can only persist facts via
        # ``group_memory`` (the group's isolated local store). Personal
        # consolidation and the save-to-memory nudge are likewise skipped in
        # ``_drive_turn``; personal MEMORY.md/USER.md are already stripped from
        # the system prompt above.
        exclude_tools = _augment_exclude_for_praesto_tag_exp(
            exclude_tools, active=praesto_tag_exp_active
        )
        if praesto_tag_exp_active:
            _ptx_schemas = self._get_tool_schemas(exclude_tools, metadata=metadata)
            _ptx_tool_names = sorted(
                str(s.get("function", {}).get("name", "")) for s in (_ptx_schemas or [])
            )
            logger.debug(
                "praesto_tag_exp turn: cid={} personal_context=stripped "
                "excluded_tools={} group_memory_in_schema={} "
                "callable_tools({})={}",
                (metadata or {}).get("cid") or "(none)",
                list(praesto_tag_exp_excluded_guidance or ()),
                "group_memory" in _ptx_tool_names,
                len(_ptx_tool_names),
                _ptx_tool_names,
            )

        # 4. Auto-match skills for injection
        injected_skills = None
        if praesto_tag_exp_active and self._group_skill_loader:
            skills_config = self._skills_config
            threshold = getattr(skills_config, "inject_threshold", 20) if skills_config else 20
            cid = str((metadata or {}).get("cid") or "")
            explicit_meeting_skills = bool(metadata is not None and "meeting_skills" in metadata)
            if cid:
                if explicit_meeting_skills:
                    raw_names = (metadata or {}).get("meeting_skills")
                    if not isinstance(raw_names, list) or not all(
                        isinstance(name, str) for name in raw_names
                    ):
                        raise ValueError("meeting_skills must be an array of canonical skill names")
                    injected_skills = (
                        self._group_skill_loader.resolve_enabled(cid, raw_names) or None
                    )
                else:
                    # Group Skill matching is independent from the personal
                    # SkillLoader's context-budget max_inject setting.
                    injected_skills = (
                        self._group_skill_loader.match(cid, user_message, threshold=threshold)
                        or None
                    )
                if injected_skills and metadata is not None:
                    metadata["group_skill_names"] = [skill.name for skill in injected_skills]
                    metadata["group_skill_hashes"] = {
                        skill.name: skill.content_hash for skill in injected_skills
                    }
                    metadata["group_skill_safe_tools"] = [
                        entry for skill in injected_skills for entry in skill.safe_tools
                    ]
        elif self._skill_loader and hasattr(self._skill_loader, "match"):
            skills_config = self._skills_config
            threshold = getattr(skills_config, "inject_threshold", 20) if skills_config else 20
            max_inject = getattr(skills_config, "max_inject", 1) if skills_config else 1
            if max_inject > 0:
                injected_skills = (
                    self._skill_loader.match(
                        user_message,
                        threshold=threshold,
                        max_results=max_inject,
                        praesto_tag_exp_active=praesto_tag_exp_active,
                    )
                    or None
                )

        # 4b. First-turn routing: if a recipe's declared patterns cover this turn's
        # SUBJECT, expose the `workflow` schema for THIS turn and note that it
        # matched. Matching is recall-oriented and makes no claim about whether the
        # user asked for execution — the note is neutral and the model decides (see
        # _recipe_route_block). The model otherwise only sees the recipe's name in
        # the inactive-tool summary and, observed live, reproduces its steps by hand.
        matched_recipe = self._match_workflow_recipe(user_message)
        if matched_recipe:
            # Only claim the tool is callable if it actually survives the agent
            # allowlist, this turn's exclusions and an explicit disable. Otherwise
            # the block would hand the model a call it is about to be refused.
            _routed = {
                str(s.get("function", {}).get("name", ""))
                for s in (
                    self._get_tool_schemas(
                        exclude_tools, metadata=metadata, include_inactive=["workflow"]
                    )
                    or []
                )
            }
            if "workflow" not in _routed:
                logger.debug(
                    "recipe_route.suppressed recipe={} reason=not_callable", matched_recipe
                )
                matched_recipe = ""
        if matched_recipe and _is_scanner_setup_turn(matched_recipe, user_message):
            # Scanner setup is a short deterministic handoff, not another
            # planned workflow. Keep Plan out of both the schema and execution
            # allowlist so the model cannot create a second main-session Plan.
            exclude_tools = list(exclude_tools or [])
            if "plan" not in exclude_tools:
                exclude_tools.append("plan")

        # 5. Build enriched user message (runtime context + skills injection).
        # Surface lightweight metadata only. Image URLs remain visible for URL
        # passthrough workflows (e.g. feedback); signed file download URLs stay
        # hidden and are only resolved by attachment_process.
        attachment_block = self._build_attachment_context(metadata)
        if attachment_block:
            user_message = f"{attachment_block}\n\n{user_message}"

        # ``user_message`` is now the durable user text (raw user input +
        # any prepended ``[attachments: ...]`` context that must survive
        # across turns). The enriched form below adds *ephemeral* per-turn
        # context (Runtime Context block + matched skill <context> blocks)
        # that must only reach the LLM for this turn. Persisting the
        # enriched form would poison future turns with a frozen
        # "Current Time: <past>" and stale one-shot skill injections
        # (issue #345 root cause). Store ``user_message``; build the
        # enriched form separately for the LLM-bound message list.
        enriched_content = self._prompt_builder.build_user_message(
            user_message,
            channel=channel,
            channel_id=channel_id,
            injected_skills=injected_skills,
            conversation_name=str((metadata or {}).get("conversation_name") or "") or None,
        )
        # praesto tag exp: prepend a minimal session-context header describing the
        # current Teams group/meeting (chat type, title, id, speaker) so the shared
        # employee is oriented before reading group memory and the user turn.
        if matched_recipe:
            enriched_content = (
                f"{_recipe_route_block(matched_recipe, user_message)}\n\n{enriched_content}"
            )
        session_context_block = self._praesto_tag_exp_session_context_block(
            metadata, self._meeting_context_provider
        )
        if session_context_block:
            enriched_content = f"{session_context_block}\n\n{enriched_content}"
        group_notify_guidance = self._teams_group_notify_guidance_block(metadata)
        if group_notify_guidance:
            enriched_content = f"{group_notify_guidance}\n\n{enriched_content}"
        user_rowid = await self._session_store.add_message(
            session_id,
            {"role": "user", "content": user_message},
        )
        user_msg = {"role": "user", "content": enriched_content}

        # 5a. Wire plan tool's session resolver + read active plan (pinned block).
        # The active-plan block is re-assembled every turn from the on-disk
        # snapshot, so compaction can never make the agent "forget" its plan.
        plan_block = ""
        active_plan_lookup: Callable[[str], str] | None = None
        plan_tool: Any | None = None
        try:
            from praestoclaw.agent.tools.plan import active_plan_block

            active_plan_lookup = active_plan_block
            plan_tool = (
                self._tool_registry.get("plan") if hasattr(self._tool_registry, "get") else None
            )
            if plan_tool and hasattr(plan_tool, "set_session_resolver"):
                plan_tool.set_session_resolver(lambda sid=session_id: sid)
            plan_block = active_plan_lookup(session_id)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Active plan block lookup failed: {}", exc)

        planning_preflight: TaskPlanningPreflight | None = None
        preflight_plan_created = False
        preflight_allowed_tools = self._resolve_allowed_tools(exclude_tools)
        plan_tool_available = plan_tool is not None and (
            preflight_allowed_tools is None or "plan" in preflight_allowed_tools
        )
        if matched_recipe:
            # A routed workflow owns planning in its isolated run. Creating a
            # generic Plan here would leave a second, unrelated task-preflight
            # Plan on the main chat before the model can call workflow(...).
            # Subject matching is deliberately recall-oriented, so a false match
            # now also suppresses one Teams preflight card; that cost is accepted
            # to keep Plan ownership exclusive when the model does run the recipe.
            logger.debug(
                "event_loop.task_preflight skipped reason=workflow_recipe_route recipe={}",
                matched_recipe,
            )
        elif meeting_goal_turn:
            logger.debug("event_loop.task_preflight skipped reason=meeting_goal_turn")
        elif should_run_task_planning_preflight(
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
            plan_block=plan_block,
            plan_tool_available=plan_tool_available,
        ):
            planning_preflight = await run_task_planning_preflight(
                self._provider,
                model=self._config.model,
                user_message=user_message,
                session_id=session_id,
                metadata=metadata,
            )
            preflight_plan_created = await self._maybe_create_task_preflight_plan(
                planning_preflight,
                session_id=session_id,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
            )
            if preflight_plan_created and active_plan_lookup is not None:
                try:
                    plan_block = active_plan_lookup(session_id)
                except Exception as exc:  # noqa: BLE001
                    logger.debug("Active plan block refresh after preflight failed: {}", exc)

        # 5. Assemble messages
        messages = self._assemble_messages(system_prompt, history, user_msg)
        if plan_block:
            # Insert immediately after the system prompt so it survives
            # compaction (compaction preserves leading system messages).
            messages.insert(1, {"role": "system", "content": plan_block})

        # 6. Preflight compression
        context_limit = self._resolve_context_limit()
        history_tokens = estimate_tokens(messages)
        if self._compressor.should_preflight_compress(history_tokens, context_limit):
            result = await self._compressor.compress(messages, current_tokens=history_tokens)
            messages = result.messages
            await self._persist_compacted(session_id, messages)
            logger.info(
                "Preflight compression: {}→{} tokens", result.tokens_before, result.tokens_after
            )

        planning_context = render_task_planning_preflight_context(
            planning_preflight,
            visible_plan_created=preflight_plan_created,
        )
        if planning_context:
            insert_task_planning_preflight_context(
                messages, planning_context, after_plan_block=bool(plan_block)
            )

        return _TurnState(
            messages=messages,
            session_id=session_id,
            plan_session_id=session_id,
            budget=budget,
            loop_detector=loop_detector,
            user_rowid=user_rowid if isinstance(user_rowid, int) else None,
            channel=channel,
            channel_id=channel_id,
            thread_id=thread_id,
            route_hint=route_hint,
            user_message=user_message,
            metadata=metadata,
            exclude_tools=exclude_tools,
            include_inactive_tools=[
                *(["workflow"] if matched_recipe else []),
                *self._group_mcp_tool_names(metadata),
            ],
            started_monotonic=time.monotonic(),
        )

    async def _maybe_create_task_preflight_plan(
        self,
        preflight: TaskPlanningPreflight | None,
        *,
        session_id: str,
        channel: Any,
        channel_id: str | None,
        thread_id: str | None,
        metadata: dict[str, Any] | None,
        exclude_tools: list[str] | None,
        user_message: str,
    ) -> bool:
        if preflight is None or not preflight.should_create_visible_plan:
            return False
        # Plan-tool availability is already proven by the preflight gate
        # (``should_run_task_planning_preflight`` returns False without it).
        if not hasattr(self._tool_registry, "execute"):
            logger.debug("event_loop.task_preflight.plan_create skipped reason=no_registry_execute")
            return False
        channel_type = ChannelType.of(channel, default=None)
        if channel_type == ChannelType.INTERNAL or not channel_id:
            logger.debug(
                "event_loop.task_preflight.plan_create skipped reason=no_push_channel channel={}",
                channel,
            )
            return False

        args = {
            "action": "create",
            "workflow": "task-preflight",
            "items": [{"title": step} for step in preflight.steps],
        }
        tool_metadata = dict(self._metadata_for_tool("plan", metadata) or {})
        tool_metadata["internal_task_preflight"] = True
        tool_call = ToolCallRequest(
            id="task-preflight-plan-create",
            name="plan",
            arguments=args,
        )
        try:
            result = await self._execute_internal_tool_call(
                tool_call,
                session_id=session_id,
                channel=channel_type,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=tool_metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "event_loop.task_preflight.plan_create error session={} error={}",
                session_id,
                exc,
            )
            return False

        # Reject both failure shapes: PlanTool's own ``"Error: ..."`` validation
        # messages AND ToolRegistry's wrapped ``"Error executing plan: ..."`` (no
        # colon after "Error") returned when the tool raises. Matching only
        # ``"Error:"`` would mistake a registry exception for success and then
        # falsely tell the agent a visible plan card exists.
        success = isinstance(result, str) and not _is_tool_error_result(result)
        logger.debug(
            "event_loop.task_preflight.plan_create session={} success={} items_n={} result={}",
            session_id,
            success,
            len(preflight.steps),
            truncate_ellipsis(str(result), 300),
        )
        return success

    async def _drive_turn(self, state: _TurnState) -> tuple[str, bool]:
        """Reentrant loop phase: call LLM → execute tools → persist → compact
        → final persist → memory consolidate. Reads/writes through *state* so
        a future promotion can swap ``state.session_id`` to a worker session
        and resume the same chain.

        Every persisted row inside the loop body appends its ``lastrowid`` to
        ``state.turn_rowids``. Promotion (step D) prunes exactly that set from
        the originating session.
        """
        budget = state.budget
        grace_enabled = self._config.budget.grace_call
        loop_detector = state.loop_detector
        messages = state.messages
        metadata = state.metadata
        exclude_tools = state.exclude_tools
        channel = state.channel
        channel_id = state.channel_id
        thread_id = state.thread_id
        route_hint = state.route_hint
        user_message = state.user_message
        # praesto tag exp: suppress personal-memory side effects for a group turn.
        praesto_tag_exp_active = bool(metadata and metadata.get("praesto_tag_exp"))
        meeting_goal_turn = bool(metadata and metadata.get("meeting_goal_turn"))

        context_limit = self._resolve_context_limit()

        # 8. Main loop
        response_text = ""
        streamed = False
        empty_final_retries = 0
        iteration = 0

        while budget.remaining > 0 or (grace_enabled and budget.grace_available):
            # b/c. Consume budget or grace; determine if tools are allowed
            forced_text_only = False
            current_tools = self._get_tool_schemas(
                exclude_tools,
                metadata=metadata,
                include_inactive=state.include_inactive_tools,
            )
            if budget.remaining > 0:
                budget.consume()
                # When grace is disabled and we just consumed the last iteration,
                # force text-only so the model wraps up with text.
                if budget.remaining == 0 and not grace_enabled:
                    current_tools = None
                    forced_text_only = True
            elif budget.grace_available:
                budget.consume_grace()
                current_tools = None  # force text-only on grace
                forced_text_only = True
            else:
                break
            state.iterations_used += 1
            if meeting_goal_turn and forced_text_only:
                state.exit = TurnExit.BUDGET_EXHAUSTED

            # d. Graceful termination nudge
            if budget.remaining == 1 and current_tools is not None:
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "Wrap up this turn soon: summarize useful progress, identify "
                            "remaining work or blockers, and leave a clear next step for the "
                            "next turn. Do not claim the task is finished unless it is actually "
                            "complete, and do not call finish_task_group before actual completion."
                            if meeting_goal_turn
                            else "You are running low on iterations. Please wrap up your current task and provide a final response."
                        ),
                    }
                )
            # d1. Position feedback, earlier than the wrap-up nudge above. That
            # nudge fires at remaining == 1, which is the first moment the model
            # learns where it stands — far too late to change course. A workflow
            # run on issue #672 spent roughly 85 of its 90 iterations reading
            # code, made no edit at all, and only found out one turn from the
            # end. Announcing the halfway and three-quarter marks turns a budget
            # written in a prompt ("orientation should take ≤ 25 turns") into
            # something the model can actually act on.
            #
            # Equality fires each mark exactly once as `remaining` counts down.
            # The set literal dedupes a budget too small for two distinct marks.
            # Guarded above 1 so a tiny budget cannot collide with the wrap-up
            # nudge and stack two system messages on the same turn.
            elif (
                current_tools is not None
                and budget.remaining > 1
                and budget.remaining in {budget.max_total // 2, budget.max_total // 4}
            ):
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            f"Iteration checkpoint: {budget.max_total - budget.remaining} of "
                            f"{budget.max_total} used, {budget.remaining} left. If you have not "
                            "started the substantive work this task asked for, stop gathering "
                            "context and start it now with a smaller scope."
                        ),
                    }
                )
                # Logged because the injected message itself is never persisted to
                # the session store — an earlier attempt to confirm from
                # sessions.db that these fire found nothing and could conclude
                # nothing, since the wrap-up nudge is equally absent there.
                logger.info(
                    "budget checkpoint injected session_id={} used={}/{}",
                    state.session_id,
                    budget.max_total - budget.remaining,
                    budget.max_total,
                )

            # d2. Memory/skill nudge (Hermes-style learning loop). Skipped for a
            # praesto tag exp group turn — the personal ``memory`` tool is gone
            # and nudging toward it would only confuse the shared employee.
            if (
                budget.remaining <= 2
                and current_tools is not None
                and not praesto_tag_exp_active
                and self._turns_since_memory >= self._memory_nudge_interval
            ):
                messages.append(
                    {
                        "role": "system",
                        "content": (
                            "Consider saving important findings to memory "
                            "(user preferences, environment details, lessons learned) "
                            "or as a skill (reusable workflows) before wrapping up."
                        ),
                    }
                )
                self._turns_since_memory = 0

            # e. Cache breakpoints
            cached_messages = apply_cache_breakpoints(messages, self._provider)

            # f. Call LLM
            try:
                llm_response, final_delivered = await self._call_llm(
                    self._config.model,
                    cached_messages,
                    current_tools,
                    channel=None if meeting_goal_turn else channel,
                    channel_id=None if meeting_goal_turn else channel_id,
                    session_id=state.plan_session_id,
                )
                self._flow_trace(
                    "turn.llm_response",
                    finish_reason=llm_response.finish_reason,
                    tool_calls=len(llm_response.tool_calls),
                    content_len=len(llm_response.content or ""),
                    streamed=final_delivered,
                )
            except CompressNeededError:
                result = await self._compressor.compress(messages)
                messages = result.messages
                state.messages = messages
                await self._persist_compacted(state.session_id, messages)
                # ``_persist_compacted`` calls ``replace_messages`` which is
                # DELETE-then-INSERT, so every rowid in MAIN is re-issued. The
                # ids already accumulated in ``state.turn_rowids`` from earlier
                # tool batches in this turn now point at rows that no longer
                # exist; a subsequent ``_promote_turn_to_worker`` cap-race
                # rollback (which reads ``state.turn_rowids`` to restore the
                # pre-prune snapshot) would otherwise see an empty list and
                # silently lose the post-compaction tool trajectory. Reset
                # here so the next batch accumulates fresh, valid rowids.
                state.turn_rowids = []
                logger.info("Mid-loop compression: saved {:.0f}%", result.savings_percent)
                continue

            if llm_response.tool_calls:
                safe_tool_calls = [
                    tc for tc in llm_response.tool_calls if is_provider_safe_tool_name(tc.name)
                ]
                if len(safe_tool_calls) != len(llm_response.tool_calls):
                    dropped = [
                        tc.name
                        for tc in llm_response.tool_calls
                        if not is_provider_safe_tool_name(tc.name)
                    ]
                    logger.warning(
                        "Dropped provider-unsafe tool_call name(s) from LLM response: {}",
                        dropped,
                    )
                    llm_response.tool_calls = safe_tool_calls

            # h. Track usage
            await self._session_store.update_usage(
                state.session_id,
                prompt_tokens=llm_response.prompt_tokens,
                completion_tokens=llm_response.completion_tokens,
                cost=0.0,
            )

            # i. Tool calls
            if llm_response.has_tool_calls:
                # Track tool-batch count; the post-persist boundary below
                # decides whether to promote this turn to a worker session
                # (event-loop execution model).
                state.tool_batches += 1
                assistant_msg = self._response_to_message(llm_response)
                rowid = await self._session_store.add_message(state.session_id, assistant_msg)
                if isinstance(rowid, int):
                    state.turn_rowids.append(rowid)
                messages.append(assistant_msg)

                # Push the model's preamble text (e.g. "Let me look that
                # up…") to channels BEFORE executing tools. The tools
                # branch above calls ``provider.complete()`` (non-stream),
                # so the streaming chunk path in ``_call_llm`` is skipped
                # — meaning the only place this content currently lands
                # is ``session_store.add_message`` above. That suffices
                # for surfaces that re-read session history (Web UI
                # polls ``/api/sessions/...``), but push-only channels
                # like Teams never see it and jump straight to the
                # tool-progress card. Emit it as an intermediate
                # OutboundMessage so cloud.py routes it via
                # ``_send_notify`` (``keep_context=True`` keeps the
                # ``/chatng`` sync waiter open for the eventual final
                # reply after tool results). Skip on CLI (no push
                # surface) and when there's no channel context (e.g.
                # ``run_once`` callers).
                # ``route_hint`` is forwarded from the inbound so cloud
                # channel routing for synthetic channel_ids (e.g.
                # ``a2a:notify:*``) lands on the right connection
                # instead of broadcasting. ``.strip()`` guards against
                # whitespace-only content (e.g. ``"\n"``) which would
                # otherwise render as an empty bubble on push channels.
                preamble = (llm_response.content or "").strip()
                if (
                    preamble
                    and not meeting_goal_turn
                    and channel
                    and channel_id
                    and channel != ChannelType.INTERNAL
                ):
                    try:
                        await self._reply_dispatcher.publish_intermediate(
                            channel=channel,
                            channel_id=channel_id,
                            content=preamble,
                            thread_id=thread_id,
                            route_hint=route_hint,
                            metadata={"keep_context": True},
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "Preamble outbound failed (channel={} channel_id={}): {}",
                            channel,
                            channel_id,
                            exc,
                        )

                results = await self._execute_tools(
                    llm_response.tool_calls,
                    session_id=state.session_id,
                    plan_session_id=state.plan_session_id,
                    channel=None if meeting_goal_turn else channel,
                    channel_id=None if meeting_goal_turn else channel_id,
                    thread_id=None if meeting_goal_turn else thread_id,
                    metadata=metadata,
                    exclude_tools=exclude_tools,
                    user_message=user_message,
                    ephemeral_tools=state.include_inactive_tools,
                )

                for tc, result_str in results:
                    is_error = _is_tool_error_result(result_str)
                    state.last_tool_name = tc.name
                    state.last_tool_succeeded = not is_error
                    if is_error:
                        state.tool_failures += 1
                    else:
                        state.tool_successes += 1
                    tool_msg: dict[str, Any] = {
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": result_str,
                    }
                    if is_error:
                        tool_msg["is_error"] = True
                    rowid = await self._session_store.add_message(state.session_id, tool_msg)
                    if isinstance(rowid, int):
                        state.turn_rowids.append(rowid)
                    messages.append(tool_msg)

                    # Reset learning loop counter when memory/skill tools are used
                    if tc.name in ("memory", "skill_manage"):
                        self._turns_since_memory = 0

                # Event-loop promotion check — post-persist tool-batch boundary.
                # At this point ``state.turn_rowids`` holds the full set of
                # ``tool_use`` + ``tool_result`` rows for this batch (complete
                # pairs only, see ``docs/design/core/event-loop/02-architecture.md``
                # §2.3). If promotion fires it returns ``_PROMOTED_RECEIPT`` via
                # an early-return so the loop's final-persist step is bypassed
                # (D-receipt — the channel receipt is never persisted to main).
                if await self._maybe_promote_turn(state, llm_response):
                    state.exit = TurnExit.PROMOTED
                    # Record the carrier route as receipt-bearing so the
                    # publish boundary can flag ``is_promotion_receipt`` without
                    # string-matching the (possibly minimal/empty) receipt text.
                    # The receipt itself was resolved inside
                    # ``_promote_turn_to_worker`` (pre-adopt) and stashed on the
                    # state, so this return path stays await-free.
                    if state.channel_id:
                        self._promotion_receipt_routes.add(state.channel_id)
                    return state.promoted_receipt, state.streamed

                # Loop detection
                for tc, _ in results:
                    warning, should_terminate = loop_detector.check(tc.name, tc.arguments)
                    if should_terminate:
                        response_text = warning or "Loop detected — stopping."
                        break
                    if warning:
                        messages.append({"role": "system", "content": warning})
                else:
                    # Post-iteration compression
                    iteration += 1
                    msg_tokens = estimate_tokens(messages)
                    if self._compressor.should_compress(msg_tokens, context_limit):
                        # Pre-compression memory flush (Hermes-style)
                        await self._flush_memories_before_compression(
                            messages,
                            state.session_id,
                            channel=channel,
                            channel_id=channel_id,
                        )
                        cr = await self._compressor.compress(messages, current_tokens=msg_tokens)
                        messages = cr.messages
                        state.messages = messages
                        await self._persist_compacted(state.session_id, messages)
                        # See mid-loop branch above: rowids accumulated before
                        # this compaction now refer to rows that have been
                        # DELETE-then-INSERT'd. Reset so cap-race rollback /
                        # success-path prune use only post-compaction ids.
                        state.turn_rowids = []
                    continue

                break  # loop terminated
            else:
                # j. Text response → done
                response_text = llm_response.content or ""
                # streamed = final delivery confirmed (all chunks + done marker sent OK)
                streamed = final_delivered
                if not response_text.strip():
                    empty_final_retries += 1
                    can_retry_empty_final = empty_final_retries == 1 and (
                        budget.remaining > 0 or (grace_enabled and budget.grace_available)
                    )
                    if can_retry_empty_final:
                        logger.warning(
                            "Agent produced empty final response; requesting explicit "
                            "continuation/wrap-up session_id={} budget_remaining={} grace_available={}",
                            state.session_id,
                            budget.remaining,
                            budget.grace_available,
                        )
                        messages.append({"role": "system", "content": _EMPTY_FINAL_RESPONSE_PROMPT})
                        continue
                    logger.warning(
                        "Agent produced empty final response and cannot retry; returning "
                        "incomplete status session_id={} budget_remaining={} grace_available={}",
                        state.session_id,
                        budget.remaining,
                        budget.grace_available,
                    )
                    response_text = _EMPTY_FINAL_RESPONSE_FALLBACK
                    streamed = False
                self._flow_trace(
                    "turn.final_text",
                    len=len(response_text or ""),
                    streamed=streamed,
                    preview=(response_text or "")[:160],
                )
                break

        # 9. Persist final response
        if response_text:
            self._flow_trace("turn.persist_final", len=len(response_text), streamed=streamed)
            rowid = await self._session_store.add_message(
                state.session_id,
                {"role": "assistant", "content": response_text},
            )
            if isinstance(rowid, int):
                state.turn_rowids.append(rowid)

        # 10. Fire-and-forget memory consolidation. Skipped for a praesto tag exp
        # group turn so the group conversation never leaks into the lending
        # employee's personal MEMORY.md (group facts belong in group_memory).
        if self._memory and response_text and not praesto_tag_exp_active:
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._async_consolidate(messages, state.session_id))
            except RuntimeError:
                pass

        # 11. Terminal plan reconciliation (#718): when the agent produced a
        # final response without explicitly marking the last plan item
        # ``done``, the progress card stays stuck at N-1/N.  Auto-complete
        # and emit a final card so the user sees 100%.
        #
        # Only on a *clean* finish. A budget-exhausted wrap-up and the
        # empty-final fallback both end the turn with work still outstanding —
        # auto-completing there would paint 100% over a run that stopped short,
        # which is worse than the stuck card this fixes.
        clean_finish = budget.remaining > 0 and response_text != _EMPTY_FINAL_RESPONSE_FALLBACK
        if response_text and state.plan_session_id and clean_finish:
            await self._reconcile_plan_on_turn_end(state)

        state.streamed = streamed
        return response_text, streamed

    # ── Event-loop promotion (Step D, see docs/design/core/event-loop/) ──

    async def _maybe_promote_turn(self, state: _TurnState, llm_response: LLMResponse) -> bool:
        """Promote *state* to a detached worker session when eligible.

        Called from ``_drive_turn`` at the post-persist tool-batch boundary
        (after the assistant ``tool_use`` row AND every ``tool_result`` row
        for the batch have been written, see
        ``docs/design/core/event-loop/02-architecture.md`` §2.3). Returns
        ``True`` when the turn was promoted, so the caller can short-circuit
        with the receipt sentinel and skip the loop's final-persist step.

        Eligibility (D-trigger × D-channel × D-cap):

        * ``metadata.source`` is in ``event_loop_promotion_channels``
        * a manager exists and a worker slot is free (cap pre-check is
          intentionally cheap and side-effect free — see invariant in
          §02 §2.3: "no corruption path on cap-full")
        * not already promoted
        * a trigger fired: ``tool_batches >= main_turn_tool_budget`` (T-count)
          OR ``elapsed >= wall_clock_promote_s`` (T-time)
        """
        if state.promoted or (state.metadata and state.metadata.get("meeting_goal_turn")):
            return False

        source = str((state.metadata or {}).get("source") or "").strip().lower()
        physical_ingress = str((state.metadata or {}).get("physical_ingress") or "").strip().lower()
        if "a2a_task" in {source, physical_ingress}:
            # A2A task carriers already have their own long-running protocol:
            # the executor keeps the carrier open with task.progress heartbeats,
            # and the final carrier response is what the Gateway converts into
            # task.progress(done). Promoting here would resolve the carrier with
            # the background-task receipt and strand the real result locally.
            logger.debug(
                "event_loop.degrade_inline reason=a2a_task_protocol main={} tool_batches={}",
                state.session_id,
                state.tool_batches,
            )
            return False
        if source not in self._event_loop_promotion_channels:
            return False

        # Trigger evaluation (logical OR). 0 disables a trigger entirely.
        count_fired = (
            self._main_turn_tool_budget > 0 and state.tool_batches >= self._main_turn_tool_budget
        )
        elapsed = 0.0
        if state.started_monotonic is not None:
            elapsed = max(0.0, time.monotonic() - state.started_monotonic)
        time_fired = self._wall_clock_promote_s > 0 and elapsed >= self._wall_clock_promote_s
        if not (count_fired or time_fired):
            return False

        manager = self._bg_task_manager
        if manager is None:
            # Promotion configured but runtime never wired the manager; legacy
            # inline path is the only safe choice.
            logger.warning(
                "event_loop.degrade_inline reason={} main={} tool_batches={}",
                "no_manager",
                state.session_id,
                state.tool_batches,
            )
            return False

        # Cap pre-check BEFORE any mutation of the main session (D-cap: "no
        # corruption path"). ``adopt`` repeats the check internally for thread
        # safety, but checking first means a refused promotion leaves no
        # side-effect on main.
        if manager.pending_count >= manager._max_tasks:
            logger.warning(
                "event_loop.degrade_inline reason={} main={} pending={} cap={}",
                "worker_cap",
                state.session_id,
                manager.pending_count,
                manager._max_tasks,
            )
            return False

        trigger = "count" if count_fired else "time"
        return await self._promote_turn_to_worker(state, manager, trigger=trigger, elapsed=elapsed)

    async def _promote_turn_to_worker(
        self,
        state: _TurnState,
        manager: BackgroundTaskManager,
        *,
        trigger: str,
        elapsed: float,
    ) -> bool:
        """Execute the 9-step promotion (see §02 §2.3).

        Returns ``True`` on success (caller should early-return with the
        receipt sentinel), ``False`` when the underlying ``adopt`` refused
        (e.g. the manager closed between pre-check and call) — in which case
        any main-session pruning has been REVERTED and the loop continues
        inline as if no promotion was attempted.
        """
        main_session = state.session_id  # keep BEFORE swap — needed for logs / owner / fold-back
        pruned_rowids = list(state.turn_rowids)  # snapshot; turn_rowids will be reset below

        try:
            # 2. fork → worker session row (parent_session_id FK keeps lineage).
            worker = await self._session_store.fork(main_session)
            # 3. seed worker from MAIN's durable rows (already #394-clean).
            snapshot = await self._session_store.get_messages(main_session)
            await self._session_store.replace_messages(worker, snapshot, reason="fork_snapshot")
            # 4. capture the in-flight rows BEFORE pruning — needed only on
            #    the cap-race rollback path below. ``adopt()`` is in-process,
            #    so the window between this capture and the eventual restore
            #    is microseconds; we never see stale content here.
            pruned_messages: list[tuple[int, dict[str, Any], str | None]] = (
                await self._session_store.get_messages_by_rowids(main_session, pruned_rowids)
                if pruned_rowids
                else []
            )
            # 5. prune in-flight tool pairs from MAIN (delete_messages is the
            #    new primitive from Step B; an empty rowid list is a no-op).
            pruned_n = 0
            if pruned_rowids:
                pruned_n = await self._session_store.delete_messages(main_session, pruned_rowids)
        except Exception as exc:  # noqa: BLE001 — promotion is best-effort
            logger.error(
                "event_loop.promote_failed main={} reason={}",
                main_session,
                exc,
            )
            return False

        # 5/6. Defer the state mutations (``state.session_id = worker`` etc.)
        # to AFTER ``adopt()`` succeeds. The pre-fix code mutated state before
        # adopt and relied on the cap-race rollback path to put it back, but
        # that left two failure modes uncovered:
        #   • ``CancelledError`` mid-rollback leaks past ``except Exception``
        #     (Python 3.11+ has it as a ``BaseException`` subclass) so state
        #     could end up permanently swapped to the worker session.
        #   • A partial rollback (one ``add_message`` raised) wrote a partial
        #     ``restored_rowids`` into ``state.turn_rowids`` even though we
        #     had set ``state.turn_rowids = []`` upfront — losing the
        #     un-restored portion silently.
        # By only swapping state once adopt has actually accepted the worker,
        # the rollback path is a pure cleanup of MAIN sqlite rows and any
        # cancellation in the meantime leaves the in-memory turn state on
        # MAIN as if no promotion was attempted.

        # 7. adopt the continuation into the background lifecycle (timeout,
        # done-callback, proactive delivery). Cap pre-check above keeps us
        # from the rare "pruned but no slot" hazard.
        from praestoclaw.host.background_tasks import BackgroundOrigin

        origin = BackgroundOrigin(
            channel=ChannelType.of(str(state.channel)) if state.channel else ChannelType.INTERNAL,
            channel_id=state.channel_id or main_session,
            thread_id=state.thread_id,
            route_hint=state.route_hint,
            # Freeze the originating Teams conversation id so the fold-back
            # lands in the originating chat even after the route is forgotten
            # (issue #473). Present only for Teams turns; None elsewhere.
            # Strip so a whitespace-only cid coerces to None rather than a
            # truthy blank delivery key.
            teams_conversation_id=str((state.metadata or {}).get("cid") or "").strip() or None,
        )

        # ``_drive_turn`` returns ``(response_text, streamed)``; ``adopt``'s
        # coro_factory is typed as ``Callable[[], Awaitable[str]]`` because
        # ``BackgroundTask.result`` is the human-readable text that the
        # delivery / fold-back paths consume. The ``streamed`` flag is
        # turn-internal and not interesting once the worker is detached
        # (its eventual output is delivered proactively, never streamed),
        # so we strip it here. The closure captures ``state`` by reference;
        # we set ``state.session_id = worker`` AFTER ``adopt()`` returns
        # non-None but BEFORE the next ``await`` yield point, which is the
        # earliest moment ``_worker_run`` could be scheduled to run — so the
        # worker always sees ``session_id == worker`` when it re-enters
        # ``_drive_turn``.
        async def _worker_run(s: _TurnState = state) -> str:
            response_text, _streamed = await self._drive_turn(s)
            return response_text

        # Resolve the carrier receipt (and advance the adaptive ramp counter)
        # BEFORE ``adopt`` so every await on the promotion path runs pre-adopt.
        # ``adopt`` itself is synchronous and the caller does not await again
        # before inspecting worker state, so the worker is not scheduled until
        # then — tests (and the #181 carrier contract) rely on this ordering.
        # On the rare cap-race rollback below (``task_id is None``) the receipt
        # is simply unused; the ramp counter may advance by one, which is
        # harmless for a best-effort UX ramp.
        state.promoted_receipt = await self._render_promoted_receipt(state)

        task_id = manager.adopt(
            coro_factory=_worker_run,
            origin=origin,
            owner=main_session,
            question=state.user_message,
            label="promoted",
        )
        if task_id is None:
            # Race: cap filled between pre-check and adopt. MAIN was already
            # mutated by the pre-adopt snapshot/prune block above; we MUST
            # roll the prune back, otherwise the inline final-persist below
            # leaves a hole in durable history (the LLM sees its own answer
            # land on a session whose tool_use/tool_result rows have just
            # been deleted, and the assistant can't reason about a chain it
            # no longer sees). Reinsert each captured row in original order;
            # the `created_at` is preserved so forensic timelines stay intact
            # (matches the `replace_messages` pattern). New rowids are written
            # back into ``state.turn_rowids`` so any subsequent ``state``
            # mutation (e.g. final-persist appending its own rowid) treats
            # this turn as fully owned by MAIN again.
            #
            # On per-row failure, ``continue`` (not ``break``) so we attempt
            # every remaining row — losing 1 row to a transient store error
            # is better than losing 1 + everything that came after.
            restored_rowids: list[int] = []
            for _orig_rowid, msg, created_at in pruned_messages:
                try:
                    new_rowid = await self._session_store.add_message(
                        main_session, msg, created_at=created_at
                    )
                except Exception as exc:  # noqa: BLE001 — best-effort, but log loudly
                    logger.error(
                        "event_loop.cap_race_restore_failed main={} reason={}",
                        main_session,
                        exc,
                    )
                    continue
                if isinstance(new_rowid, int):
                    restored_rowids.append(new_rowid)
            if len(restored_rowids) < len(pruned_messages):
                # Partial restore is a serious operational signal — the
                # store rejected at least one row mid-rollback, leaving
                # MAIN with a hole the operator should investigate.
                logger.error(
                    "event_loop.cap_race_restore_partial main={} expected={} restored={}",
                    main_session,
                    len(pruned_messages),
                    len(restored_rowids),
                )
            logger.warning(
                "event_loop.degrade_inline reason={} main={} worker={} "
                "pruned_n={} restored_n={} "
                "note=cap_filled_between_precheck_and_adopt",
                "worker_cap_race",
                main_session,
                worker,
                pruned_n,
                len(restored_rowids),
            )
            # State was never swapped to the worker (we deferred the swap
            # until after ``adopt()`` succeeded). The caller continues inline
            # on MAIN with ``state.turn_rowids`` rebuilt from whatever rows
            # we successfully re-inserted. The worker session is left behind
            # as a benign forked row.
            state.turn_rowids = restored_rowids
            return False

        # adopt succeeded — NOW swap the state to the worker session.
        state.session_id = worker
        state.promoted = True
        state.turn_rowids = []

        # 8. stash the channel's ↩️ quote (fold-back path consumes it).
        self._stash_promotion_quote(state)

        # 9. Plan A — orphan-prevention ack row.
        # Promotion's load-bearing invariant ("main only contains complete
        # turns") used to be violated for the model's view of the world: a
        # promoted turn left main ending on an answer-less ``user-A`` row,
        # and the LLM on the next turn read that as "I still owe an answer
        # to A" → it kept running A's tool chain. The prod incident
        # (2026-06-14 11:21–11:28) showed this as 3 workers redoing the
        # same ADO query.
        #
        # Plan A fixes it by appending ONE ``role=assistant`` row whose
        # content begins with ``[BG task=<id>]`` — a stable, machine-
        # readable sentinel telling the model "this user request was
        # handed off; do NOT continue it". Properties:
        #   • role=assistant, no tool_calls → no #345 anti-pattern
        #   • carries the real ``task_id`` so future compaction / startup-
        #     reaper logic can correlate the row with a (live | dead) task
        #   • the config-controlled carrier receipt is independent — this ack
        #     row is for the LLM's durable-history view, while the receipt
        #     (empty by default) is only for the channel transport / human UX
        # Append AFTER ``adopt`` so the row is only written once a worker
        # genuinely owns the task. If the row write itself fails we log
        # and continue — the worker is already adopted, the channel
        # delivery still works, the only loss is orphan-prevention on
        # this one turn.
        try:
            ack_row = self._build_promotion_ack_row(state, task_id)
            await self._session_store.add_message(main_session, ack_row)
        except Exception as exc:  # noqa: BLE001 — ack write is best-effort
            logger.warning(
                "event_loop.ack_write_failed main={} task_id={} reason={}",
                main_session,
                task_id,
                exc,
            )

        logger.info(
            "event_loop.promote main={} worker={} task_id={} trigger={} "
            "tool_batches={} pruned_rowids_n={} elapsed_s={:.2f}",
            main_session,
            worker,
            task_id,
            trigger,
            state.tool_batches,
            pruned_n,
            elapsed,
        )
        logger.info(
            "event_loop.adopt task_id={} owner={} lane=subagent",
            task_id,
            main_session,
        )
        return True

    def _stash_promotion_quote(self, state: _TurnState) -> None:
        """Best-effort stash of the user's question into the channel quote map.

        The cloud channel's ``_remember_timeout_quote`` maps a request_id →
        original user text; when a late proactive reply is sent, ``send()``
        pops the entry and prefixes the answer with ``↩️ Re your earlier
        question "…"``. Step F wires the fold-back path through this map; we
        seed it here at promotion so the bookkeeping is done while the
        question is still in hand.

        Resolution order:
          1. ``self._channel_resolver(state.channel)`` — runtime-injected
             ``channel_manager.get``. This is the production path: it returns
             the real ``CloudChannel`` instance whose
             ``_remember_timeout_quote`` actually accepts the entry.
          2. ``state.channel`` directly — only useful when callers pass a
             channel *instance* (legacy / some tests). When ``state.channel``
             is a ``ChannelType`` enum (the typical case), ``getattr`` returns
             ``None`` and the stash silently no-ops, which is exactly the prod
             2026-06-14 13:07 regression — the helper looked plausible but
             never reached the channel and every fold-back lost its ↩️
             envelope. Keep the fallback for legacy callers but rely on the
             resolver for production correctness.
        """
        channel_id = state.channel_id
        if not channel_id:
            return
        target: Any = None
        if self._channel_resolver is not None and state.channel is not None:
            try:
                target = self._channel_resolver(state.channel)
            except Exception as exc:  # noqa: BLE001 — resolver lookup is non-essential
                logger.debug("event_loop.channel_resolver_failed: {}", exc)
                target = None
        if target is None:
            target = state.channel
        if target is None:
            return
        helper = getattr(target, "_remember_timeout_quote", None)
        if helper is None:
            return
        try:
            helper(channel_id, state.user_message)
        except Exception as exc:  # noqa: BLE001 — quote stash is non-essential
            logger.debug("event_loop.quote_stash_failed: {}", exc)

    async def _render_promoted_receipt(self, state: _TurnState) -> str:
        """Build the carrier-visible "I'm working on it" placeholder.

        Verbosity follows ``ExecutionConfig.background_task_receipt``:

        * ``"adaptive"`` — ramp down per user: full for the first
          ``_ADAPTIVE_FULL_LIMIT`` promotions, minimal up to
          ``_ADAPTIVE_MINIMAL_LIMIT`` (cumulative), then silent. The count is
          durable per user (``SessionStore`` ``counters``).
        * ``"full"`` — always the complete educational handoff copy.
        * ``"minimal"`` — always a terse one-liner.
        * ``"silent"`` (default) — empty string; no visible receipt is posted (the
          carrier reply is empty, which the Teams bridge renders as
          "nothing to post"). The user only sees the eventual fold-back.

        Bilingual (zh / en) heuristic mirrors the cloud channel's
        ``_pick_long_task_placeholder`` so the user sees a consistent voice
        whether the receipt is rendered here (promotion) or there (legacy
        carrier timeout). Returned to the caller as the receipt; it is NEVER
        persisted to the main session (D-receipt).

        NOTE: the returned text is intentionally NOT the signal used to set
        ``is_promotion_receipt`` downstream — that flag is keyed on
        ``_promotion_receipt_routes`` so it survives the empty ``"silent"``
        body and any future copy change. Called once per promotion ATTEMPT,
        BEFORE ``adopt()`` (the call site resolves the receipt pre-adopt so
        every await on the promotion path runs before the worker is
        scheduled). On the rare cap-race rollback (``adopt`` returns ``None``)
        the rendered receipt goes unused and the adaptive ramp counter may
        advance by one — an accepted, harmless over-count for a best-effort
        UX ramp.
        """
        mode: str = self._background_task_receipt
        if mode == "adaptive":
            mode = await self._resolve_adaptive_receipt_mode(state)
        if mode == "silent":
            return ""
        is_zh = contains_cjk(state.user_message or "")
        if mode == "minimal":
            return _PROMOTED_RECEIPT_MINIMAL_ZH if is_zh else _PROMOTED_RECEIPT_MINIMAL_EN
        return _PROMOTED_RECEIPT_ZH if is_zh else _PROMOTED_RECEIPT_EN

    async def _resolve_adaptive_receipt_mode(self, state: _TurnState) -> str:
        """Resolve the adaptive ramp to a concrete mode for THIS promotion.

        Increments a durable per-user counter and maps it:
        ``1..N`` → full, ``N+1..M`` → minimal, ``>M`` → silent (N/M are
        ``_ADAPTIVE_FULL_LIMIT`` / ``_ADAPTIVE_MINIMAL_LIMIT``). The user key is
        the session's ``sender`` (stable identity); if it can't be resolved or
        the store errors, we fail safe to ``"full"`` (the most informative copy)
        rather than silently dropping the receipt.
        """
        try:
            sender = await self._session_store.get_session_sender(state.session_id)
            user_key = sender or state.session_id
            count = await self._session_store.increment_counter(f"promotion_receipt:{user_key}")
        except Exception as exc:  # noqa: BLE001 — adaptive ramp is best-effort
            logger.debug("event_loop.adaptive_receipt_count_failed: {}", exc)
            return "full"
        if count <= _ADAPTIVE_FULL_LIMIT:
            return "full"
        if count <= _ADAPTIVE_MINIMAL_LIMIT:
            return "minimal"
        return "silent"

    @staticmethod
    def _build_promotion_ack_row(state: _TurnState, task_id: str) -> dict[str, Any]:
        """Build the orphan-prevention ack row appended to main at promotion.

        See ``_PROMOTION_ACK_SENTINEL_PREFIX`` for the contract: the row's
        ``content`` begins with ``[BG task=<task_id>]`` so the LLM (and
        downstream sanitizers / compactors) can identify it. zh/en branch
        is keyed by the question's CJK content (mirrors
        ``_render_promoted_receipt`` and ``_prefix_reply_quote``).
        """
        question = state.user_message or ""
        snippet = truncate_ellipsis(question.strip(), REPLY_QUOTE_SNIPPET_MAX)
        is_zh = contains_cjk(question)
        template = _PROMOTION_ACK_TEMPLATE_ZH if is_zh else _PROMOTION_ACK_TEMPLATE_EN
        content = template.format(
            sentinel=_PROMOTION_ACK_SENTINEL_PREFIX,
            task_id=task_id,
            snippet=snippet,
        )
        return {"role": "assistant", "content": content}

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _call_llm(
        self,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        *,
        channel: Any = None,
        channel_id: str | None = None,
        session_id: str | None = None,
    ) -> tuple[LLMResponse, bool]:
        """Call provider — complete() when tools enabled, stream() for text-only.

        Returns (LLMResponse, final_delivered) where final_delivered is True
        only when ALL streaming chunks AND the done=True marker were successfully
        dispatched to an external delivery channel. If any dispatch fails or if the stream
        errors mid-way, final_delivered is False and the caller should send a
        full OutboundMessage as fallback.

        The done marker is always sent in a finally block.
        """
        # Forward the agent's configured reasoning_effort (e.g. "high" thinking)
        # to the provider. Providers/models that don't support it ignore the value.
        reasoning_effort = getattr(self._config, "reasoning_effort", None)
        provider_started = time.monotonic()

        def _audit_provider(*, is_error: bool = False, error: str | None = None) -> None:
            if not self._audit or not session_id:
                return
            self._audit.log_event(
                action="agent:provider",
                data={
                    "model": model,
                    "is_error": is_error,
                    "error": sanitize_diagnostic_text(error or "", max_chars=2000)
                    if error
                    else None,
                    "duration_ms": (time.monotonic() - provider_started) * 1000,
                    "session_id": session_id,
                    "conversation_session_id": session_id,
                },
            )

        self._flow_trace(
            "llm.start",
            model=model,
            tools_enabled=bool(tools),
            message_count=len(messages),
            channel=str(channel) if channel is not None else None,
            channel_id=channel_id,
            reasoning_effort=reasoning_effort,
        )
        if tools:
            try:
                response = await self._provider.complete(
                    model=model,
                    messages=messages,
                    tools=tools,
                    reasoning_effort=reasoning_effort,
                )
            except Exception as exc:
                _audit_provider(is_error=True, error=f"{type(exc).__name__}: {exc}")
                raise
            _audit_provider()
            self._flow_trace(
                "llm.end",
                model=response.model or model,
                finish_reason=response.finish_reason,
                tool_calls=len(response.tool_calls),
                content_len=len(response.content or ""),
                content_preview=(response.content or "")[:120],
            )
            return response, False

        # Streaming for text-only responses
        content_parts: list[str] = []
        finish_reason = "stop"
        any_chunk_sent = False
        any_dispatch_failed = False
        done_dispatched = False
        stream_error = False
        chunk_count = 0

        try:
            async for chunk in self._provider.stream(
                model=model,
                messages=messages,
                tools=None,
                reasoning_effort=reasoning_effort,
            ):
                chunk_count += 1
                if chunk.content:
                    content_parts.append(chunk.content)
                    self._flow_trace(
                        "llm.chunk",
                        idx=chunk_count,
                        len=len(chunk.content),
                        preview=chunk.content[:120],
                    )
                    if channel and channel_id and channel != ChannelType.INTERNAL:
                        try:
                            delivered = await self._reply_dispatcher.publish_stream_chunk(
                                channel=channel,
                                channel_id=channel_id or "",
                                content=chunk.content,
                                done=False,
                            )
                            if delivered:
                                any_chunk_sent = True
                            else:
                                any_dispatch_failed = True
                        except Exception:
                            any_dispatch_failed = True
                if chunk.finish_reason:
                    finish_reason = chunk.finish_reason
                    self._flow_trace(
                        "llm.finish_reason",
                        idx=chunk_count,
                        finish_reason=chunk.finish_reason,
                    )
        except Exception as exc:
            stream_error = True
            self._flow_trace("llm.error", stage="stream", error="stream iteration failed")
            _audit_provider(is_error=True, error=f"{type(exc).__name__}: {exc}")
            raise
        finally:
            if any_chunk_sent:
                try:
                    done_dispatched = await self._reply_dispatcher.publish_stream_chunk(
                        channel=channel,
                        channel_id=channel_id or "",
                        content="",
                        done=True,
                    )
                    if not done_dispatched:
                        any_dispatch_failed = True
                except Exception:
                    any_dispatch_failed = True
            self._flow_trace(
                "llm.done_marker",
                sent=done_dispatched,
                any_chunk_sent=any_chunk_sent,
                dispatch_failed=any_dispatch_failed,
            )

        # final_delivered = all chunks sent successfully + done marker sent + no errors
        response_content = "".join(content_parts)
        final_delivered = (
            any_chunk_sent
            and done_dispatched
            and bool(response_content.strip())
            and not any_dispatch_failed
            and not stream_error
        )
        self._flow_trace(
            "llm.end",
            model=model,
            finish_reason=finish_reason,
            tool_calls=0,
            content_len=len(response_content),
            chunks=chunk_count,
            final_delivered=final_delivered,
        )
        _audit_provider()

        return LLMResponse(
            content=response_content,
            finish_reason=finish_reason,
            model=model,
        ), final_delivered

    # ── Context assembly ──────────────────────────────────────────────────
    #
    # Delegates to PromptBuilder (praestoclaw/agent/prompt_builder.py).
    # See that module's docstring for the full build order.
    #

    def _build_system_prompt(
        self,
        *,
        include_personal_context: bool = True,
        exclude_tool_guidance: Iterable[str] | None = None,
        include_skills: bool = True,
        include_confirm_gate_guidance: bool = True,
    ) -> str:
        """Assemble the system prompt via PromptBuilder.

        ``include_personal_context`` is threaded to
        :meth:`PromptBuilder.build_system_prompt`; a praesto tag exp group turn
        passes ``False`` so the shared/public digital-employee mock never leaks
        the lending employee's SOUL/USER/MEMORY into a borrowed-identity turn.

        ``exclude_tool_guidance`` names tools whose behavioural guidance must be
        suppressed even though the tool is still in the registry — a group turn
        excludes ``memory``/``search_history`` from the callable schema, so their
        prompt guidance ("save durable facts using the memory tool") must go too,
        or the model reaches for a tool it cannot call (and tries to re-enable it
        via the ``tools`` meta-tool, tripping a borrowed-identity approval).
        """
        return self._prompt_builder.build_system_prompt(
            mode=self._prompt_mode,
            include_personal_context=include_personal_context,
            exclude_tool_guidance=exclude_tool_guidance,
            include_skills=include_skills,
            include_confirm_gate_guidance=include_confirm_gate_guidance,
        )

    def _build_attachment_context(self, metadata: dict[str, Any] | None) -> str:
        if not _has_pending_attachments(metadata):
            return ""
        refs = _AttachmentResolver().list_current(metadata)
        if not refs:
            return ""

        pending_images = (metadata or {}).get("pending_images") or {}
        errors = pending_images.get("errors") if isinstance(pending_images, dict) else []
        image_urls = pending_images.get("urls") if isinstance(pending_images, dict) else []
        prompt_safe_image_urls: set[str] = (
            {url.strip() for url in image_urls if isinstance(url, str) and url.strip()}
            if isinstance(image_urls, list)
            else set()
        )
        has_successful_image_url = bool(prompt_safe_image_urls)
        err_note = (
            f" ({len(errors)} image upload(s) failed)"
            if errors and not has_successful_image_url
            else ""
        )
        lines = [
            f"[attachments: {len(refs)} file(s)/image(s) attached by user; "
            f"use attachment_process if attachment content is needed{err_note}]"
        ]
        for ref in refs:
            bits = [f"{ref.index}. {ref.kind}"]
            if ref.name:
                bits.append(f"name={ref.name}")
            if ref.file_type:
                bits.append(f"file_type={ref.file_type}")
            if ref.content_type:
                bits.append(f"content_type={ref.content_type}")
            # Only surface URLs that were republished via the public image host
            # (i.e. present in pending_images.urls). Raw Teams/SharePoint signed
            # URLs stay hidden — the model can still read content via
            # attachment_process. See PR #325 review comment.
            if ref.kind == "image" and not ref.requires_auth and ref.url in prompt_safe_image_urls:
                bits.append(f"url={ref.url}")
            else:
                bits.append("url=hidden; available via attachment_process")
            lines.append("  - " + "; ".join(bits))
        return "\n".join(lines)

    def _assemble_messages(
        self,
        system: str,
        history: list[dict[str, Any]],
        user_msg: dict[str, Any],
    ) -> list[dict[str, Any]]:
        # Filter session history to LLM-acceptable roles only. Non-LLM
        # records (``approval_request`` / ``approval_resolved`` and other
        # UI-only metadata) live in the session JSONL so the Web UI can
        # render them, but they MUST NOT be sent to the model:
        #
        #   - OpenAI/compatible providers reject unknown roles outright.
        #   - Other SDKs silently coerce unknown roles to "user", which
        #     plants the raw approval JSON (including ``resolved_card``,
        #     adaptive-card body, agent reasoning) into the model's
        #     context. The model then echoes / paraphrases that JSON in
        #     its next reply, which surfaces in Teams as a ~2 KB blob of
        #     plain text alongside the resolved card. See issue #84.
        #
        # ``is_error`` is dropped only for ``role == "user"`` (UI-only
        # echoes of failed user messages). Tool error results are kept:
        # the model needs to see prior tool failures to recover.
        from praestoclaw.session.store import LLM_ROLES

        history = [
            m
            for m in history
            if m.get("role") in LLM_ROLES and not (m.get("role") == "user" and m.get("is_error"))
        ]
        messages = [{"role": "system", "content": system}, *history, user_msg]
        return sanitize_tool_messages(messages)

    def _match_workflow_recipe(self, user_message: str) -> str:
        """Recipe whose declared subject covers this turn, else "".

        Recall-oriented on purpose. This decides only WHICH recipe is topically
        relevant; whether the user is actually asking for it to be run is left to
        the model, which sees the whole turn (see ``_recipe_route_block``). So a
        near-miss here is cheap and a miss is not: failing to match reproduces the
        original bug, where the ``workflow`` tool was absent from the schema and
        the model could not run a recipe even when plainly asked to.

        Still gated on the recipe's own ``metadata.activation.patterns`` so a
        recipe opts in to being routed to and names its own subject, rather than
        every recipe competing on generic token overlap.

        Best-effort: a missing provider, a recipe without patterns, or any error
        simply means no routing — never a failed turn.
        """
        if self._recipes_provider is None or not user_message.strip():
            return ""
        try:
            recipes = self._recipes_provider() or {}
        except Exception:  # noqa: BLE001 - routing is best-effort
            return ""
        best_name, best_score, tied = "", 0, False
        for name, recipe in recipes.items():
            patterns = getattr(recipe, "patterns", None)
            if not patterns:
                continue  # a recipe opts in to routing by declaring patterns
            try:
                # Keywords alone must NEVER route: two topical keywords reach the
                # threshold by themselves, so every recipe sharing a common word
                # would match every turn. A declared pattern has to hit first.
                if not any(pat.search(user_message) for pat in patterns):
                    continue
                score = int(recipe.score(user_message))
            except Exception as exc:  # noqa: BLE001 - one bad recipe must not break the turn
                logger.debug("recipe_route.score_failed recipe={} err={}", name, exc)
                continue
            if score > best_score:
                best_name, best_score, tied = str(name), score, False
            elif score == best_score and score > 0 and str(name) != best_name:
                tied = True
        if tied:
            # Two recipes match equally well. Picking one would depend on the
            # provider's iteration order (i.e. the filesystem). Abstain — the
            # model still sees every recipe name in the inactive-tool summary.
            logger.debug("recipe_route.ambiguous score={} first={}", best_score, best_name)
            return ""
        return best_name if best_score >= _RECIPE_ROUTE_THRESHOLD else ""

    def _get_tool_schemas(
        self,
        exclude_tools: list[str] | None = None,
        *,
        metadata: dict[str, Any] | None = None,
        include_inactive: list[str] | None = None,
    ) -> list[dict[str, Any]] | None:
        allowed = self._config.tools or None
        group_mcp_names = self._group_mcp_tool_names(metadata)
        if allowed and group_mcp_names:
            allowed = list(dict.fromkeys([*allowed, *group_mcp_names]))
        # Per-agent memory_writable enforcement
        exclude = list(exclude_tools or [])
        if not getattr(self._config, "memory_writable", True):
            exclude.append("memory")
        if not _has_pending_attachments(metadata):
            exclude.append("attachment_process")
        if not (metadata and metadata.get("praesto_tag_exp")):
            hidden = set(_PRAESTO_TAG_EXP_ONLY_BUILTIN_TOOLS_SET)
            if _kb_curation_is_active(metadata):
                hidden -= set(_PRAESTO_KB_CURATION_BUILTIN_TOOLS_SET)
            exclude.extend(sorted(hidden))
        exact_exclude = [name for name in exclude if not name.endswith("*")]
        schemas = self._tool_registry.get_schemas(
            allowed,
            exclude=exact_exclude or None,
            include_inactive=list(
                dict.fromkeys(
                    [
                        *(include_inactive or []),
                        *self._group_skill_safe_tool_names(metadata),
                        *self._group_mcp_tool_names(metadata),
                    ]
                )
            ),
        )
        schemas = [
            schema
            for schema in schemas
            if not self._tool_excluded(
                str(schema.get("function", {}).get("name", "")),
                exclude,
            )
        ]
        if metadata and metadata.get("praesto_tag_exp"):
            schemas = [
                schema
                for schema in schemas
                if praesto_tag_exp_tool_is_exposed(
                    str(schema.get("function", {}).get("name", "")),
                    group_skill_safe_tools=(
                        metadata.get("group_skill_safe_tools")
                        if isinstance(metadata.get("group_skill_safe_tools"), list)
                        else None
                    ),
                    group_mcp_tool_names=self._group_mcp_tool_names(metadata),
                )
            ]
        if not schemas:
            return None
        return list(schemas)

    @staticmethod
    def _group_skill_safe_tool_names(metadata: dict[str, Any] | None) -> list[str]:
        if not metadata or not metadata.get("praesto_tag_exp"):
            return []
        entries = metadata.get("group_skill_safe_tools")
        if not isinstance(entries, list):
            return []
        return [
            str(entry.get("tool"))
            for entry in entries
            if isinstance(entry, dict) and str(entry.get("tool") or "")
        ]

    @staticmethod
    def _group_mcp_tool_names(metadata: dict[str, Any] | None) -> list[str]:
        if not metadata or not metadata.get("praesto_tag_exp"):
            return []
        names = metadata.get("group_mcp_tool_names")
        return [str(name) for name in names] if isinstance(names, list) else []

    @staticmethod
    def _metadata_for_tool(
        tool_name: str,
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        """Return the tool-visible metadata view for one tool call.

        Attachment URLs are runtime-private adapter data. Only
        ``attachment_process`` receives them; other tools receive provenance
        and control metadata without current-turn attachment URL payloads.
        """
        if metadata is None:
            return None
        if tool_name in {"attachment_process", "mcp"}:
            return metadata
        return {
            key: value
            for key, value in metadata.items()
            if key not in {"pending_images", "pending_attachments"}
        }

    @staticmethod
    def _tool_excluded(name: str, exclude_tools: list[str] | None) -> bool:
        for pattern in exclude_tools or []:
            if pattern.endswith("*") and name.startswith(pattern[:-1]):
                return True
            if name == pattern:
                return True
        return False

    def _resolve_context_limit(self) -> int:
        return self._config.context_limit or _DEFAULT_CONTEXT_LIMIT

    def _response_to_message(self, response: LLMResponse) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": "assistant"}
        if response.content:
            msg["content"] = response.content
        if response.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.name,
                        "arguments": json.dumps(tc.arguments, ensure_ascii=False)
                        if isinstance(tc.arguments, dict)
                        else tc.arguments,
                    },
                }
                for tc in response.tool_calls
            ]
        return msg

    async def _preflight_tool_call(
        self,
        tc: ToolCallRequest,
        *,
        session_id: str | None,
        plan_session_id: str | None = None,
        channel: Any,
        channel_id: str | None,
        metadata: dict[str, Any] | None,
        exclude_tools: list[str] | None,
        user_message: str = "",
        ephemeral_tools: list[str] | None = None,
    ) -> tuple[str | None, str | None]:
        """Shared execution gate for model and runtime-initiated tool calls."""
        # An explicitly disabled tool must not run, whoever asked. get_schemas
        # already refuses to show one, but a hallucinated or provider-replayed
        # call would otherwise reach execute(), which only skips auto-activation.
        # Duck-typed registry: a scoped/mock registry may not expose it.
        _is_disabled = getattr(self._tool_registry, "is_disabled", None)
        if callable(_is_disabled) and _is_disabled(tc.name):
            logger.warning("Tool '{}' blocked at execution time: explicitly disabled", tc.name)
            return "disabled", (
                f"Tool {tc.name!r} is disabled. Do NOT retry this tool. "
                "Ask the user to re-enable it if it is genuinely needed."
            )
        allowed_tools = self._resolve_allowed_tools(exclude_tools, include_inactive=ephemeral_tools)

        if allowed_tools is not None and tc.name not in allowed_tools:
            logger.warning("Tool '{}' blocked by allowlist at execution time", tc.name)
            if self._audit:
                self._audit.log_security(
                    event="tool_blocked_by_allowlist",
                    details={
                        "tool": tc.name,
                        "session_id": session_id,
                        "conversation_session_id": plan_session_id or session_id,
                    },
                    severity="warning",
                )
            return (
                "allowlist",
                f"Tool '{tc.name}' is not available for this agent. Do NOT retry this tool.",
            )

        if tc.name == "memory" and not getattr(self._config, "memory_writable", True):
            logger.warning("Memory tool blocked: memory_writable=false")
            return (
                "memory_writable",
                "Memory writes are disabled for this agent (memory_writable=false).",
            )

        if self._hooks:
            _tool = (
                self._tool_registry.get(tc.name) if hasattr(self._tool_registry, "get") else None
            )
            _user_msgs: list[str] = [user_message] if user_message else []
            if not _user_msgs and session_id:
                try:
                    _all = await self._session_store.get_messages(session_id)
                    _user_msgs = [
                        m["content"] for m in _all if m.get("role") == "user" and m.get("content")
                    ][-3:]
                except Exception:
                    pass
            _user_msgs = [redact_credentials(m) for m in _user_msgs]

            tool_metadata = self._metadata_for_tool(tc.name, metadata)
            pre_ctx = PreToolHookContext(
                tool_name=tc.name,
                args=tc.arguments,
                agent_name=self._config.name,
                session_id=session_id or "",
                tool_call_id=tc.id,
                tool_ref=_tool,
                channel=channel if isinstance(channel, ChannelType) else None,
                channel_id=str(channel_id or ""),
                user_messages=_user_msgs,
                metadata=tool_metadata or {},
            )
            pre_result = await self._hooks.dispatch_checked("pre_tool_use", pre_ctx)
            if pre_result.verdict == HookVerdict.REJECT:
                logger.warning("Tool '{}' blocked by hook: {}", tc.name, pre_result.reason)
                if self._audit:
                    self._audit.log_event(
                        action="agent:hook_reject",
                        data={
                            "status": "pre tool use rejected",
                            "tool": tc.name,
                            "session_id": session_id,
                            "conversation_session_id": plan_session_id or session_id,
                        },
                    )
                return (
                    "hook_reject",
                    f"Tool '{tc.name}' blocked by security policy: {pre_result.reason}\n"
                    "Do NOT retry this tool. Inform the user it was blocked.",
                )

        return None, None

    async def _execute_internal_tool_call(
        self,
        tc: ToolCallRequest,
        *,
        session_id: str | None = None,
        plan_session_id: str | None = None,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        user_message: str = "",
    ) -> str | None:
        """Execute a runtime-created tool call after the normal safety gates."""
        blocked_by, block_message = await self._preflight_tool_call(
            tc,
            session_id=session_id,
            plan_session_id=plan_session_id,
            channel=channel,
            channel_id=channel_id,
            metadata=metadata,
            exclude_tools=exclude_tools,
            user_message=user_message,
        )
        if blocked_by is not None:
            logger.debug(
                "event_loop.internal_tool skipped tool={} reason={} message={}",
                tc.name,
                blocked_by,
                truncate_ellipsis(block_message or "", 200),
            )
            return None

        exec_args = dict(tc.arguments)
        async with tool_resource_lock(tc.name, exec_args, workspace=self._workspace):
            result: str = await self._tool_registry.execute(
                tc.name,
                exec_args,
                actor="agent",
                session_id=session_id,
                plan_session_id=plan_session_id,
                bus=self._bus,
                channel=channel,
                channel_id=channel_id,
                thread_id=thread_id,
                metadata=self._metadata_for_tool(tc.name, metadata),
                tool_call_id=tc.id,
            )
        return result

    async def _execute_tools(
        self,
        tool_calls: list[ToolCallRequest],
        *,
        session_id: str | None = None,
        plan_session_id: str | None = None,
        channel: Any = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        exclude_tools: list[str] | None = None,
        user_message: str = "",
        ephemeral_tools: list[str] | None = None,
    ) -> list[tuple[ToolCallRequest, str]]:
        """IronClaw 3-phase tool execution pipeline.

        ``ephemeral_tools`` are names exposed for THIS turn only (see
        ``get_schemas(include_inactive=...)``). Calling one must not add it to
        the registry's shared activation set, or the per-turn exception would
        become permanent the first time the model takes it up.

        Phase 1 (Preflight, sequential): allowlist enforcement + pre_tool_use hooks
        Phase 2 (Execute, parallel when safe): actual tool invocation
        Phase 3 (Postflight, sequential): post_tool_use hooks → redaction → truncation
        """
        import time

        ephemeral_tools = list(
            dict.fromkeys([*(ephemeral_tools or []), *self._group_mcp_tool_names(metadata)])
        )

        # Telemetry ids set by ChannelTurnKernel and threaded through metadata.
        _telemetry_turn_id: str | None = None
        _telemetry_session_id: str | None = None
        if isinstance(metadata, dict):
            _val = metadata.get("telemetry_turn_id")
            if isinstance(_val, str) and _val:
                _telemetry_turn_id = _val
            _val = metadata.get("telemetry_session_id")
            if isinstance(_val, str) and _val:
                _telemetry_session_id = _val

        # Phase 1: Preflight — enforce allowlist + pre_tool_use hooks (sequential)
        approved: list[tuple[ToolCallRequest, str | None]] = []  # (tc, blocked_by or None)
        preflight_results: dict[str, str] = {}  # tc.id → error msg for blocked tools

        for tc in tool_calls:
            logger.info("Tool call: {}({})", tc.name, list(tc.arguments.keys()))
            blocked_by, block_message = await self._preflight_tool_call(
                tc,
                session_id=session_id,
                plan_session_id=plan_session_id,
                channel=channel,
                channel_id=channel_id,
                metadata=metadata,
                exclude_tools=exclude_tools,
                user_message=user_message,
                ephemeral_tools=ephemeral_tools,
            )
            if blocked_by is not None and block_message is not None:
                preflight_results[tc.id] = block_message
            approved.append((tc, blocked_by))

        # Phase 2: Execute — parallel for independent tools
        async def _exec_one(tc: ToolCallRequest) -> str:
            tool_start = time.monotonic()
            self._flow_trace(
                "tool.start",
                tool=tc.name,
                arg_keys=sorted(tc.arguments.keys()) if isinstance(tc.arguments, dict) else [],
            )
            try:
                # Copy args to prevent ToolRegistry.execute() from mutating
                # the original tc.arguments (it injects _channel, _metadata etc.)
                # which would pollute loop detection arg comparison and tracing.
                exec_args = dict(tc.arguments)
                if tc.name in {"attachment_process", "image_compare", "video_evidence"}:
                    exec_args["_model"] = self._config.model
                if tc.name == "attachment_process":
                    exec_args["_user_message"] = user_message
                if tc.name == "meeting_automation":
                    exec_args["_original_message"] = user_message
                    exec_args["_tool_call_id"] = tc.id
                async with tool_resource_lock(tc.name, exec_args, workspace=self._workspace):
                    result: str = await self._tool_registry.execute(
                        tc.name,
                        exec_args,
                        actor="agent",
                        session_id=session_id,
                        plan_session_id=plan_session_id,
                        bus=self._bus,
                        channel=channel,
                        channel_id=channel_id,
                        thread_id=thread_id,
                        metadata=self._metadata_for_tool(tc.name, metadata),
                        tool_call_id=tc.id,
                        ephemeral=ephemeral_tools,
                    )
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=int((time.monotonic() - tool_start) * 1000),
                    success=not _is_tool_error_result(result),
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
                self._flow_trace(
                    "tool.end",
                    tool=tc.name,
                    ok=not _is_tool_error_result(result),
                    duration_ms=int((time.monotonic() - tool_start) * 1000),
                    result_len=len(result or ""),
                    result_preview=(result or "")[:120],
                )
                return result
            except Exception as e:
                logger.error("Tool {} failed: {}", tc.name, e)
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=int((time.monotonic() - tool_start) * 1000),
                    success=False,
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
                return f"Error: {e}"

        runnable = [tc for tc, blocked_by in approved if blocked_by is None]
        # Emit a tool_invoked row for every preflight-blocked tool so the
        # blocked_by dimension shows up in dashboards (success=false implicit).
        for tc, blocked_by in approved:
            if blocked_by is not None:
                _emit_tool_invoked(
                    tool_name=tc.name,
                    duration_ms=0,
                    success=False,
                    blocked_by=blocked_by,
                    turn_id=_telemetry_turn_id,
                    session_id=_telemetry_session_id,
                )
                self._flow_trace("tool.blocked", tool=tc.name, blocked_by=blocked_by)
        exec_results: dict[str, tuple[str, float]] = {}  # tc.id → (result, duration_ms)

        if runnable:
            exec_start = time.monotonic()
            raw_results = await self._parallelizer.execute_batch(runnable, _exec_one)
            duration = (time.monotonic() - exec_start) * 1000
            per_tool_ms = duration / len(runnable) if runnable else 0
            for tc_id, result_str in raw_results:
                exec_results[tc_id] = (result_str, per_tool_ms)

        # Phase 3: Postflight — post_tool_use hooks → redaction → truncation (sequential)
        final_results: list[tuple[ToolCallRequest, str]] = []

        for tc, blocked_by in approved:
            if blocked_by is not None:
                final_results.append(
                    (tc, preflight_results.get(tc.id, f"Tool '{tc.name}' blocked."))
                )
                continue

            result, duration_ms = exec_results.get(tc.id, ("", 0.0))

            # post_tool_use hook BEFORE redaction (leak scanner needs raw output)
            if self._hooks:
                post_ctx = PostToolHookContext(
                    tool_name=tc.name,
                    args=tc.arguments,
                    result=result,
                    success=not _is_tool_error_result(result),
                    agent_name=self._config.name,
                    session_id=session_id or "",
                    tool_call_id=tc.id,
                    duration_ms=duration_ms,
                    channel=channel if isinstance(channel, ChannelType) else None,
                    channel_id=str(channel_id or ""),
                    metadata=metadata or {},
                )
                hook_result = await self._hooks.dispatch_checked("post_tool_use", post_ctx)
                if hook_result.data and isinstance(hook_result.data, PostToolHookContext):
                    result = hook_result.data.result

            # Redact secrets AFTER hooks inspected raw output
            result = Sanitizer.redact_env_values(result)

            # Unified truncation
            tool_obj = (
                self._tool_registry.get(tc.name) if hasattr(self._tool_registry, "get") else None
            )
            tool_max = getattr(getattr(tool_obj, "metadata", None), "max_output_chars", 0)
            output_cfg = (
                self._tool_registry.output_config
                if hasattr(self._tool_registry, "output_config")
                else None
            )
            max_chars = tool_max if tool_max > 0 else (getattr(output_cfg, "max_chars", 50_000))
            llm_enabled = (
                getattr(output_cfg, "llm_compression_enabled", True) if output_cfg else True
            )
            result = await truncate_tool_output(
                content=result,
                tool_name=tc.name,
                max_chars=max_chars,
                provider=self._provider,
                llm_enabled=llm_enabled,
                tool_args=tc.arguments,
            )

            final_results.append((tc, result))

        return final_results

    def _resolve_allowed_tools(
        self,
        exclude_tools: list[str] | None = None,
        *,
        include_inactive: list[str] | None = None,
    ) -> set[str] | None:
        """Build the effective allowed tool set for runtime enforcement.

        Returns None if all tools are allowed, otherwise a set of allowed names.

        ``include_inactive`` must carry the same per-turn exception the schema was
        built with. Without it, a turn that excludes any unrelated tool derives the
        allowed set from the *active* registry only, so a tool the model was just
        shown as callable is rejected at preflight.
        """
        # Start with agent config allowlist
        config_tools = self._config.tools
        if config_tools is None or (isinstance(config_tools, list) and not config_tools):
            # None or empty list = all tools allowed
            allowed: set[str] | None = None
        else:
            allowed = set(config_tools)
            allowed.update(include_inactive or [])

        # Apply exclude_tools
        if exclude_tools and allowed is not None:
            allowed = {name for name in allowed if not self._tool_excluded(name, exclude_tools)}
        elif exclude_tools and allowed is None:
            # Visible tools minus excluded. NOT "all tools": get_schemas() returns
            # what is callable this turn (core + activated, plus include_inactive),
            # which is what an allowlist should be measured against. Pre-existing
            # semantics — this branch only gained the include_inactive pass-through,
            # so the per-turn exception is not dropped when exclude_tools is set.
            schemas = self._tool_registry.get_schemas(include_inactive=include_inactive)
            all_names = {s.get("function", {}).get("name", "") for s in schemas}
            allowed = {name for name in all_names if not self._tool_excluded(name, exclude_tools)}

        return allowed

    async def _flush_memories_before_compression(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
        *,
        channel: Any = None,
        channel_id: str | None = None,
    ) -> None:
        """Pre-compression memory flush (Hermes-style).

        Give the agent one LLM call with only the memory tool to save
        important findings before context is compressed and older messages
        are lost. Only fires if the conversation has enough user turns
        to have generated meaningful content.
        """
        if not self._memory:
            return
        # Only flush if there's been meaningful conversation (>= 6 user turns)
        user_turns = sum(1 for m in messages if m.get("role") == "user")
        if user_turns < 6:
            return

        flush_msg = {
            "role": "system",
            "content": (
                "[System: The session context is being compressed. "
                "Save anything worth remembering — prioritize user preferences, "
                "corrections, and recurring patterns over task-specific details.]"
            ),
        }
        try:
            # Build a minimal message list with only memory tool
            flush_messages = messages + [flush_msg]
            memory_schema = self._tool_registry.get_schemas(["memory"])
            if not memory_schema:
                return
            response, _ = await self._call_llm(
                self._config.model,
                flush_messages,
                list(memory_schema),
                channel=channel,
                channel_id=channel_id,
                session_id=session_id,
            )
            # Execute any memory tool calls from the flush response
            if response.tool_calls:
                results = await self._execute_tools(
                    response.tool_calls,
                    session_id=session_id,
                    channel=channel,
                    channel_id=channel_id,
                )
                logger.info(
                    "Pre-compression flush: {} memory tool call(s)",
                    len(results),
                )
            # Don't append flush artifacts to the conversation —
            # they would be compressed away immediately anyway
        except Exception as exc:
            logger.debug("Pre-compression flush failed: {}", exc)

    async def _persist_compacted(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Persist compacted messages.

        Strips ephemeral system messages (the base prompt is rebuilt by
        :meth:`_assemble_messages` on every turn, so persisting it would
        duplicate the row on next assemble) but preserves compaction
        summary rows (identified by :func:`is_compaction_summary`). The
        summary carries cross-turn memory of the older history, so dropping
        it on persist would force every future compaction to start from
        the truncated tail and steadily lose context.

        For ``role=user`` rows, strips any ephemeral Runtime Context /
        injected skill blocks that the LLM-bound message list carries.
        Without this, the bulk ``replace_messages`` call would overwrite
        the raw user row written by ``_run_conversation_impl`` with the
        enriched form, reintroducing the frozen ``Current Time:`` / skill
        context into durable history (issue #345 regression vector for
        long sessions that hit compaction).
        """
        from praestoclaw.agent.compressor import is_compaction_summary

        keep: list[dict[str, Any]] = []
        for m in messages:
            role = m.get("role")
            if role == "system" and not is_compaction_summary(m):
                continue
            if role == "user" and is_injected_runtime_context(m.get("content", "")):
                stripped = strip_injected_context(m["content"])
                if stripped != m["content"]:
                    m = {**m, "content": stripped}
            keep.append(m)
        await self._session_store.replace_messages(session_id, keep, reason="compaction")

    async def _process_message(self, msg: InboundMessage) -> str:
        """Process a single inbound message through the full agent pipeline.

        Matches v1's _process_message: audit → approval routing → slash commands
        → hooks (on_message_received) → typing → agent loop → hooks
        (on_message_sent) → outbound.
        """
        channel = ChannelType.of(msg.logical_channel)
        delivery_route_id = msg.delivery_route_id
        conversation_id = msg.conversation_id or delivery_route_id
        sender_for_session = self._sender_for_session(
            msg,
            conversation_id=conversation_id,
            delivery_route_id=delivery_route_id,
        )
        agent_session_key = self._resolve_agent_session_key(msg)
        await self._session_store.ensure_session(
            agent_session_key,
            str(channel),
            sender_for_session,
        )
        self._maybe_capture_owner_session(msg, agent_session_key, channel, sender_for_session)

        turn_started = time.monotonic()

        def _audit_turn(action: str, **data: Any) -> None:
            if not self._audit:
                return
            self._audit.log_event(
                action=action,
                data={
                    **data,
                    "session_id": agent_session_key,
                    "conversation_session_id": agent_session_key,
                    "duration_ms": (time.monotonic() - turn_started) * 1000,
                },
            )

        _audit_turn("agent:turn_start")

        # ── Audit: inbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="inbound",
                actor=msg.sender_id or "unknown",
                session_id=agent_session_key,
            )

        # ── Approval routing ──
        if await self._try_route_approval(msg):
            _audit_turn("agent:turn_end", status="approval handled")
            return ""

        # ── Slash commands ──
        content = msg.content.strip()
        if content.startswith("/"):
            reply = await self._handle_slash(content, agent_session_key, msg)
            if reply is not None:
                await self._reply_dispatcher.publish_final(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content=reply,
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                    dedupe=False,
                )
                _audit_turn("agent:turn_end", status="slash command completed")
                return reply

        # ── Hook: on_message_received ──
        if self._hooks:
            hook_ctx = MessageHookContext(
                content=msg.content,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.INTERNAL,
                sender_id=msg.sender_id or "",
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_received", hook_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Message rejected by hook: {}", result.reason)
                if self._audit:
                    self._audit.log_event(
                        action="agent:hook_reject",
                        data={
                            "status": "inbound message rejected",
                            "session_id": agent_session_key,
                            "conversation_session_id": agent_session_key,
                        },
                    )
                await self._reply_dispatcher.publish_final(
                    channel=channel,
                    channel_id=delivery_route_id,
                    content=f"Message blocked: {result.reason}",
                    thread_id=conversation_id,
                    route_hint=msg.route_hint,
                    dedupe=False,
                )
                _audit_turn("agent:turn_end", status="blocked")
                return f"Message blocked: {result.reason}"
        else:
            # Fallback: inline prompt injection check when no hooks configured
            findings = Sanitizer.check_prompt_injection(msg.content)
            if findings:
                if self._audit:
                    self._audit.log_security(
                        event="prompt_injection_detected",
                        details={"findings": findings, "sender": msg.sender_id},
                        severity="warning",
                    )
                logger.warning("Prompt injection detected from {}: {}", msg.sender_id, findings)

        # ── Typing indicator ──
        typing_task = self._start_typing(channel, delivery_route_id, metadata=msg.metadata)

        # ── Task heartbeat (issue #181) ──
        # If the inbound carrier was a task-bearing a2a envelope, the
        # cloud channel stashed a private ``_task_progress_sender`` in
        # metadata. Pop it out (we never want the callable to leak into
        # the LLM/tool layer) and wrap the agent turn in a heartbeat
        # emitter so the original sender sees periodic ``executing``
        # progress events and the Gateway extends the executing-stage
        # soft deadline. No-op when the carrier was not a task.
        heartbeat = self._build_task_heartbeat(msg.metadata)

        # Source-driven tool exclusions. Inbound carriers (notably
        # ``source="a2a_task"`` from ``CloudProtocolChannel``) stamp an
        # ``exclude_tools`` list into ``metadata`` to keep the executor
        # turn from re-invoking ``a2a`` (infinite hop) or ``cron`` /
        # ``spawn`` (privilege escalation by a remote peer). ``notify``
        # is deliberately *not* excluded for a2a_task so the executor
        # can still push a final summary to its own owner — see the
        # corresponding NOTE in ``CloudChannel._handle_conversation_request``.
        raw_exclude = (msg.metadata or {}).get("exclude_tools")
        exclude_tools = (
            [str(t) for t in raw_exclude if isinstance(t, str)]
            if isinstance(raw_exclude, list)
            else None
        )
        turn_metadata = self._conversation_metadata_for_message(msg)

        try:
            history = self._llm_history(await self._session_store.get_messages(agent_session_key))
            if heartbeat is not None:
                async with heartbeat:
                    response, streamed = await self._run_conversation(
                        msg.content,
                        history,
                        agent_session_key,
                        channel=channel,
                        channel_id=delivery_route_id,
                        thread_id=conversation_id,
                        metadata=turn_metadata,
                        exclude_tools=exclude_tools,
                        route_hint=msg.route_hint,
                    )
            else:
                response, streamed = await self._run_conversation(
                    msg.content,
                    history,
                    agent_session_key,
                    channel=channel,
                    channel_id=delivery_route_id,
                    thread_id=conversation_id,
                    metadata=turn_metadata,
                    exclude_tools=exclude_tools,
                    route_hint=msg.route_hint,
                )
        except Exception as exc:
            logger.opt(exception=exc).error("Agent loop error: {}", exc)
            error_context = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            _audit_turn(
                "agent:turn_error",
                error=sanitize_diagnostic_text(error_context, max_chars=4000),
            )
            await self._reply_dispatcher.publish_final(
                channel=channel,
                channel_id=delivery_route_id,
                content="Sorry, an internal error occurred. Please try again.",
                thread_id=conversation_id,
                route_hint=msg.route_hint,
                dedupe=False,
            )
            return "Sorry, an internal error occurred. Please try again."
        finally:
            self._stop_typing(typing_task, channel, delivery_route_id)

        # Is this emission the synchronous promotion receipt for a turn that
        # was just handed off to a background worker? Keyed on the carrier
        # route (recorded at promotion time) rather than the receipt TEXT, so
        # the flag survives a "minimal" one-liner, an empty "silent" body, and
        # any future copy change. Popped here so it can't leak to a later turn
        # that reuses the route id.
        is_promotion_receipt = delivery_route_id in self._promotion_receipt_routes
        self._promotion_receipt_routes.discard(delivery_route_id)

        # Tagged group turns already close their synchronous carrier with the
        # immediate like ACK. Keep the worker promotion, but do not publish a
        # second user-visible acknowledgement before its fold-back result.
        if (
            is_promotion_receipt
            and turn_metadata.get("praesto_tag_exp")
            and turn_metadata.get("praesto_tag_exp_is_tag_message")
        ):
            _audit_turn("agent:turn_end", status="promoted after group ack")
            return response

        # Empty/whitespace-only non-streamed turns have no user-visible outbound message.
        # Suppress them before outbound hooks/audit so hooks only observe
        # content that was streamed or is about to be published.
        #
        # EXCEPTION: a "silent"-mode promotion receipt is an empty body that
        # MUST still be published — the carrier /chatng waiter is resolved by
        # the channel send, so suppressing it here would hang the carrier until
        # it times out. The empty body renders as "nothing to post" on the
        # Teams bridge, so the user sees no receipt while the fold-back still
        # arrives later. The ``is_promotion_receipt`` flag also keeps the cloud
        # channel from popping the fold-back's stash + Teams route.
        if not streamed and not response.strip() and not is_promotion_receipt:
            logger.info(
                "Agent produced no final response; suppressing empty outbound "
                "channel={} channel_id={} session_id={}",
                channel,
                delivery_route_id,
                agent_session_key,
            )
            _audit_turn("agent:turn_end", status="completed without reply")
            return response

        # ── Hook: on_message_sent — runs on delivered/publishable content ──
        # For streamed responses, the hook runs on the full accumulated text
        # (same as v1's _stream_response which ran the hook after streaming).
        # If the hook rejects, we still send a replacement OutboundMessage
        # even if chunks were already streamed (best-effort correction).
        hook_blocked = False
        if self._hooks:
            out_ctx = MessageHookContext(
                content=response,
                channel=channel if isinstance(channel, ChannelType) else ChannelType.INTERNAL,
                session_id=agent_session_key,
            )
            result = await self._hooks.dispatch_checked("on_message_sent", out_ctx)
            if result.verdict == HookVerdict.REJECT:
                logger.warning("Outbound message blocked by hook: {}", result.reason)
                if self._audit:
                    self._audit.log_event(
                        action="agent:hook_reject",
                        data={
                            "status": "outbound message rejected",
                            "session_id": agent_session_key,
                            "conversation_session_id": agent_session_key,
                        },
                    )
                response = "[Message blocked by security policy]"
                hook_blocked = True
            elif result.data and isinstance(result.data, MessageHookContext):
                response = result.data.content

        # ── Outbound: send full message only when NOT already delivered ──
        # If streaming delivered the final response AND hook didn't block,
        # skip the full OutboundMessage (channels already have the content).
        # If hook blocked a streamed response, send the replacement text.
        if not streamed or hook_blocked:
            # Mark the promotion-receipt emission so the cloud channel can
            # tell it apart from a normal final reply or a fold-back late
            # reply. Receipts are synchronous answers to the just-sent
            # message — they don't need the ↩️ envelope and they MUST NOT
            # consume the stash + Teams route that the eventual fold-back
            # will need (prod 2026-06-14 13:35–37). ``is_promotion_receipt``
            # was resolved above from ``_promotion_receipt_routes`` (route
            # identity), so it is correct regardless of the receipt copy
            # ("full" / "minimal" / empty "silent").
            metadata = {"is_promotion_receipt": True} if is_promotion_receipt else None
            await self._reply_dispatcher.publish_final(
                channel=channel,
                channel_id=delivery_route_id,
                content=response,
                thread_id=conversation_id,
                route_hint=msg.route_hint,
                metadata=metadata,
                dedupe=False,
            )

        # ── Audit: outbound ──
        if self._audit:
            self._audit.log_message(
                channel=str(channel),
                direction="outbound",
                actor="agent",
                session_id=agent_session_key,
            )
        _audit_turn("agent:turn_end", status="completed")
        return response

    def _build_task_heartbeat(self, metadata: dict[str, Any] | None) -> Any:
        """Construct a :class:`TaskHeartbeatEmitter` for task-bearing inbounds.

        Returns ``None`` when *metadata* does not describe a task carrier
        (the common case — plain chat / a2a messages get no heartbeat).
        The ``_task_progress_sender`` callable is popped out so it never
        reaches the LLM/tool serialization layer; cloud.py owns the
        contract that this private key carries the outbound handle.
        """

        if not metadata:
            return None
        sender = metadata.pop("_task_progress_sender", None)
        task_id = metadata.get("task_id")
        if sender is None or not isinstance(task_id, str) or not task_id:
            return None
        summary = ""
        raw_summary = metadata.get("task_summary")
        if isinstance(raw_summary, str):
            summary = raw_summary
        try:
            from praestoclaw.task.heartbeat import TaskHeartbeatEmitter  # noqa: PLC0415

            return TaskHeartbeatEmitter(
                sender,
                task_id=task_id,
                summary=summary,
            )
        except Exception as exc:  # noqa: BLE001
            # Heartbeat is best-effort: a misconfigured emitter must not
            # block the actual agent turn. Log and run without it.
            logger.warning("task heartbeat emitter init failed: {}", exc)
            return None

    async def _async_consolidate(
        self,
        messages: list[dict[str, Any]],
        session_id: str,
    ) -> None:
        """Fire-and-forget memory consolidation."""
        try:
            if hasattr(self._memory, "consolidate"):
                await self._memory.consolidate(messages, session_id)
        except Exception:
            logger.exception("Memory consolidation failed")

    async def _reconcile_plan_on_turn_end(self, state: _TurnState) -> None:
        """Reconcile a plan whose last item was left ``in_progress`` (#718).

        Called at the end of ``_drive_turn`` after the final response has been
        persisted. When exactly one non-terminal plan item remains and it is
        ``in_progress``, mark it ``done`` and emit a final progress card so
        the Teams card reflects 100%.

        Keys off ``plan_session_id``, not ``session_id``: promotion swaps the
        latter to the worker session while the visible card still belongs to
        the originating conversation's plan (same rule as the plan tool kwargs
        in step 8).

        Best-effort: any failure is logged and swallowed — never let a cosmetic
        card update break the turn.
        """
        try:
            from praestoclaw.agent.tools.plan import PlanTool

            plan_tool = self._tool_registry.get("plan")
            if not isinstance(plan_tool, PlanTool):
                return
            await plan_tool.reconcile_and_notify(
                state.plan_session_id,
                {
                    # ``state.channel`` is ``Any`` and callers are not required
                    # to normalize it. ``ChannelType`` is a StrEnum, so ``str()``
                    # yields the same "cloud" for the enum and for a raw string,
                    # while ``.value`` would raise on the latter — inside this
                    # debug-swallowing except, i.e. another silent skip. Same
                    # defence as the ``str(state.channel)`` at the promotion site.
                    "_channel": str(state.channel) if state.channel else "",
                    "_channel_id": state.channel_id or "",
                    "_metadata": state.metadata or {},
                },
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("plan terminal reconciliation failed: {}", exc)
