"""Shared edit semantics for local personal and group memory files."""

from __future__ import annotations

from dataclasses import dataclass

MAX_MEMORY_BYTES = 16_384


@dataclass(frozen=True)
class MemoryEdit:
    content: str | None
    message: str


def add_memory_entry(existing: str, content: str, label: str) -> MemoryEdit:
    if not content or not content.strip():
        return MemoryEdit(None, "Error: content is empty.")
    content = content.strip()
    if content in existing:
        return MemoryEdit(None, f"Skipped: this entry already exists in {label}.")

    updated = existing.rstrip() + "\n" + content + "\n" if existing.strip() else content + "\n"
    if len(updated.encode("utf-8")) > MAX_MEMORY_BYTES:
        return MemoryEdit(
            None,
            f"Error: adding this entry would exceed the {MAX_MEMORY_BYTES // 1024} KB limit "
            f"for {label}. Remove old entries first.",
        )
    return MemoryEdit(updated, f"Added to {label}.")


def replace_memory_entry(existing: str, old_text: str, new_text: str, label: str) -> MemoryEdit:
    if not old_text:
        return MemoryEdit(None, "Error: old_text is empty.")
    if not new_text:
        return MemoryEdit(None, "Error: new_text is empty. Use 'remove' action to delete entries.")
    if old_text not in existing:
        return MemoryEdit(None, f"Error: '{old_text[:60]}...' not found in {label}.")
    return MemoryEdit(existing.replace(old_text, new_text, 1), f"Replaced in {label}.")


def remove_memory_entry(existing: str, old_text: str, label: str) -> MemoryEdit:
    if not old_text:
        return MemoryEdit(None, "Error: old_text is empty.")
    if old_text not in existing:
        return MemoryEdit(None, f"Error: '{old_text[:60]}...' not found in {label}.")

    updated = existing.replace(old_text, "", 1)
    while "\n\n\n" in updated:
        updated = updated.replace("\n\n\n", "\n\n")
    content = updated.strip() + "\n" if updated.strip() else ""
    return MemoryEdit(content, f"Removed from {label}.")
