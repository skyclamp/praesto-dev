"""Model-facing ``skill`` lifecycle tool for group conversations."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.group_skills import GroupSkillError, GroupSkillRegistry
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupSkillTool(Tool):
    """Manage current-chat group skill snapshots."""

    def __init__(self, registry: GroupSkillRegistry, import_roots: list[Path]) -> None:
        self._registry = registry
        self._import_roots = [Path(root) for root in import_roots]

    @property
    def name(self) -> str:
        return "skill"

    @property
    def description(self) -> str:
        return (
            "Manage skills isolated to this group chat. Register an external repository, "
            "import an installed same-named skill snapshot, list/status, load/unload, "
            "read a loaded skill's package files, update, or remove it. Loading enables "
            "matching on later group turns."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="core", timeout=150)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "register",
                        "import",
                        "list",
                        "status",
                        "load",
                        "unload",
                        "read",
                        "update",
                        "remove",
                    ],
                },
                "name": {"type": "string", "description": "Canonical skill name."},
                "repo_url": {
                    "type": "string",
                    "description": ("Repository URL supplied by the user. Required for register."),
                },
                "path": {
                    "type": "string",
                    "description": "Package-relative UTF-8 text file for read.",
                },
            },
            "required": ["action"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(
            0 if args.get("action") in {"list", "status"} else 3, "Group-local skill lifecycle"
        )

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata")
        if not praesto_tag_exp_is_active(metadata):
            return "Error: skill is available only in a shared group session."
        cid = str((metadata or {}).get("cid") or "").strip()
        if not cid:
            return "Error: current group chat id is missing."
        action = str(kwargs.get("action") or "")
        name = str(kwargs.get("name") or "").strip()
        actor = str((metadata or {}).get("sender_oid") or (metadata or {}).get("sender_id") or "")
        try:
            if action == "list":
                return self._format_list(cid)
            if action == "status":
                return self._format_status(cid, name)
            if action == "register":
                record = await asyncio.to_thread(
                    self._registry.install_external,
                    chat_id=cid,
                    name=name,
                    repo_url=str(kwargs.get("repo_url") or ""),
                    installed_by=actor,
                )
                return (
                    f"Registered group skill '{record.name}' for this chat (disabled until load)."
                )
            if action == "import":
                return self._import(cid, name, actor, preserve_enabled=False)
            if action == "load":
                record = self._registry.set_enabled(cid, name, True)
                return (
                    f"[Group Skill: {record.name}]\n\n"
                    f"{record.content}\n\n"
                    "[Loaded for this chat; automatic matching and safe-tools apply from "
                    "the next turn.]"
                )
            if action == "unload":
                self._registry.set_enabled(cid, name, False)
                return f"Unloaded group skill '{name}' for this chat."
            if action == "read":
                content = self._registry.read_asset(cid, name, str(kwargs.get("path") or ""))
                return f"[Group Skill asset: {name}/{kwargs.get('path')}]\n\n{content}"
            if action == "remove":
                return (
                    f"Removed group skill '{name}' from this chat."
                    if self._registry.remove(cid, name)
                    else f"Group skill '{name}' is not registered in this chat."
                )
            if action == "update":
                existing = self._registry.get(cid, name)
                if existing is None:
                    raise GroupSkillError(f"group skill '{name}' is not registered in this chat")
                if existing.source_type == "external":
                    record = await asyncio.to_thread(
                        self._registry.install_external,
                        chat_id=cid,
                        name=name,
                        repo_url=existing.source_locator,
                        installed_by=actor,
                        preserve_enabled=True,
                    )
                    return (
                        f"Updated group skill '{record.name}' to {record.resolved_revision[:12]}."
                    )
                return self._import(cid, name, actor, preserve_enabled=True, verb="Updated")
        except GroupSkillError as exc:
            return f"Error: {exc}"
        return "Error: unknown action."

    def _import(
        self,
        cid: str,
        name: str,
        actor: str,
        *,
        preserve_enabled: bool,
        verb: str = "Imported",
    ) -> str:
        source_file = self._find_import_source(name)
        if source_file is None:
            raise GroupSkillError(f"installed personal/bundled skill '{name}' was not found")
        record = self._registry.install_snapshot(
            chat_id=cid,
            requested_name=name,
            source_file=source_file,
            source_type="import",
            source_locator=name,
            installed_by=actor,
            preserve_enabled=preserve_enabled,
        )
        return f"{verb} group skill '{record.name}' as a snapshot for this chat."

    def _find_import_source(self, name: str) -> Path | None:
        """Find an import candidate without consulting the personal SkillLoader."""
        for root in self._import_roots:
            for candidate in (
                root / name / "SKILL.md",
                root / name / "skill.md",
                root / f"{name}.md",
            ):
                if candidate.is_file():
                    return candidate
        return None

    def _format_list(self, cid: str) -> str:
        records = self._registry.list(cid)
        if not records:
            return "No group skills are registered in this chat."
        return "Group skills in this chat:\n" + "\n".join(
            f"- {record.name}: {'loaded' if record.enabled else 'unloaded'} ({record.source_type})"
            for record in records
        )

    def _format_status(self, cid: str, name: str) -> str:
        if not name:
            return self._format_list(cid)
        record = self._registry.get(cid, name)
        if record is None:
            return f"Group skill '{name}' is not registered in this chat."
        return (
            f"{record.name}: {'loaded' if record.enabled else 'unloaded'}; "
            f"source={record.source_type}; hash={record.content_hash[:12]}; "
            f"safe_tools={len(record.safe_tools)}"
        )
