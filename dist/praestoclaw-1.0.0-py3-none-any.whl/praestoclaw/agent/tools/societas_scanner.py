"""Deterministic Societas bug and PR watcher used by cron tool mode."""

from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
import tempfile
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlsplit

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.plan import (
    PlanDisposition,
    get_plan_disposition,
    is_legacy_societas_review_park,
)
from praestoclaw.security.risk import RiskAssessment, RiskScore
from praestoclaw.utils.helpers import get_data_dir

SCHEMA_VERSION = 4
TOOL_NAME = f"societas_scanner_v{SCHEMA_VERSION}"
_ADO_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"
_TERMINAL_BUG_STATES = frozenset({"closed", "resolved", "removed", "done"})
_SAVED_QUERY_RE = re.compile(r"^saved:([0-9a-fA-F-]{36})$")
_FLAT_WIQL_FROM_RE = re.compile(r"\bFROM\s+WorkItems\b", re.IGNORECASE)
_BUG_QUERY_FIELDS = (
    "[System.Id]",
    "[System.WorkItemType]",
    "[System.Title]",
    "[System.State]",
    "[System.AssignedTo]",
)
_WORK_ITEM_ID_RE = re.compile(r"(?<!\d)(\d{7,})(?!\d)")
_ADO_ORG_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?$")

AzRunner = Callable[[list[str]], Awaitable[str]]
PlansFn = Callable[[], list[Any]]


def _compact_error(exc: Exception) -> str:
    text = " ".join(str(exc).split())
    return (text or type(exc).__name__)[:300]


def _normalize_email(value: Any) -> str:
    if isinstance(value, dict):
        value = value.get("uniqueName") or value.get("UniqueName")
    return str(value or "").strip().casefold()


def _as_dict(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _normalize_ado_org_url(value: Any) -> str | None:
    """Return a canonical official ADO organization URL, or ``None``."""
    text = str(value or "").strip()
    try:
        parsed = urlsplit(text)
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme.casefold() != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or port is not None
        or parsed.query
        or parsed.fragment
    ):
        return None
    host = parsed.hostname.casefold()
    path = parsed.path.rstrip("/")
    if host == "dev.azure.com":
        match = re.fullmatch(r"/([^/]+)", path)
        if match is None or _ADO_ORG_RE.fullmatch(match.group(1)) is None:
            return None
        return f"https://dev.azure.com/{match.group(1)}"

    suffix = ".visualstudio.com"
    if not host.endswith(suffix) or path:
        return None
    organization = host.removesuffix(suffix)
    if _ADO_ORG_RE.fullmatch(organization) is None:
        return None
    return f"https://{organization}.visualstudio.com"


def _infer_work_item_id(pr: dict[str, Any]) -> int | None:
    evidence = " ".join(str(pr.get(field) or "") for field in ("title", "sourceRefName"))
    candidates = {int(match) for match in _WORK_ITEM_ID_RE.findall(evidence)}
    candidates.discard(int(pr.get("pullRequestId") or 0))
    return candidates.pop() if len(candidates) == 1 else None


def _old_bug_snapshot(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    bugs = state.get("bugs")
    if isinstance(bugs, dict):
        return {str(key): value for key, value in bugs.items() if isinstance(value, dict)}
    if isinstance(bugs, list):
        return {
            str(item["id"]): item
            for item in bugs
            if isinstance(item, dict) and item.get("id") is not None
        }
    return {}


def _old_pr_snapshot(state: dict[str, Any]) -> list[dict[str, Any]]:
    snapshot = _as_dict(state.get("prs")).get("snapshot")
    if isinstance(snapshot, list):
        return [item for item in snapshot if isinstance(item, dict)]
    if isinstance(snapshot, dict):
        return [item for item in snapshot.values() if isinstance(item, dict)]
    return []


def _old_reminded(state: dict[str, Any]) -> set[str]:
    reminded = _as_dict(state.get("prs")).get("reminded")
    if not isinstance(reminded, list):
        return set()
    return {str(item) for item in reminded if item}


def _old_pending_bug_ids(state: dict[str, Any]) -> list[str]:
    pending = state.get("pending_bug_ids")
    if not isinstance(pending, list):
        return []
    return [str(item) for item in pending if str(item).isdigit()]


def _bugs_with_active_pr(snapshot: list[dict[str, Any]]) -> set[str]:
    """Bug ids that already have an active PR, read off this scan's PR snapshot.

    Free: ``_scan_prs`` already lists active PRs and appends EVERY valid row to the
    snapshot (only ``actionables`` is conditional), each carrying ``bugId``. So the
    bug→PR mapping costs no extra ADO call.

    Ids are stringified because the snapshot stores ``bugId`` as an int while the
    bug map is keyed by ``str(row["id"])``.

    Scope: ``_scan_prs`` queries ``--creator <assigned_to>``, so a PR someone ELSE
    opened for the same bug is invisible here and that bug stays offerable. Covering
    those needs the work-item Relations read that ``ado_query_active_prs`` does, at
    one extra call per bug.
    """
    return {
        str(item["bugId"])
        for item in snapshot
        if isinstance(item, dict) and item.get("bugId") is not None
    }


def _card(body_text: str, action_title: str, action_value: str) -> str:
    return json.dumps(
        {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "type": "AdaptiveCard",
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "version": "1.4",
                        "body": [{"type": "TextBlock", "text": body_text, "wrap": True}],
                        "actions": [
                            {
                                "type": "Action.Submit",
                                "title": action_title,
                                "data": {
                                    "msteams": {
                                        "type": "imBack",
                                        "value": action_value,
                                    }
                                },
                            }
                        ],
                    },
                }
            ],
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


class SocietasScannerTool(Tool):
    """Scan assigned bugs and authored PRs without an LLM or shell script."""

    risk_range = (3, 3)

    def __init__(
        self,
        data_dir: Path | None = None,
        *,
        az_runner: AzRunner | None = None,
        plans_fn: PlansFn | None = None,
    ) -> None:
        self._data_dir = data_dir or get_data_dir()
        self._state_path = self._data_dir / "workspace" / ".societas-bug-watcher" / "state.json"
        self._az_runner = az_runner or self._run_az
        if plans_fn is None:
            from praestoclaw.agent.tools.plan import PlanStore

            plans_fn = PlanStore(self._data_dir).list_active
        self._plans_fn = plans_fn
        self._delivery_acks: dict[str, tuple[str, str]] = {}
        self._state_lock = asyncio.Lock()

    @property
    def name(self) -> str:
        return TOOL_NAME

    @property
    def description(self) -> str:
        return "Deterministically scan Societas bugs and PRs for a scheduled watcher."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "bug_query_source": {
                    "type": "string",
                    "description": "saved:<GUID>, wiql:<query>, or builtin",
                },
                "org_url": {"type": "string"},
                "project": {"type": "string"},
                "repository": {"type": "string"},
                "assigned_to": {"type": "string"},
                "repo_path": {"type": "string"},
            },
            "required": [
                "bug_query_source",
                "org_url",
                "project",
                "repository",
                "assigned_to",
                "repo_path",
            ],
            "additionalProperties": False,
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="hidden")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Read Azure DevOps and update the scoped watcher snapshot")

    def validate(self, args: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        for key in (
            "bug_query_source",
            "org_url",
            "project",
            "repository",
            "assigned_to",
            "repo_path",
        ):
            if not str(args.get(key) or "").strip():
                errors.append(f"{key} is required")
        source = str(args.get("bug_query_source") or "").strip()
        if source and source != "builtin" and not source.startswith("wiql:"):
            match = _SAVED_QUERY_RE.fullmatch(source)
            if match is None:
                errors.append("bug_query_source must be saved:<GUID>, wiql:<query>, or builtin")
        if source.startswith("wiql:") and not source.removeprefix("wiql:").strip():
            errors.append("wiql query must not be empty")
        org_url = str(args.get("org_url") or "").strip()
        if org_url and _normalize_ado_org_url(org_url) is None:
            errors.append(
                "org_url must be https://dev.azure.com/<org> or "
                "https://<org>.visualstudio.com with no credentials, port, query, "
                "fragment, or extra path"
            )
        return errors

    @staticmethod
    def _safe_command_value(value: Any) -> str:
        text = str(value or "").strip()
        if not text:
            return ""
        if "=" in text or any(ch.isspace() for ch in text):
            # Keep the imBack payload one physical line while preserving paths
            # such as ``Q:\\Societas Repo``. JSON quoting escapes CR/LF and
            # backslashes instead of letting a value smuggle extra tokens.
            return json.dumps(text, ensure_ascii=False)
        return text

    def _workflow_command(
        self,
        *,
        pr_id: int,
        bug_id: int,
        repo_path: str,
        plans: list[Any],
        plan_owner: str,
    ) -> tuple[str, bool, str, int | None]:
        """Return the exact resume command and newest-first Plan rank when resumable."""
        if pr_id <= 0:
            command = f"run workflow fix-societas-bug bug_id={bug_id}"
            mapped_repo = self._safe_command_value(repo_path)
            if mapped_repo:
                command += f" repo_path={mapped_repo}"
            return command, False, "", None
        for plan_rank, plan in enumerate(plans):
            if str(getattr(plan, "workflow", "") or "") != "fix-societas-bug":
                continue
            if not plan_owner or str(getattr(plan, "owner", "") or "") != plan_owner:
                continue
            task_id = self._safe_command_value(getattr(plan, "origin_task", ""))
            if not task_id or bool(getattr(plan, "superseded", False)):
                continue
            disposition = get_plan_disposition(plan)
            if disposition is not PlanDisposition.PARKED and not is_legacy_societas_review_park(
                plan
            ):
                continue
            if disposition is PlanDisposition.PARKED:
                lifecycle_id = str(getattr(plan, "lifecycle_id", "") or "").strip()
                if lifecycle_id != f"ado-pr:{pr_id}":
                    continue
            items = list(getattr(plan, "items", None) or [])
            unfinished = [
                item
                for item in items
                if str(getattr(item, "status", "") or "") not in {"done", "skipped"}
            ]
            if not any(
                str(getattr(item, "title", "") or "").strip().casefold() == "review"
                and str(getattr(item, "status", "") or "") == "blocked"
                for item in unfinished
            ):
                continue
            params = getattr(plan, "params", None) or getattr(plan, "workflow_params", None)
            params = params if isinstance(params, dict) else {}
            saved_bug_id = str(params.get("bug_id") or "").strip()
            evidence = " ".join(
                str(getattr(item, field, "") or "")
                for item in items
                for field in ("acceptance", "note", "evidence")
            )
            if saved_bug_id:
                if saved_bug_id != str(bug_id):
                    continue
            elif str(bug_id) not in evidence:
                continue
            if disposition is not PlanDisposition.PARKED and str(pr_id) not in evidence:
                continue
            resolved_repo = self._safe_command_value(
                params.get("repo_path")
            ) or self._safe_command_value(repo_path)
            command = f"resume workflow fix-societas-bug task_id={task_id} bug_id={bug_id}"
            if resolved_repo:
                command += f" repo_path={resolved_repo}"
            return command, True, task_id, plan_rank
        command = f"run workflow fix-societas-bug bug_id={bug_id}"
        mapped_repo = self._safe_command_value(repo_path)
        if mapped_repo:
            command += f" repo_path={mapped_repo}"
        return command, False, "", None

    async def _run_az(self, args: list[str]) -> str:
        executable = shutil.which("az")
        if not executable:
            raise RuntimeError("Azure CLI 'az' was not found")
        env = os.environ.copy()
        env["PYTHONIOENCODING"] = "utf-8"
        process = await asyncio.create_subprocess_exec(
            executable,
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=120)
        except TimeoutError:
            process.kill()
            await process.wait()
            raise RuntimeError(f"az {' '.join(args[:3])} timed out") from None
        if process.returncode != 0:
            detail = (stderr or stdout).decode("utf-8", errors="replace").strip()
            raise RuntimeError(detail or f"az exited with {process.returncode}")
        return stdout.decode("utf-8-sig", errors="replace")

    async def _az_json(self, args: list[str]) -> Any:
        raw = await self._az_runner(args)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"Azure CLI returned invalid JSON: {exc.msg}") from exc

    def _load_state(self) -> tuple[dict[str, Any], bool]:
        try:
            parsed = json.loads(self._state_path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            return {}, True
        return (parsed, False) if isinstance(parsed, dict) else ({}, True)

    def _write_state(self, state: dict[str, Any]) -> None:
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(
            prefix="state-", suffix=".tmp", dir=self._state_path.parent
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(state, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
            os.replace(temp_name, self._state_path)
        except Exception:
            try:
                os.unlink(temp_name)
            except OSError:
                pass
            raise

    def _remember_delivery_ack(self, result: str, kind: str, key: str) -> None:
        self._delivery_acks[result] = (kind, key)
        while len(self._delivery_acks) > 64:
            self._delivery_acks.pop(next(iter(self._delivery_acks)))

    async def acknowledge_delivery(self, result: str) -> None:
        """Consume one reminder only after the scheduler confirms delivery."""
        async with self._state_lock:
            token = self._delivery_acks.pop(result, None)
            if token is None:
                return
            kind, key = token
            state, _ = self._load_state()
            if kind == "bug":
                state["pending_bug_ids"] = [
                    bug_id for bug_id in _old_pending_bug_ids(state) if bug_id != key
                ]
            elif kind == "pr":
                prs = dict(_as_dict(state.get("prs")))
                reminded = _old_reminded(state)
                reminded.add(key)
                prs["reminded"] = sorted(reminded)
                state["prs"] = prs
            else:  # pragma: no cover - internal token invariant
                return
            self._write_state(state)

    @staticmethod
    def _wiql_literal(value: str) -> str:
        return value.replace("'", "''")

    @staticmethod
    def _canonicalize_bug_wiql(wiql: str) -> str:
        """Keep the caller's scope while requesting every field the scanner verifies."""
        from_match = _FLAT_WIQL_FROM_RE.search(wiql)
        if from_match is None:
            return wiql
        return f"SELECT {', '.join(_BUG_QUERY_FIELDS)} {wiql[from_match.start() :]}"

    def _bug_query_args(
        self, source: str, org_url: str, project: str, assigned_to: str
    ) -> list[str]:
        common = ["--org", org_url, "--project", project, "-o", "json", "--only-show-errors"]
        saved = _SAVED_QUERY_RE.fullmatch(source)
        if saved:
            return ["boards", "query", "--id", saved.group(1), *common]
        if source.startswith("wiql:"):
            wiql = self._canonicalize_bug_wiql(source.removeprefix("wiql:"))
            return ["boards", "query", "--wiql", wiql, *common]
        escaped_project = self._wiql_literal(project)
        escaped_assignee = self._wiql_literal(assigned_to)
        wiql = (
            # Fixed WIQL shape; interpolated literals are escaped above.
            f"SELECT {', '.join(_BUG_QUERY_FIELDS)} FROM WorkItems WHERE "  # noqa: S608
            f"[System.TeamProject] = '{escaped_project}' AND "
            "[System.WorkItemType] = 'Bug' AND "
            f"[System.AssignedTo] = '{escaped_assignee}' AND "
            "[System.State] NOT IN ('Closed', 'Resolved', 'Removed', 'Done') "
            "ORDER BY [System.Id]"
        )
        return ["boards", "query", "--wiql", wiql, *common]

    async def _scan_bugs(
        self,
        *,
        source: str,
        org_url: str,
        project: str,
        assigned_to: str,
        old_source: str,
        old_bugs: dict[str, dict[str, Any]],
    ) -> tuple[dict[str, dict[str, Any]], list[str]]:
        rows = await self._az_json(self._bug_query_args(source, org_url, project, assigned_to))
        if not isinstance(rows, list):
            raise RuntimeError("bug query response is not an array")
        bugs: dict[str, dict[str, Any]] = {}
        target = assigned_to.casefold()
        for row in rows:
            if not isinstance(row, dict) or row.get("id") is None or row.get("rev") is None:
                raise RuntimeError("bug query returned an item without id/rev")
            fields = row.get("fields")
            required = ("System.WorkItemType", "System.Title", "System.State")
            if not isinstance(fields, dict) or any(key not in fields for key in required):
                raise RuntimeError("bug query returned an item with incomplete fields")
            if str(fields["System.WorkItemType"]).casefold() != "bug":
                continue
            state = str(fields["System.State"])
            if state.casefold() in _TERMINAL_BUG_STATES:
                continue
            email = _normalize_email(fields.get("System.AssignedTo"))
            if email != target:
                continue
            bug_id = str(row["id"])
            bugs[bug_id] = {
                "id": row["id"],
                "rev": row["rev"],
                "title": str(fields["System.Title"]),
                "state": state,
                "assigned_to": email,
            }
        new_ids = []
        if old_source == source:
            new_ids = sorted(set(bugs) - set(old_bugs), key=int)
        return bugs, new_ids

    async def _scan_prs(
        self,
        *,
        org_url: str,
        project: str,
        repository: str,
        assigned_to: str,
        repo_path: str,
        old_snapshot: list[dict[str, Any]],
        old_reminded: set[str],
        plans: list[Any],
        plan_owner: str,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
        rows = await self._az_json(
            [
                "repos",
                "pr",
                "list",
                "--org",
                org_url,
                "--project",
                project,
                "--repository",
                repository,
                "--creator",
                assigned_to,
                "--status",
                "active",
                "-o",
                "json",
                "--only-show-errors",
            ]
        )
        if not isinstance(rows, list):
            raise RuntimeError("active PR response is not an array")
        old_by_id = {str(item.get("pr")): item for item in old_snapshot if item.get("pr")}
        snapshot: list[dict[str, Any]] = []
        actionables: list[dict[str, Any]] = []
        errors: list[str] = []
        project_path = quote(project, safe="")
        repository_path = quote(repository, safe="")

        for row in rows:
            if not isinstance(row, dict) or row.get("pullRequestId") is None:
                errors.append("active PR list contained an invalid item")
                continue
            pr_id = int(row["pullRequestId"])
            try:
                policies_raw, details, threads_raw = await asyncio.gather(
                    self._az_json(
                        [
                            "repos",
                            "pr",
                            "policy",
                            "list",
                            "--id",
                            str(pr_id),
                            "--org",
                            org_url,
                            "-o",
                            "json",
                            "--only-show-errors",
                        ]
                    ),
                    self._az_json(
                        [
                            "repos",
                            "pr",
                            "show",
                            "--id",
                            str(pr_id),
                            "--org",
                            org_url,
                            "-o",
                            "json",
                            "--only-show-errors",
                        ]
                    ),
                    self._az_json(
                        [
                            "rest",
                            "--method",
                            "get",
                            "--resource",
                            _ADO_RESOURCE,
                            "--url",
                            (
                                f"{org_url.rstrip('/')}/{project_path}/_apis/git/repositories/"
                                f"{repository_path}/pullRequests/{pr_id}/threads"
                            ),
                            "--uri-parameters",
                            "api-version=7.1",
                            "--only-show-errors",
                        ]
                    ),
                )
                if not isinstance(policies_raw, list) or not isinstance(details, dict):
                    raise RuntimeError("PR policy/details response has the wrong shape")
                source_commit = str(
                    _as_dict(details.get("lastMergeSourceCommit")).get("commitId") or ""
                )
                if not source_commit:
                    raise RuntimeError("PR source commit is missing")
                target_commit = str(
                    _as_dict(details.get("lastMergeTargetCommit")).get("commitId") or ""
                )
                current_policies: list[dict[str, Any]] = []
                applicable_policies: list[dict[str, Any]] = []
                for policy in policies_raw:
                    config = _as_dict(_as_dict(policy).get("configuration"))
                    policy_type = _as_dict(config.get("type"))
                    if policy_type.get("displayName") != "Build":
                        continue
                    if config.get("isEnabled") is not True or config.get("isBlocking") is not True:
                        continue
                    context = _as_dict(_as_dict(policy).get("context"))
                    projected = {
                        "status": str(_as_dict(policy).get("status") or ""),
                        "buildIsNotCurrent": context.get("buildIsNotCurrent"),
                        "lastMergeSourceCommitId": str(
                            context.get("lastMergeSourceCommitId") or ""
                        ),
                    }
                    applicable_policies.append(projected)
                    if context.get("buildIsNotCurrent") is not False:
                        continue
                    if str(context.get("lastMergeSourceCommitId") or "") != source_commit:
                        continue
                    current_policies.append(projected)
                thread_rows = _as_dict(threads_raw).get("value")
                if not isinstance(thread_rows, list):
                    raise RuntimeError("PR threads response has the wrong shape")
                open_thread_ids = sorted(
                    int(thread["id"])
                    for thread in thread_rows
                    if isinstance(thread, dict)
                    and str(thread.get("status") or "").casefold() in {"active", "pending"}
                    and thread.get("id") is not None
                )
                is_draft = bool(row.get("isDraft"))
                statuses = [item["status"].casefold() for item in current_policies]
                all_policies_current = bool(applicable_policies) and len(current_policies) == len(
                    applicable_policies
                )
                kind = ""
                reason = ""
                signature = ""
                if open_thread_ids:
                    kind = "comment"
                    reason = f"有 {len(open_thread_ids)} 条未处理 review 评论"
                    joined = ",".join(str(item) for item in open_thread_ids)
                    signature = f"{pr_id}:comment:{joined}"
                elif any(status in {"rejected", "broken"} for status in statuses):
                    kind = "ci"
                    reason = "CI 未通过"
                    signature = f"{pr_id}:ci:{source_commit}"
                elif any(status in {"queued", "running"} for status in statuses):
                    pass
                elif all_policies_current and all(status == "approved" for status in statuses):
                    if is_draft:
                        kind = "green-draft"
                        signature = f"{pr_id}:green-draft:{source_commit}"
                elif applicable_policies:
                    kind = "stale-ci"
                    reason = "CI 需要重新验证"
                    signature = f"{pr_id}:stale-ci:{source_commit}:{target_commit}"

                bug_id: int | None = None
                if kind:
                    work_items = await self._az_json(
                        [
                            "repos",
                            "pr",
                            "work-item",
                            "list",
                            "--id",
                            str(pr_id),
                            "--org",
                            org_url,
                            "-o",
                            "json",
                            "--only-show-errors",
                        ]
                    )
                    if isinstance(work_items, list) and work_items:
                        first_id = _as_dict(work_items[0]).get("id")
                        if first_id is not None:
                            bug_id = int(first_id)
                    if bug_id is None:
                        bug_id = _infer_work_item_id(row)

                action_value = ""
                resumes = False
                resume_rank: int | None = None
                if kind and bug_id is not None:
                    action_value, resumes, resume_task_id, resume_rank = self._workflow_command(
                        pr_id=pr_id,
                        bug_id=bug_id,
                        repo_path=repo_path,
                        plans=plans,
                        plan_owner=plan_owner,
                    )
                    if resume_task_id:
                        signature = f"{signature}:resume:{resume_task_id}"

                item = {
                    "pr": pr_id,
                    "title": str(row.get("title") or ""),
                    "isDraft": is_draft,
                    "source": str(row.get("sourceRefName") or ""),
                    "target": str(row.get("targetRefName") or ""),
                    "bugId": bug_id,
                    "sourceCommit": source_commit,
                    "targetCommit": target_commit,
                    "currentPolicies": current_policies,
                    "stalePolicyCount": len(applicable_policies) - len(current_policies),
                    "openThreadIds": open_thread_ids,
                }
                snapshot.append(item)
                if kind and bug_id is not None and signature not in old_reminded:
                    actionables.append(
                        {
                            "pr": pr_id,
                            "title": item["title"],
                            "kind": kind,
                            "reason": reason,
                            "signature": signature,
                            "bug_id": bug_id,
                            "action_value": action_value,
                            "resumes": resumes,
                            "resume_rank": resume_rank,
                        }
                    )
            except Exception as exc:
                errors.append(f"PR {pr_id}: {_compact_error(exc)}")
                previous = old_by_id.get(str(pr_id))
                if previous:
                    snapshot.append(previous)
        actionables.sort(
            key=lambda item: (
                item["resume_rank"] is None,
                item["resume_rank"] if item["resume_rank"] is not None else 0,
            )
        )
        return snapshot, actionables, errors

    async def execute(self, **kwargs: Any) -> str:
        async with self._state_lock:
            return await self._execute_locked(**kwargs)

    async def _execute_locked(self, **kwargs: Any) -> str:
        validation = self.validate(kwargs)
        if validation:
            return "Error: " + "; ".join(validation)
        source = str(kwargs["bug_query_source"]).strip()
        org_url = _normalize_ado_org_url(kwargs["org_url"])
        if org_url is None:  # validate() above keeps this branch defensive.
            return "Error: invalid org_url"
        project = str(kwargs["project"]).strip()
        repository = str(kwargs["repository"]).strip()
        assigned_to = str(kwargs["assigned_to"]).strip()
        repo_path = str(kwargs["repo_path"]).strip()
        metadata = kwargs.get("_metadata")
        plan_owner = (
            str(metadata.get("plan_owner") or "").strip()[:200]
            if isinstance(metadata, dict)
            else ""
        )
        try:
            plans = list(self._plans_fn() or []) if plan_owner else []
        except Exception:
            plans = []
        state, first_run = self._load_state()
        old_source = str(state.get("bug_source") or "")
        old_bugs = _old_bug_snapshot(state)
        old_pending_bug_ids = _old_pending_bug_ids(state)
        old_prs = _old_pr_snapshot(state)
        old_reminded = _old_reminded(state)
        errors: list[str] = []

        bugs = old_bugs
        new_bug_ids: list[str] = []
        bug_success = False
        try:
            bugs, new_bug_ids = await self._scan_bugs(
                source=source,
                org_url=org_url,
                project=project,
                assigned_to=assigned_to,
                old_source=old_source,
                old_bugs=old_bugs,
            )
            bug_success = True
        except Exception as exc:
            errors.append(f"bug scan: {_compact_error(exc)}")

        if bug_success:
            pending_bug_ids = (
                []
                if old_source != source
                else [bug_id for bug_id in old_pending_bug_ids if bug_id in bugs]
            )
            pending_bug_ids.extend(
                bug_id for bug_id in new_bug_ids if bug_id not in pending_bug_ids
            )
        else:
            pending_bug_ids = [bug_id for bug_id in old_pending_bug_ids if bug_id in bugs]

        pr_snapshot = old_prs
        actionables: list[dict[str, Any]] = []
        pr_success = False
        try:
            pr_snapshot, actionables, pr_errors = await self._scan_prs(
                org_url=org_url,
                project=project,
                repository=repository,
                assigned_to=assigned_to,
                repo_path=repo_path,
                old_snapshot=old_prs,
                old_reminded=old_reminded,
                plans=plans,
                plan_owner=plan_owner,
            )
            errors.extend(pr_errors)
            pr_success = True
        except Exception as exc:
            errors.append(f"PR scan: {_compact_error(exc)}")

        # A bug whose fix is already in flight must not be announced as new work.
        # Suppress it at SELECTION time, never by dropping it from pending_bug_ids:
        # `new_bug_ids` is a one-shot set difference against the `bugs` snapshot
        # (_scan_bugs), so a bug removed from pending can never become "new" again —
        # not even after its PR is abandoned. Leaving it pending keeps the offer owed
        # and lets it resurface on the first scan where the PR is gone.
        #
        # Only when the PR scan SUCCEEDED: on failure `pr_snapshot` is the stale
        # `old_prs`, and suppressing on stale data would silence a bug indefinitely.
        # Each lane degrades on its own here (see the bug-scan failure path above).
        suppressed_bug_ids = _bugs_with_active_pr(pr_snapshot) if pr_success else set()
        offerable_bug_ids = [
            bug_id for bug_id in pending_bug_ids if bug_id not in suppressed_bug_ids
        ]

        selected_pr: dict[str, Any] | None = None
        # Gated on OFFERABLE, not pending: a suppressed bug stays pending forever
        # (never offered, so never acknowledged), and gating on `pending_bug_ids`
        # would let it starve the PR lane permanently. That also fixes the same
        # starvation for a bug whose card delivery keeps failing.
        if not first_run and not offerable_bug_ids and actionables:
            selected_pr = actionables[0]

        if bug_success or pr_success:
            merged = {
                "bug_source": source if bug_success else old_source,
                "captured_at": datetime.now(UTC).isoformat(),
                "bugs": bugs,
                "pending_bug_ids": pending_bug_ids,
                "prs": {
                    "snapshot": pr_snapshot,
                    "reminded": sorted(old_reminded),
                },
            }
            try:
                self._write_state(merged)
            except Exception as exc:
                return f"Error: failed to update watcher state: {_compact_error(exc)}"
        else:
            return "Error: Societas watcher failed: " + "; ".join(errors)

        if first_run:
            return "(no response)"
        if offerable_bug_ids:
            bug = bugs[offerable_bug_ids[0]]
            action_value, _, _, _ = self._workflow_command(
                pr_id=0,
                bug_id=int(bug["id"]),
                repo_path=repo_path,
                plans=plans,
                plan_owner=plan_owner,
            )
            result = _card(
                f"🐛 有新 bug #{bug['id']}：{bug['title']} assign 给你了，要现在跑 "
                "fix-societas-bug 修复吗？",
                f"🔧 修 bug #{bug['id']}",
                action_value,
            )
            self._remember_delivery_ack(result, "bug", str(bug["id"]))
            return result
        if selected_pr:
            pr_id = int(selected_pr["pr"])
            bug_id = int(selected_pr["bug_id"])
            title = str(selected_pr["title"])
            action_value = str(selected_pr["action_value"])
            resumes = bool(selected_pr["resumes"])
            if selected_pr["kind"] == "green-draft":
                result = _card(
                    f"✅ PR #{pr_id}「{title}」（关联 bug #{bug_id}）CI 已全绿，但还是 "
                    "draft。要我把它迭代到 ready 吗？",
                    (
                        f"▶️ 继续 PR #{pr_id} 到 ready"
                        if resumes
                        else f"⏩ flip PR #{pr_id} 到 ready"
                    ),
                    action_value,
                )
            else:
                result = _card(
                    f"⏩ PR #{pr_id}「{title}」（关联 bug #{bug_id}）卡在 "
                    f"{selected_pr['reason']}，要我继续处理到 ready for review 吗？",
                    (f"▶️ 继续 PR #{pr_id}" if resumes else f"⏩ 迭代 PR #{pr_id}"),
                    action_value,
                )
            self._remember_delivery_ack(result, "pr", str(selected_pr["signature"]))
            return result
        if errors:
            return "Societas watcher partial failure: " + "; ".join(errors)
        return "(no response)"
