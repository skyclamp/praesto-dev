"""Praesto tag experiment sink for Teams knowledge-capture snapshots."""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_MAX_CAPTURE_BYTES = 5 * 1024 * 1024
_CACHED_SOURCES = ("messages", "transcripts")


def default_capture_dir() -> Path:
    """``<data_dir>/kb/captures`` — where a capture snapshot lands.

    Resolved lazily rather than at import time so a ``--data-dir`` override (or
    a test's ``set_data_dir``) still applies. The snapshot is the hand-off
    between the two stages: collection writes it, curation reads it. It
    therefore belongs beside the verbatim cache it folds in
    (``<data_dir>/teams-web``) rather than in a developer scratch directory.
    """
    from praestoclaw.kb import captures_dir

    return captures_dir()


def _filename_slug(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9\u4e00-\u9fff._-]+", "-", value).strip("-._")
    return cleaned[:64] or "teams-capture"


def _load_cached_records(cid: str, sources: list[str]) -> tuple[list[dict[str, Any]], list[str]]:
    """Fold what ``teams_group_fetch`` cached for *cid* into snapshot records.

    The cache is keyed by conversation id, so this can only ever surface the
    material belonging to the group that asked. Provenance labels travel with
    the payload: ``verbatim/chatsvc`` for messages, ``verbatim/ams`` (speaker
    attribution is ground truth) or ``verbatim/odsp`` (no attribution) for
    transcripts. Nothing here is model-mediated.
    """
    from praestoclaw.teams_web.recordings import ALL_RENDITIONS, RecordingPointer
    from praestoclaw.teams_web.store import TeamsWebChatStore

    store = TeamsWebChatStore(cid)
    segments = store.load_segments()
    records: list[dict[str, Any]] = []
    missing: list[str] = []

    if "messages" in sources:
        stored = store.load_messages()
        if not stored.count:
            missing.append("messages")
        else:
            records.append(
                {
                    "type": "chat_messages",
                    "provenance": "verbatim/chatsvc",
                    "conversation_id": cid,
                    "fetched_at": stored.fetched_at,
                    "region": stored.region,
                    "count": stored.count,
                    "covered_from": segments[0].to_index_entry()["from"] if segments else None,
                    "covered_to": segments[-1].to_index_entry()["to"] if segments else None,
                    "segments": [segment.to_index_entry() for segment in stored.segments],
                    "cache_dir": str(store.messages_dir),
                    # ``messages`` remains the verbatim chatsvc response.  The
                    # parallel projection makes quote/image/file/reaction
                    # material explicit for curation without losing the raw
                    # source that established it.
                    "messages": stored.messages,
                    "normalized_messages": _materialize_message_views(stored.messages),
                    # Bytes are intentionally not duplicated into the snapshot
                    # (which has a strict size cap). Each sidecar points at a
                    # content-addressed, cid-scoped local artifact instead.
                    "artifacts": store.load_artifact_metadata(),
                }
            )

    if "transcripts" in sources:
        inventory = store.load_transcript_inventory()
        found = False
        for entry in inventory:
            pointer = RecordingPointer.from_dict(entry)
            for rendition in ALL_RENDITIONS:
                vtt = store.load_transcript(
                    call_id=pointer.call_id,
                    transcript_id=pointer.transcript_id,
                    rendition=rendition,
                )
                if not vtt:
                    continue
                found = True
                records.append(
                    {
                        "type": "meeting_transcript",
                        "provenance": ("verbatim/ams" if rendition == "ams" else "verbatim/odsp"),
                        "speaker_attribution": ("ground_truth" if rendition == "ams" else "absent"),
                        "conversation_id": cid,
                        "rendition": rendition,
                        "pointer": pointer.to_dict(),
                        "cache_path": str(
                            store.transcript_dir(pointer.call_id, pointer.transcript_id)
                            / f"{rendition}.vtt"
                        ),
                        "vtt": vtt,
                    }
                )
        if not found:
            missing.append("transcripts")

    return records, missing


def _materialize_message_views(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Resolve quoted-message ids against this cache, never another chat."""
    from praestoclaw.teams_web.chatsvc import normalize_message_for_capture

    by_id = {str(message.get("id") or ""): message for message in messages if message.get("id")}
    views = [normalize_message_for_capture(message) for message in messages]
    for view in views:
        quote = view.get("quoted_original")
        if not isinstance(quote, dict):
            continue
        raw = quote.get("raw")
        ref_id = str(quote.get("referenced_message_id") or "")
        if isinstance(raw, dict):
            ref_id = ref_id or str(
                raw.get("id")
                or raw.get("messageId")
                or raw.get("message_id")
                or raw.get("itemid")
                or raw.get("itemId")
                or raw.get("targetId")
                or ""
            )
        if ref_id:
            quote["referenced_message_id"] = ref_id
            original = by_id.get(ref_id)
            if original is not None:
                quote["resolved_from_cached_message"] = True
                quote["raw_message"] = original
                quote["normalized_message"] = normalize_message_for_capture(original)
            else:
                quote["resolved_from_cached_message"] = False
                quote["resolution"] = "unresolved_preview_only"
        else:
            quote["resolution"] = "inline_preview_only"
    return views


class TeamKnowledgeCaptureTool(Tool):
    """Write a structured Teams snapshot to the experiment discussion workspace."""

    risk_range = (2, 2)

    def __init__(self, base_dir: Path | None = None) -> None:
        self._base_dir = base_dir

    @property
    def name(self) -> str:
        return "team_knowledge_capture"

    @property
    def description(self) -> str:
        return (
            "Save Teams content collected for the team knowledge-base experiment. "
            "It creates one JSON snapshot under <data_dir>/kb/captures and cannot "
            "write anywhere else. Pass cached_sources to fold in what "
            "teams_group_fetch already cached for this conversation without "
            "retyping it. Only available in a praesto tag exp group session."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=15, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(2, reason="Write one experiment snapshot to <data_dir>/kb/captures")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "title": {
                    "type": "string",
                    "description": "Short filename/title describing this capture.",
                },
                "user_request": {
                    "type": "string",
                    "description": "The user's original collection instruction.",
                },
                "records": {
                    "type": "array",
                    "description": (
                        "Records the model assembled itself — notably source_gap entries "
                        "describing what could not be retrieved. Preserve source identifiers, "
                        "links, authors, timestamps, message bodies, and reply relationships "
                        "whenever available. May be omitted when cached_sources is used."
                    ),
                    "items": {
                        "type": "object",
                        "additionalProperties": True,
                    },
                },
                "cached_sources": {
                    "type": "array",
                    "description": (
                        "Fold the verbatim material teams_group_fetch cached for THIS "
                        "conversation into the snapshot: 'messages' embeds every captured "
                        "message, 'transcripts' embeds the downloaded VTT renditions with "
                        "their provenance."
                    ),
                    "items": {"type": "string", "enum": list(_CACHED_SOURCES)},
                },
            },
            "required": ["title", "user_request"],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not praesto_tag_exp_is_active(metadata):
            return "team_knowledge_capture is only available in a praesto tag exp group session."

        title = str(kwargs.get("title") or "").strip()
        user_request = str(kwargs.get("user_request") or "").strip()
        records = kwargs.get("records")
        if records is None:
            records = []
        if not title:
            return "Error: title is required."
        if not user_request:
            return "Error: user_request is required."
        if not isinstance(records, list):
            return "Error: records must be an array."
        if not all(isinstance(record, dict) for record in records):
            return "Error: every records item must be an object."

        cid = str(metadata.get("cid") or "")
        requested_sources = [
            source for source in (kwargs.get("cached_sources") or []) if source in _CACHED_SOURCES
        ]
        records = list(records)
        if requested_sources:
            if not cid:
                return "Error: cached_sources needs a Teams conversation id on this turn."
            cached_records, missing = _load_cached_records(cid, requested_sources)
            records.extend(cached_records)
            for source in missing:
                records.append(
                    {
                        "type": "source_gap",
                        "source": source,
                        "conversation_id": cid,
                        "status": "not_cached",
                        "reason": (
                            f"teams_group_fetch has not cached '{source}' for this "
                            "conversation yet."
                        ),
                    }
                )

        if not records:
            return (
                "Error: nothing to save. Provide records, or cached_sources after running "
                "teams_group_fetch."
            )

        captured_at = datetime.now().astimezone()
        payload = {
            "schema_version": 2,
            "captured_at": captured_at.isoformat(),
            "request_context": {
                "user_request": user_request,
                "requesting_conversation_id": cid,
                "requesting_conversation_name": str(metadata.get("conversation_name") or ""),
                "requested_by": str(metadata.get("sender_name") or ""),
            },
            "records": records,
        }
        serialized = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
        size = len(serialized.encode("utf-8"))
        if size > _MAX_CAPTURE_BYTES:
            return (
                f"Error: capture is too large ({size:,} bytes). "
                f"Split it into files smaller than {_MAX_CAPTURE_BYTES:,} bytes."
            )

        try:
            base_dir = self._base_dir or default_capture_dir()
            base_dir.mkdir(parents=True, exist_ok=True)
            timestamp = captured_at.strftime("%Y%m%d-%H%M%S-%f")
            path = base_dir / f"{timestamp}-{_filename_slug(title)}.json"
            with path.open("x", encoding="utf-8", newline="\n") as handle:
                handle.write(serialized)
        except OSError as exc:
            return f"Error saving Teams capture: {exc}"

        replacement_guidance = ""
        if cid:
            # Put the mandatory replacement action beside the newly written
            # capture path.  This is the last tool result the model sees before
            # it previously drifted into a recommendation-only answer, so do not
            # rely on an earlier skill paragraph alone.
            from praestoclaw.kb.draft import CurationTaskStore

            if active := CurationTaskStore(cid).active():
                replacement_guidance = (
                    "\nAn unfinished KB proposal is active "
                    f"({active.task_id}). If this capture belongs to a NEW KB update "
                    "or update-assessment request, you MUST now call "
                    "kb_draft(action='restart', user_request=<current request>, "
                    f"capture='{path.name}'). This verifies deletion of the old local "
                    "Git proposal branch and starts the fresh publish process. Continue "
                    "through kb_draft(action='stage') in this turn; do not reply with a "
                    "recommendation list."
                )

        return (
            f"Saved {len(records)} Teams record(s) to {path}\n"
            "Capture is complete. If the request also asked for the team knowledge base "
            "to be updated, continue now with tools(name='team-knowledge-curate', "
            "action='skill') and continue through kb_draft(action='stage') in this same "
            "turn; do not stop with recommendations or say that no draft was created. "
            "If it only asked for collection, stop here."
            f"{replacement_guidance}"
        )
