"""Create a bounded draft pull request in the Societas Azure DevOps repository."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import quote

import httpx

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.host.runtime_contracts import is_trusted_workflow_run
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ORGANIZATION = "https://o365exchange.visualstudio.com"
_PROJECT = "O365 Core"
_REPOSITORY = "Societas"
_ADO_RESOURCE = "499b84ac-1321-427f-aa17-267ca6975798"
_API_VERSION = "7.1"
_WORKFLOW = "fix-societas-bug"
_MAX_BRANCH_CHARS = 255
_MAX_TITLE_CHARS = 200
_MAX_DESCRIPTION_CHARS = 3900

TokenProvider = Callable[[], Awaitable[str | None]]


class SocietasPrSubmitTool(Tool):
    """Create or recover one draft PR through a fixed Societas boundary."""

    risk_range = (6, 6)

    def __init__(
        self,
        *,
        token_provider: TokenProvider | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._token_provider = token_provider or self._default_token_provider
        self._transport = transport

    @property
    def name(self) -> str:
        return "societas_pr_submit"

    @property
    def description(self) -> str:
        return (
            "For a trusted fix-societas-bug workflow, create or recover a draft pull "
            "request in the fixed O365 Core/Societas repository, using explicit source "
            "and target branches and linking the workflow's ADO bug."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "bug_id": {"type": "integer", "minimum": 1},
                "source_branch": {"type": "string", "maxLength": _MAX_BRANCH_CHARS},
                "target_branch": {"type": "string", "maxLength": _MAX_BRANCH_CHARS},
                "title": {"type": "string", "maxLength": _MAX_TITLE_CHARS},
                "description": {"type": "string", "maxLength": _MAX_DESCRIPTION_CHARS},
            },
            "required": [
                "bug_id",
                "source_branch",
                "target_branch",
                "title",
                "description",
            ],
            "additionalProperties": False,
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(6, reason="Create a draft pull request in O365 Core/Societas")

    def audit_args(self, args: dict[str, Any]) -> dict[str, Any]:
        description = args.get("description") if isinstance(args.get("description"), str) else ""
        return {
            "bug_id": args.get("bug_id"),
            "source_branch": str(args.get("source_branch") or ""),
            "target_branch": str(args.get("target_branch") or ""),
            "title": self._sanitize_text(str(args.get("title") or "")),
            **({"description": f"[omitted: {len(description)} chars]"} if description else {}),
        }

    @staticmethod
    def _sanitize_text(value: str) -> str:
        return redact_credentials(value)

    @staticmethod
    def _is_trusted_workflow(metadata: Any) -> bool:
        if not isinstance(metadata, dict) or metadata.get("workflow") != _WORKFLOW:
            return False
        scope = metadata.get("workflow_allowed_tools")
        return (
            is_trusted_workflow_run(metadata)
            and isinstance(scope, list)
            and "societas_pr_submit" in scope
        )

    @staticmethod
    def _workflow_bug_id(metadata: Any) -> str:
        if not isinstance(metadata, dict):
            return ""
        params = metadata.get("workflow_params")
        return str(params.get("bug_id") or "").strip() if isinstance(params, dict) else ""

    @staticmethod
    def _reject_unencodable(value: str, field: str) -> str:
        """Refuse text the ADO request could not encode, e.g. a lone surrogate."""
        try:
            value.encode("utf-8")
        except UnicodeEncodeError:
            return f"Refused: {field} contains invalid Unicode."
        return ""

    @staticmethod
    def _validate_branch(value: Any, field: str) -> tuple[str, str]:
        if not isinstance(value, str) or not value or value != value.strip():
            return "", f"Refused: {field} must be a non-empty branch name."
        if len(value) > _MAX_BRANCH_CHARS:
            return "", f"Refused: {field} exceeds {_MAX_BRANCH_CHARS} characters."
        # execute() prefixes every branch with "refs/heads/", so a fully-qualified
        # ref would silently become "refs/heads/refs/heads/...". Refuse it here
        # rather than letting ADO reject the double prefix after the request.
        if value.startswith("refs/"):
            return "", f"Refused: {field} must be a plain branch name, not a fully-qualified ref."
        if (
            value.startswith(("-", ".", "/"))
            or value.endswith((".", "/", ".lock"))
            or ".." in value
            or "@{" in value
            or "//" in value
            or any(ord(char) <= 32 or char in "~^:?*\\[]" for char in value)
        ):
            return "", f"Refused: {field} is not a safe branch name."
        refusal = SocietasPrSubmitTool._reject_unencodable(value, field)
        if refusal:
            return "", refusal
        return value, ""

    @staticmethod
    def _validate_text(value: Any, field: str, maximum: int) -> tuple[str, str]:
        if not isinstance(value, str) or not value.strip():
            return "", f"Refused: {field} must not be empty."
        if len(value) > maximum:
            return "", f"Refused: {field} exceeds {maximum} characters."
        if "\0" in value or (field == "title" and any(char in value for char in "\r\n")):
            return "", f"Refused: {field} contains an invalid control character."
        refusal = SocietasPrSubmitTool._reject_unencodable(value, field)
        if refusal:
            return "", refusal
        return SocietasPrSubmitTool._sanitize_text(value), ""

    @staticmethod
    async def _default_token_provider() -> str | None:
        from praestoclaw.auth.azure_cli import AzureCliProvider

        provider = AzureCliProvider(resource=_ADO_RESOURCE)
        return await asyncio.to_thread(provider.try_silent)

    @staticmethod
    def _http_error(response: httpx.Response) -> str:
        try:
            payload = response.json()
            detail = payload.get("message") if isinstance(payload, dict) else ""
        except ValueError:
            detail = response.text
        compact = " ".join(str(detail or "").split())[:500]
        return redact_credentials(compact or response.reason_phrase or "request failed")

    @classmethod
    async def _request_json(
        cls,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        *,
        expected_statuses: frozenset[int] = frozenset({200}),
        **kwargs: Any,
    ) -> tuple[dict[str, Any] | None, str]:
        try:
            response = await client.request(method, url, **kwargs)
        except httpx.HTTPError as exc:
            return None, f"request failed: {redact_credentials(str(exc))}"
        if response.status_code not in expected_statuses:
            return None, f"HTTP {response.status_code}: {cls._http_error(response)}"
        try:
            payload = response.json()
        except ValueError:
            return None, "response was not valid JSON"
        if not isinstance(payload, dict):
            return None, "response JSON was not an object"
        return payload, ""

    @staticmethod
    def _work_item_ids(pull_request: dict[str, Any]) -> set[str]:
        refs = pull_request.get("workItemRefs")
        if not isinstance(refs, list):
            return set()
        return {
            str(item.get("id"))
            for item in refs
            if isinstance(item, dict) and item.get("id") is not None
        }

    @staticmethod
    def _pull_request_id(pull_request: Any) -> int | None:
        """Return the positive pull request ID, or None when it is unusable."""
        if not isinstance(pull_request, dict):
            return None
        try:
            pull_request_id = int(pull_request["pullRequestId"])
        except (KeyError, TypeError, ValueError):
            return None
        return pull_request_id if pull_request_id >= 1 else None

    @classmethod
    def _validate_pull_request(
        cls,
        pull_request: dict[str, Any],
        *,
        repository_id: str,
        source_branch: str,
        target_branch: str,
        bug_id: int,
    ) -> str:
        repository = pull_request.get("repository")
        if not isinstance(repository, dict):
            return "repository was missing"
        if cls._pull_request_id(pull_request) is None:
            return "pull request ID was invalid"
        checks = (
            (str(repository.get("id") or "") == repository_id, "repository ID differed"),
            (
                str(repository.get("name") or "").casefold() == _REPOSITORY.casefold(),
                "repository name differed",
            ),
            (
                pull_request.get("sourceRefName") == f"refs/heads/{source_branch}",
                "source branch differed",
            ),
            (
                pull_request.get("targetRefName") == f"refs/heads/{target_branch}",
                "target branch differed",
            ),
            (pull_request.get("isDraft") is True, "pull request was not draft"),
            (
                str(pull_request.get("status") or "").casefold() == "active",
                "pull request was not active",
            ),
            (str(bug_id) in cls._work_item_ids(pull_request), "bug work item was not linked"),
        )
        return next((message for valid, message in checks if not valid), "")

    @staticmethod
    def _result(
        action: str,
        pull_request: dict[str, Any],
        *,
        repository_id: str,
        source_branch: str,
        target_branch: str,
        bug_id: int,
    ) -> str:
        pull_request_id = int(pull_request["pullRequestId"])
        url = (
            f"{_ORGANIZATION}/{quote(_PROJECT, safe='')}/_git/"
            f"{quote(_REPOSITORY, safe='')}/pullrequest/{pull_request_id}"
        )
        return json.dumps(
            {
                "action": action,
                "pull_request_id": pull_request_id,
                "url": url,
                "repository_id": repository_id,
                "source_branch": source_branch,
                "target_branch": target_branch,
                "is_draft": True,
                "work_item_id": bug_id,
            },
            ensure_ascii=False,
        )

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata")
        if not self._is_trusted_workflow(metadata):
            return "Refused: societas_pr_submit requires a trusted fix-societas-bug workflow run."

        raw_bug_id = kwargs.get("bug_id")
        if isinstance(raw_bug_id, bool) or not isinstance(raw_bug_id, int) or raw_bug_id < 1:
            return "Refused: bug_id must be a positive integer."
        bug_id = raw_bug_id
        if self._workflow_bug_id(metadata) != str(bug_id):
            return "Refused: bug_id must match the trusted workflow bug_id."

        source_branch, refusal = self._validate_branch(kwargs.get("source_branch"), "source_branch")
        if refusal:
            return refusal
        target_branch, refusal = self._validate_branch(kwargs.get("target_branch"), "target_branch")
        if refusal:
            return refusal
        if source_branch == target_branch:
            return "Refused: source_branch and target_branch must be different."
        if str(bug_id) not in source_branch:
            return "Refused: source_branch must contain bug_id."

        title, refusal = self._validate_text(kwargs.get("title"), "title", _MAX_TITLE_CHARS)
        if refusal:
            return refusal
        description, refusal = self._validate_text(
            kwargs.get("description"), "description", _MAX_DESCRIPTION_CHARS
        )
        if refusal:
            return refusal
        if f"Fixes AB#{bug_id}." not in description:
            return f"Refused: description must contain 'Fixes AB#{bug_id}.'"

        try:
            token = await self._token_provider()
        except Exception as exc:  # noqa: BLE001 - provider errors become tool errors
            return f"PR submission unavailable: token acquisition failed: {self._sanitize_text(str(exc))}"
        if not token:
            return "PR submission unavailable: Azure CLI could not provide an ADO token."

        project_url = f"{_ORGANIZATION}/{quote(_PROJECT, safe='')}"
        repository_url = f"{project_url}/_apis/git/repositories/{quote(_REPOSITORY, safe='')}"
        async with httpx.AsyncClient(
            headers={"Authorization": f"Bearer {token}"},
            timeout=httpx.Timeout(45.0, connect=15.0),
            transport=self._transport,
            follow_redirects=False,
        ) as client:
            repository, error = await self._request_json(
                client,
                "GET",
                repository_url,
                params={"api-version": _API_VERSION},
            )
            if error:
                return f"PR submission failed while resolving the fixed repository: {error}"
            repository_id = str((repository or {}).get("id") or "")
            if (
                not repository_id
                or str((repository or {}).get("name") or "").casefold() != _REPOSITORY.casefold()
            ):
                return "PR submission refused: the fixed Societas repository could not be verified."

            pull_requests_url = f"{project_url}/_apis/git/repositories/{repository_id}/pullrequests"
            existing_payload, error = await self._request_json(
                client,
                "GET",
                pull_requests_url,
                params={
                    "searchCriteria.status": "active",
                    "searchCriteria.sourceRefName": f"refs/heads/{source_branch}",
                    "searchCriteria.includeWorkItems": "true",
                    "api-version": _API_VERSION,
                },
            )
            if error:
                return f"PR submission failed during duplicate check: {error}"
            raw_existing = (existing_payload or {}).get("value")
            count = (existing_payload or {}).get("count")
            if (
                not isinstance(raw_existing, list)
                or isinstance(count, bool)
                or not isinstance(count, int)
                or count != len(raw_existing)
            ):
                return "PR submission failed during duplicate check: malformed response."
            existing = raw_existing
            exact_source = [
                item
                for item in existing
                if isinstance(item, dict)
                and item.get("sourceRefName") == f"refs/heads/{source_branch}"
            ]
            if len(exact_source) > 1:
                return "Refused: multiple active pull requests already use source_branch."
            if exact_source:
                existing_id = self._pull_request_id(exact_source[0])
                if existing_id is None:
                    return "Refused: the existing pull request ID was invalid."
                current, error = await self._request_json(
                    client,
                    "GET",
                    f"{pull_requests_url}/{existing_id}",
                    params={"includeWorkItemRefs": "true", "api-version": _API_VERSION},
                )
                if error:
                    return f"PR submission failed while verifying the existing PR: {error}"
                assert current is not None
                verification_error = self._validate_pull_request(
                    current,
                    repository_id=repository_id,
                    source_branch=source_branch,
                    target_branch=target_branch,
                    bug_id=bug_id,
                )
                if verification_error:
                    return (
                        "Refused: an active pull request already uses source_branch, but "
                        f"{verification_error}."
                    )
                return self._result(
                    "reuse",
                    current,
                    repository_id=repository_id,
                    source_branch=source_branch,
                    target_branch=target_branch,
                    bug_id=bug_id,
                )

            created, error = await self._request_json(
                client,
                "POST",
                pull_requests_url,
                expected_statuses=frozenset({200, 201}),
                params={"api-version": _API_VERSION},
                json={
                    "sourceRefName": f"refs/heads/{source_branch}",
                    "targetRefName": f"refs/heads/{target_branch}",
                    "title": title,
                    "description": description,
                    "isDraft": True,
                    "workItemRefs": [{"id": str(bug_id)}],
                },
            )
            if error:
                return f"PR submission failed; creation outcome may be ambiguous: {error}"

            created_id = self._pull_request_id(created)
            if created_id is None:
                return "PR may have been created, but its pull request ID was invalid."
            created, error = await self._request_json(
                client,
                "GET",
                f"{pull_requests_url}/{created_id}",
                params={"includeWorkItemRefs": "true", "api-version": _API_VERSION},
            )
            if error:
                return f"PR may have been created, but its details could not be verified: {error}"

        assert created is not None
        verification_error = self._validate_pull_request(
            created,
            repository_id=repository_id,
            source_branch=source_branch,
            target_branch=target_branch,
            bug_id=bug_id,
        )
        if verification_error:
            return f"PR may have been created, but {verification_error}."
        return self._result(
            "create",
            created,
            repository_id=repository_id,
            source_branch=source_branch,
            target_branch=target_branch,
            bug_id=bug_id,
        )
