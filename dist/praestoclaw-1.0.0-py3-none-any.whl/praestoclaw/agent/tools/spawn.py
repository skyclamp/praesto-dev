"""
Sub-agent spawning tool — create and manage child agent executions.

The tool delegates actual agent creation to a runtime-provided callback
(``spawn_fn``), keeping the tool itself decoupled from runtime internals.
Supports three execution modes:

- **serial**: await a single sub-agent and return its result.
- **parallel**: run multiple agents concurrently (prompt is a JSON array)
  and return all results.
- **background**: delegate to the runtime background manager when one is
  available; otherwise run inline and return the real result.
"""

from __future__ import annotations

import asyncio
import inspect
import json
from collections.abc import Awaitable, Callable
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.host.background_tasks import BackgroundOrigin, origin_from_kwargs
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

# Type alias for the runtime-provided spawn callback.
# Signature: async spawn_fn(agent_name: str, prompt: str, *, metadata: dict | None) -> str
SpawnFn = Callable[..., Awaitable[str]]

# Type alias for the runtime-provided detached background launcher.
# Signature: async background_fn(agent, prompt, *, origin, metadata, parent_session) -> (task_id, message)
BackgroundFn = Callable[..., Awaitable[tuple[str | None, str]]]

# The one ``workflow*`` metadata key a spawned child KEEPS. It is an allowlist the
# runtime intersects into the child's own palette (workflow.intersect_allowed_tools),
# not a grant — see the strip in :meth:`SpawnTool.execute` for why it must survive.
_WORKFLOW_CAPABILITY_CAP = "workflow_allowed_tools"

# The second ``workflow*`` key a spawned child keeps, and the first that is a
# GRANT rather than a cap — say so plainly, because the distinction is the whole
# reason the strip below exists. It carries one value: the repository path this
# run already resolved, so a child can be handed read access to the tree its
# parent is already working in (runtime._grant_child_repo_reads). It is not the
# whole ``workflow_params`` dict — forwarding that would carry the spec path,
# work item and target branch along with it for no reason.
#
# It grants nothing the run does not hold: `shell` is in the recipe's palette
# and every step is already `cd -- '<repo_path>' && …` inside that tree. What it
# buys is a second reader — the coverage auditor — that can see what the first
# pass could already see.
_WORKFLOW_READ_ROOT = "workflow_repo_path"

# A denial list, unlike every other `workflow*` key, cannot grant a child
# anything — it only ever removes commands. Stripping it was the strictly less
# safe direction: the child of a recipe that declares `spawn` was running with
# the parent's prohibitions silently lifted.
_WORKFLOW_DENIED_COMMANDS = "workflow_denied_commands"

_WORKFLOW_KEEP = frozenset(
    {_WORKFLOW_CAPABILITY_CAP, _WORKFLOW_READ_ROOT, _WORKFLOW_DENIED_COMMANDS}
)


class SpawnTool(Tool):
    """Spawn sub-agents in serial, parallel, or background mode."""

    risk_range = (2, 7)

    def __init__(
        self,
        spawn_fn: SpawnFn,
        available_agents: list[str] | None = None,
        *,
        background_fn: BackgroundFn | None = None,
    ) -> None:
        self._spawn_fn = spawn_fn
        self._background_fn = background_fn
        self._available_agents = available_agents or []
        # Cache whether spawn_fn accepts a metadata kwarg (inspect once).
        try:
            sig = inspect.signature(spawn_fn)
            params = list(sig.parameters.values())
            self._spawn_accepts_metadata = any(
                p.name == "metadata" or p.kind is inspect.Parameter.VAR_KEYWORD for p in params
            )
            # Whether spawn_fn accepts a ``_parent_session`` kwarg, so the
            # forked sub-agent session can be linked to the originating
            # conversation instead of a synthetic local default (which does
            # not exist in web/cloud deployments → fork AssertionError).
            self._spawn_accepts_parent_session = any(
                p.name == "_parent_session" or p.kind is inspect.Parameter.VAR_KEYWORD
                for p in params
            )
        except (ValueError, TypeError):
            self._spawn_accepts_metadata = False
            self._spawn_accepts_parent_session = False

    def set_available_agents(self, agents: list[str]) -> None:
        """Update the available agent names (called after agents are merged)."""
        self._available_agents = agents

    # ── Tool ABC ────────────────────────────────────────────────────────

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        agent = (args.get("agent", "") or "").strip()
        mode = (args.get("mode", "serial") or "serial").strip()
        # Mode is checked FIRST, and the explorer shortcut is gated on serial.
        # `parallel` ignores the top-level `agent` entirely — `_parallel` reads the
        # agent names out of the prompt JSON — so scoring on `agent` alone let
        # `spawn(agent="explorer", mode="parallel", prompt='[{"agent":"default",…}]')`
        # take the deterministic RiskScore(2) path and auto-approve a full `default`
        # child. That is the shape issue #646 was about, and because the base decider
        # already returns AUTO, no downstream gate (including the workflow-scoped
        # narrowing in hooks.ApprovalGate) ever got to see the call.
        if mode == "parallel":
            return RiskPrompt(
                context=f"Parallel sub-agent spawn (agent={agent})",
                range=(4, 7),
                factors=(
                    "4: Parallel read-only tasks (search, analysis)",
                    "5: Parallel tasks with local writes (file edits, git)",
                    "6: Parallel tasks with external side effects (API, push)",
                    "7: Parallel tasks with broad scope or unknown agents",
                ),
            )
        if agent == "explorer" and mode == "serial":
            return RiskScore(2, reason="Read-only explorer sub-agent")
        return RiskPrompt(
            context=f"Sub-agent spawn (agent={agent}, mode={mode})",
            range=(3, 6),
            factors=(
                "3: Known agent doing read-only or analysis task",
                "4: Agent with local write scope (file edits, git commit)",
                "5: Agent with external side effects or broad scope",
                "6: Unknown agent, background mode, or unrestricted prompt",
            ),
        )

    @property
    def name(self) -> str:
        return "spawn"

    @property
    def description(self) -> str:
        return "Delegate a task to a sub-agent."

    @property
    def parameters(self) -> dict[str, Any]:
        agent_desc = "Agent name. "
        if self._available_agents:
            agent_desc += f"Available: {', '.join(self._available_agents)}. "
        agent_desc += "Ignored in parallel mode."

        return {
            "type": "object",
            "properties": {
                "agent": {
                    "type": "string",
                    "description": agent_desc,
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Task prompt. For parallel mode: JSON array of "
                        '[{"agent": "...", "prompt": "..."}] objects.'
                    ),
                },
                "mode": {
                    "type": "string",
                    "enum": ["serial", "parallel", "background"],
                    "description": (
                        "serial (default) = wait for result; "
                        "parallel = run multiple agents concurrently; "
                        "background = use the runtime background manager when available, "
                        "otherwise run inline and return the result."
                    ),
                },
            },
            "required": ["agent", "prompt"],
        }

    async def execute(self, **kwargs: Any) -> str:
        prompt: str = kwargs.get("prompt") or ""
        if not prompt:
            return "Error: spawn requires a non-empty 'prompt'."
        mode: str = kwargs.get("mode", "serial")
        # ``agent`` is required by the JSON schema for serial/background modes
        # (parallel mode carries the agent per-item inside the ``prompt`` JSON
        # array). Validate explicitly and return a clear error rather than
        # silently defaulting a missing/blank value — that would mask a
        # malformed tool call and could route work to a non-existent agent.
        agent: str = (kwargs.get("agent") or "").strip()
        if mode in ("serial", "background") and not agent:
            return "Error: spawn requires a non-empty 'agent' for serial/background mode."
        # Metadata injected by registry via _metadata kwarg (same pattern as _channel).
        # Propagated to child agents so cron security restrictions carry through.
        metadata: dict[str, Any] | None = kwargs.get("_metadata")
        # A spawned child is NEVER itself a top-level workflow RUN. Strip the parent's
        # workflow-run markers (`workflow`, `workflow_owner`, `workflow_max_*`, …)
        # before forwarding — otherwise a spawn(mode='background') from inside a
        # running workflow inherits `metadata["workflow"]` and gets MISCLASSIFIED as a
        # workflow session (MAIN lane, workflow runner + teardown, scoped
        # auto-approval, societas_pr_submit's trusted-workflow check).
        #
        # `workflow_allowed_tools` is the ONE exception, and it is kept deliberately.
        # It is the recipe's declared capability envelope, read by
        # runtime._run_isolated_agent_session (intersect_allowed_tools) AFTER this
        # function returns — so stripping it left the on-demand child bounded by
        # nothing at all: a workflow whose recipe declares 8 tools could spawn a child
        # holding the default agent's ENTIRE palette (runtime resolves the default
        # agent's `tools=None` to every registered tool: shell, file write, browser,
        # spawn). The cron path partially covered this by inverting the same allowlist
        # into `exclude_tools`, which is forwarded and honored transitively — but only
        # partially: cron builds that denylist from `get_schemas()`, which lists only
        # ACTIVE tools, so every standard-tier tool (write_file, browser, git, spawn, …)
        # was missing from it. Keeping the key here is the only complete cap on either
        # path: a child can never hold a tool the recipe did not declare.
        #
        # Keeping it grants the child nothing. It is an allowlist intersected into the
        # child's own palette, and every consumer that treats it as authority also
        # requires `workflow` (hooks.ApprovalGate, societas_pr_submit), which is gone.
        if isinstance(metadata, dict) and any(
            k.startswith("workflow") and k not in _WORKFLOW_KEEP for k in metadata
        ):
            metadata = {
                k: v
                for k, v in metadata.items()
                if not k.startswith("workflow") or k in _WORKFLOW_KEEP
            }
        # Originating session (registry-injected). Used as the fork parent so the
        # sub-agent's session links to the real conversation rather than the
        # synthetic local default, which is absent in web/cloud deployments.
        parent_session: str | None = kwargs.get("_session_id")

        if mode == "serial":
            return await self._serial(
                agent, prompt, metadata=metadata, parent_session=parent_session
            )
        elif mode == "parallel":
            return await self._parallel(prompt, metadata=metadata, parent_session=parent_session)
        elif mode == "background":
            origin = self._origin_from_kwargs(kwargs)
            return await self._background(
                agent, prompt, metadata=metadata, origin=origin, parent_session=parent_session
            )
        else:
            return f"Error: unknown spawn mode '{mode}'. Use serial, parallel, or background."

    # ── Mode implementations ────────────────────────────────────────────

    async def _call_spawn(
        self,
        agent: str,
        prompt: str,
        metadata: dict[str, Any] | None,
        parent_session: str | None = None,
    ) -> str:
        """Call spawn_fn, forwarding metadata / parent session when accepted."""
        call_kwargs: dict[str, Any] = {}
        if metadata is not None and self._spawn_accepts_metadata:
            call_kwargs["metadata"] = metadata
        if parent_session and self._spawn_accepts_parent_session:
            call_kwargs["_parent_session"] = parent_session
        return await self._spawn_fn(agent, prompt, **call_kwargs)

    async def _serial(
        self,
        agent: str,
        prompt: str,
        *,
        metadata: dict[str, Any] | None = None,
        parent_session: str | None = None,
    ) -> str:
        """Await a single sub-agent and return its result."""
        logger.info(f"Spawning agent '{agent}' in serial mode")
        try:
            result = await self._call_spawn(agent, prompt, metadata, parent_session)
            return result
        except Exception as exc:
            logger.error(f"Serial spawn of '{agent}' failed: {exc}")
            return f"Error: sub-agent '{agent}' failed: {exc}"

    async def _parallel(
        self,
        prompt: str,
        *,
        metadata: dict[str, Any] | None = None,
        parent_session: str | None = None,
    ) -> str:
        """Run multiple agents concurrently and return all results."""
        try:
            items = json.loads(prompt)
        except json.JSONDecodeError as exc:
            return (
                f"Error: parallel mode requires prompt to be a JSON array "
                f'of {{"agent": ..., "prompt": ...}} objects. Parse error: {exc}'
            )

        if not isinstance(items, list) or not items:
            return "Error: parallel mode requires a non-empty JSON array."

        # Validate each item has agent + prompt.
        for i, item in enumerate(items):
            if not isinstance(item, dict):
                return f"Error: item at index {i} is not an object."
            if "agent" not in item or "prompt" not in item:
                return f"Error: item at index {i} must have 'agent' and 'prompt' keys."

        logger.info(f"Spawning {len(items)} agents in parallel mode")

        async def _run(item: dict[str, str]) -> str:
            try:
                return await self._call_spawn(
                    item["agent"], item["prompt"], metadata, parent_session
                )
            except Exception as exc:
                return f"Error ({item['agent']}): {exc}"

        results = await asyncio.gather(*[_run(item) for item in items])

        # Format results with agent names.
        parts: list[str] = []
        for item, result in zip(items, results):
            parts.append(f"[{item['agent']}]\n{result}")

        return "\n\n---\n\n".join(parts)

    async def _background(
        self,
        agent: str,
        prompt: str,
        *,
        metadata: dict[str, Any] | None = None,
        origin: BackgroundOrigin | None = None,
        parent_session: str | None = None,
    ) -> str:
        """Run a sub-agent through the configured background lifecycle.

        When a runtime ``background_fn`` is wired and the originating
        conversation is known, delegate to the BackgroundTaskManager so the
        result is delivered proactively. Otherwise run serially and return the
        real result to the caller.
        """
        if self._background_fn is not None and origin is not None:
            try:
                _, message = await self._background_fn(
                    agent, prompt, origin=origin, metadata=metadata, parent_session=parent_session
                )
                return message
            except Exception as exc:
                logger.error(f"Background spawn of '{agent}' failed to start: {exc}")
                return f"Error: could not start background task for '{agent}': {exc}"

        # No detached lifecycle wired (CLI / standalone): degrade to an inline
        # serial run. There is no proactive delivery or poll-only registry to fall
        # back to, so awaiting inline is the only honest option — the caller gets
        # the real result instead of a task id it can never check.
        logger.info(f"Spawning agent '{agent}' in background mode (degraded to serial)")
        try:
            return await self._call_spawn(agent, prompt, metadata, parent_session)
        except Exception as exc:
            logger.error(f"Background fallback spawn of '{agent}' failed: {exc}")
            return f"Error: sub-agent '{agent}' failed: {exc}"

    @staticmethod
    def _origin_from_kwargs(kwargs: dict[str, Any]) -> BackgroundOrigin | None:
        """Internal shim — delegates to the shared public ``origin_from_kwargs``."""
        return origin_from_kwargs(kwargs)
