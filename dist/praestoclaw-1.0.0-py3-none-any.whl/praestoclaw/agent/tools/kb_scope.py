"""Bind a group to its knowledge base, and to the folder it prefers inside it.

Configuration used to be agent-level: one operator list served every group, so
a second group with a different knowledge base meant editing a YAML file on the
employee's devbox. This tool moves the *choice* into the conversation that has
to live with it, while leaving the *authorisation* where it was.

The split matters. ``praesto_tag_exp.kb.repos`` still decides what this agent
may ever write to on the lending employee's behalf, and only they can widen it —
``kb_publish`` commits and pushes with their git credentials, so a group message
must never be able to aim that at a new repository. Inside that boundary the
group picks freely, with no approval and no config edit.

A rejected request therefore has to say which of two different things went
wrong, because the fix is different: a repository outside the allowlist needs a
person, whereas a folder that does not exist just needs a better answer.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.kb.repo import KbRepo, KbRepoError
from praestoclaw.kb.scope import (
    GroupScopeStore,
    KbScope,
    RepoAmbiguousError,
    RepoNotAllowedError,
    SubfolderMissingError,
    SubfolderNotADirectoryError,
    allowlist,
    resolve_allowed_repo,
    resolve_subfolder,
)
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = ("show", "set", "clear")

# Used when the lending employee's display name is unavailable (no cloud login
# yet, or a test harness). Naming them is better, but an unnamed instruction is
# still actionable — the group knows who runs the bot.
_FALLBACK_ADMIN = "管理员"

# Notify category the cloud channel exempts from the group-chat verbosity gate
# (``channels/cloud.py:_UNDROPPABLE_GROUP_CATEGORIES``). Kept as a literal so
# this tool does not import the channel layer.
_GROUP_NOTICE_CATEGORY = "group_notice"

# Ceiling on the announcement push. It is best-effort: a stuck outbound handler
# must not fail a binding that is already saved.
_NOTICE_TIMEOUT_S = 10


def _notice_text(scope: KbScope) -> str:
    """The announcement itself — addressed to the group, in the group's language.

    Deliberately short and correctable: it states what was recorded and invites
    a correction in the same breath, because the group is being told about a
    choice it did not explicitly make.
    """
    where = (
        f"，默认写入 `{scope.subfolder}`" if scope.subfolder else "，未指定文件夹，整个仓库都可以写"
    )
    return (
        f"📚 本群的知识库已记为 **{scope.repo}**{where}。\n"
        "如果不对，在群里说一声要换成哪个仓库或哪个文件夹，我改。"
    )


class KbScopeTool(Tool):
    """Show, set or clear which knowledge base this group writes to."""

    risk_range = (0, 2)

    def __init__(self, kb_config: Any = None, scope_store: Any = None, bus: Any = None) -> None:
        self._config = kb_config
        self._scopes: GroupScopeStore | None = scope_store
        # Message bus, so a saved binding announces itself to the group rather
        # than depending on the model to mention it (see ``_announce``).
        self._bus = bus

    def set_bus(self, bus: Any) -> None:
        """Inject the message bus so a saved binding is announced to the group."""
        self._bus = bus

    @property
    def name(self) -> str:
        return "kb_scope"

    @property
    def description(self) -> str:
        return (
            "Which knowledge-base repository this group writes to, and which "
            "folder in it the group prefers. Actions: 'show' returns the current "
            "binding (or reports that none is set, with the repositories that may "
            "be chosen); 'set' records repo and optional subfolder after checking "
            "the repository is allowed and the folder really exists, and posts a "
            "short notice to the group naming what was recorded; 'clear' "
            "removes it. Take the repository and folder from what the group said — "
            "asked now, or said earlier in this chat — never from your own "
            "preference. The subfolder is a preference for where work lands, not "
            "a restriction."
        )

    @property
    def metadata(self) -> ToolMetadata:
        # 'set' clones the repository on first use to verify the folder exists.
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        if str(args.get("action") or "") == "show":
            return RiskScore(0, reason="Read this group's knowledge-base binding")
        return RiskScore(
            2, reason="Record this group's knowledge-base binding (no repository write)"
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(_ACTIONS),
                    "description": (
                        "show = current binding; set = record repo/subfolder; clear = forget it."
                    ),
                },
                "repo": {
                    "type": "string",
                    "description": (
                        "For 'set': the repository the group named, as 'owner/name', "
                        "a clone URL, or a bare name when it is unambiguous."
                    ),
                },
                "subfolder": {
                    "type": "string",
                    "description": (
                        "For 'set': optional repository-relative folder the group "
                        "prefers, any depth (e.g. 'context/teams/atlas'). Omit when "
                        "they did not name one — do not guess."
                    ),
                },
            },
            "required": ["action"],
        }

    # ── configuration ────────────────────────────────────────────────────

    def _enabled(self) -> bool:
        return bool(getattr(self._config, "enabled", True))

    def _sync_timeout(self) -> int:
        return int(getattr(self._config, "sync_timeout_s", 180) or 180)

    def _allowed(self) -> list[str]:
        return allowlist(self._config)

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return "kb_scope is only available in a Teams group experiment or personal Teams chat."
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."
        if self._scopes is None:
            return "Error: kb_scope has no group store wired."

        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "Error: kb_scope needs a Teams conversation id on this turn."

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        if action == "show":
            return self._action_show(cid)
        if action == "clear":
            return self._action_clear(cid)
        return await self._action_set(cid, kwargs, metadata)

    def _action_show(self, cid: str) -> str:
        scope = self._scopes.read(cid) if self._scopes else None
        allowed = self._allowed()
        if scope is None:
            return self._dump(
                {
                    "configured": False,
                    "selectable_repos": allowed,
                    "next_step": (
                        "Ask the group which knowledge-base repository to use and, "
                        "optionally, which folder inside it — then record their answer "
                        "with kb_scope(action='set'). Do not choose for them."
                    ),
                }
            )
        return self._dump(
            {
                "configured": True,
                "repo": scope.repo,
                "subfolder": scope.subfolder,
                "set_by": scope.set_by,
                "set_at": scope.set_at,
                "selectable_repos": allowed,
                "note": (
                    "The subfolder is where work is preferred, not a limit — read its "
                    "rules first and draft there unless the repository's own "
                    "conventions point elsewhere."
                ),
            }
        )

    def _action_clear(self, cid: str) -> str:
        if self._scopes and self._scopes.clear(cid):
            return "Knowledge-base binding cleared for this group."
        return "This group had no knowledge-base binding."

    async def _action_set(self, cid: str, kwargs: dict[str, Any], metadata: dict[str, Any]) -> str:
        requested = str(kwargs.get("repo") or "").strip()
        if not requested:
            return (
                "Error: repo is required for 'set'. Ask the group which knowledge base "
                "to use and pass exactly what they answer."
            )

        allowed = self._allowed()
        try:
            entry = resolve_allowed_repo(allowed, requested)
        except RepoAmbiguousError as exc:
            return (
                f"'{exc.wanted}' matches more than one allowed knowledge base: "
                f"{', '.join(exc.candidates)}. Ask the group which one they mean and "
                "pass it as 'owner/name'."
            )
        except RepoNotAllowedError:
            return self._not_allowed_message(requested, allowed, metadata)

        repo = KbRepo(entry)
        try:
            await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        except KbRepoError as exc:
            return (
                f"'{entry}' is allowed, but this machine could not open it, so the "
                f"folder could not be checked and nothing was saved.\n{exc}"
            )

        try:
            subfolder = await asyncio.to_thread(
                resolve_subfolder, repo, str(kwargs.get("subfolder") or "")
            )
        except SubfolderNotADirectoryError as exc:
            return (
                f"'{exc.subfolder}' is a file in {entry}, not a folder. Name a folder "
                "or leave it out to use the whole repository."
            )
        except SubfolderMissingError as exc:
            return self._missing_subfolder_message(entry, exc)

        scope = KbScope(
            repo=entry,
            subfolder=subfolder,
            set_by=str(metadata.get("sender_name") or "").strip(),
        )
        stored = self._scopes.write(cid, scope) if self._scopes else scope
        logger.info("kb_scope: cid={} repo={} subfolder={}", cid, entry, subfolder)
        announced = await self._announce(stored, kwargs)
        payload = {
            "configured": True,
            "repo": stored.repo,
            "subfolder": stored.subfolder,
            "set_by": stored.set_by,
            "summary": stored.describe(),
            "announced_to_group": announced,
            "note": (
                "Saved for this conversation only. The subfolder is the preferred "
                "place for this group's knowledge, not a restriction."
            ),
        }
        payload["next"] = (
            "The group has been told what was recorded, so do not repeat it — say "
            "what you are doing next. If they correct it, call 'set' again."
            if announced
            else "Tell the group in this conversation which repository and folder "
            "were recorded, so they can correct it if it is wrong."
        )
        return self._dump(payload)

    async def _announce(self, scope: KbScope, kwargs: dict[str, Any]) -> bool:
        """Tell the group which knowledge base was just recorded for them.

        The binding is normally inferred from what the group already said rather
        than put to them as a question, which is convenient and occasionally
        wrong. Announcing it is what keeps "inferred" from becoming "silent":
        the group cannot object to a choice nobody showed them, and asking the
        model to mention it has proved unreliable — it reports the binding when
        the turn happens to be about configuration and omits it when the turn is
        about something else.

        Best-effort. A binding that is already saved must not be undone by a
        stuck channel, so every failure is logged and reported as *not*
        announced, which puts the job back on the model.
        """
        channel_raw = kwargs.get("_channel", "")
        channel_id = str(kwargs.get("_channel_id", "") or "")
        if self._bus is None or not channel_raw or not channel_id:
            return False
        try:
            from praestoclaw.bus.events import OutboundMessage
            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
        except Exception as exc:  # noqa: BLE001
            logger.debug("kb_scope announce: unusable channel {!r} — {}", channel_raw, exc)
            return False

        meta_in = kwargs.get("_metadata") or {}
        source = str(meta_in.get("source", "")) if isinstance(meta_in, dict) else ""
        metadata: dict[str, Any] = {
            # Intermediate: this must not consume the turn's reply slot.
            "keep_context": True,
            # …but the group has to see it, so it is exempt from the verbosity
            # gate that silences ordinary progress chatter.
            "notify_category": _GROUP_NOTICE_CATEGORY,
        }
        if source in ("cloud_teams", "teams_bridge"):
            metadata["push_target"] = "teams"

        try:
            await asyncio.wait_for(
                self._bus.publish_outbound(
                    OutboundMessage(
                        channel=ch,
                        channel_id=channel_id,
                        content=_notice_text(scope),
                        metadata=metadata,
                    )
                ),
                timeout=_NOTICE_TIMEOUT_S,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("kb_scope announce failed for {} — {}", scope.repo, exc)
            return False
        return True

    # ── refusals ─────────────────────────────────────────────────────────

    def _not_allowed_message(
        self, requested: str, allowed: list[str], metadata: dict[str, Any]
    ) -> str:
        """Explain that only the profile's owner can widen the allowlist.

        Naming them is the point: the allowlist lives in that person's own
        ``praestoclaw.local.yaml`` on the machine this agent runs on, so an
        instruction that cannot say who to ask is not actionable.
        """
        admin = str(metadata.get("owner_display_name") or "").strip() or _FALLBACK_ADMIN
        lines = [
            f"'{requested}' is not a knowledge base this agent may write to, so nothing was saved.",
            "",
            f"To use it, {admin} has to add it on the machine running this agent — "
            "in praestoclaw.local.yaml under praesto_tag_exp.kb.repos — and restart. "
            "Ask them, then configure again.",
        ]
        if allowed:
            lines += ["", f"Available right now: {', '.join(allowed)}."]
        else:
            lines += [
                "",
                "No knowledge base is configured at all yet, so every repository "
                "needs that same step first.",
            ]
        return "\n".join(lines)

    @staticmethod
    def _missing_subfolder_message(entry: str, exc: SubfolderMissingError) -> str:
        """A folder that does not exist is re-asked, never created on a guess.

        Predictability is the whole reason the binding exists: later work is
        supposed to land somewhere the group already agreed on. Curation may
        still propose a *new* area when the repository's rules call for one —
        that decision goes through the group's own review, not through a
        silently invented binding.
        """
        where = f"{entry}/{exc.existing_at}" if exc.existing_at else entry
        lines = [
            f"'{exc.subfolder}' does not exist in {entry}, so nothing was saved.",
            f"The path exists as far as {where}.",
        ]
        if exc.siblings:
            lines.append(f"Folders there: {', '.join(exc.siblings)}.")
        else:
            lines.append("There are no subfolders at that level.")
        lines.append(
            "Ask the group to name an existing folder, or to leave it out and use the "
            "whole repository."
        )
        return "\n".join(lines)
