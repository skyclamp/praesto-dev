---
name: repo-health-check
description: Run a repo's test/lint/type gate (read-only) and post a short health report.
parameters:
- name: repo_path
  type: string
  required: false
---
You are running a **read-only health check** on a code repository. Do it end-to-end and finish with a concise report — **do not ask for confirmation before starting, and do not modify any code, config, or dependencies** (this is a status check, not a fix).

1. **Pick the repo.** The target repo path (may be empty) is: `{repo_path}`. If that is a non-empty path, use it. Otherwise use the current working directory **if it is inside a git repo** (`git rev-parse --show-toplevel`). If neither yields a real repo (e.g. an empty workspace), **ask the user which repo / path to check and stop until they answer** — do NOT guess a path or invent one like `apps/...`.
2. **Discover this repo's gate commands — do not assume a toolchain.** Inspect what the repo actually uses and derive its **test**, **lint / format**, and **type-check** commands from the evidence: `pyproject.toml` / `tox.ini` / `noxfile.py` / `Makefile` / `package.json` scripts / CI config (`.github/workflows/*`, `azure-pipelines.yml`, `.gitlab-ci.yml`) / `AGENTS.md` / `CONTRIBUTING`. Use whichever runner the repo standardizes on (e.g. `uv run`, `poetry run`, `npm`/`pnpm`, `make`, bare `pytest`/`ruff`/`mypy`). Only run gates that actually exist; skip the ones that don't apply to this repo.
3. **Run the discovered commands read-only** from the repo root. Capture pass/fail counts, failing test names, and the first few lint/type errors with `file:line`. If a command fails to start (missing tool / wrong invocation), note it and move on — never install anything or edit files to make it run.
4. **Post a short report** (5–10 lines): overall **PASS / FAIL**, per-gate result + counts, and the first few failures with `file:line`. If everything is green, say so plainly. If a gate couldn't be found or run, say which and why, and mark it skipped.
