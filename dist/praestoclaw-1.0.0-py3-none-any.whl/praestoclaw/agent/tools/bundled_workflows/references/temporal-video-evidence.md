# Temporal Video Evidence Reference

This reference applies only after an owning workflow determines that a visible,
time-dependent symptom cannot be judged reliably from a stable screenshot. The owning
workflow decides eligibility, product setup, test location, account, fixtures, stop
semantics, and delivery rules. This reference owns only the bounded local-video
mechanism.

## Evidence boundary

Analyze only the current workflow task's local Playwright native video. The video must
come from the final regression spec while running against the owning workflow's local
environment. External recordings, report attachments, shared videos, and recordings
from remote environments are context only. They must not become model input, Repro
RED, attestation input, GREEN input, or final evidence.

Videos, contact sheets, and non-selected frames are intermediate local inputs. Only the
confirmed RED screenshot and paired GREEN screenshot may become product evidence.

## Required preflight

All checks must pass before a characterization round:

1. The owning report defines a UI entry point, action, visible symptom, and falsifiable
   expected result. An external video cannot fill missing report text.
2. The final committable Playwright spec uses the report-derived input and contains a
   named `TARGET:` step whose observable window is at most 30 seconds.
3. The owning workflow's required local environment, account, services, fixtures, and
   cleanup path are ready. Never switch to a remote environment to obtain evidence.
4. Playwright native recording is enabled, runner retries are zero, and `ffmpeg` plus
   `ffprobe` are available.
5. Resolve the OS temp root with Python's `tempfile.gettempdir()`. Keep the manifest
   and native video below
   `<temp-root>/praestoclaw-video-evidence/<workflow>/<background_task_id>/`.
6. The recording is privacy-safe. Unavoidable credentials, customer data, or PII are
   a blocker, not a redaction task.

A failed preflight follows the owning workflow's stop/block contract immediately. Do
not run a model, inspect an external video, or change environments.

## Run manifest

Write one UTF-8 JSON manifest per Playwright run. `manifest_path` passed to
`inspect_local_run` must be absolute and inside the task root above. `video_path` is a
safe relative path from the manifest's directory to Playwright's native
`test-results/.../video.webm`.

The manifest fields are:

```json
{
  "schema_version": 1,
  "workflow": "<runtime workflow name>",
  "background_task_id": "<runtime task id>",
  "test_env": "local",
  "producer": "playwright",
  "phase": "repro",
  "video_path": "playwright/test-results/<case>/video.webm",
  "video_sha256": "<lowercase sha256>",
  "spec_path": "<safe repository-relative spec path>",
  "test_id": "<final test id>",
  "retry": 0,
  "test_status": "failed",
  "privacy_safe": true,
  "target": {
    "name": "TARGET: <observable action>",
    "reached": true,
    "start_seconds": 0.0,
    "end_seconds": 10.0
  },
  "scenario": {
    "sample_fingerprint": "<stable fingerprint>",
    "seed_fingerprint": "<stable fingerprint>",
    "viewport": {"width": 1280, "height": 720},
    "locale": "en-US",
    "browser": "chromium",
    "recording": "playwright-native"
  },
  "code_state": "<commit or bounded tree-state fingerprint>"
}
```

Use `phase: repro` before the fix and `phase: verify` after the final fix. A
TARGET-reaching Repro status is non-passing; a GREEN registration requires a passing
Verify status.

## Characterization and TARGET

- Run at most three materially different Playwright characterization rounds per
  workflow task.
- A round exists only after the final committable spec runs. Record spec path, test id,
  exact command, what changed, TARGET, execution status, observed result, and paths.
- `NOT_REACHED`, setup failures, and skipped tests consume a Playwright round but zero
  model budget.
- Functional assertions and DOM/event logs may locate TARGET but cannot replace the
  visible product symptom.

## Hard budget

- Analyze at most two TARGET-reaching local videos per workflow task.
- Each source video is at most 10 minutes, 200 MB, and 1920x1080. TARGET is at most
  30 seconds.
- Decode locally, perceptually deduplicate, and keep at most 12 representative frames
  in one contact sheet, then at most four full-size candidate frames.
- Make at most two vision calls per video, four per workflow task, ten image inputs per
  workflow task, and request at most 800 output tokens per call.
- `video_evidence` enforces counters with the runtime-injected
  `workflow + background_task_id`; callers do not pass their own scope identifier.
- A second video requires a materially different scenario fingerprint. Re-analyzing
  the same video, merely widening TARGET, or lowering a threshold is forbidden.
- Once a candidate is found, stop all E2E, extraction, and model work until the human
  confirmation resolves.

Budget exhaustion, missing marker, invalid manifest/hash, unavailable media tooling,
privacy failure, two videos without confirmed RED, or three exhausted rounds follows
the owning workflow's stop/block contract.

## Candidate localization

Enable the inactive tool only now with `tools(name="video_evidence")`.

1. Call `inspect_local_run` with only `action` and `manifest_path`. It verifies runtime
   workflow/task ownership, local provenance, TARGET, file limits, hashes, codec, and
   scenario identity, then returns a runtime-owned run token.
2. Call `locate_red` with `action`, that run token, and the report-derived
   `symptom_rubric`. Local reduction creates bounded model input. The model may return
   candidate timestamps and observations; it cannot confirm RED.
3. Treat `CANDIDATE`, `NO_CANDIDATE`, `INCONCLUSIVE`, `PRIVACY_UNSAFE`,
   `NOT_REACHED`, `NOT_CONFIGURED`, and `BUDGET_EXHAUSTED` as protocol states, not
   prose to reinterpret.

## Human confirmation

A `CANDIDATE` is not RED. Create exactly one blocking Plan checkpoint whose `summary`
starts with `[temporal-red-candidate:<candidate token>]`. Put the marker first so the
persisted approval preview visibly binds the decision to that runtime candidate. The
rest of the summary shows the local source path, candidate frame/contact sheet,
timestamp, report-derived rubric, spec/test id, TARGET, and privacy result. Use the
existing `ask_user=true` checkpoint API; do not add fields to Plan.

- Approval authorizes only that candidate token for this workflow task.
- Rejection permits one second materially different local video when budget remains.
- Expiry or lost approval follows the owning workflow's stop/block contract.
- While pending, run no E2E, ffmpeg, or vision calls.

After approval, call `attest_red` with the candidate token. The tool verifies the
checkpoint, re-hashes the source artifacts, records scenario/code provenance, renames
the selected frame to `red-before.jpg`, and deletes the contact sheet. Attest that RED
screenshot with the owning workflow's image-attestation mechanism before changing
code.

## Verify and GREEN

Run the byte-identical regression spec after the final fix with the same local sample,
seed, TARGET name, viewport, locale, browser, and recording configuration. The
functional GREEN must reach TARGET. Inspect its `phase: verify` manifest, then call
`register_green` with the attested RED token and GREEN run token.

The tool maps the confirmed RED timestamp to the same relative position in GREEN's
TARGET window and extracts `green-after.jpg`. It returns only the final RED/GREEN
screenshot paths as product evidence; videos remain intermediate local inputs.

Compare those screenshots through the owning workflow's image comparison contract.
A changed scenario fingerprint, failed GREEN, privacy failure, missing screenshot, or
pair-registration failure follows the owning workflow's stop/block contract.

## Delivery and cleanup

Upload only the final RED and GREEN screenshots using the owning workflow's existing
screenshot-pair labels. Do not upload either video, the contact sheet, or any
non-selected frame. Never publish a half pair.

Keep intermediate videos only until the screenshot comparison and delivery complete.
Then remove the exact task-scoped directory and stop processes started by the run.
Never glob a temp root. On a blocked outcome, retain only the minimum privacy-safe
artifacts required by the owning workflow and name every retained path.
