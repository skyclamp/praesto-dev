---
name: implement-societas-feature
description: Implement a Societas feature end-to-end from a spec or ADO work item through requirement analysis, dev design, a test plan, before/after evidence, and a verified draft PR.
plan: true
metadata:
  # First-turn routing (loop_v2._match_workflow_recipe). These name the recipe's
  # SUBJECT, never the execution verb — the injected note is neutral and the model
  # judges intent from the full turn (loop_v2._recipe_route_block). Matching too
  # narrowly is the expensive direction: a false positive costs one neutral note,
  # a false negative costs an uncontrolled run.
  #
  # No \b around 'societas' or the CJK alternatives: Python treats CJK as word
  # characters, so \bsocietas fails to match inside '这个societas feature'.
  #
  # Deliberately distinct from fix-societas-bug: that recipe matches
  # bug/缺陷/问题/故障 near 'societas'. These match feature/功能/需求 and ADO work
  # item references instead, so a bug report never routes here.
  activation:
    keywords:
    - societas feature
    patterns:
    - "(?i)societas[^\\n]{0,16}(?:features?|功能|需求|user story)"
    - "(?i)(?:features?|功能|需求|user story)[^\\n]{0,16}societas"
    - "(?i)societas[^\\n]{0,24}AB#\\s*\\d{4,}"
parameters:
# The feature's requirements come from EITHER a spec file in the repository OR an
# ADO work item. Neither can be `required` on its own — that would make the other
# impossible to use — so they share a `required_group`: each stays optional, and
# the group is what the call must satisfy. This used to be prose here and a
# refusal in step 1, which meant a run with neither could start, notify, and
# spend ninety seconds before saying it had no requirements.
- name: spec_path
  type: string
  required: false
  required_group: requirements
- name: feature_id
  type: string
  required: false
  required_group: requirements
- name: repo_path
  type: string
  required: false
- name: target_branch
  type: string
  required: false
limits:
  allowed_tools:
    - shell
    - plan
    - tools
    - config_praestoclaw
    # browser is granted so a UI-observable criterion can be proved on the surface
    # a user sees. Without it the "capture a screenshot" instruction below is dead
    # text: allowed_tools is a hard gate (loop_v2 blocks the call and logs
    # tool_blocked_by_allowlist), and a tool absent from the palette never even
    # appears in the model's tool schema, so the run cannot try and cannot report
    # that it failed to try.
    - browser
    # spawn serves two read-only roles: adversarial test planning and acceptance
    # review. Use it only with
    # agent="explorer" in serial mode — that spawn assesses as a deterministic
    # RiskScore(2), and it is the ONLY shape the workflow-scoped auto-approval
    # admits (hooks/handlers.py::_workflow_scope_admits). Every other agent name
    # and every non-serial mode falls through to the normal approval gate, where
    # an unattended run has nobody to answer.
    # This comment used to claim the fall-through was automatic. It was not:
    # scoped auto-approval matched on the tool NAME alone, so `spawn(agent=
    # "default", mode="background")` was allowed exactly as readily as the review
    # below — and the child kept the default agent's whole palette. That is now a
    # code-enforced narrowing rather than a promise made in a comment.
    # explorer is also read-only, which is what makes it a reviewer rather than a
    # second implementer. The child is additionally capped by THIS allowlist
    # (spawn.py forwards `workflow_allowed_tools`), so a tool absent from this
    # list is absent from the reviewer's palette too.
    - spawn
    # The reviewer's own palette. It is spawned as `explorer`, whose tools are
    # exactly these three, and the child is capped by THIS list — so omitting them
    # hands the reviewer zero tools and it silently reviews nothing. Runtime binds
    # these read-only tools to the trusted workflow repo path; writes remain absent.
    # Review diffs still live in the workspace so their exact scope is explicit.
    - read_file
    - list_dir
    - search_files
  # NOTE: agents.default.budget.max_iterations (default 90) is a PER-STRETCH
  # budget, not the run's ceiling — Runtime._run_workflow_session re-invokes
  # run_once with a fresh budget while the plan is non-terminal, up to
  # _WORKFLOW_AUTO_CONTINUATION_LIMIT = 3. What ends a run early is
  # runtime.py::_plan_is_terminal: plan complete, ANY item `blocked` WITH evidence,
  # or
  # an unresolved approval checkpoint. See the Budget section.
  max_runtime: 3600
  max_output: 20000
concurrency:
  max_instances: 1
  key_parameters: [spec_path, feature_id]
---
Implement a Societas feature end-to-end, from its requirements through a **draft
pull request**, producing a reviewable artifact at every phase.

Parameters — **an empty value means that parameter was not supplied**, and step 1
resolves what to do about it. Never read an empty value as a real one:

- spec / PRD file inside the repository: `{spec_path}`
- ADO work item id: `{feature_id}`
- repository path: `{repo_path}`
- PR target branch: `{target_branch}`

Exactly one of the first two carries the requirements. The last two fall back to
configuration.

This is an authorized internal development workflow on the team's own Societas
repository.

## What this run must leave behind

Every phase writes its output **to a file, immediately**, before moving on. This is
not bookkeeping: it is what makes a run that runs out of wall clock still worth
something, and it is the only way a later phase can be re-done without re-doing the
whole run.

These are **working files**, written under
`<repo>/.workflow-run/<feature-slug>/` — a scratch directory that is **not what
ships**:

| File | Written by | Contains |
|---|---|---|
| `requirement-analysis.md` | step 2 | what is being asked, user flows, the acceptance criteria verbatim, what the spec does not answer |
| `design.md` | step 3 | **≥2 options with the reason for the choice**, the end-to-end path, the file list |
| `test-plan.md` | step 4 | the effect ledger, the executable checks, and the e2e cases for the deployed environment |
| `evidence-before.md` | step 6 | the checks run **against unmodified code**, with their real output; the browser RED |
| `evidence-after.md` | step 8 | the same commands after the change, with their real output; the browser GREEN |

**What ships is one document, and it is not these five.** Step 10 distils them
into a single design note that follows what the repository already does with
design notes — see *The shape of the deliverable* below. The five stay behind:
they are how a run survives being interrupted and how a later phase gets re-done
without redoing the whole run, and they are also, unavoidably, full of raw
command output that belongs nowhere near a product repository.

The distinction is not tidiness. A previous run committed all five, including an
`evidence-after.md` of **3789 lines, 3197 of them over 200 characters**, against
a production change of **two lines**. Nothing in that file was false. It was
still the wrong artefact: a reviewer cannot read it, and the repository now
carries a transcript of one afternoon forever.

### The shape of the deliverable

**One design note, in the directory the repository already keeps design notes
in, written the way the notes already there are written.** Before writing it,
read two of them — `ls docs/design/` and open the two closest to your change.
Match what you find; the paragraph below describes what those notes look like
today, and the files win if they have moved on.

They are single files of a few hundred lines. They explain the flow and the
implementation. **They contain no command output at all** — a representative one
carries zero lines over 200 characters. Nobody has ever pasted a test log into
one, and the reason is worth stating: a repository stores how the thing works,
not what happened on the afternoon it was built.

So the note carries the conclusions and drops the transcripts:

| Section | From | What survives |
|---|---|---|
| Summary | step 3 | what shipped, and the size of the production change |
| Contract differences | step 4 | where intent, spec and code disagree — often the most valuable lines, and invisible in the diff |
| Scope | step 3 | the requested customer outcome, full or approved-partial mode, and any source non-goals or approved deferrals |
| Implementation | step 7 | the path through existing code, file by file |
| Verification | steps 6/8 | **one line per gate**: `<gate>: PASS / FAIL / BLOCKED — reason`, and what the RED and GREEN images show |
| Not covered | steps 4/8 | what needs a deployed build, a decision, or an owner |

**A gate's line is its verdict, not its output.** "`pnpm build`: PASS" is the
whole entry. If it failed and you fixed it, that is one more line, not the log
of both runs.

The coverage ledger from step 4a is evidence for **this** review, not
documentation of the feature — put it in the PR description, or attach the
working file. It does not belong in a design note that outlives the PR.

**Keep the scratch directory out of Git yourself.** It is untracked when you
create it, and untracked is enough as long as staging is by explicit path, which
step 10 requires. Do not add it to the repository's `.gitignore`: that file is
shared with everyone, and this workflow does not get to edit a product repo's
conventions to suit its own bookkeeping. If you find `.workflow-run/` in
`git status` at commit time, that is the expected state — stage around it.

**A phase is not finished until its file exists on disk.** Say the path in your
progress note. If the run ends early, the last written file is the handoff.

**When an artifact from an earlier run is already there, correct it — do not only
append.** A reused branch often carries a previous run's files, and their
conclusions were true for that run, not this one. An appended "Addendum" leaves
the stale sentence sitting above it, so a reader meets the wrong answer first and
only learns better if they keep going. Rewrite the sentence that is now false,
then add what is new. If you want the history preserved, mark the old line
explicitly as superseded and say by what — never leave two live claims that
contradict each other.

## Execution guardrails

- **Callout contract** — the ONLY way to stop this run and hand the decision back
  to the user. Every "stop", "pause and ask", "escalate", or "blocked" instruction
  below means exactly this, and nothing else counts:
  1. `plan(action='update', id='<current item id>', status='blocked', evidence='<what you tried, the exact blocker, the missing prerequisite>')` — `id` and a
     **non-empty `evidence`** are both required; a blocked item with empty evidence
     does not stop the run. Where the item sits in the list no longer matters: the
     runtime scans every item, so a Callout recorded on a later item is not hidden
     by an earlier one still being open.
  2. Put the question to the user in the **same reply**. A question in the reply
     alone is not a stop — the runtime cannot see it and will drive the run again.

  **An evidenced Callout is a successful outcome of this run, not a failure.** A run
  that stops with a concrete blocker and hands the user a real decision has done its
  job; a run that manufactures evidence to reach the PR has not. Never prefer
  inventing data, a stand-in test, or a synthetic screenshot over stopping here.
  What keeps this honest is the evidence: a Callout must name the concrete paths you
  actually tried, each with its command and its real output. Stopping on the first
  obstacle without trying anything is not a Callout.

- **Keep repository operations scoped to the task.** The implementation agent
  uses `shell` rooted in `<repo_path>` for edits and Git. The two Explorer roles
  use only `read_file`, `search_files`, and `list_dir`; runtime binds these to the
  resolved repo read-only. A blocked read is a missing prerequisite, not permission
  to widen the sandbox or copy the tree into the workspace.

- **Locate, then read once.** Use `rg`/`search_files` to find the relevant code;
  read small files whole and large files by the relevant complete functions and
  callers. Fetch elided required ranges. Do not repeatedly read unchanged content
  or scan unrelated parts of the product to fill a review quota.

- **Work in place, in `<repo_path>` itself. Create a branch; never create a
  worktree, a clone, or a copy.** `git worktree add` shares `.git` but not the
  ignored working tree, and in this repository the ignored working tree is what
  makes the code runnable: `backend/.venv` (1.3 GB), `frontend/node_modules`
  (1.1 GB), root `node_modules`, plus `backend/.env` and `frontend/.env.local` —
  configuration you cannot author. A fresh worktree therefore has no runnable
  backend, no runnable frontend, and no way to produce the before/after evidence
  this run exists to capture; the setup alone would consume the wall clock.
  `<repo_path>` already has all of it.

  If the checkout is dirty, that is not a reason to relocate. Read the next
  guardrail: pre-existing changes are user-owned state you work alongside, and a
  conflict in a file your slice needs is a Callout, not a reason to build a second
  tree somewhere else.

- Read the repository's own instructions (`AGENTS.md` / `CLAUDE.md` for the
  directories you touch) before changing Git state. Use exactly one task checkout
  and one feature branch for the entire run. Reuse an existing task-specific
  branch when it already contains valid work; never create `v2`/`v3` variants
  merely to obtain a globally clean status.

- **Generated and lock files the run did not deliberately change are not part of
  the slice.** Running the test suites is enough to rewrite a lockfile in place;
  such a diff is usually pure churn (the same line count added and removed) and
  says nothing about the feature. Stage by explicit path, never `git add -A` or
  `git add .`, and if a lockfile appears in the staged set, either justify the
  dependency change in the PR or leave it out of the commit.

- Record the initial `git status --short`. Treat unrelated pre-existing changes,
  generated files, and Git LFS materialization noise as user-owned state: do not
  reset, restore, clean, stage, or delete them. Judge this task with path-scoped
  status/diffs for the files it actually changes. If a target file was already
  modified before the task, stop via the Callout contract instead of overwriting it.

- **Never push to the target branch. Never merge.** Merging is a human action.
  Open the draft PR and stop.

- Use syntax native to the current shell. On Windows PowerShell, root commands with
  `Set-Location -LiteralPath '<repo_path>'; ...`, use `$null` instead of
  `/dev/null`, and `Get-Content -Tail <n>` instead of `tail`. On POSIX, use
  `cd -- '<repo_path>' && ...`. Never send bash-only syntax to PowerShell. In
  PowerShell interpolated strings, delimit a variable before `:` or a URL query as
  `${path}:...` or `${buildId}?api-version=...`; PowerShell does not use `\"` to
  escape double quotes — use single quotes or a single-quoted here-string.

- Omit shell's `directory` argument. `directory="workspace"` targets
  PraestoClaw's own workspace, not this task's repo; use
  `cd -- '<repo_path>' && ...` or `git -C '<repo_path>'` instead.

- **Do not repeat an identical command.** The loop detector warns on the third
  identical tool call and terminates the run on the fourth.

- Load at most one phase-specific skill at a time. During pickup, load only
  `azure-cli-check`. Load `pr-workflow` only after the acceptance checks pass.
  Do not load `ado`: this recipe owns the work-item phase.

## Budget

**The limit that ends your run is wall clock, not turns: 60 minutes**
(`execution.background_task_timeout_seconds`). When it expires the task is killed
wherever it stands — no PR, no hand-off, and the checkout left dirty.

Turns are the looser limit. You get about **90 per stretch**, and when a stretch
runs out the runtime hands you a fresh 90 and lets you carry on, up to three times
(`_WORKFLOW_AUTO_CONTINUATION_LIMIT = 3`). **Continuations grant turns, never
time.** Four stretches at 20 minutes each is 80 minutes against a 60-minute clock,
so they are slack for one stretch that overruns, not capacity you can plan to use.

Take the clock's measure yourself: run `date -u +%H:%M:%S` when you create the
plan, record it in the Pick up evidence, and check it again at each phase boundary.
If you are 20 minutes in and have not made a substantive edit, stop surveying. Do
not shrink scope silently: keep the full feature, use the early partial-scope
checkpoint in step 3, or use the Callout contract.

**What ends the run early is you.** After each stretch the runtime asks whether
the plan is terminal and stops if the plan is complete, an approval checkpoint is
unresolved, or **any item is `blocked` and carries evidence**. So marking
the step you are on `blocked` because you are running low on turns **forfeits every
remaining continuation**. When a stretch runs low, leave the item `in_progress`,
write a short note saying where you are, and let the turn end — you will be resumed
with a full budget and the same checkout. Reserve `blocked` for an obstacle you
cannot resolve at all. At one iteration remaining or less, PlanTool enforces this when
the runtime still has another continuation: it refuses both a legacy
`update(status='blocked')` transition and the terminal `callout` action without
touching the item. `park` remains available for a real external lifecycle wait. A
real terminal blocker can be recorded at the start of the fresh continuation; on
the final continuation the guard is disabled.

**Ask for several files in ONE turn.** The budget counts *turns*, not tool calls:
a turn carrying four `cat` calls costs exactly what a turn carrying one costs, and
independent calls in a turn execute concurrently. A measured run on another
repository spent 83 of its 112 turns issuing a single tool call — the same work
batched four at a time is roughly a third of the turns. Request the producer, the
contract, the consumer and the test together; do not read one, think, read the
next.

Spend the time roughly like this. Nine steps, sixty minutes, and the front half has
to stay cheap:

| By minute | Step | You should have |
|---|---|---|
| 8 | 1–2 | repo + target branch + source resolved; `requirement-analysis.md` written |
| 18 | 3 | customer outcome and delivery scope agreed, code path located, deliverability test passed, `design.md` written |
| 25 | 4 | `test-plan.md` maps every required criterion to checks |
| 32 | 5 | app running and authenticated — a browser can reach it |
| 37 | 6 | `evidence-before.md` written — **the RED is captured, browser RED included** |
| 48 | 7–8 | implementation done, `evidence-after.md` written — the GREEN is captured |
| 60 | 9–10 | acceptance review, PR, hand-off |

**The RED at minute 37 is the checkpoint that matters.** Reach it and every later
phase has something real to stand on; miss it and the run produces a diff nobody
can trust. Do not retroactively shrink scope at minute 37: record `NOT_READY` and
use the Callout contract with the concrete missing evidence or blocker.

**Steps 5 and 6 share one running app.** Bringing it up costs a few minutes once;
starting it twice, or starting it only for the GREEN, costs the whole point of
having it.

The five working files are written as you go, so a run that dies at minute 50
still leaves four of them for the next attempt. **That only holds if you write
each file when its phase ends**, not in a batch at the end.

## Steps

### 1. Pick up

Resolve the repository **without searching the filesystem**. Prefer the explicit
`repo_path`; otherwise read `agents.default.metadata.ado_repo_local_path` — enable
the tool once with `tools(name="config_praestoclaw")` if needed, then
`config_praestoclaw(action="show", path="agents.default.metadata")`. Do not grep
config files, logs, or `sessions.db` for this value. `config_praestoclaw` is
**hard-blocked in a scheduled/cron run**, so a scheduled invocation MUST pass an
explicit `repo_path`.

If both are empty, do not guess and do not ask across turns — stop on the **first**
turn via the Callout contract, naming both sources and the two ways to supply the
value (set `agents.default.metadata.ado_repo_local_path`, or re-run with an
explicit `repo_path`).

**Resolve the PR target branch in this same step and never guess it.** It is
`agents.default.metadata.ado_pr_target_branch`, read from the response you already
fetched (or passed explicitly as `target_branch`). If neither is set, **stop here
via the Callout contract** and tell the user to configure it — do NOT fall back to
`main`, `master`, `dev`, the repo's default branch, or the branch the checkout
happens to be on. This repository's integration branch is not the one a
general-purpose guess produces: a run that assumed `main` opened a PR carrying
**717 files and +80665 lines** of unrelated drift, because the real target was
`dev` and `dev` was long ahead of `main`. Quote the resolved value verbatim from
the metadata and record it in the evidence.

In that same command, record `date -u +%H:%M:%S`, the initial `git status --short`,
and any task-named branches with their HEAD commits, so a reusable prior attempt is
found before you fetch broad context.

**Reusing a prior attempt is a convenience, never an obligation.** If checking one
out would touch anything in that initial status, do not check it out and do not
try to make it checkoutable — **start a fresh branch from the resolved target
branch and say in the evidence which prior branch you passed over and why.**

This is the shape it takes, and it stopped two runs dead in one morning: a prior
task branch is based on a `dev` from weeks ago, so switching to it rewrites every
file `dev` has moved since — including one the user is holding uncommitted local
changes in, for something entirely unrelated to this feature. Git refuses, and it
is right to. Stashing, resetting, restoring or committing on the user's behalf to
clear the way are all forbidden, so an attempt to reuse that branch has nowhere
left to go and burns the run on a Callout that had a perfectly good alternative
sitting next to it.

Starting fresh is also usually the *better* choice here, not merely the available
one: a prior attempt's branch may carry that attempt's design note, and step
4a is not allowed to read a previous run's test plan. Checking it out puts the one
document that would contaminate the enumeration directly under the working
directory.

#### Resolve the requirements source

The feature's requirements come from **one** of two places, and this step decides
which **before** fetching anything. Do not go looking for a second source once one
has answered.

- **`spec_path` is set** — read that file whole, once. It is the requirements.
  **Do not query ADO at all**, and do not treat a work item id mentioned inside the
  spec as a reason to fetch one.
- **`spec_path` is empty and `feature_id` is set** — check Azure CLI auth, then
  fetch the work item **once**:

  ```
  az boards work-item show --id {feature_id} --detect true --expand all -o json
  ```

  That response is the source for the description, acceptance criteria and
  relations. Query comments/attachments separately only when the work item
  explicitly says they carry the acceptance detail. Do not enumerate unrelated
  work-item history.
- **Both empty** — stop on the **first** turn via the Callout contract, naming both
  parameters. Do not search the repository for something that looks like a spec.

Record which source you used and its path or id. Every later phase quotes from
**that one source**; a criterion that appears in neither is invented. Keep an exact
local copy for the independent audit: use `spec_path` directly, or save the fetched
ADO JSON and every authoritative downloaded attachment under the scratch directory.
Record those source paths; `requirement-analysis.md` is a summary, not the source.

Derive `<feature-slug>` from the spec filename or the work item title —
lowercase, hyphenated, no dates — and create
`<repo>/.workflow-run/<feature-slug>/`. Every working file goes there.

**The task branch name is fixed, not a creative choice.** A full run once finished
the code and review, then stranded its commit at the last step because it invented
`feature/7822936-turn-usage`; the server returned `VS403660` only at push time.
For an ADO work-item run, use exactly
`users/<alias>/{feature_id}-<feature-slug>`. Derive `<alias>` from the local Git
identity's email prefix — never from the person's display name, and never guess it:

```sh
if ! cd -- '<repo_path>'
then
  echo "BRANCH_CHECK=FAIL no repository"
  exit 1
fi
email=$(git config user.email)
alias=${email%%@*}
if [ -z "$alias" ]
then
  echo "BRANCH_CHECK=FAIL git config user.email has no alias"
  exit 1
fi
if [ -n "{feature_id}" ]
then
  branch="users/$alias/{feature_id}-<feature-slug>"
else
  # A spec-only run has no work-item id to put in the name. Do not invent one.
  branch="users/$alias/<feature-slug>"
fi
if ! git check-ref-format --branch "$branch" >/dev/null
then
  echo "BRANCH_CHECK=FAIL invalid ref"
  exit 1
fi
# Run the switch only after applying the safe-reuse rules above.
if git show-ref --verify --quiet "refs/heads/$branch"
then
  git switch "$branch"
elif git ls-remote --exit-code --heads origin "$branch" >/dev/null 2>&1
then
  git fetch origin "$branch:refs/remotes/origin/$branch"
  git switch --track -c "$branch" "origin/$branch"
else
  git switch -c "$branch" '<resolved-target>'
fi
actual=$(git branch --show-current)
if [ "$actual" != "$branch" ]
then
  echo "BRANCH_CHECK=FAIL branch switch did not select the recorded name"
  exit 1
fi
printf '%s\n' "$branch" > '<repo_path>/.workflow-run/<feature-slug>/task-branch.txt'
echo "BRANCH_NAME=$branch"
echo "BRANCH_CHECK=OK"
```

Only that exact branch is a reusable task branch. `user/…`, `feature/…`, a branch
without the work-item id, or any other plausible variant is not close enough. If
the exact branch does not exist, create it from the resolved target branch. If it
does exist, apply the safe-reuse rules above before checking it out. A rejected
push is a Callout, but this read-back is intended to catch the wrong name before
the run spends an hour reaching the push.

### 2. Understand the requirement

**One reading pass over the source**, producing `requirement-analysis.md`. This
phase reads and writes; it does not touch code and does not decide anything.

Cover exactly this, and nothing else:

- **The problem** — whose problem, and what they do today instead. One paragraph,
  from the source's own words.
- **User flows** — the journeys the feature must serve, each as a numbered
  sequence of user-visible steps. Name the surfaces (page, dialog, entry point) the
  source names.
- **In scope / out of scope** — copy the source's own non-goals verbatim. A spec
  that says what it will *not* do is telling you where a slice may not wander.
- **Acceptance criteria, verbatim.** Every one of them, in the source's own words.
  Do not paraphrase — a paraphrase is where an implementation quietly drifts from
  what was asked. For each, note what a **user could observe** that proves it. A
  criterion whose only evidence is "the code now contains X" is not an acceptance
  criterion; find what behaviour it produces, or record that the source does not
  say.
- **What the source does not answer** — the questions an implementer would have to
  guess at. List them. **Do not answer them here**, and do not treat a gap as
  permission to invent; step 3 decides whether a gap blocks the slice you pick.

A rich spec states requirements at several strengths — "must", "should", "best
effort", "P0", "P1". **Preserve that ranking exactly.** Flattening "best effort"
into a requirement is how a slice grows; promoting a P1 into the slice is how a run
spends its budget on something nobody asked for this release.

Do not restate the whole spec. If your analysis is longer than the section of the
source it covers, you are copying, not analysing.

If the source names no criterion you can verify at all, stop via the Callout
contract and ask for one. Do not invent acceptance criteria from the title.

### 3. Design

One phase, one artifact: `design.md`. It answers *which customer outcome and
scope* and then *how*, and it is the phase this workflow has been missing. In six
earlier evaluation runs, five of the failures were decided here — invisibly,
mid-run, with
no artifact anyone could correct. As a file it is reviewable in minutes instead of
discovered in a PR forty minutes later.

Work through it in four passes. Do not write `design.md` until all four are done —
pass 3 can send you back to pass 1.

#### Pass 1 — define the customer outcome and delivery scope

**The default delivery scope is the full source-defined feature:** every P0
requirement and acceptance criterion, at the priority the source assigned it.
Source-defined P1 items and non-goals stay out; do not promote them.

**A vertical slice completes the requested customer outcome.** Group requirements
that must fire together before a user would call the action done. Opening a picker,
rendering a button, or adding an endpoint **is an entry point, not a completed
customer outcome** when the request is to create an attachment, save an artifact,
submit a result, or reach another downstream state. Make the implementation thin
inside that outcome by choosing the narrowest source-approved path and reusing an
existing downstream path—not by dropping the producer, consumer, persistence, or
required failure behavior.

A smaller delivery is allowed only when the user approves it **before design is
finalized and before production code changes**. If you are considering one, list
the proposed customer outcome and exact deferred P0/acceptance criteria, but do not
request approval yet. Pass 2 must first prove that no implementation in those paths
predates the approval. Time pressure, implementation size, and low turn budget
never authorize an implicit reduction.

Stop and ask (Callout) when the agreed outcome needs a material change to a public
contract, a storage or schema shape, a permission boundary, or a dependency — or a
product decision the source does not answer. Size alone is not permission to pick a
trivial entry point.

#### Pass 2 — locate the owning code path

Use one targeted `rg` search, `cat` the directly implicated files whole, and
inspect relevant git history once. Stop when you can name, with `file:line`:

- where the behaviour must be produced;
- the neighbouring implementation you will copy as a pattern;
- the exact `<production_scope_paths>` this outcome may change;
- the test file you will extend, and the command that runs it.

Do not map the surrounding subsystem for completeness. If you cannot produce
`file:line` for the first of these, you have not finished this pass.

For a proposed partial only, prove that its production paths contain no work that
predates approval:

```sh
base=$(git -C '<repo_path>' merge-base '<resolved-target>' HEAD) || exit 1
if ! git -C '<repo_path>' diff --quiet "$base" HEAD -- <production_scope_paths> \
  || ! git -C '<repo_path>' diff --quiet HEAD -- <production_scope_paths> \
  || [ -n "$(git -C '<repo_path>' ls-files --others --exclude-standard -- <production_scope_paths>)" ]; then
  echo "PRE_SCOPE_CHECK=FAIL production scope already differs from the target or HEAD"
  exit 1
fi
echo "PRE_SCOPE_CHECK=OK"
```

On `FAIL`, do not request retroactive approval: keep `FULL_FEATURE`, start fresh
under step 1's safe-reuse rules, or use the Callout contract. On `OK`, write the
exact proposal to `<scratch>/scope-decision.md`: customer outcome, included
requirements, deferred P0/acceptance criteria, and the statement that this does not
complete the work item. Compute its digest with
`git hash-object -- '<scratch>/scope-decision.md'`. Use
`plan(action='update', ...)` on the in-progress Design item and set evidence to
`PARTIAL_SCOPE_PROPOSAL=<path> DIGEST=<digest> APPROVAL=PENDING`; this is what a
resumed run receives. Then call:

```
plan(action='checkpoint',
     summary='<the exact proposal above; proposal path and digest>',
     next_step='Reuse that proposal verbatim; implement it and report the full work item incomplete',
     ask_user=true)
```

Set scope mode `USER_APPROVED_PARTIAL` only after observing the PlanTool result
`User APPROVED this checkpoint`, the trusted resume marker `The user explicitly
approved the latest waiting checkpoint`, or an explicit reply approving that exact
proposal. A bare/full-auto result, rejection, expiry, silence, or later PR-opening
approval is not approval. Fail closed to `FULL_FEATURE` or Callout.

After approval, verify the digest, reuse the file verbatim, and update the Design
item evidence to `PARTIAL_SCOPE_PROPOSAL=<path> DIGEST=<digest>
APPROVAL=APPROVED PROOF=<observed verdict/reply>`. Persist the exact proposal,
checkpoint summary, digest, and approval proof in `design.md` before any production
edit; never re-derive it after a resume.

#### Pass 3 — the deliverability test

1. **It can be proven by something you did not write.** The agreed customer
   outcome must admit assertions whose inputs are *produced by the system*, not
   authored by you. A hand-written fixture fed to your own new code proves only
   that it agrees with itself.

2. **Both ends of every required contract exist.** If the outcome reads a field
   or event something else is supposed to emit, confirm a real producer exists
   first. **Do not grep for the field name** — that answers "does this string appear", not
   "does anything emit it into this payload". Search for the payload's own
   discriminator, and **keep the quoting optional** — languages in one repository
   disagree about it, and a strict pattern silently reports "no producer":

   ```
   rg -n --pcre2 "['\"]?<key>['\"]?\s*:\s*['\"]<payload type>['\"]" <source root>
   ```

   Hardcoding double quotes has failed this check twice on another
   repository: the strict form found 2 construction sites where the permissive
   form found 14. Open every site and read what it sets. Also check **what gates
   each producer** — a site that sets your field but only runs behind a flag does
   not fire in your acceptance scenario.

3. **Cite what you claim exists.** Every "X already does Y" needs `file:line`.

4. **Your own output must fire in the acceptance scenario.** Trace the whole path,
   not just the first gate, and confirm the data source can carry every field the
   result needs. A producer emitting into a payload nobody renders delivers nothing.

If any check fails, the outcome or scope is wrong and must be revised — go back
to pass 1.
It is not a deferral, and it is not something to note in `design.md` and proceed
past.

#### Pass 4 — write `design.md`

1. **The requested customer outcome and delivery scope** — `FULL_FEATURE` or the
   exact early-approved `USER_APPROVED_PARTIAL` scope. For a partial, copy the
   proposal, digest, checkpoint summary, and observed approval proof from
   `scope-decision.md` and the Design item's evidence; do not consult only the last
   checkpoint.
2. **At least two options, with the reason for the choice.** Not a token
   alternative written to satisfy this instruction — two approaches you would
   actually defend, each with what it costs and what it forecloses. If you truly
   see only one, say why the obvious alternatives are unavailable **here, in this
   codebase**; "there is only one way" is almost never true and is usually a sign
   the customer outcome is drawn wrong.
3. **The chosen end-to-end path**, one `file:line` per hop, from the user action
   through the producer and reused downstream path to the final observable state.
4. **The file list** — every file to be changed, and one line on what changes in
   each.
5. **What this design deliberately does not do.** List only source-defined
   non-goals or criteria named by the early partial-scope approval; no P0 or
   acceptance criterion may disappear silently.

Follow the conventions already in the directories you named — copy the
neighbouring implementation you identified in pass 2. A design that introduces a
new pattern where an existing one fits is a design that will fail review.

**Where the design turns on a product decision the source does not answer**, do not
pick silently. Name the decision, state both options and your recommendation, and
raise a Callout. This is the one place in the run where stopping is cheap: nothing
has been built yet.

### 4. Test plan

This phase has two sub-phases with different evidence rules: **4a enumerates from
production code** and the original requirements through an independent Explorer;
4b realizes that adversarial plan in executable tests. No production code is
written in either.

**Reviewer input contract (also applies to step 9).** Give the child these rules:
read every required input from this run and the current repository, not summaries
claiming it passed. `search_files.path` is a directory; use `file_pattern` to select
files, and `read_file` for a known file. Do not rediscover paths already supplied.
Read short required documents whole; a successful range read is not a full-file read.
List the actual files/ranges read and any unread required inputs. Emit exactly one `REVIEW_INPUTS=OK` or `REVIEW_INPUTS=FAIL`, followed by the
phase verdict. `BLOCKED:`, `File not found:`, `Error reading file:`, and required
`lines elided` that were never fetched mean input failure until a legitimate
corrected read succeeds. Never substitute a stale workspace copy, guess unseen
contents, or use shell to bypass denied reads. An empty result or missing or
contradictory verdict is not a pass. Input failure forces the phase's FAIL verdict;
it is not `CONDITIONAL` and is not evidence that the code is clean. The parent must
repair the input problem or use the Callout contract, never manufacture OK. These
are self-reported read accounts, not a deterministic proof of semantic review.

#### 4a. Independent adversarial test-plan author

Before writing any draft test plan or tests, activate `spawn` with `tools(name="spawn")`
and call `spawn(agent="explorer", mode="serial", prompt=<the task below>)`.
WorkflowTool resolves the configured Societas checkout before launch and runtime
scopes Explorer's read-only tools to that exact repository; write tools remain absent.

Give it the original requirements source paths—not the main agent's interpretation—
exact agreed scope, and production starting paths from step 3. For partial scope
include `scope-decision.md`, its digest,
and the recorded approval proof verbatim: matching proposal digest, checkpoint
summary, and explicit approval proof, not the surrounding design argument.
These are starting points, not a boundary: follow relevant producers and consumers.
Do not give it design conclusions, an existing or draft test plan, your impact
matrix, or your traversal order. Existing test artifacts are forbidden in 4a.

Tell it: **"You are the adversarial test-plan author, not an approver of the
implementer's story. Requirements define the expected behavior; production code
reveals integration points and constraints, not permission to narrow that behavior.
Do not fail merely because new code is not implemented yet. Apply the Reviewer
input contract and the 4a method below. Return the effect inventory and cases for
every non-deferred P0/acceptance criterion, including the happy path. For each
material contract propose FALSIFICATION: input/state, operation, expected assertion,
and the defect that assertion must catch; WEAK_TEST: a plausible wrong implementation
that a shallow test would still pass; and PATH_GAP: missing or conflicting producer,
consumer or policy hops, distinguishing planned implementation from a blocker.
Challenge delayed or hanging dependencies, cancellation, resource cleanup ordering,
shared validation and count/size limits, alternate entry points and shared-state
consumers where relevant. Do not demand an irrelevant test matrix or invent bugs.
Do not read existing tests, fixtures, coverage reports or a previous run's plan.
Return the plan in your reply; you have no write or execution tools."**

Include this method in that task, rather than doing its enumeration yourself:

```
Required user outcome
-> user trigger and production integration point
-> state change, response, or event
-> relevant consumers and inherited policies
-> observable assertions, including failure and boundary cases
```

**Evidence allowed in 4a:** the original work item or spec, approved scope evidence,
and current production code -- routes, components, controllers,
handlers, hooks, state stores, feature flags, i18n strings, APIs, services, and
UI-facing persistence.

**Evidence forbidden in 4a:** anything under `test/`, `tests/`, `e2e/`,
`e2e_test/`; `*.test.*` and `*.spec.*`; fixtures, snapshots, golden data; and
**any existing test plan, coverage document, or test report -- including one a
previous run of this workflow produced.**

That ban has exactly one purpose: an inventory derived from existing tests
inherits the blind spots those tests already have. 4b reads the testing docs for
*procedure*; 4a must not read them for *behaviour*. Nothing enforces this at the
tool layer, so it is on you.

**Anchor the inventory on what a user can trigger, never on what the backend can
do.** Backend capabilities are the trap that hides cases, because UI-only actions
have no backend entry at all -- language switch, theme, sign-out, keyboard
shortcuts, drag-reorder, hover reveals. Enumerate triggers, not operations.

Three sweeps are mandatory. Use `search_files` on production directories (not
individual file paths). Each finds a class the one before it is structurally blind to:

1. **Handler sweep.** Label-based enumeration finds buttons, menu items, links,
   tabs and fields -- anything carrying visible text, an i18n key or a route. It
   cannot see behavioural triggers. Search the code you touch, and the components
   that render it, for `onKeyDown`, drag handlers, `onWheel`, `onPaste`,
   hover-reveal, and **`onBlur`/`onFocusOut` that commit state** -- committing on
   defocus is a different effect from the click that opened the editor.
2. **Real-time consumer sweep.** Where the product pushes state -- SSE, WebSocket,
   subscribe, polling -- a second actor mutating while the local UI reflects it
   live is its own effect, and it never substitutes for the first-actor flow.
3. **Shared reactive data sweep.** For every write, find every *other* rendered
   surface that reads the same value. This is the class both sweeps above miss:
   adding a row must also enable Undo; a batch commit must produce exactly one
   history revision; a cell's text must be identical in the grid and in the
   detail drawer.

Scope all three to the surface this feature reaches, plus the global chrome it
touches -- not the whole product.

**Record every effect in a ledger**, one row each:

```
Effect ID | UI effect | Required operation | Case ID | Coverage status | Evidence | Exercised by
```

`Evidence` is a `file:line` in production code -- where the effect comes from.
`Coverage status` is exactly one of `COVERED_MAIN`, `COVERED_BRANCH`,
`COVERED_ADDITIONAL_CASE`, `CAPABILITY_GAP`, `OUT_OF_SCOPE`, `UNRESOLVED`.

**`Exercised by` is what ran**, in three parts, and it is filled in when the check
actually runs -- step 6 for the RED, step 8 for the GREEN:

```
<test identifier>; exit <n>; inputs <the values the test actually used>
```

A row whose status starts with `COVERED_` and whose cell is missing any of the
three fails the check below. Only those three are read, and anything after them
is ignored -- so listing several inputs the obvious way, `inputs a.java; b.sh`,
is not a format error. `CAPABILITY_GAP` carries `NOT_EXERCISED - <reason>`
instead. `OUT_OF_SCOPE` carries nothing, because nothing was owed.

The third part is not decoration. A previous run marked "removing a selected
**Java/Shell** attachment" as covered by an existing test whose first line reads
`new File(["test content"], "test.txt", ...)` -- a real, passing test that never
saw a Java or Shell file. Naming the inputs is what makes that visible in the
table instead of three files away.

Five rules keep the ledger honest:

- **Do not finish 4a with anything `UNRESOLVED`.** Investigate it, raise it via the
  Callout contract, or classify it honestly as a capability gap or a justified
  exclusion. Dropping it silently is the one thing that is not allowed.
- **A deferral is valid only if its target exists.** "Covered by the X case" is
  `UNRESOLVED` until X is a row in this ledger. An unverified punt is the most
  common way an effect disappears.
- **Optional, advanced, developer-facing, post-completion, or absent from the happy
  path are not reasons for `OUT_OF_SCOPE`.** If the target code path enables,
  populates or reveals it, it gets a case or an explicit non-covered status.
- **"The same handler" is a design argument, not a test result.** Two triggers
  reaching one function is a reason to *expect* a case to pass; it is not that
  case having passed. A row that reasons its way to `COVERED_BRANCH` without an
  `exit <n>` is claiming a result nobody obtained. Either write the case and run
  it, or set `CAPABILITY_GAP` with `NOT_EXERCISED - <why it is not worth one>`.
  Both are honest; only one of them is true.
- **An existing test covers an effect only if it ran with the effect's own
  input.** Reusing a passing test is legitimate and often right -- reusing it for
  an input it never received is not. If the effect is about `.java` and the test
  feeds `test.txt`, the test proves something else. Say what it fed, in the
  `inputs` field, and let the mismatch show.

Record a **contract-difference** entry wherever intent, spec and code disagree --
for example, "the work item names a file-type picker; search finds no such control in
production, only a hard-coded accept list at `X.tsx:NN`". This is often the single
most valuable line in the document, because it is the one a reviewer cannot get
from reading the diff.

**End of the author's method.** The parent now records the Explorer's returned
plan, not a replacement enumeration; do not ask the child to run the checks below.
Write the scope header, summary, and effect rows to `test-plan.md` now; step 4b
adds executable cases to that same file. Open it with this summary, so the case set
is traceable to the method that produced it. **The first line after the stamp names what the counts are counting**
— an effect surface is always the surface of *some* scope, and left unstated a
reader supplies the widest one available:

```
repo-to-fsq-goal v1.4.0 (adapted)
Scope: <the agreed customer outcome and required criteria>.
Mode: <FULL_FEATURE | USER_APPROVED_PARTIAL with the early checkpoint reference>.
The counts below cover this agreed production-code surface.
[UI Effect Coverage Summary]
- Total relevant effects: <N>
- Covered in main case: <N>
- Covered in branches: <N>
- Covered in additional cases: <N>
- Capability gaps: <N>
- Justified out of scope: <N>
- Unresolved: 0
```

**Recompute that block; never count by hand.** A miscount is invisible: the six
numbers can sum to the right total while misattributing between buckets, so the
document self-checks clean while over-reporting coverage. Run this against the
plan file and paste its output into the step's evidence verbatim:

```awk
awk -f- test-plan.md <<'AWKPROG'
BEGIN{FS="|";K["Total relevant effects"]="TOTAL";K["Covered in main case"]="COVERED_MAIN"
K["Covered in branches"]="COVERED_BRANCH";K["Covered in additional cases"]="COVERED_ADDITIONAL_CASE"
K["Capability gaps"]="CAPABILITY_GAP";K["Justified out of scope"]="OUT_OF_SCOPE";K["Unresolved"]="UNRESOLVED"
split("COVERED_MAIN COVERED_BRANCH COVERED_ADDITIONAL_CASE CAPABILITY_GAP OUT_OF_SCOPE UNRESOLVED",A," ")
for(i=1;i<=6;i++)V[A[i]]=1
for(t in K)L[K[t]]=t}
/^[ \t]*- [A-Za-z ]+: *[0-9]+ *$/{l=$0;sub(/^[ \t]*- /,"",l);v=l;sub(/:.*/,"",l);sub(/^[^:]*: */,"",v);gsub(/ /,"",v)
if(l in K){C[K[l]]=v+0;S[K[l]]=1};next}
/^[ \t]*\| *E[0-9]+ *\|/{r++;id=$2;cid=$5;st=$6;ex=$8
gsub(/^ +| +$/,"",id);gsub(/^ +| +$/,"",st);gsub(/^ +| +$/,"",ex);n[st]++
if(!(st in V)){printf "UNKNOWN-STATUS: %s carries \"%s\", which is not one of the six\n",id,st;b++}
if(st=="OUT_OF_SCOPE"&&match(cid,/L[0-9]+-C[0-9]+/))
{printf "CONTRADICTION: %s is OUT_OF_SCOPE yet a case was written for it (%s)\n",id,substr(cid,RSTART,RLENGTH);b++}
if(st ~ /^COVERED_/){if(ex==""){printf "MISSING-EXERCISE: %s claims %s with an empty Exercised-by cell\n",id,st;b++}
else{np=split(ex,P,";");for(i=1;i<=np;i++)gsub(/^ +| +$/,"",P[i])
if(P[1]==""||P[1]~/^exit /||P[1]~/^inputs /){printf "NO-TEST-ID: %s names no test identifier before the first \";\"\n",id;b++}
else{if(P[2] !~ /^exit [0-9]/){printf "UNEXERCISED-CLAIM: %s claims %s with no \"exit <n>\" as its second field -- an argument is not a result\n",id,st;b++}
if(P[3] !~ /^inputs [^ ]/){printf "NO-INPUTS: %s names no \"inputs <...>\" as its third field -- a test that never saw the input does not cover it\n",id;b++}}}}
if(st=="CAPABILITY_GAP"&&ex !~ /NOT_EXERCISED[^A-Za-z0-9]+[A-Za-z0-9]/)
{printf "MISSING-EXERCISE: %s is CAPABILITY_GAP without a reason after NOT_EXERCISED\n",id;b++}}
END{printf "LEDGER_ROWS=%d\n",r
if(r==0){print "NO-ROWS: no ledger rows matched -- is the table present?";b++}
if(!S["TOTAL"]){printf "MISSING-LINE: %s\n",L["TOTAL"];b++}
for(i=1;i<=6;i++){k=A[i]
if(!S[k]){printf "MISSING-LINE: %s\n",L[k];b++;continue}
if(n[k]+0!=C[k]+0){printf "MISMATCH: %s -- summary %d, ledger %d\n",k,C[k]+0,n[k]+0;b++}}
if(S["TOTAL"]&&C["TOTAL"]+0!=r){printf "MISMATCH: Total -- summary %d, ledger %d rows\n",C["TOTAL"]+0,r;b++}
if(n["UNRESOLVED"]+0){printf "BLOCKER: %d row(s) UNRESOLVED\n",n["UNRESOLVED"]+0;b++}
print(b?"PLAN_LEDGER_CHECK=FAIL":"PLAN_LEDGER_CHECK=OK");exit(b?1:0)}
AWKPROG
```

**The citations have to resolve, and they have to say against what.** A `file:line`
is the one part of the ledger a reviewer can check in a second — and the second
they find one pointing at unrelated code, they stop trusting the whole table.
Line numbers do not survive a stale base: a branch cut from a `dev` that has since
moved rewrites every file in between, so a citation that was exact when written
now lands somewhere arbitrary. Record the commit they were resolved against, and
verify they resolve:

```sh
root=$(git rev-parse --show-toplevel) || exit 2
bad=0; n=0
for ref in $(grep -ohE '`[A-Za-z0-9_./-]+\.[a-z]+:[0-9]+`' test-plan.md | tr -d '`' | sort -u); do
  f=${ref%:*}; l=${ref##*:}; n=$((n+1))
  p=$(git -C "$root" ls-files --error-unmatch -- "$f" 2>/dev/null) \
    || p=$(git -C "$root" ls-files -- "*/$f" 2>/dev/null | head -1)
  if [ -z "$p" ]; then echo "UNRESOLVED: $ref — no tracked file matches"; bad=$((bad+1)); continue; fi
  t=$(wc -l < "$root/$p")
  [ "$l" -le "$t" ] || { echo "PAST-EOF: $ref — $p has $t lines"; bad=$((bad+1)); }
done
echo "CITATIONS=$n RESOLVED_AT=$(git -C "$root" rev-parse --short HEAD)"
[ "$bad" -eq 0 ] && echo "CITATION_CHECK=OK" || { echo "CITATION_CHECK=FAIL"; exit 1; }
```

Put the `CITATIONS=… RESOLVED_AT=…` line in the plan under the scope line, and do
not finish this step on `CITATION_CHECK=FAIL`. It proves reachability, not
relevance — a line that exists but says something else is still on you.

`Unresolved: 0` classifies the discovered effects in the agreed scope; it does not
by itself declare the feature complete. The independent requirements audit below
checks the original source for any P0 or acceptance criterion the design or ledger
omitted.

**That block needs a POSIX shell and `awk`.** It is the one place in this recipe
that cannot be transliterated into PowerShell by the rule above — a here-doc fed
to `awk -f-` has no direct equivalent. On a Windows host, run it under WSL, Git
Bash, or any `sh` on `PATH`; if none is reachable, say so and reconcile the six
numbers against the table by hand, in the evidence, row by row. Do not skip the
reconciliation because the tool is missing — miscounting is what it exists for.

**This step is not done until that command prints `PLAN_LEDGER_CHECK=OK`.** On
`FAIL`, fix the ledger — not the summary line you happened to write first. The
contradiction it reports is worth reading twice: a row you wrote a case for is
covered by that case, at whatever layer it runs; `OUT_OF_SCOPE` means outside the
requested code boundary, and **anything the spec names in its own acceptance
criteria can never be outside that boundary.** Not-run-here is a realization
status, not an exclusion.

Mark it `(adapted)` and mean it: the method it follows bans reading test artefacts
outright, and 4b below reads them for procedure. That deviation is deliberate and
scoped to 4b -- do not quietly widen it back into 4a.

The author ends with `REQUIREMENTS_AUDIT=OK` only when `REVIEW_INPUTS=OK`, every
source P0 or acceptance criterion is represented or explicitly approved deferred,
and no unresolved requirement/policy conflict blocks the proposed cases. Otherwise
it ends with `REQUIREMENTS_AUDIT=FAIL`, naming missing source ids/lines and inputs.
This verdict approves the plan's coverage, not an implementation that does not exist.
Record the reference and verbatim response. After correcting inputs or missing scope,
repeat once if necessary; do not leave on FAIL. Use the Callout contract if the author
cannot run or converge. **Never describe a self-review as independent or write the
OK verdict on the reviewer's behalf.**

#### 4b. Realize the adversarial plan

The parent adds executable checks to `test-plan.md`. Account for every proposed case:
realize it as a test/assertion, or give source-grounded counter-evidence or an already
approved exclusion. A capability gap carries the precise missing proof; it does not
turn required behavior into optional scope. Do not delete a hard case or weaken its
expected result to get GREEN. Read tests here only for framework/procedure.

Start with a requirement-to-case matrix containing every P0 and acceptance criterion
in the agreed scope. Map each to Layer 1/2/3 cases, or an explicit not-verified reason.
`FULL_FEATURE` uses the whole source set; an approved partial excludes only the
requirements named in its persisted approval.

**Read the repository's own instructions before choosing a shape** — both for
testing and for **running the app**, which are different questions:

- *How do I test?* — `backend/TESTING.md`,
  `backend/docs/testing/TEST_ARCHITECTURE.md`, `frontend/tests/TESTING.md`,
  `test/e2e_test/README.md`, and any `AGENTS.md` in the directories you touch.
- *How do I run it?* — `backend/README.md` (Docker Desktop, then
  `docker compose -f ./dependencies/docker-compose.yml up -d`, then the two
  `shared.dao_postgres.migrate … up` commands), and
  **`.claude/agents/app-verifier.md`** / **`.claude/commands/verify.md`**, which
  are the repository's own procedure for starting both services and verifying in
  a browser.

**Cite only files that are in the repository.** Before you rely on a doc, run
`git ls-files --error-unmatch <path>`. A file that is present on this machine but
untracked exists for nobody else — building a rule on it produces a rule that
fails on every other checkout. This is not hypothetical: this repo has several
untracked local docs sitting beside tracked ones in the same directory.

`app-verifier.md` also states, in its own verification matrix, **which
verification a change requires**. Read that matrix and obey it. It maps
`frontend/src/**/*.tsx` to "pnpm build, **browser check**", and
`test/e2e_test/**` to "**Remote only**" — that is the repository telling you both
that the deployed suite is out of reach *and* that a frontend change is expected
to be looked at in a browser.

The plan has **three layers, and they are not interchangeable**:

**Layer 1 — executable now, no app running.** Unit and integration checks in the
repository's own suites (`pnpm test`, `uv run pytest`), runnable on this branch
with nothing started. **This layer must contain the locally executable acceptance
checks** for every required criterion they can prove. The checks fail today
*because the feature is absent*, not because they reference missing symbols.

**Layer 2 — the running app, in a real browser, locally.** Reachable, and
**mandatory whenever the customer outcome or any required criterion is
user-visible.** Step 5 brings the app up; this phase decides which browser cases
prove those criteria and what each screenshot must show.

**Layer 3 — the deployed e2e suite.** `test/e2e_test/` is Playwright against
**deployed environments** (dev / test / dogfood / staging / prod) and needs MSA
account passwords from Key Vault. **It cannot exercise an unmerged branch.** So
Layer 3 is a *produced artifact*: the cases, their steps, and their expected
results, written so a tester or a later pipeline run can execute them once the
change is deployed.

**Layer 3 being out of reach says nothing about Layer 2.** Confusing the two is
the specific mistake this section exists to prevent: a previous run correctly
recorded that `test/e2e_test` targets deployed environments, then treated that as
a reason no browser verification was possible at all, and shipped a user-visible
feature with no screenshot.

**Never present a Layer 3 case as evidence this run produced.** Saying "e2e
verified" when nothing ran is the failure mode this whole phase exists to prevent.
If a required criterion is only provable at Layer 3, keep it in the matrix, say
so explicitly, and mark it *not verified by this run*.

#### Designing the Layer 2 case

A Layer 2 case is designed with the same rigour as a Layer 1 case, and it needs
two fields the other layers do not. Write each one as:

```
Action:            the concrete thing a user does — "select Example.java through
                   the Add Content file input"
Visible signal:    what a user would then SEE — "an attachment card labelled
                   Example.java appears in the composer"
Screenshot shows:  name the thing that must be legible in the image — "the
                   attachment card with the filename Example.java"
Screenshot must not: the failure surface of this same action. One exact string
                   per line, matched case-insensitively as a fixed string, never
                   empty:
                     Failed to upload
                     Retry upload
                     File type not supported
Before (RED):      the same action on unmodified code, and what is seen instead —
                   "no attachment card; the unsupported-format message appears"
Criteria:          every P0/acceptance-criterion id this case serves
```

**One string per line, and the lines go into the file verbatim.** They are matched
with `grep -F`, so a line holding three quoted phrases joined by commas is one
string that nothing will ever contain — the check then passes over a snapshot that
says `Failed to upload` in as many words. The first draft of this block said "one
per line" in a paragraph whose own example ran three across a wrapped line; that
is the shape of green light this whole section exists to remove.

**`Screenshot must not` is where a case stops being satisfiable by a failure.**
The RED line above already names what is *absent*; the GREEN side had only a
presence to look for, and a presence is cheap. A run wrote its expectation as *an
attachment card labelled `example.html` appears*, then shipped a GREEN whose image
carried a red banner reading **`Failed to upload example.html`** and a retry
button beside the card. The filename was legible. The expectation was met to the
letter. The upload had failed, because the backend allowlist was never touched.

Its own snapshot said so:

```text
main: Hi yueliu1, what can I do for you? Failed to upload example.html
text: example.html
button "Retry upload"
```

**Name the end of the action, not its beginning.** A picker opening is the start
of capture; the requested attachment is the end. A card appearing may be the start
of an upload; `Ready` is the end of its success case, while an actionable `Failed`
state belongs to a separately planned failure case. Evidence that stops at the
entry point leaves the downstream requirements unserved. A visible error is never
outside the required action that produced it.

**`Screenshot shows` is not optional and it is not "the app".** A screenshot of a
loaded, signed-in page proves the app runs; it does not prove the feature works.
If you cannot name, in advance, a thing that will be visible in the image and
would be absent without your change, you have not designed a Layer 2 case — you
have designed a smoke test.

**Reading an attribute is not a visible signal.** `accept=".java,.sh"` on a file
input is a DOM property; a user never sees it. Checking it in a browser proves the
constant reached the DOM — which the Layer 1 component test already proved, and
proves it faster. A Layer 2 case that only reads attributes has spent the whole
cost of bringing the app up and bought nothing.

The test is simple: **would this case still pass if the feature were wired to
nothing?** If yes, go one step further — perform the action, and assert on what
comes back.

**Assert on what is reachable locally, not on what you wish were.** Some paths
cannot complete on a developer machine at all — file upload here reaches storage
and stops, because the storage layer always speaks ADLS Gen2 (which the local
Azurite emulator does not implement) and the real cloud account rejects a
developer identity with `AuthorizationPermissionMismatch`. The attachment card
still renders, so a criterion phrased "see it as an attachment" is provable while
one phrased "the upload succeeds" is not. Find that line before you write the
case, and record which side of it each expectation falls on.

Three rules govern every assertion, at every layer. They come from a four-way
comparison of generated test cases run on this product, where the loose-assertion
variant missed defects the precise variant caught:

1. **Assert precisely, never on a loose range.** "5–6 slides" passes a build that
   produced the wrong count; "exactly the requested count" does not.
2. **Assert on a signal the user can see** for the end-to-end outcome: a count,
   state, card, order or error. Layer 1 must also assert required internal contracts
   such as resource release ordering and shared validation; those checks supplement,
   but do not substitute for the user-visible result.
3. **Every expectation in the plan must survive into the executable check.** An
   expectation that exists in `test-plan.md` and in no assertion is a check nobody
   runs. When one cannot be expressed, write down which one and why.

For each case, record what it proves, every criterion it maps to, the exact
command, and the expected result. One case may prove several criteria, but every
required criterion in the agreed scope must map to at least one case or an explicit
not-verified reason. A case that maps to none does not belong in the plan.


**Close the loop with 4a.** Every row in 4a's ledger appears here with either a
realization -- which layer, which case, which assertion -- or an explicit
non-realization carrying its reason. The counts in the summary block must match
what this section actually contains. A ledger that promises more coverage than
`test-plan.md` delivers is worse than no ledger, because it reads as proof.

### 5. Bring the app up

**Skip this step only when no required criterion or customer outcome is user-visible.** Otherwise it
is a gate: the app comes up *now*, before any production code changes, and stays
up through both the RED and the GREEN. That ordering is the whole point — a run
that starts the app only when it wants a GREEN has no RED to pair it with, and a
browser GREEN with no browser RED proves nothing about causation.

This procedure was executed end to end on this repository; each failure mode below
is observed, not anticipated:

**Bring-up spans more than one tool call.** Starting a service and waiting for it
are separate calls. A single `shell` that does both runs out of its 600-second
ceiling before the waiting does: the two readiness polls below are 90 iterations
of `sleep 2` each, so six minutes go to waiting before Docker, the migrations and
the two startups are counted. The processes are `nohup`-ed and survive the tool
timeout, which is why a run that packs it into one call still finds the app up
afterwards — having spent ten minutes learning that. Start, return, then poll.

1. **Infrastructure.** `open -a Docker`, wait for the daemon, then
   `docker compose -f backend/dependencies/docker-compose.yml up -d postgres`.
   Postgres is the one hard blocker — `api.py`'s startup calls
   `run_all_auto_migrations()` outside any try/except, so a closed 5432 aborts
   uvicorn. Start `redis` too only if nothing already serves 6379; a local Redis
   installed outside Docker will make that container fail to bind.
2. **Migrations.** The two `uv run python -m shared.dao_postgres.migrate … up`
   commands from `backend/README.md`.
3. **Backend.** `cd` on its own line, then background a single command — never
   `cd backend && nohup … &`:

   ```sh
   scratch="<repo_path>/.workflow-run/<feature-slug>"
   mkdir -p "$scratch" || { echo "NO_SCRATCH_DIR"; exit 1; }
   cd -- '<repo_path>/backend' || { echo "NO_BACKEND_DIR"; exit 1; }
   nohup uv run python api.py > "$scratch/backend.log" 2>&1 &
   echo $! > "$scratch/backend.pid"
   ```

   Then poll `http://localhost:8000/health` until it returns `"status":"ok"` with
   `database` and `redis` both `connected`. Read the log on failure; the health
   body names which dependency is down.
4. **Frontend.** Same shape:

   ```sh
   scratch="<repo_path>/.workflow-run/<feature-slug>"
   mkdir -p "$scratch" || { echo "NO_SCRATCH_DIR"; exit 1; }
   cd -- '<repo_path>/frontend' || { echo "NO_FRONTEND_DIR"; exit 1; }
   PORT=3000 nohup pnpm dev:turbo > "$scratch/frontend.log" 2>&1 &
   echo $! > "$scratch/frontend.pid"
   ```

   Then poll `http://localhost:3000/`. **Do not use `frontend/dev.sh` on the
   primary checkout** — it exports `PORT` from `.env.local`, and when that file
   has no `PORT=` line it exports an empty string and Next refuses to start.

**`&` binds the whole `&&` list, not the last command.** Written
`cd backend && nohup … &`, the background job is a *subshell* running both, and
that subshell keeps the parent's stdout. Pipe the surrounding block into `tee`
— the obvious way to keep a bring-up log — and `tee` waits for a writer that
never closes, because the server it is waiting on does not exit. Two calls in one
run burned the full 600-second tool ceiling this way.

Measured, same server, three shapes:

```text
{ … cd backend && nohup api.py > log 2>&1 & … } | tee   ->  waits for the server
{ … cd backend && nohup api.py > log 2>&1 & … } >> f    ->  returns immediately
cd backend; nohup api.py > log 2>&1 & …         | tee   ->  returns immediately
```

All three redirect the server's own stdout and stderr to a file; the redirection
is not what separates them. What the first one leaves attached to the pipe is the
**subshell** `&` created around `cd backend && nohup …`, and `tee` waits on that.

Neither `| tee` nor `cd &&` is wrong alone. The pair is.

**`mkdir -p "$scratch"` before either service starts.** The redirection targets a
directory the run creates in step 1; on a resumed run, or one that reached step 5
by another path, it may not be there. Without it the failure is quiet and
complete: `> "$scratch/backend.log"` fails inside the backgrounded subshell so the
server never starts, `echo $! > "$scratch/backend.pid"` fails too, and the step
prints two redirection errors and no summary line — nothing that reads as *the
service did not come up*.

**Keep the guard when you split the `cd` out.** `cd backend && …` at least refuses
to start the server from the wrong place; a bare `cd` on its own line does not, and
`cd` failing there leaves the next line running in the repository root. Hence
`cd -- '<path>' || { echo NO_..._DIR; exit 1; }` — the split removes the hang, the
`||` keeps what the `&&` was doing.
5. **Authenticate.** `cd backend && uv run scripts/stress_token.py` — a
   repository-provided local dev path. It flips `ENABLE_STRESS_TOKEN=true` in
   `backend/.env`, picks an account from local Postgres, and prints an auto-login
   URL. **Restart the backend afterwards** or the flag has no effect. Verify the
   token before trusting it: the same endpoint must return 401 without it and 200
   with it.
6. **Confirm the browser can drive it.** Navigate to the auto-login URL and check
   the app is really authenticated — a signed-in surface, and API calls returning
   200 rather than 401.

**Check the browser's localhost access before changing anything.** The tool grant
is not a destination grant. First read
`config_praestoclaw(action="show", path="tools.browser.allowed_domains")` and its
`baseHash`. If `localhost` and `127.0.0.1` are already present, do not patch.
Otherwise explain that the change is persistent, globally effective personal
configuration, not temporary app setup. Propose only the missing hosts and
preserve every existing entry. Submit the resulting patch with the fresh `base_hash`;
the tool gate requires exact-call user approval, even in a workflow/full-auto run.
Do not add a duplicate Plan checkpoint for that same tool approval. On hash conflict,
read again; a changed value requires a new approval. On denial, expiry, or unavailable
approval, record the actual blocker and use the Callout contract. This is not
permission to edit config through shell or to evade SSRF with another browser tool.

`browser.py` skips SSRF validation for hosts in this list. The exact field takes
effect immediately because BrowserTool holds the shared config object. Read the
result; if it mentions a restart, the change is not live. Do not assume other config
changes hot-reload or restart the service without authorization.

**Choosing a browser — try the machine's own first, download only as a fallback.**
In that order:

1. **The browser already installed**, via Playwright's `channel` option —
   `channel="msedge"`, then `channel="chrome"`. This needs no download, works on a
   machine whose network blocks the Playwright CDN, and is the normal case here.
2. **Only if both channels fail**, download Playwright's own build
   (`playwright install chromium`). Expect this to be the slow path and expect it
   to fail on a restricted network; if it does, say so with the real error rather
   than concluding a browser is unavailable.

`executable_path` reporting a path is *not* evidence a binary exists — it is a
computed location, and it resolves happily for a browser that was never
downloaded. Launch it, or you have not checked.

**If the app cannot be brought up, that is a Callout**, with every command you ran
and its real error — not a sentence in the evidence file and a run that continues
as though Layer 2 were optional. The one thing you may not do is proceed to the
implementation and then start the app for the GREEN.

**Restore afterwards** (step 8 reminds you again): `ENABLE_STRESS_TOKEN=false`,
**stop every service this run started — including any you restarted during
cleanup** — and confirm `git status --short` shows the production tree unchanged.

Restarting the backend to prove the auth bypass is off is a good check; **leaving
it running afterwards is not cleanup**. Record which services were running before
you began, and return the machine to exactly that set. A service the user did not
start and did not ask for is a leftover even when it is harmless, and "I left it
up for safety" is not a reason — stop it, and say in the evidence file that you
verified the bypass was dead before you did.

### 6. Current-state evidence (before)

Run the Layer 1 checks **against unmodified code**, and write `evidence-before.md`.

**For every planned user-visible Layer 2 case, capture the RED here.** The app
is already running (step 5), so there is no startup cost left to weigh and no
"the frontend was not running" to record — perform the case's `Action` against
unmodified code, screenshot, and show that the `Visible signal` is **absent**.
That image is what makes the later GREEN mean something; without it the pair is
"a browser saw the feature" versus "nothing looked", which proves nothing about
your change.

This must happen **before any production code changes**. Confirm it: `git status
--short` and `git diff --stat` should show the new test files and the artifacts,
and no change to the code under test. Say so in the file.

Capture three things, each with the exact command, the exit code, and the real
output — never a summary, never a reconstruction:

**"The real output" means the tool's words about your check, not everything the
tool printed.** `frontend/jest.config.js` sets `collectCoverage: true`, so running
a single test file prints a coverage table for the whole project. A run captured
**1,081,784 bytes** into `evidence-before.md` to record a result whose entire
content was the last two lines it printed:

```text
Test Suites: 1 failed, 1 total
Tests:       1 failed, 27 passed, 28 total
```

Keep the command, the exit code, the failing assertion, and the counts. Leave the
full capture on disk and cite its path instead of inlining it. Per-file coverage
for code this change never touches is not evidence about this change, and pasting
it does not make the RED more true. **"Never a summary" forbids inventing a result
you did not see; it does not oblige you to transcribe output about something
else.** If you did not read a line, it is not evidence — it is volume.

1. **Every planned acceptance check fails.** These RED results are the evidence
   in this run that cannot be produced by accident. Together they separate a
   delivered feature from a PR that merely compiles.
2. **It fails for the right reason.** Read the failure. An `ImportError`, a
   `NameError`, a syntax error, or a missing fixture is **not** the feature being
   absent — it is your test being broken. Fix the test and re-run until the failure
   message describes the missing behaviour.
3. **The baseline around it.** Run the whole test files you will touch, on the
   **target branch's** state, with the **same command** you will use afterwards. A
   test that already fails before your change is not a regression you caused, and
   the only way to know that is to have run it first.

If any acceptance check **passes** before you have implemented anything, stop.
That behavior already exists, the check asserts something else, or the scope is
wrong. Any of the three invalidates the run — say which, via the Callout contract.

### 7. Implement the agreed customer outcome

Make the smallest change that satisfies the agreed customer outcome and scope,
following the repository's own conventions for the directories you touch.
Implement **the design in `design.md`**
— if you find mid-way that the design is wrong, say so and update the file; do not
quietly build something else and leave the artifact describing work that never
happened.

The acceptance checks already exist and already fail: step 4 wrote them and step
6 captured the RED results. **Do not rewrite checks to fit the implementation.**
If a check turns out to assert the wrong thing, that is a finding — record it in
`evidence-after.md` with the old and new assertion side by side, and say why the
first was wrong. Silently editing an assertion until it passes converts the run's
one trustworthy piece of evidence into a tautology.

Choose the boundary each required behavior is observable at, and read the
instruction file that owns that surface before writing the check. **Never select a
lower boundary because it is easier**: "it isn't really visual", "it is observable
in logs", or "it is easier to test at the unit level" are not reasons. A
user-visible behavior is proved on the surface a user sees.

**Discover the checks; do not assume a toolchain.** Read the repository's
instructions and run the gates that apply to the directories you changed. If the
package commits build output, rebuild it — editing a source that compiles into a
committed artifact ships nothing without that step.

### 8. Verify evidence (after)

Re-run **exactly the commands step 6 ran**, and write `evidence-after.md`. Same
commands, same scope — a different command produces a comparison that means
nothing, and the whole value of the before/after pair is that the only variable is
your change.

Capture, with real output and exit codes:

1. **Every planned executable acceptance check now passes.** These are the GREEN
   results. Pair each with its RED from `evidence-before.md` so a reviewer sees the
   transition, not just the endpoint. A required Layer 3 check that did not run
   remains explicitly not verified; it is not a GREEN.
2. **The baseline is unchanged.** Run the same whole test files, not selected
   cases: a selection can only confirm your own work and can never show you a
   neighbour you broke. Compare against the before run **case by case**, not by
   total count — a suite that goes from 103 passed to 103 passed can still have
   swapped which ones.
3. **The repository's own gates** for the directories you changed — lint,
   typecheck, format, whatever the instructions name.

   **Each gate gets a one-line verdict, not just its output.** Write
   `<gate>: PASS`, `FAIL`, or `BLOCKED — <reason>`. Pasting a wall of log that
   ends in `[ERROR]` and moving on leaves a reviewer to work out for themselves
   whether a required gate was satisfied, and the honest answer gets buried in
   the one place nobody rereads. A gate the repository's own instructions mark
   as required for a path you changed, and which did not pass, is stated again
   in the PR under `Not run` with its reason — a run that reaches the PR with a
   required gate quietly failed has mis-stated its own readiness.

   **A gate that repairs dependencies can break the checkout it runs in.** Some
   `typecheck`/`build` entry points reinstall packages before doing anything,
   and against a private feed with no credentials they exit having deleted a
   working install rather than restored one. If a gate leaves the working
   checkout less usable than it found it, that belongs in the evidence with the
   exact command and what is now missing — the next person to run tests here
   needs to know before they lose an hour to it.

If something that passed in `evidence-before.md` fails now, that is a regression
you introduced, not an outdated expectation. The honest fix is to make your change
additive; editing the assertion to match your new behaviour is a decision to break
that surface, and if you truly intend it, say so in the PR under `Behaviour
deliberately changed` and name who is affected.

**Capture every planned Layer 2 GREEN**: repeat each case's `Action` on the
changed code, screenshot, and confirm the image shows exactly what `test-plan.md`
said. Put each RED/GREEN pair side by side; one pair may prove several criteria
only when every mapped visible signal appears.

**Check the image, do not assume it.** A screenshot proves what is *in* it. If the
plan said the image would show an attachment card labelled `Example.java` and the
image shows a signed-in landing page, the case did not pass — it ran and produced
the wrong evidence, which is worse than not running, because it looks like proof.
Say what the image actually shows.

When a required criterion is user-visible and you have no image, do not describe the
pixels in prose as though you had seen them — record that the visual evidence is
missing and that it needs a human or a deployed-environment run.

Finally, restate the Layer 3 e2e cases as **not run**, with the reason (no
deployed build of this branch). Never let the after-evidence read as if the
deployed suite passed.

**A GREEN may not contain the failure of the action it proves.** Save the browser
snapshot beside the screenshot, write the plan's `Screenshot must not` lines to a
file, and check one against the other:

```sh
cd -- '<repo_path>/.workflow-run/<feature-slug>'
test -s layer2-green-snapshot.txt || {
  echo "LAYER2_CHECK=FAIL green snapshot not saved"; exit 1; }
bad= ; used=0
while IFS= read -r s || [ -n "$s" ]; do
  [ -n "$(printf '%s' "$s" | tr -d '[:space:]')" ] || continue
  used=$((used + 1))
  if grep -qiF -- "$s" layer2-green-snapshot.txt; then
    printf 'LAYER2_SAW %s\n' "$s"; bad=1
  fi
done < layer2-must-not.txt
printf 'LAYER2_STRINGS_USED=%s\n' "$used"
[ "$used" -ge 1 ] || {
  echo "LAYER2_CHECK=FAIL no must-not strings declared"; exit 1; }
[ -z "$bad" ] && echo "LAYER2_CHECK=OK" || { echo "LAYER2_CHECK=FAIL"; exit 1; }
```

`read` returns non-zero on a final line with no newline after it, so the loop is
written `read -r s || [ -n "$s" ]`: without that, a must-not file saved by hand
loses its last string in silence. Declaring two and comparing one printed `OK`
over a snapshot containing the string that was dropped.

Both files are required, and the count that matters is `LAYER2_STRINGS_USED` —
the lines the loop actually compared, not the bytes on disk. `test -s` passes on a
file holding nothing but blank lines, every one of which the loop then skips, and
the check reports a pass having compared nothing. A check with nothing to look
for and a check with nothing to look in are the same green light over nothing, and
file size does not tell them apart. `LAYER2_SAW` names the string that fired, so a
failure says which expectation was violated rather than that one was.

On `LAYER2_CHECK=FAIL` the Layer 2 GREEN does not exist. Do not record it as
passing with the failure noted alongside as out of scope; that is the sentence the
run under discussion wrote, and it is how a red banner became evidence.

**Say which path produced the GREEN, and let the ledger feel it.** A Layer 2
GREEN can come from driving the real producer, or from a fixture you seeded
straight into the store. Those are different claims: the first says the feature is
reachable, the second says the component renders when handed the data you believe
it will get. A run proved only the second and recorded the first. It had *tried*
the real path, hit an infrastructure error, honestly kept the failed screenshot,
then seeded a row and marked the required behavior covered anyway.

Emit exactly one of these beside the snapshot:

```sh
echo "LAYER2_PATH=REAL"                       # the producer actually ran
# Seeding is a decision for the user, not for this run. Callout FIRST, then record it:
echo "LAYER2_PATH=SEEDED <why REAL was unavailable>"
echo "LAYER2_SEEDED_CALLOUT=<blocked item id OR APPROVED:<what the user answered>>"
```

**A blocked real path is a Callout at the moment it blocks, not a detour.** The
guardrail above already bans preferring "a stand-in test, or a synthetic
screenshot over stopping here", and a run walked straight past it: the local LLM
returned `403 AUTH_ALLOWED_UPNS`, and instead of asking — a fix its user could
have made in minutes — it seeded a row and carried on for another half hour. It
was honest about having seeded, and it still spent the run producing something
nobody could verify.

Credentials, permissions, quota, a missing binary, a refused ref: these are the
user's to fix, and they are cheap for the user to fix. The moment one of them
makes you reach for a substitute, stop and ask. Continuing costs the run; asking
costs one message.

On `SEEDED`, the criterion row in the ledger may **not** carry a `COVERED_` status
— it is `CAPABILITY_GAP` with `NOT_EXERCISED <reason>` — and the PR's delivery
readiness may not exceed "renders when fed the expected shape". Check it:

```sh
python3 - "$scratch/layer2-path.txt" "$scratch/test-plan.md" <<'PY'
import sys, pathlib
PIPE = chr(124)   # a literal "|" in a quoted argument would trip auto-approve
read = lambda f: pathlib.Path(f).read_text(encoding="utf-8", errors="replace").splitlines()
decls = [l for l in read(sys.argv[1]) if l.startswith("LAYER2_PATH=")]
print("LAYER2_PATH_DECLARATIONS=%d" % len(decls))
if len(decls) != 1:
    print("LAYER2_PATH_CHECK=FAIL expected exactly one declaration"); sys.exit(1)
rest = decls[0].split("=", 1)[1].split()
decl = rest[0] if rest else ""
print("LAYER2_PATH_DECLARED=" + (decl or "NONE"))
if decl not in ("REAL", "SEEDED"):
    print("LAYER2_PATH_CHECK=FAIL value must be REAL or SEEDED"); sys.exit(1)
if decl == "SEEDED" and len(rest) < 2:
    print("LAYER2_PATH_CHECK=FAIL SEEDED needs the reason REAL was unavailable"); sys.exit(1)
if decl == "SEEDED":
    co = [l for l in read(sys.argv[1]) if l.startswith("LAYER2_SEEDED_CALLOUT=")]
    val = co[0].split("=", 1)[1].strip() if len(co) == 1 else ""
    print("LAYER2_SEEDED_CALLOUT=" + (val or "NONE"))
    if len(co) != 1 or not val:
        print("LAYER2_PATH_CHECK=FAIL seeding requires a Callout the user answered"); sys.exit(1)
if decl == "SEEDED":
    bad = [l for l in read(sys.argv[2]) if l.lstrip().startswith(PIPE) and "COVERED_" in l]
    if bad:
        print("LAYER2_PATH_CHECK=FAIL seeded GREEN cannot back a COVERED_ row (%d)" % len(bad))
        sys.exit(1)
print("LAYER2_PATH_CHECK=OK")
PY
```

Seeding is a legitimate way to reach a surface the real path cannot reach today.
It is never a way to say the path works.

**Size the working files before you leave this step.** The rule above says to keep
the counts and the failing assertion and cite the capture's path; this checks that
you did:

```sh
cd -- '<repo_path>/.workflow-run/<feature-slug>' || {
  echo "EVIDENCE_CHECK=FAIL no such directory"; exit 1; }
bad= ; n=0
for f in requirement-analysis.md design.md test-plan.md evidence-before.md evidence-after.md; do
  if [ ! -f "$f" ]; then printf 'EVIDENCE_MISSING %s\n' "$f"; bad=1; continue; fi
  b=$(wc -c < "$f" | tr -d ' ')
  n=$((n + 1))
  printf 'EVIDENCE_BYTES %s=%s\n' "$f" "$b"
  [ "$b" -le 65536 ] || bad=1
done
printf 'EVIDENCE_FILES_MEASURED=%s\n' "$n"
[ "$n" -eq 5 ] || bad=1
[ -z "$bad" ] && echo "EVIDENCE_CHECK=OK" || { echo "EVIDENCE_CHECK=FAIL"; exit 1; }
```

**A check that measured nothing must not print `OK`.** The first version of this
block did: an unhandled `cd` left it in the wrong directory, every file missed
`[ -f ]`, every iteration `continue`d, `bad` stayed unset, and it reported a pass
having weighed nothing. `EVIDENCE_FILES_MEASURED` is printed so the count is on the
record, and a run that produced four of the five files fails on the fifth instead
of being congratulated for the four.

65536 is six times what these files need. Measured on a real run: the three
analysis files came in at 8.5 KB, 8.0 KB and 9.9 KB, and `evidence-after.md`
would have been **10 KB** — except that five captured logs were pasted into it
whole, three of them near-identical coverage tables of about 155 KB each, taking
it to **517 KB**. Nothing in it was false. None of it was read.

On `EVIDENCE_CHECK=FAIL`, do not trim by deleting findings. Find the pasted
capture, leave it on disk, and cite its path — that is the same instruction as
step 6, and this is the check that it happened.

### 9. Acceptance review

**Try to disprove the delivery claim.** The reviewer challenges logic or safety
errors, incomplete outcomes, and false proof within the agreed scope. Passing CI
and a working happy path are inputs to that review, not reasons to skip it.

Compute the diff and write it **outside** the repository so no `git add -A` can
sweep it in. **`git add -N` first, or the review is blind to every new file:**

```
cd -- '<repo_path>' \
  && base=$(git merge-base '<target>' HEAD) \
  && git add -N -- <changed_paths> \
  && git diff --stat "$base" -- <changed_paths> > "$HOME/.praestoclaw/workspace/review-{feature_id}.stat" \
  && git diff "$base" -- <changed_paths> > "$HOME/.praestoclaw/workspace/review-{feature_id}.diff"
```

**Also capture what you did *not* nominate.** The two diffs above cover the paths
you chose; everything the run disturbed outside that list is invisible to them, and
to the reviewer reading them:

```
cd -- '<repo_path>' \
  && git -c color.status=false status --porcelain --untracked-files=all \
     > "$HOME/.praestoclaw/workspace/review-{feature_id}.tree"
```

`--porcelain` is the format Git documents as stable for scripts; `--short` is for
people and shifts with the reader's config. Both flags are pinned for the same
reason: colour codes and a repository-level `status.showUntrackedFiles` would
otherwise decide what the reviewer is allowed to see.

A run picking its own review scope is the suspect choosing the evidence. One run
handed the reviewer five files and 150 insertions while the working tree also held
a lockfile rewritten by the test suites (**4842 lines**), a file carrying the user's
own local debug flags, and an unrelated doc edit. The reviewer answered *is any file
here unnecessary* correctly, over a set that had already been filtered.

`<changed_paths>` is the list of paths this change owns. It is **the same list
every time it appears** — the three commands above, and the `git reset` below
that undoes them. Substitute it once and reuse it verbatim: a diff taken over a
narrower set than the intent-to-add is a diff with holes in exactly the place
this step exists to cover.

`git diff` says nothing about an untracked file. It does not warn, it does not
fail — naming one on the command line simply produces no output for it, and the
review proceeds over whatever remains. A run once handed the reviewer a 154-line
diff of five code files while five new artefacts sat beside them unlisted, one of
them **3789 lines**. The reviewer's second question is *is any file here not
required by the criterion* — it asked, and the file was not in front of it.

**`HEAD` is the wrong base here.** Step 1 may reuse a task branch that already
carries a prior run's commits, and `git diff HEAD` shows only what is *un*committed
— the committed half of the same change never reaches the reviewer. The merge-base
against the target branch covers both halves. Do not reach for `<target>...HEAD`
instead: the three-dot form compares two commits and never consults the working
tree, so it drops everything not yet committed, which at this step is normally the
entire change.

`git add -N` records intent-to-add: new files appear in the diff with their
contents, and no content is staged. **Undo it before you leave this step** —

```
cd -- '<repo_path>' && git reset -- <changed_paths>
```

— because until you do, `git status` reports those files as `A` rather than
untracked, and step 10 stages by explicit path against exactly that reading. The
files themselves are untouched by the reset.

**Prove every identity join this change introduces.** Pass 3 already told you
both ends of a contract must exist and that a fixture you wrote proves only that
it agrees with itself. Nothing read those back, so a run shipped a feature that
never worked: it matched `run.id === threadRunId`, where `thread_run_id` is a
fresh uuid4 minted per model response and `AgentRun.id` is the outer run's row.
Two different producers, never equal in production. The run then wrote a frontend
test binding both names to `"run-usage-1"`, seeded a browser fixture setting
`metadata.thread_run_id` to the `agent_runs` row id, and every gate passed. The
repository had documented the trap in a docstring — *"Messages persist only
metadata.thread_run_id (a per-response uuid), never agent_run_id"* — and the run
never read it.

Extract the joins the diff introduces. This reads **added lines only**, so
untouched code contributes nothing:

```sh
python3 - "$HOME/.praestoclaw/workspace/review-{feature_id}.diff" <<'PY' > "$scratch/join-check.txt"
import re,sys,pathlib
CMP=re.compile(r"([A-Za-z_][A-Za-z0-9_.\[\]]*)\s*===?\s*([A-Za-z_][A-Za-z0-9_.\[\]]*)")
leaf=lambda e: e.split(".")[-1].strip("[]")
isid=lambda k: k.lower()=="id" or k.lower().endswith("id")
norm=lambda k: k.lower().replace("_","")
joins=set()
for ln in pathlib.Path(sys.argv[1]).read_text(encoding="utf-8",errors="replace").splitlines():
    if not ln.startswith("+") or ln.startswith("+++"): continue
    for a,b in CMP.findall(ln[1:]):
        la,lb=leaf(a),leaf(b)
        if isid(la) and isid(lb) and norm(la)!=norm(lb): joins.add((min(a,b),max(a,b)))
for a,b in sorted(joins): print("JOIN_INTRODUCED %s == %s"%(a,b))
print("JOINS_INTRODUCED=%d"%len(joins))
PY
cat "$scratch/join-check.txt"
```

For **each** line it prints, the design note must carry a block in exactly this
shape — the two `writes-` citations are the point, because going to find them is
what exposes an assumed equality:

```
JOIN <left> == <right>
  writes-left   <file:line that assigns the left side in production>
  writes-right  <file:line that assigns the right side in production>
  equal-because <file:line that guarantees they hold the same value | NOT-GUARANTEED>
```

Then read the result back:

```sh
grep '^JOIN_INTRODUCED ' "$scratch/join-check.txt" | sed 's/^JOIN_INTRODUCED //' \
  | sort -u > "$scratch/joins-needed.txt"
grep -oE 'JOIN [^ ]+ == [^ ]+' "$scratch/design.md" | sed 's/^JOIN //' \
  | sort -u > "$scratch/joins-proven.txt"
missing=$(comm -23 "$scratch/joins-needed.txt" "$scratch/joins-proven.txt")
ng=$(grep -c 'equal-because NOT-GUARANTEED' "$scratch/design.md" || true)
echo "JOINS_INTRODUCED_COUNT=$(wc -l < "$scratch/joins-needed.txt")"
[ -z "$missing" ] || { echo "JOIN_CHECK=FAIL unproven:"; echo "$missing"; exit 1; }
[ "$ng" -eq 0 ] || { echo "JOIN_CHECK=FAIL $ng join(s) NOT-GUARANTEED"; exit 1; }
echo "JOIN_CHECK=OK"
```

`NOT-GUARANTEED` is a finding about the **slice**, not a disclosure that lets it
proceed: if production never makes the two sides equal, the code is wrong and no
note fixes it. Go back to step 7. The count is printed so an `OK` over zero joins
is visibly an `OK` over zero joins.

**What this does not cover.** It reads `==`/`===` in the diff, so a join expressed
positionally — a SQL `INSERT` that puts the same value in two columns, a
`Map.get`, a lookup by array index — is invisible to it. Measured against 25
merged PRs in this repository it fired twice, both one-line justifications; an
earlier version that scanned *fixtures* for a value bound to two id-shaped keys
fired **43 times across 257 untouched test files**, because `id: "call-1"` beside
`toolCallId: "call-1"` is the correct shape nearly everywhere. Scanning what the
change *joins on* is the low-noise surface; scanning what fixtures *contain* is
not.

**Give the reviewer the `--stat` first.** A per-file line count is the cheapest
signal there is and it does not require reading anything: an artefact far larger
than the production change it documents is a finding on sight, before a word of
its content has been read.

Spawn a fresh reviewer with `agent="explorer"`, `mode="serial"`, and the Reviewer
input contract from step 4. Give exact paths to the original source, the approved
scope/proof, current `design.md`, `test-plan.md`, `evidence-before.md` and
`evidence-after.md`, plus stat, full diff and dirty tree. It must read those inputs,
the changed tests' actual assertions, and the relevant production functions/callers.
**Read the `--stat` before the diff**; use targeted ranges for large source
files and follow required producer/consumer context, not the whole codebase.
Runtime supplies live repository reads; workspace files supply only this run's diff.
Do not tell it your own verdict or give it the earlier review's passing conclusion.
Ask exactly these four questions:

1. **Enough?** Find a concrete input/state that breaks a non-deferred requirement
   or makes the change unsafe. Cite the changed line and upstream/downstream evidence.
   Check lifecycle and async ordering, cancellation, and shared validation bypasses.
   A new entry point does not satisfy its downstream result.
2. **False proof?** Name a production mutation or disconnected producer that would
   still let a claimed test pass. Report missing tests and tests that do not prove
   their claims: read the assertions, not just names, mocks or passing counts. Check
   failure/delayed paths, actual inputs, and what each browser/manual proof reached.
3. **Connected?** Trace the user action through the real producer, inherited policies,
   and downstream consumer, one `file:line` per hop. Does every non-deferred P0/AC
   have the implementation and evidence its claimed status needs?
4. **Too much?** **Anything else touched?** Name unnecessary changed files and every
   dirty tree path missing from the stat; say whether the outcome needed each.
   The diff was scoped by the same run that dirtied the tree. A disproportionately large
   artifact is a scope finding, not a style comment. The single design note is a
   required deliverable: judge its accuracy and size, not whether it executes at runtime.

Require concrete, falsifiable findings, not a bug quota. NONE is valid when no
counterexample is supported. Exclude pure style, naming, formatting, lint or type-only
noise, not behavioral defects CI missed. Answer in one pass. Once an in-scope blocker
is confirmed against the code, stop expanding the search: report the verified findings
and any unchecked remainder with FAIL. A failing verdict does not require exhausting
every possible issue; an OK verdict still requires all mandatory reads and checks.

It ends with `CUSTOMER_OUTCOME_CHECK=OK` only with `REVIEW_INPUTS=OK` and no
unresolved finding contradicting the original requirements and stated readiness.
Otherwise return `CUSTOMER_OUTCOME_CHECK=FAIL`. An unresolved in-scope blocker means
`NOT_READY`, even with approved partial scope. Preserve that scope approval, but do
not describe its slice as implemented and proven. `CONDITIONAL` requires complete
implementation with only named external/human product proof left, never missing
review inputs or a failing requirement.

**Parent disposition — not part of the reviewer prompt.** The reviewer reports
findings, not Accepted/Rejected dispositions. Re-derive each finding yourself.
Record Accepted with the fix or Rejected with source-grounded counter-evidence (code, actual test output, or the original spec).
"Tests pass", "already handled", or a bare "out of scope" is not counter-evidence.
Record every disposition and the verbatim verdict. Re-review **only if you changed
something**, once. Remaining findings go under `Review findings not addressed` in
the reviewer's words; do not replace FAIL with your own OK to open a ready PR.

### 10. Draft pull request and hand off

Verify the checkout is on the **exact branch step 1 recorded**, not merely a
branch that is different from the target. Read the decision back before staging:

```sh
expected=$(sed -n '1p' '<repo_path>/.workflow-run/<feature-slug>/task-branch.txt')
actual=$(git -C '<repo_path>' branch --show-current)
echo "BRANCH_EXPECTED=${expected:-NONE}"
echo "BRANCH_ACTUAL=${actual:-NONE}"
if [ -z "$expected" ]
then
  echo "BRANCH_CHECK=FAIL task branch record is empty"
  exit 1
fi
if [ "$actual" != "$expected" ]
then
  echo "BRANCH_CHECK=FAIL checkout does not match the task branch recorded in step 1"
  exit 1
fi
echo "BRANCH_CHECK=OK"
```

Do not rename at push time and do not substitute a plausible prefix after this
fails. Return to step 1 and create or safely check out the recorded branch.

**Write the design note now** — distil the five working files into one, per *The
shape of the deliverable* — and commit it with the code change. A PR that carries
the diff without it ships the half a reviewer cannot check. Commit and push the
recorded task branch — never the target.

**The working files do not go in the commit.** `.workflow-run/` is scratch; the
note is the deliverable. Check before you stage: if the diff contains a file with
raw command output in it, that file is in the wrong place.

**Commit the design note. Do not commit the screenshots.** They are
review material, not source: a few hundred kilobytes each, never diffable, and
permanent once merged. Upload them to the PR and link them, so a reviewer sees
them without the product repository carrying them forever.

**A filename is not a link.** A run that wrote ``RED `red-html-upload.png` ``
into the description had done the hard part — the images existed, they showed
the right thing, and they had correctly stayed out of the commit — and a
reviewer still could not open either one. The description must carry a URL the
attachment upload returned, rendered as an image or a link. Paste the upload
command and its response into the evidence, so "attached" is a fact with a
receipt rather than a claim.

Where the platform cannot take an attachment, say so with the exact command that
failed and give the manual upload step — do not fall back to committing the
binary, and do not leave a bare filename standing in for an image nobody can
reach.

**An image that maps to no acceptance criterion is not evidence and is not
delivered.** A login probe, a "the app is up" shot, a screenshot taken while
finding the right selector — those are working material. Ship the RED and the
GREEN for the criterion, and nothing else.

**Stage by explicit path.** `git add -A` in this repository sweeps up whatever the
suites regenerated — a lockfile rewritten with the same number of lines added and
removed is the usual one, and in a diff it is indistinguishable from a dependency
the feature actually needed.

**Prove the staged set, do not assert it.** Stage, then check what is actually
there against what you meant:

```sh
cd -- '<repo_path>'
git add -- <changed_paths> <design_note_path>
STAGED=$(git diff --cached --name-only | LC_ALL=C sort)
WANT=$(printf '%s\n' <changed_paths> <design_note_path> | LC_ALL=C sort)
if [ "$STAGED" = "$WANT" ]; then echo "STAGE_CHECK=OK"; else
  echo "STAGE_CHECK=FAIL"; echo "--- < declared, > staged ---"
  d=$(mktemp -d) || exit 1
  printf '%s\n' "$WANT" > "$d/want"; printf '%s\n' "$STAGED" > "$d/got"
  diff "$d/want" "$d/got"; rm -rf "$d"; exit 1
fi
```

`LC_ALL=C` so both sides sort the same way whatever the shell's locale is, and
`mktemp -d` rather than `/tmp/<pid>` — a predictable path in a world-writable
directory is a collision at best and a symlink someone else planted at worst.

Do not commit on `STAGE_CHECK=FAIL`. The failure prints the difference both ways,
so an extra path and a missing one read differently.

A run reached this point with a lockfile carrying **4842 changed lines** beside two
lines of production code, plus a file holding the user's own uncommitted debug
flags. Nothing was wrong with its intent — it never ran `git add -A`. The staged
set was simply never compared to the list it had just written down.

Before opening the PR, call
`plan(action='checkpoint', summary=…, next_step='Open the draft PR for the stated
branch, target, requirements source and acceptance evidence', ask_user=true)` and **wait for
approval**. The summary must state the customer outcome, scope mode, delivery
readiness, every approved deferral or unserved requirement, and whether the
acceptance check went RED→GREEN or is missing. Map the buttons: Approve opens that
honestly classified draft; Reject stops here. This PR-opening approval never
retroactively authorizes a partial scope.

Only after approval:

```
az repos pr create … --draft --target-branch <resolved> …
```

Pass `--target-branch` **explicitly**, using the value resolved in step 1 — never
omit it (ADO falls back to the repo default branch) and never re-derive it here.
Before creating the PR, confirm the diff is scoped: `git diff --stat <target>...HEAD`.
A count in the hundreds of files means the target is wrong — stop and say so rather
than opening the PR. Link the work item when one exists.


**Attaching the images: use this call, it is the one that works.** ADO takes PR
attachments over its REST API and nowhere else — `az repos pr attachment` is not a
subcommand and exits 2, and `az rest --method put` without `--resource` answers
`Method Not Allowed`. Both were tried by real runs; each cost a step and one of
them shipped a PR whose images had to be attached by hand.

```sh
token=$(az account get-access-token --resource '499b84ac-1321-427f-aa17-267ca6975798' \
        --query accessToken -o tsv)
base='<collection>/<project>/_apis/git/repositories/<repo_id>/pullRequests/<pr_id>/attachments'
for f in <red>.png <green>.png; do
  curl -fsSL -X POST --oauth2-bearer "$token" \
       -H 'Content-Type: application/octet-stream' \
       --data-binary "@$f" "$base/$(basename "$f")?api-version=7.1-preview.1"
done
```

`499b84ac-1321-427f-aa17-267ca6975798` is Azure DevOps' own resource id; the token
will not work without it. `--oauth2-bearer` sends the same bearer header
`-H "Authorization: …"` would, and is used instead because redaction layers scrub
an explicit `Authorization:` value -- a reviewer reading this file through one
reported the header as `******` and concluded the command could not
authenticate. The flag carries no header text to scrub. A success returns JSON carrying `id`, `displayName` and
a `url` — that `url` is what the description links to. If the POST fails, say so
with the command and its real error, and name the files a human must attach; do
not describe an attachment that is not there.

**A passing check does not go under `Not run`.** That heading means *checks this
repository has and this run did not perform*; a reader who sees a browser RED/GREEN
pair there concludes the browser was never driven. A run put its screenshots there
because this template used to list them there, and the same run's committed design
note said `Local browser check: PASS` — one run, two records, disagreeing. The
images belong under `Visual evidence`; only the failure to obtain them belongs
under `Not run`.

Keep the description at or below **3900 characters**; ADO rejects over 4000.

That limit does not mean cutting evidence — it means each thing goes where it
belongs. The design note carries the conclusions and is committed, so the
description links to it. The images are attachments, so the description links
to those. The coverage ledger is review material for this PR, so it goes in the
description if it fits and becomes an attachment if it does not. The working
files stay in `.workflow-run/` and are linked from nowhere, because nobody
outside this run needs them.

**What never happens is dropping a finding to make the character count work.**
If the description is over, something in it is a transcript rather than a
conclusion — find that and move it, do not delete a gate verdict or a contract
difference to buy room.

**Count it, do not estimate it.** Write the description to a file and measure it
before `pr create` sees it:

```sh
CHARS=$(wc -m < "<description_path>" | tr -d ' ')
echo "DESC_CHARS=$CHARS"
[ "$CHARS" -le 3900 ] && echo "DESC_CHECK=OK" || { echo "DESC_CHECK=FAIL"; exit 1; }
```

`wc -m` counts characters, not bytes — `wc -c` over-counts every non-ASCII
character and will send you trimming a description that fits. Do not open the PR
on `DESC_CHECK=FAIL`.

3900 is not the real ceiling; 4000 is. The hundred characters between them exist
so a description that grows by a line during review still posts. A run that lands
on 3986 has not passed — it has spent the margin and left fourteen characters for
everything that comes next. Every other numeric gate in this recipe is machine-
checked, and those are the ones that hold.

```
### Delivery readiness
<READY | CONDITIONAL | PARTIAL | NOT_READY>
Conditions before merge: <numbered, or "none">

### Summary
<one line: whether the agreed customer outcome is complete>. Refs <work item, or the spec path>.

### Design note
docs/design/<feature-slug>.md — scope, contract differences, implementation, gate verdicts.

### Coverage ledger
<the effect ledger table from step 4a, with its summary block and both check outputs>

### Acceptance mapping
Customer outcome: <one observable sentence>
Scope mode: <FULL_FEATURE | USER_APPROVED_PARTIAL>
Partial approval proof: <proposal path/digest, checkpoint summary, and observed explicit verdict/reply — or none>
Required items served: <ids/lines and evidence>
Approved deferrals: <ids/lines, or none>
Not served: <ids/lines and exact reason, or none>
Requirements audit: <REQUIREMENTS_AUDIT=OK | FAIL>
Customer-outcome review: <CUSTOMER_OUTCOME_CHECK=OK | FAIL>
RED  `<command>` → <the failing assertion, one line>
GREEN `<same command>` → <the passing result, one line>

### Scope of change
<files changed, grouped by what each group does>

### Out of scope but touched
<any file the agreed scope did not require, justified or reverted — "none" if none>

### Implementation
<why this is the smallest change that delivers the agreed customer outcome>

### Validation performed
Command: `<command>`  Exit: <code>
<tail of output>
Baseline unchanged: <before → after, case-level, not just totals>

### Acceptance review
Findings addressed: <one line each, with the fix>
Review findings not addressed: <in the reviewer's words, with why — or none>

### Visual evidence
Local browser check: RED <attachment> / GREEN <attachment> — and what each image shows.

### Not run
<every check that exists in this repo and was NOT run, and why>
Local browser check: if it could not be reached, the exact commands run and their real errors.
e2e (test/e2e_test): not run — targets deployed environments; this branch is not deployed.

### Quality judgment
<does this complete the agreed feature scope; if not, say why it is incomplete>

### Risks
- Blast radius: <files changed, who calls them>
- Reversibility: <how to undo>
```

**`Delivery readiness` is not the plan's status.** Finishing every workflow step
does not complete the feature. Use these meanings exactly:

- `READY`: the full source-defined scope is implemented and proven.
- `CONDITIONAL`: implementation is complete; only named external or human proof
  remains. It never hides missing code.
- `PARTIAL`: the user explicitly approved the exact persisted proposal before
  implementation, and `design.md` carries its digest, summary, and approval proof.
  It is an incremental PR, not completion of the work item.
- `NOT_READY`: required behavior is missing, failed, or unproven without a valid
  `CONDITIONAL` boundary. Do not recommend normal merge as feature completion.

The PR-opening checkpoint authorizes creating the classified draft; it does not
change the classification.

**`Not run` is mandatory and must be honest.** If you ran one test file, say so and
list the gates you skipped. Writing "all tests pass" when you ran a subset is a
false report and is worse than saying nothing.

**`Quality judgment` is your own assessment, not a restatement of the results.**
Say what you would not yet rely on. Evidence for only an entry point never supports
a claim that the feature is complete.

Record the PR URL in the item's evidence. A local branch or drafted PR text is not
a deliverable — only a real PR URL is.

#### Hand off

Mark the Plan complete, but make the **first line** exactly one feature status:

- `Feature complete — READY`
- `Feature implemented — CONDITIONAL`
- `Feature incomplete — USER-APPROVED PARTIAL`
- `Feature incomplete — NOT_READY`

Then give the PR URL, customer outcome, RED/GREEN evidence, design-note path,
approved deferrals or unserved requirements, checks not run, and the human's next
action. A `PARTIAL` PR must not close the full work item; a `NOT_READY` PR must not
be recommended for merge as feature completion. Even when every Plan item ran,
**never say `Completed the workflow`** instead of the feature status and **never
recommend `review/merge normally`** for `PARTIAL` or `NOT_READY`.
Then stop. Do not poll CI, do not wait for review comments, do not start another
cycle.
