---
name: implement-societas-feature
description: Implement a Societas feature end-to-end from a spec or ADO work item through requirement analysis, dev design, a test plan, before/after evidence, and a verified draft PR.
plan: true
metadata:
  # First-turn routing (loop_v2._match_workflow_recipe). These name the recipe's
  # SUBJECT, never the execution verb — the injected note is neutral and the model
  # judges intent from the full turn (loop_v2._recipe_route_block). Matching too
  # narrowly is the expensive direction: a false positive costs one neutral note,
  # a false negative costs an uncontrolled run.
  #
  # No \b around 'societas' or the CJK alternatives: Python treats CJK as word
  # characters, so \bsocietas fails to match inside '这个societas feature'.
  #
  # Deliberately distinct from fix-societas-bug: that recipe matches
  # bug/缺陷/问题/故障 near 'societas'. These match feature/功能/需求 and ADO work
  # item references instead, so a bug report never routes here.
  activation:
    keywords:
    - societas feature
    patterns:
    - "(?i)societas[^\\n]{0,16}(?:features?|功能|需求|user story)"
    - "(?i)(?:features?|功能|需求|user story)[^\\n]{0,16}societas"
    - "(?i)societas[^\\n]{0,24}AB#\\s*\\d{4,}"
parameters:
# The feature's requirements come from EITHER a spec file in the repository OR an
# ADO work item. Neither can be `required` on its own — that would make the other
# impossible to use — so they share a `required_group`: each stays optional, and
# the group is what the call must satisfy. This used to be prose here and a
# refusal in step 1, which meant a run with neither could start, notify, and
# spend ninety seconds before saying it had no requirements.
- name: spec_path
  type: string
  required: false
  required_group: requirements
- name: feature_id
  type: string
  required: false
  required_group: requirements
- name: repo_path
  type: string
  required: false
- name: target_branch
  type: string
  required: false
limits:
  allowed_tools:
    - shell
    - plan
    - tools
    - config_praestoclaw
    # browser is granted so a UI-observable criterion can be proved on the surface
    # a user sees. Without it the "capture a screenshot" instruction below is dead
    # text: allowed_tools is a hard gate (loop_v2 blocks the call and logs
    # tool_blocked_by_allowlist), and a tool absent from the palette never even
    # appears in the model's tool schema, so the run cannot try and cannot report
    # that it failed to try.
    - browser
    # spawn is granted for ONE purpose: the acceptance review. Use it only with
    # agent="explorer" in serial mode — that spawn assesses as a deterministic
    # RiskScore(2), and it is the ONLY shape the workflow-scoped auto-approval
    # admits (hooks/handlers.py::_workflow_scope_admits). Every other agent name
    # and every non-serial mode falls through to the normal approval gate, where
    # an unattended run has nobody to answer.
    # This comment used to claim the fall-through was automatic. It was not:
    # scoped auto-approval matched on the tool NAME alone, so `spawn(agent=
    # "default", mode="background")` was allowed exactly as readily as the review
    # below — and the child kept the default agent's whole palette. That is now a
    # code-enforced narrowing rather than a promise made in a comment.
    # explorer is also read-only, which is what makes it a reviewer rather than a
    # second implementer. The child is additionally capped by THIS allowlist
    # (spawn.py forwards `workflow_allowed_tools`), so a tool absent from this
    # list is absent from the reviewer's palette too.
    - spawn
    # The reviewer's own palette. It is spawned as `explorer`, whose tools are
    # exactly these three, and the child is capped by THIS list — so omitting them
    # hands the reviewer zero tools and it silently reviews nothing. They reach only
    # PraestoClaw's workspace (Sandbox.resolve_path), which is precisely why the
    # acceptance review writes the diff there before spawning.
    - read_file
    - list_dir
    - search_files
  # NOTE: agents.default.budget.max_iterations (default 90) is a PER-STRETCH
  # budget, not the run's ceiling — Runtime._run_workflow_session re-invokes
  # run_once with a fresh budget while the plan is non-terminal, up to
  # _WORKFLOW_AUTO_CONTINUATION_LIMIT = 3. What ends a run early is
  # runtime.py::_plan_is_terminal: plan complete, ANY item `blocked` WITH evidence,
  # or
  # an unresolved approval checkpoint. See the Budget section.
  max_runtime: 3600
  max_output: 20000
concurrency:
  max_instances: 1
  key_parameters: [spec_path, feature_id]
---
Implement a Societas feature end-to-end, from its requirements through a **draft
pull request**, producing a reviewable artifact at every phase.

Parameters — **an empty value means that parameter was not supplied**, and step 1
resolves what to do about it. Never read an empty value as a real one:

- spec / PRD file inside the repository: `{spec_path}`
- ADO work item id: `{feature_id}`
- repository path: `{repo_path}`
- PR target branch: `{target_branch}`

Exactly one of the first two carries the requirements. The last two fall back to
configuration.

This is an authorized internal development workflow on the team's own Societas
repository.

## What this run must leave behind

Every phase writes its output **to a file, immediately**, before moving on. This is
not bookkeeping: it is what makes a run that runs out of wall clock still worth
something, and it is the only way a later phase can be re-done without re-doing the
whole run.

These are **working files**, written under
`<repo>/.workflow-run/<feature-slug>/` — a scratch directory that is **not what
ships**:

| File | Written by | Contains |
|---|---|---|
| `requirement-analysis.md` | step 2 | what is being asked, user flows, the acceptance criteria verbatim, what the spec does not answer |
| `design.md` | step 3 | **≥2 options with the reason for the choice**, the end-to-end path, the file list |
| `test-plan.md` | step 4 | the effect ledger, the executable checks, and the e2e cases for the deployed environment |
| `evidence-before.md` | step 6 | the checks run **against unmodified code**, with their real output; the browser RED |
| `evidence-after.md` | step 8 | the same commands after the change, with their real output; the browser GREEN |

**What ships is one document, and it is not these five.** Step 10 distils them
into a single design note that follows what the repository already does with
design notes — see *The shape of the deliverable* below. The five stay behind:
they are how a run survives being interrupted and how a later phase gets re-done
without redoing the whole run, and they are also, unavoidably, full of raw
command output that belongs nowhere near a product repository.

The distinction is not tidiness. A previous run committed all five, including an
`evidence-after.md` of **3789 lines, 3197 of them over 200 characters**, against
a production change of **two lines**. Nothing in that file was false. It was
still the wrong artefact: a reviewer cannot read it, and the repository now
carries a transcript of one afternoon forever.

### The shape of the deliverable

**One design note, in the directory the repository already keeps design notes
in, written the way the notes already there are written.** Before writing it,
read two of them — `ls docs/design/` and open the two closest to your change.
Match what you find; the paragraph below describes what those notes look like
today, and the files win if they have moved on.

They are single files of a few hundred lines. They explain the flow and the
implementation. **They contain no command output at all** — a representative one
carries zero lines over 200 characters. Nobody has ever pasted a test log into
one, and the reason is worth stating: a repository stores how the thing works,
not what happened on the afternoon it was built.

So the note carries the conclusions and drops the transcripts:

| Section | From | What survives |
|---|---|---|
| Summary | step 3 | what shipped, and the size of the production change |
| Contract differences | step 4 | where intent, spec and code disagree — often the most valuable lines, and invisible in the diff |
| Scope | step 3 | the criterion served, and every deferred one with its reason |
| Implementation | step 7 | the path through existing code, file by file |
| Verification | steps 6/8 | **one line per gate**: `<gate>: PASS / FAIL / BLOCKED — reason`, and what the RED and GREEN images show |
| Not covered | steps 4/8 | what needs a deployed build, a decision, or an owner |

**A gate's line is its verdict, not its output.** "`pnpm build`: PASS" is the
whole entry. If it failed and you fixed it, that is one more line, not the log
of both runs.

The coverage ledger from step 4a is evidence for **this** review, not
documentation of the feature — put it in the PR description, or attach the
working file. It does not belong in a design note that outlives the PR.

**Keep the scratch directory out of Git yourself.** It is untracked when you
create it, and untracked is enough as long as staging is by explicit path, which
step 10 requires. Do not add it to the repository's `.gitignore`: that file is
shared with everyone, and this workflow does not get to edit a product repo's
conventions to suit its own bookkeeping. If you find `.workflow-run/` in
`git status` at commit time, that is the expected state — stage around it.

**A phase is not finished until its file exists on disk.** Say the path in your
progress note. If the run ends early, the last written file is the handoff.

**When an artifact from an earlier run is already there, correct it — do not only
append.** A reused branch often carries a previous run's files, and their
conclusions were true for that run, not this one. An appended "Addendum" leaves
the stale sentence sitting above it, so a reader meets the wrong answer first and
only learns better if they keep going. Rewrite the sentence that is now false,
then add what is new. If you want the history preserved, mark the old line
explicitly as superseded and say by what — never leave two live claims that
contradict each other.

## Execution guardrails

- **Callout contract** — the ONLY way to stop this run and hand the decision back
  to the user. Every "stop", "pause and ask", "escalate", or "blocked" instruction
  below means exactly this, and nothing else counts:
  1. `plan(action='update', id='<current item id>', status='blocked', evidence='<what you tried, the exact blocker, the missing prerequisite>')` — `id` and a
     **non-empty `evidence`** are both required; a blocked item with empty evidence
     does not stop the run. Where the item sits in the list no longer matters: the
     runtime scans every item, so a Callout recorded on a later item is not hidden
     by an earlier one still being open.
  2. Put the question to the user in the **same reply**. A question in the reply
     alone is not a stop — the runtime cannot see it and will drive the run again.

  **An evidenced Callout is a successful outcome of this run, not a failure.** A run
  that stops with a concrete blocker and hands the user a real decision has done its
  job; a run that manufactures evidence to reach the PR has not. Never prefer
  inventing data, a stand-in test, or a synthetic screenshot over stopping here.
  What keeps this honest is the evidence: a Callout must name the concrete paths you
  actually tried, each with its command and its real output. Stopping on the first
  obstacle without trying anything is not a Callout.

- **The task repository is outside PraestoClaw's workspace boundary.** `read_file`,
  `search_files`, `list_dir`, `edit_file` and `write_file` are workspace-scoped and
  will return `BLOCKED: Path escapes workspace` for every path under the Societas
  checkout — they are not granted here for that reason. Perform **all** repository
  reads, searches, edits and Git operations through `shell` commands rooted in
  `<repo_path>`.

- **Read whole files with `cat`. Search with `rg`. Never page with `sed -n`, and
  never read with a `python - <<'PY'` heredoc.** A heredoc is for *writing*
  something a patch cannot express, never for reading. Paging a file in windows is
  how a comparable run spent 67 of 78 tool calls opening one file 32 times and died
  having written nothing: `rg -n -C4 '<symbol>'` locates, `cat <file>` reads it
  once. If you find yourself opening the same file a second time, you did not read
  it properly the first time.

- **Work in place, in `<repo_path>` itself. Create a branch; never create a
  worktree, a clone, or a copy.** `git worktree add` shares `.git` but not the
  ignored working tree, and in this repository the ignored working tree is what
  makes the code runnable: `backend/.venv` (1.3 GB), `frontend/node_modules`
  (1.1 GB), root `node_modules`, plus `backend/.env` and `frontend/.env.local` —
  configuration you cannot author. A fresh worktree therefore has no runnable
  backend, no runnable frontend, and no way to produce the before/after evidence
  this run exists to capture; the setup alone would consume the wall clock.
  `<repo_path>` already has all of it.

  If the checkout is dirty, that is not a reason to relocate. Read the next
  guardrail: pre-existing changes are user-owned state you work alongside, and a
  conflict in a file your slice needs is a Callout, not a reason to build a second
  tree somewhere else.

- Read the repository's own instructions (`AGENTS.md` / `CLAUDE.md` for the
  directories you touch) before changing Git state. Use exactly one task checkout
  and one feature branch for the entire run. Reuse an existing task-specific
  branch when it already contains valid work; never create `v2`/`v3` variants
  merely to obtain a globally clean status.

- **Generated and lock files the run did not deliberately change are not part of
  the slice.** Running the test suites is enough to rewrite a lockfile in place;
  such a diff is usually pure churn (the same line count added and removed) and
  says nothing about the feature. Stage by explicit path, never `git add -A` or
  `git add .`, and if a lockfile appears in the staged set, either justify the
  dependency change in the PR or leave it out of the commit.

- Record the initial `git status --short`. Treat unrelated pre-existing changes,
  generated files, and Git LFS materialization noise as user-owned state: do not
  reset, restore, clean, stage, or delete them. Judge this task with path-scoped
  status/diffs for the files it actually changes. If a target file was already
  modified before the task, stop via the Callout contract instead of overwriting it.

- **Never push to the target branch. Never merge.** Merging is a human action.
  Open the draft PR and stop.

- Use syntax native to the current shell. On Windows PowerShell, root commands with
  `Set-Location -LiteralPath '<repo_path>'; ...`, use `$null` instead of
  `/dev/null`, and `Get-Content -Tail <n>` instead of `tail`. On POSIX, use
  `cd -- '<repo_path>' && ...`. Never send bash-only syntax to PowerShell. In
  PowerShell interpolated strings, delimit a variable before `:` or a URL query as
  `${path}:...` or `${buildId}?api-version=...`; PowerShell does not use `\"` to
  escape double quotes — use single quotes or a single-quoted here-string.

- Omit shell's `directory` argument. `directory="workspace"` is a shorthand for
  PraestoClaw's OWN workspace root — not this task's repo, which is outside it — so
  it never targets the right place; use `cd -- '<repo_path>' && ...` instead.

- **Do not repeat an identical command.** The loop detector warns on the third
  identical tool call and terminates the run on the fourth.

- Load at most one phase-specific skill at a time. During pickup, load only
  `azure-cli-check`. Load `pr-workflow` only after the acceptance check passes.
  Do not load `ado`: this recipe owns the work-item phase.

## Budget

**The limit that ends your run is wall clock, not turns: 60 minutes**
(`execution.background_task_timeout_seconds`). When it expires the task is killed
wherever it stands — no PR, no hand-off, and the checkout left dirty.

Turns are the looser limit. You get about **90 per stretch**, and when a stretch
runs out the runtime hands you a fresh 90 and lets you carry on, up to three times
(`_WORKFLOW_AUTO_CONTINUATION_LIMIT = 3`). **Continuations grant turns, never
time.** Four stretches at 20 minutes each is 80 minutes against a 60-minute clock,
so they are slack for one stretch that overruns, not capacity you can plan to use.

Take the clock's measure yourself: run `date -u +%H:%M:%S` when you create the
plan, record it in the Pick up evidence, and check it again at each phase
boundary. If you are 20 minutes in and have not made a substantive edit, the slice
is too big — cut it down rather than continuing to survey.

**What ends the run early is you.** After each stretch the runtime asks whether
the plan is terminal and stops if the plan is complete, an approval checkpoint is
unresolved, or **any item is `blocked` and carries evidence**. So marking
the step you are on `blocked` because you are running low on turns **forfeits every
remaining continuation**. When a stretch runs low, leave the item `in_progress`,
write a short note saying where you are, and let the turn end — you will be resumed
with a full budget and the same checkout. Reserve `blocked` for an obstacle you
cannot resolve at all.

**Ask for several files in ONE turn.** The budget counts *turns*, not tool calls:
a turn carrying four `cat` calls costs exactly what a turn carrying one costs, and
independent calls in a turn execute concurrently. A measured run on another
repository spent 83 of its 112 turns issuing a single tool call — the same work
batched four at a time is roughly a third of the turns. Request the producer, the
contract, the consumer and the test together; do not read one, think, read the
next.

Spend the time roughly like this. Nine steps, sixty minutes, and the front half has
to stay cheap:

| By minute | Step | You should have |
|---|---|---|
| 8 | 1–2 | repo + target branch + source resolved; `requirement-analysis.md` written |
| 18 | 3 | slice chosen, code path located, deliverability test passed, `design.md` written |
| 25 | 4 | `test-plan.md` written and the acceptance check exists |
| 32 | 5 | app running and authenticated — a browser can reach it |
| 37 | 6 | `evidence-before.md` written — **the RED is captured, browser RED included** |
| 48 | 7–8 | implementation done, `evidence-after.md` written — the GREEN is captured |
| 60 | 9–10 | acceptance review, PR, hand-off |

**The RED at minute 37 is the checkpoint that matters.** Reach it and every later
phase has something real to stand on; miss it and the run produces a diff nobody
can trust. If minute 37 arrives and the RED is not captured, the slice is too big
— cut it rather than pressing on.

**Steps 5 and 6 share one running app.** Bringing it up costs a few minutes once;
starting it twice, or starting it only for the GREEN, costs the whole point of
having it.

The five working files are written as you go, so a run that dies at minute 50
still leaves four of them for the next attempt. **That only holds if you write
each file when its phase ends**, not in a batch at the end.

## Steps

### 1. Pick up

Resolve the repository **without searching the filesystem**. Prefer the explicit
`repo_path`; otherwise read `agents.default.metadata.ado_repo_local_path` — enable
the tool once with `tools(name="config_praestoclaw")` if needed, then
`config_praestoclaw(action="show", path="agents.default.metadata")`. Do not grep
config files, logs, or `sessions.db` for this value. `config_praestoclaw` is
**hard-blocked in a scheduled/cron run**, so a scheduled invocation MUST pass an
explicit `repo_path`.

If both are empty, do not guess and do not ask across turns — stop on the **first**
turn via the Callout contract, naming both sources and the two ways to supply the
value (set `agents.default.metadata.ado_repo_local_path`, or re-run with an
explicit `repo_path`).

**Resolve the PR target branch in this same step and never guess it.** It is
`agents.default.metadata.ado_pr_target_branch`, read from the response you already
fetched (or passed explicitly as `target_branch`). If neither is set, **stop here
via the Callout contract** and tell the user to configure it — do NOT fall back to
`main`, `master`, `dev`, the repo's default branch, or the branch the checkout
happens to be on. This repository's integration branch is not the one a
general-purpose guess produces: a run that assumed `main` opened a PR carrying
**717 files and +80665 lines** of unrelated drift, because the real target was
`dev` and `dev` was long ahead of `main`. Quote the resolved value verbatim from
the metadata and record it in the evidence.

In that same command, record `date -u +%H:%M:%S`, the initial `git status --short`,
and any task-named branches with their HEAD commits, so a reusable prior attempt is
found before you fetch broad context.

**Reusing a prior attempt is a convenience, never an obligation.** If checking one
out would touch anything in that initial status, do not check it out and do not
try to make it checkoutable — **start a fresh branch from the resolved target
branch and say in the evidence which prior branch you passed over and why.**

This is the shape it takes, and it stopped two runs dead in one morning: a prior
task branch is based on a `dev` from weeks ago, so switching to it rewrites every
file `dev` has moved since — including one the user is holding uncommitted local
changes in, for something entirely unrelated to this feature. Git refuses, and it
is right to. Stashing, resetting, restoring or committing on the user's behalf to
clear the way are all forbidden, so an attempt to reuse that branch has nowhere
left to go and burns the run on a Callout that had a perfectly good alternative
sitting next to it.

Starting fresh is also usually the *better* choice here, not merely the available
one: a prior attempt's branch may carry that attempt's design note, and step
4a is not allowed to read a previous run's test plan. Checking it out puts the one
document that would contaminate the enumeration directly under the working
directory.

#### Resolve the requirements source

The feature's requirements come from **one** of two places, and this step decides
which **before** fetching anything. Do not go looking for a second source once one
has answered.

- **`spec_path` is set** — read that file whole, once. It is the requirements.
  **Do not query ADO at all**, and do not treat a work item id mentioned inside the
  spec as a reason to fetch one.
- **`spec_path` is empty and `feature_id` is set** — check Azure CLI auth, then
  fetch the work item **once**:

  ```
  az boards work-item show --id {feature_id} --detect true --expand all -o json
  ```

  That response is the source for the description, acceptance criteria and
  relations. Query comments/attachments separately only when the work item
  explicitly says they carry the acceptance detail. Do not enumerate unrelated
  work-item history.
- **Both empty** — stop on the **first** turn via the Callout contract, naming both
  parameters. Do not search the repository for something that looks like a spec.

Record which source you used and its path or id. Every later phase quotes from
**that one source**; a criterion that appears in neither is invented.

Derive `<feature-slug>` from the spec filename or the work item title —
lowercase, hyphenated, no dates — and create
`<repo>/.workflow-run/<feature-slug>/`. Every working file goes there.

### 2. Understand the requirement

**One reading pass over the source**, producing `requirement-analysis.md`. This
phase reads and writes; it does not touch code and does not decide anything.

Cover exactly this, and nothing else:

- **The problem** — whose problem, and what they do today instead. One paragraph,
  from the source's own words.
- **User flows** — the journeys the feature must serve, each as a numbered
  sequence of user-visible steps. Name the surfaces (page, dialog, entry point) the
  source names.
- **In scope / out of scope** — copy the source's own non-goals verbatim. A spec
  that says what it will *not* do is telling you where a slice may not wander.
- **Acceptance criteria, verbatim.** Every one of them, in the source's own words.
  Do not paraphrase — a paraphrase is where an implementation quietly drifts from
  what was asked. For each, note what a **user could observe** that proves it. A
  criterion whose only evidence is "the code now contains X" is not an acceptance
  criterion; find what behaviour it produces, or record that the source does not
  say.
- **What the source does not answer** — the questions an implementer would have to
  guess at. List them. **Do not answer them here**, and do not treat a gap as
  permission to invent; step 3 decides whether a gap blocks the slice you pick.

A rich spec states requirements at several strengths — "must", "should", "best
effort", "P0", "P1". **Preserve that ranking exactly.** Flattening "best effort"
into a requirement is how a slice grows; promoting a P1 into the slice is how a run
spends its budget on something nobody asked for this release.

Do not restate the whole spec. If your analysis is longer than the section of the
source it covers, you are copying, not analysing.

If the source names no criterion you can verify at all, stop via the Callout
contract and ask for one. Do not invent acceptance criteria from the title.

### 3. Design

One phase, one artifact: `design.md`. It answers *which* criterion and *how*, in
that order, and it is the phase this workflow has been missing. In six earlier
evaluation runs, five of the failures were decided here — invisibly, mid-run, with
no artifact anyone could correct. As a file it is reviewable in minutes instead of
discovered in a PR forty minutes later.

Work through it in four passes. Do not write `design.md` until all four are done —
pass 3 can send you back to pass 1.

#### Pass 1 — choose the thinnest slice that makes ONE criterion actually pass

**The unit of work is an acceptance criterion, not a layer.** Pick the criterion
that produces the **behaviour a user can observe** and implement everything needed
to make it true, however many packages or languages that touches.

**Choose the criterion by observability, not by cost.** These are never reasons to
pick a different one:

- "it spans two components, two languages, or two toolchains"
- "the other half is a separate concern, follow-up work, or someone else's layer"
- "this one is cheaper, safer, or easier to test"
- "the plumbing must land first"

If the only criteria you can serve produce **no user-visible change**, you have not
found a deliverable slice. Say so and stop — do not ship the plumbing and call it a
slice.

**Then make it as thin as possible *within* that criterion. Vertical, not wide:**
one path end to end, not every path. Defer the *other* criteria freely — that is
what deferral is for. **Never defer a *layer* of the criterion you picked**; that
is what leaves a half-feature that cannot be demonstrated.

Stop and ask (Callout) only when the criterion needs a material change to a public
contract, a storage or schema shape, a permission boundary, or a dependency — or a
product decision the source does not answer. **Size alone is never a reason to
stop**; it is a reason to pick one criterion instead of several.

#### Pass 2 — locate the owning code path

Use one targeted `rg` search, `cat` the directly implicated files whole, and
inspect relevant git history once. Stop when you can name, with `file:line`:

- where the behaviour must be produced;
- the neighbouring implementation you will copy as a pattern;
- the test file you will extend, and the command that runs it.

Do not map the surrounding subsystem for completeness. If you cannot produce
`file:line` for the first of these, you have not finished this pass.

#### Pass 3 — the deliverability test

1. **It can be proven by something you did not write.** The slice must admit at
   least one assertion whose input is *produced by the system*, not authored by
   you. A hand-written fixture fed to your own new code proves only that it agrees
   with itself.

2. **Both ends of any contract exist.** If your slice reads a field or event
   something else is supposed to emit, confirm a real producer exists first. **Do
   not grep for the field name** — that answers "does this string appear", not
   "does anything emit it into this payload". Search for the payload's own
   discriminator, and **keep the quoting optional** — languages in one repository
   disagree about it, and a strict pattern silently reports "no producer":

   ```
   rg -n --pcre2 "['\"]?<key>['\"]?\s*:\s*['\"]<payload type>['\"]" <source root>
   ```

   Hardcoding double quotes has failed this check twice on another
   repository: the strict form found 2 construction sites where the permissive
   form found 14. Open every site and read what it sets. Also check **what gates
   each producer** — a site that sets your field but only runs behind a flag does
   not fire in your acceptance scenario.

3. **Cite what you claim exists.** Every "X already does Y" needs `file:line`.

4. **Your own output must fire in the acceptance scenario.** Trace the whole path,
   not just the first gate, and confirm the data source can carry every field the
   result needs. A producer emitting into a payload nobody renders delivers nothing.

If any check fails, the slice is wrong and must be re-chosen — go back to pass 1.
It is not a deferral, and it is not something to note in `design.md` and proceed
past.

#### Pass 4 — write `design.md`

1. **The criterion served**, verbatim.
2. **At least two options, with the reason for the choice.** Not a token
   alternative written to satisfy this instruction — two approaches you would
   actually defend, each with what it costs and what it forecloses. If you truly
   see only one, say why the obvious alternatives are unavailable **here, in this
   codebase**; "there is only one way" is almost never true and is usually a sign
   the slice is drawn wrong.
3. **The chosen end-to-end path**, one `file:line` per hop, from where the change
   originates to where a user observes it.
4. **The file list** — every file to be changed, and one line on what changes in
   each.
5. **What this design deliberately does not do**, and which criteria that leaves
   unserved.

Follow the conventions already in the directories you named — copy the
neighbouring implementation you identified in pass 2. A design that introduces a
new pattern where an existing one fits is a design that will fail review.

**Where the design turns on a product decision the source does not answer**, do not
pick silently. Name the decision, state both options and your recommendation, and
raise a Callout. This is the one place in the run where stopping is cheap: nothing
has been built yet.

### 4. Test plan

This phase has **two sub-phases with different evidence rules**, and running them
as one is what produces a plan that only restates what the existing tests already
cover. **4a enumerates from production code. 4b decides how much of that gets
executed.** No production code is written in either.

#### 4a. Enumerate the effect surface, from production code only

Derive what the feature can do from the code that implements it, never from a
journey someone already wrote down. The model is:

```
User trigger
-> production handler
-> state change, response, or event
-> every UI consumer that reads that state
-> observable UI effects
```

**Evidence allowed in 4a:** the work item or spec, product requirement and design
documents, and current production code -- routes, components, controllers,
handlers, hooks, state stores, feature flags, i18n strings, APIs, services, and
UI-facing persistence.

**Evidence forbidden in 4a:** anything under `test/`, `tests/`, `e2e/`,
`e2e_test/`; `*.test.*` and `*.spec.*`; fixtures, snapshots, golden data; and
**any existing test plan, coverage document, or test report -- including one a
previous run of this workflow produced.**

That ban has exactly one purpose: an inventory derived from existing tests
inherits the blind spots those tests already have. 4b reads the testing docs for
*procedure*; 4a must not read them for *behaviour*. Nothing enforces this at the
tool layer, so it is on you.

**Anchor the inventory on what a user can trigger, never on what the backend can
do.** Backend capabilities are the trap that hides cases, because UI-only actions
have no backend entry at all -- language switch, theme, sign-out, keyboard
shortcuts, drag-reorder, hover reveals. Enumerate triggers, not operations.

Three sweeps are mandatory. Each is an `rg` over production code, and each finds a
class the one before it is structurally blind to:

1. **Handler sweep.** Label-based enumeration finds buttons, menu items, links,
   tabs and fields -- anything carrying visible text, an i18n key or a route. It
   cannot see behavioural triggers. Search the code you touch, and the components
   that render it, for `onKeyDown`, drag handlers, `onWheel`, `onPaste`,
   hover-reveal, and **`onBlur`/`onFocusOut` that commit state** -- committing on
   defocus is a different effect from the click that opened the editor.
2. **Real-time consumer sweep.** Where the product pushes state -- SSE, WebSocket,
   subscribe, polling -- a second actor mutating while the local UI reflects it
   live is its own effect, and it never substitutes for the first-actor flow.
3. **Shared reactive data sweep.** For every write, find every *other* rendered
   surface that reads the same value. This is the class both sweeps above miss:
   adding a row must also enable Undo; a batch commit must produce exactly one
   history revision; a cell's text must be identical in the grid and in the
   detail drawer.

Scope all three to the surface this feature reaches, plus the global chrome it
touches -- not the whole product.

**Record every effect in a ledger**, one row each:

```
Effect ID | UI effect | Required operation | Case ID | Coverage status | Evidence | Exercised by
```

`Evidence` is a `file:line` in production code -- where the effect comes from.
`Coverage status` is exactly one of `COVERED_MAIN`, `COVERED_BRANCH`,
`COVERED_ADDITIONAL_CASE`, `CAPABILITY_GAP`, `OUT_OF_SCOPE`, `UNRESOLVED`.

**`Exercised by` is what ran**, in three parts, and it is filled in when the check
actually runs -- step 6 for the RED, step 8 for the GREEN:

```
<test identifier>; exit <n>; inputs <the values the test actually used>
```

A row whose status starts with `COVERED_` and whose cell is missing any of the
three fails the check below. Only those three are read, and anything after them
is ignored -- so listing several inputs the obvious way, `inputs a.java; b.sh`,
is not a format error. `CAPABILITY_GAP` carries `NOT_EXERCISED - <reason>`
instead. `OUT_OF_SCOPE` carries nothing, because nothing was owed.

The third part is not decoration. A previous run marked "removing a selected
**Java/Shell** attachment" as covered by an existing test whose first line reads
`new File(["test content"], "test.txt", ...)` -- a real, passing test that never
saw a Java or Shell file. Naming the inputs is what makes that visible in the
table instead of three files away.

Five rules keep the ledger honest:

- **Do not finish 4a with anything `UNRESOLVED`.** Investigate it, raise it via the
  Callout contract, or classify it honestly as a capability gap or a justified
  exclusion. Dropping it silently is the one thing that is not allowed.
- **A deferral is valid only if its target exists.** "Covered by the X case" is
  `UNRESOLVED` until X is a row in this ledger. An unverified punt is the most
  common way an effect disappears.
- **Optional, advanced, developer-facing, post-completion, or absent from the happy
  path are not reasons for `OUT_OF_SCOPE`.** If the target code path enables,
  populates or reveals it, it gets a case or an explicit non-covered status.
- **"The same handler" is a design argument, not a test result.** Two triggers
  reaching one function is a reason to *expect* a case to pass; it is not that
  case having passed. A row that reasons its way to `COVERED_BRANCH` without an
  `exit <n>` is claiming a result nobody obtained. Either write the case and run
  it, or set `CAPABILITY_GAP` with `NOT_EXERCISED - <why it is not worth one>`.
  Both are honest; only one of them is true.
- **An existing test covers an effect only if it ran with the effect's own
  input.** Reusing a passing test is legitimate and often right -- reusing it for
  an input it never received is not. If the effect is about `.java` and the test
  feeds `test.txt`, the test proves something else. Say what it fed, in the
  `inputs` field, and let the mismatch show.

Record a **contract-difference** entry wherever intent, spec and code disagree --
for example, "the work item names a file-type picker; `rg` finds no such control in
production, only a hard-coded accept list at `X.tsx:NN`". This is often the single
most valuable line in the document, because it is the one a reviewer cannot get
from reading the diff.

Open the plan with this summary, so the case set is traceable to the method that
produced it. **The first line after the stamp names what the counts are counting**
— an effect surface is always the surface of *some* scope, and left unstated a
reader supplies the widest one available:

```
repo-to-fsq-goal v1.4.0 (adapted)
Scope: <the one criterion step 3 selected>. The other <N> acceptance criteria in
the spec are deferred with reasons in design.md; the counts below cover this
slice's code surface only.
[UI Effect Coverage Summary]
- Total relevant effects: <N>
- Covered in main case: <N>
- Covered in branches: <N>
- Covered in additional cases: <N>
- Capability gaps: <N>
- Justified out of scope: <N>
- Unresolved: 0
```

**Recompute that block; never count by hand.** A miscount is invisible: the six
numbers can sum to the right total while misattributing between buckets, so the
document self-checks clean while over-reporting coverage. Run this against the
plan file and paste its output into the step's evidence verbatim:

```awk
awk -f- test-plan.md <<'AWKPROG'
BEGIN{FS="|";K["Total relevant effects"]="TOTAL";K["Covered in main case"]="COVERED_MAIN"
K["Covered in branches"]="COVERED_BRANCH";K["Covered in additional cases"]="COVERED_ADDITIONAL_CASE"
K["Capability gaps"]="CAPABILITY_GAP";K["Justified out of scope"]="OUT_OF_SCOPE";K["Unresolved"]="UNRESOLVED"
split("COVERED_MAIN COVERED_BRANCH COVERED_ADDITIONAL_CASE CAPABILITY_GAP OUT_OF_SCOPE UNRESOLVED",A," ")
for(i=1;i<=6;i++)V[A[i]]=1
for(t in K)L[K[t]]=t}
/^[ \t]*- [A-Za-z ]+: *[0-9]+ *$/{l=$0;sub(/^[ \t]*- /,"",l);v=l;sub(/:.*/,"",l);sub(/^[^:]*: */,"",v);gsub(/ /,"",v)
if(l in K){C[K[l]]=v+0;S[K[l]]=1};next}
/^[ \t]*\| *E[0-9]+ *\|/{r++;id=$2;cid=$5;st=$6;ex=$8
gsub(/^ +| +$/,"",id);gsub(/^ +| +$/,"",st);gsub(/^ +| +$/,"",ex);n[st]++
if(!(st in V)){printf "UNKNOWN-STATUS: %s carries \"%s\", which is not one of the six\n",id,st;b++}
if(st=="OUT_OF_SCOPE"&&match(cid,/L[0-9]+-C[0-9]+/))
{printf "CONTRADICTION: %s is OUT_OF_SCOPE yet a case was written for it (%s)\n",id,substr(cid,RSTART,RLENGTH);b++}
if(st ~ /^COVERED_/){if(ex==""){printf "MISSING-EXERCISE: %s claims %s with an empty Exercised-by cell\n",id,st;b++}
else{np=split(ex,P,";");for(i=1;i<=np;i++)gsub(/^ +| +$/,"",P[i])
if(P[1]==""||P[1]~/^exit /||P[1]~/^inputs /){printf "NO-TEST-ID: %s names no test identifier before the first \";\"\n",id;b++}
else{if(P[2] !~ /^exit [0-9]/){printf "UNEXERCISED-CLAIM: %s claims %s with no \"exit <n>\" as its second field -- an argument is not a result\n",id,st;b++}
if(P[3] !~ /^inputs [^ ]/){printf "NO-INPUTS: %s names no \"inputs <...>\" as its third field -- a test that never saw the input does not cover it\n",id;b++}}}}
if(st=="CAPABILITY_GAP"&&ex !~ /NOT_EXERCISED[^A-Za-z0-9]+[A-Za-z0-9]/)
{printf "MISSING-EXERCISE: %s is CAPABILITY_GAP without a reason after NOT_EXERCISED\n",id;b++}}
END{printf "LEDGER_ROWS=%d\n",r
if(r==0){print "NO-ROWS: no ledger rows matched -- is the table present?";b++}
if(!S["TOTAL"]){printf "MISSING-LINE: %s\n",L["TOTAL"];b++}
for(i=1;i<=6;i++){k=A[i]
if(!S[k]){printf "MISSING-LINE: %s\n",L[k];b++;continue}
if(n[k]+0!=C[k]+0){printf "MISMATCH: %s -- summary %d, ledger %d\n",k,C[k]+0,n[k]+0;b++}}
if(S["TOTAL"]&&C["TOTAL"]+0!=r){printf "MISMATCH: Total -- summary %d, ledger %d rows\n",C["TOTAL"]+0,r;b++}
if(n["UNRESOLVED"]+0){printf "BLOCKER: %d row(s) UNRESOLVED\n",n["UNRESOLVED"]+0;b++}
print(b?"PLAN_LEDGER_CHECK=FAIL":"PLAN_LEDGER_CHECK=OK");exit(b?1:0)}
AWKPROG
```

**The citations have to resolve, and they have to say against what.** A `file:line`
is the one part of the ledger a reviewer can check in a second — and the second
they find one pointing at unrelated code, they stop trusting the whole table.
Line numbers do not survive a stale base: a branch cut from a `dev` that has since
moved rewrites every file in between, so a citation that was exact when written
now lands somewhere arbitrary. Record the commit they were resolved against, and
verify they resolve:

```sh
root=$(git rev-parse --show-toplevel) || exit 2
bad=0; n=0
for ref in $(grep -ohE '`[A-Za-z0-9_./-]+\.[a-z]+:[0-9]+`' test-plan.md | tr -d '`' | sort -u); do
  f=${ref%:*}; l=${ref##*:}; n=$((n+1))
  p=$(git -C "$root" ls-files --error-unmatch -- "$f" 2>/dev/null) \
    || p=$(git -C "$root" ls-files -- "*/$f" 2>/dev/null | head -1)
  if [ -z "$p" ]; then echo "UNRESOLVED: $ref — no tracked file matches"; bad=$((bad+1)); continue; fi
  t=$(wc -l < "$root/$p")
  [ "$l" -le "$t" ] || { echo "PAST-EOF: $ref — $p has $t lines"; bad=$((bad+1)); }
done
echo "CITATIONS=$n RESOLVED_AT=$(git -C "$root" rev-parse --short HEAD)"
[ "$bad" -eq 0 ] && echo "CITATION_CHECK=OK" || { echo "CITATION_CHECK=FAIL"; exit 1; }
```

Put the `CITATIONS=… RESOLVED_AT=…` line in the plan under the scope line, and do
not finish this step on `CITATION_CHECK=FAIL`. It proves reachability, not
relevance — a line that exists but says something else is still on you.

`Unresolved: 0` is a claim about **this scope**, not about the feature. A run that
delivers one of thirteen acceptance criteria and reports zero unresolved effects
is telling the truth and will still be read as "nothing left to check" by anyone
who opens only this file — which is most reviewers, because this is the file with
the numbers in it. One line of scope costs nothing and is the difference between
a reader who can act on the counts and one who is misled by them.

**That block needs a POSIX shell and `awk`.** It is the one place in this recipe
that cannot be transliterated into PowerShell by the rule above — a here-doc fed
to `awk -f-` has no direct equivalent. On a Windows host, run it under WSL, Git
Bash, or any `sh` on `PATH`; if none is reachable, say so and reconcile the six
numbers against the table by hand, in the evidence, row by row. Do not skip the
reconciliation because the tool is missing — miscounting is what it exists for.

**This step is not done until that command prints `PLAN_LEDGER_CHECK=OK`.** On
`FAIL`, fix the ledger — not the summary line you happened to write first. The
contradiction it reports is worth reading twice: a row you wrote a case for is
covered by that case, at whatever layer it runs; `OUT_OF_SCOPE` means outside the
requested code boundary, and **anything the spec names in its own acceptance
criteria can never be outside that boundary.** Not-run-here is a realization
status, not an exclusion.

Mark it `(adapted)` and mean it: the method it follows bans reading test artefacts
outright, and 4b below reads them for procedure. That deviation is deliberate and
scoped to 4b -- do not quietly widen it back into 4a.

**Audit the ledger with a second agent before you leave this step.** You cannot
check your own enumeration: the same reading that missed an effect the first time
misses it again on review, and confidently, because the surface *looks* covered.
Only a pass that rebuilds the inventory without seeing yours can tell you what is
not there.

```
spawn(agent="explorer", mode="serial", prompt=<the task below>)
```

Its read tools reach `<repo_path>` for the duration of this run — the same tree
every step of this run already shells into, so this shows a second reader what
the first could already see and grants nothing further. Writes are not included.

Give it **the production-code scope and the ledger**, and nothing else:

- name the surface — the feature's entry points, and the global chrome it touches;
- attach the ledger rows, effect text and status only;
- **do not give it your impact matrix, your reasoning, or the order you found
  things in.** Handed your route, it will walk your route, and agree;
- tell it the test-artefact ban applies to it too, for the same reason it applied
  to you.

Ask for exactly one thing: **every user-reachable trigger it finds that has no row
in the ledger.** Not a critique of the rows that exist — a list of what is
missing, each with a `file:line`.

Every returned trigger becomes a row before this step is done: a case, a
`CAPABILITY_GAP`, or an `OUT_OF_SCOPE` with a reason. Re-run the ledger check
afterwards — new rows move the counts. Record what the audit returned even when
it returns nothing, because "the audit found nothing" and "no audit ran" are the
same sentence in a document that mentions neither.

If the spawn is refused or the child comes back having read no files, say so and
mark the audit `CAPABILITY_GAP`. **Never describe a self-review as independent.**

#### 4b. Decide what actually gets executed

Write `test-plan.md`, and write the executable checks it describes.

**Read the repository's own instructions before choosing a shape** — both for
testing and for **running the app**, which are different questions:

- *How do I test?* — `backend/TESTING.md`,
  `backend/docs/testing/TEST_ARCHITECTURE.md`, `frontend/tests/TESTING.md`,
  `test/e2e_test/README.md`, and any `AGENTS.md` in the directories you touch.
- *How do I run it?* — `backend/README.md` (Docker Desktop, then
  `docker compose -f ./dependencies/docker-compose.yml up -d`, then the two
  `shared.dao_postgres.migrate … up` commands), and
  **`.claude/agents/app-verifier.md`** / **`.claude/commands/verify.md`**, which
  are the repository's own procedure for starting both services and verifying in
  a browser.

**Cite only files that are in the repository.** Before you rely on a doc, run
`git ls-files --error-unmatch <path>`. A file that is present on this machine but
untracked exists for nobody else — building a rule on it produces a rule that
fails on every other checkout. This is not hypothetical: this repo has several
untracked local docs sitting beside tracked ones in the same directory.

`app-verifier.md` also states, in its own verification matrix, **which
verification a change requires**. Read that matrix and obey it. It maps
`frontend/src/**/*.tsx` to "pnpm build, **browser check**", and
`test/e2e_test/**` to "**Remote only**" — that is the repository telling you both
that the deployed suite is out of reach *and* that a frontend change is expected
to be looked at in a browser.

The plan has **three layers, and they are not interchangeable**:

**Layer 1 — executable now, no app running.** Unit and integration checks in the
repository's own suites (`pnpm test`, `uv run pytest`), runnable on this branch
with nothing started. **This layer must contain the acceptance check** — a test
that exercises the chosen criterion and fails today *because the feature is
absent*, not because it references a symbol that does not exist yet.

**Layer 2 — the running app, in a real browser, locally.** Reachable, and
**mandatory to design whenever the criterion is user-visible.** Step 5 brings the
app up; this phase decides *what the browser case does and what its screenshot
must show*. It is not a procedure — the procedure is step 5's job.

**Layer 3 — the deployed e2e suite.** `test/e2e_test/` is Playwright against
**deployed environments** (dev / test / dogfood / staging / prod) and needs MSA
account passwords from Key Vault. **It cannot exercise an unmerged branch.** So
Layer 3 is a *produced artifact*: the cases, their steps, and their expected
results, written so a tester or a later pipeline run can execute them once the
change is deployed.

**Layer 3 being out of reach says nothing about Layer 2.** Confusing the two is
the specific mistake this section exists to prevent: a previous run correctly
recorded that `test/e2e_test` targets deployed environments, then treated that as
a reason no browser verification was possible at all, and shipped a user-visible
feature with no screenshot.

**Never present a Layer 3 case as evidence this run produced.** Saying "e2e
verified" when nothing ran is the failure mode this whole phase exists to prevent.
If a criterion is only provable at Layer 3, say so explicitly and mark it *not
verified by this run*.

#### Designing the Layer 2 case

A Layer 2 case is designed with the same rigour as a Layer 1 case, and it needs
two fields the other layers do not. Write each one as:

```
Action:            the concrete thing a user does — "select Example.java through
                   the Add Content file input"
Visible signal:    what a user would then SEE — "an attachment card labelled
                   Example.java appears in the composer"
Screenshot shows:  name the thing that must be legible in the image — "the
                   attachment card with the filename Example.java"
Screenshot must not: the failure surface of this same action. One exact string
                   per line, matched case-insensitively as a fixed string, never
                   empty:
                     Failed to upload
                     Retry upload
                     File type not supported
Before (RED):      the same action on unmodified code, and what is seen instead —
                   "no attachment card; the unsupported-format message appears"
Criterion:         which acceptance criterion this serves
```

**One string per line, and the lines go into the file verbatim.** They are matched
with `grep -F`, so a line holding three quoted phrases joined by commas is one
string that nothing will ever contain — the check then passes over a snapshot that
says `Failed to upload` in as many words. The first draft of this block said "one
per line" in a paragraph whose own example ran three across a wrapped line; that
is the shape of green light this whole section exists to remove.

**`Screenshot must not` is where a case stops being satisfiable by a failure.**
The RED line above already names what is *absent*; the GREEN side had only a
presence to look for, and a presence is cheap. A run wrote its expectation as *an
attachment card labelled `example.html` appears*, then shipped a GREEN whose image
carried a red banner reading **`Failed to upload example.html`** and a retry
button beside the card. The filename was legible. The expectation was met to the
letter. The upload had failed, because the backend allowlist was never touched.

Its own snapshot said so:

```text
main: Hi yueliu1, what can I do for you? Failed to upload example.html
text: example.html
button "Retry upload"
```

**Name the end of the action, not its beginning.** The signal has to be the state
a user would call done. A card that has appeared is the start of an upload; the
upload succeeding is the end of it. If the thinnest slice you can find stops
before the action completes, the slice is the front half of something that
visibly fails — pick a different one, or say plainly that the criterion is not
served yet. A visible error is never *outside the criterion* of the action that
produced it.

**`Screenshot shows` is not optional and it is not "the app".** A screenshot of a
loaded, signed-in page proves the app runs; it does not prove the feature works.
If you cannot name, in advance, a thing that will be visible in the image and
would be absent without your change, you have not designed a Layer 2 case — you
have designed a smoke test.

**Reading an attribute is not a visible signal.** `accept=".java,.sh"` on a file
input is a DOM property; a user never sees it. Checking it in a browser proves the
constant reached the DOM — which the Layer 1 component test already proved, and
proves it faster. A Layer 2 case that only reads attributes has spent the whole
cost of bringing the app up and bought nothing.

The test is simple: **would this case still pass if the feature were wired to
nothing?** If yes, go one step further — perform the action, and assert on what
comes back.

**Assert on what is reachable locally, not on what you wish were.** Some paths
cannot complete on a developer machine at all — file upload here reaches storage
and stops, because the storage layer always speaks ADLS Gen2 (which the local
Azurite emulator does not implement) and the real cloud account rejects a
developer identity with `AuthorizationPermissionMismatch`. The attachment card
still renders, so a criterion phrased "see it as an attachment" is provable while
one phrased "the upload succeeds" is not. Find that line before you write the
case, and record which side of it each expectation falls on.

Three rules govern every assertion, at every layer. They come from a four-way
comparison of generated test cases run on this product, where the loose-assertion
variant missed defects the precise variant caught:

1. **Assert precisely, never on a loose range.** "5–6 slides" passes a build that
   produced the wrong count; "exactly the requested count" does not.
2. **Assert on a signal the user can see** — a count, a state, a card, an order, an
   error message. Not on an internal value the user never observes.
3. **Every expectation in the plan must survive into the executable check.** An
   expectation that exists in `test-plan.md` and in no assertion is a check nobody
   runs. When one cannot be expressed, write down which one and why.

For each case, record: what it proves, which criterion it maps to, the exact
command, and the expected result. A case that maps to no criterion does not belong
in the plan.


**Close the loop with 4a.** Every row in 4a's ledger appears here with either a
realization -- which layer, which case, which assertion -- or an explicit
non-realization carrying its reason. The counts in the summary block must match
what this section actually contains. A ledger that promises more coverage than
`test-plan.md` delivers is worse than no ledger, because it reads as proof.

### 5. Bring the app up

**Skip this step only when no criterion in the plan is user-visible.** Otherwise it
is a gate: the app comes up *now*, before any production code changes, and stays
up through both the RED and the GREEN. That ordering is the whole point — a run
that starts the app only when it wants a GREEN has no RED to pair it with, and a
browser GREEN with no browser RED proves nothing about causation.

This procedure was executed end to end on this repository; each failure mode below
is observed, not anticipated:

**Bring-up spans more than one tool call.** Starting a service and waiting for it
are separate calls. A single `shell` that does both runs out of its 600-second
ceiling before the waiting does: the two readiness polls below are 90 iterations
of `sleep 2` each, so six minutes go to waiting before Docker, the migrations and
the two startups are counted. The processes are `nohup`-ed and survive the tool
timeout, which is why a run that packs it into one call still finds the app up
afterwards — having spent ten minutes learning that. Start, return, then poll.

1. **Infrastructure.** `open -a Docker`, wait for the daemon, then
   `docker compose -f backend/dependencies/docker-compose.yml up -d postgres`.
   Postgres is the one hard blocker — `api.py`'s startup calls
   `run_all_auto_migrations()` outside any try/except, so a closed 5432 aborts
   uvicorn. Start `redis` too only if nothing already serves 6379; a local Redis
   installed outside Docker will make that container fail to bind.
2. **Migrations.** The two `uv run python -m shared.dao_postgres.migrate … up`
   commands from `backend/README.md`.
3. **Backend.** `cd` on its own line, then background a single command — never
   `cd backend && nohup … &`:

   ```sh
   scratch="<repo_path>/.workflow-run/<feature-slug>"
   mkdir -p "$scratch" || { echo "NO_SCRATCH_DIR"; exit 1; }
   cd -- '<repo_path>/backend' || { echo "NO_BACKEND_DIR"; exit 1; }
   nohup uv run python api.py > "$scratch/backend.log" 2>&1 &
   echo $! > "$scratch/backend.pid"
   ```

   Then poll `http://localhost:8000/health` until it returns `"status":"ok"` with
   `database` and `redis` both `connected`. Read the log on failure; the health
   body names which dependency is down.
4. **Frontend.** Same shape:

   ```sh
   scratch="<repo_path>/.workflow-run/<feature-slug>"
   mkdir -p "$scratch" || { echo "NO_SCRATCH_DIR"; exit 1; }
   cd -- '<repo_path>/frontend' || { echo "NO_FRONTEND_DIR"; exit 1; }
   PORT=3000 nohup pnpm dev:turbo > "$scratch/frontend.log" 2>&1 &
   echo $! > "$scratch/frontend.pid"
   ```

   Then poll `http://localhost:3000/`. **Do not use `frontend/dev.sh` on the
   primary checkout** — it exports `PORT` from `.env.local`, and when that file
   has no `PORT=` line it exports an empty string and Next refuses to start.

**`&` binds the whole `&&` list, not the last command.** Written
`cd backend && nohup … &`, the background job is a *subshell* running both, and
that subshell keeps the parent's stdout. Pipe the surrounding block into `tee`
— the obvious way to keep a bring-up log — and `tee` waits for a writer that
never closes, because the server it is waiting on does not exit. Two calls in one
run burned the full 600-second tool ceiling this way.

Measured, same server, three shapes:

```text
{ … cd backend && nohup api.py > log 2>&1 & … } | tee   ->  waits for the server
{ … cd backend && nohup api.py > log 2>&1 & … } >> f    ->  returns immediately
cd backend; nohup api.py > log 2>&1 & …         | tee   ->  returns immediately
```

All three redirect the server's own stdout and stderr to a file; the redirection
is not what separates them. What the first one leaves attached to the pipe is the
**subshell** `&` created around `cd backend && nohup …`, and `tee` waits on that.

Neither `| tee` nor `cd &&` is wrong alone. The pair is.

**`mkdir -p "$scratch"` before either service starts.** The redirection targets a
directory the run creates in step 1; on a resumed run, or one that reached step 5
by another path, it may not be there. Without it the failure is quiet and
complete: `> "$scratch/backend.log"` fails inside the backgrounded subshell so the
server never starts, `echo $! > "$scratch/backend.pid"` fails too, and the step
prints two redirection errors and no summary line — nothing that reads as *the
service did not come up*.

**Keep the guard when you split the `cd` out.** `cd backend && …` at least refuses
to start the server from the wrong place; a bare `cd` on its own line does not, and
`cd` failing there leaves the next line running in the repository root. Hence
`cd -- '<path>' || { echo NO_..._DIR; exit 1; }` — the split removes the hang, the
`||` keeps what the `&&` was doing.
5. **Authenticate.** `cd backend && uv run scripts/stress_token.py` — a
   repository-provided local dev path. It flips `ENABLE_STRESS_TOKEN=true` in
   `backend/.env`, picks an account from local Postgres, and prints an auto-login
   URL. **Restart the backend afterwards** or the flag has no effect. Verify the
   token before trusting it: the same endpoint must return 401 without it and 200
   with it.
6. **Confirm the browser can drive it.** Navigate to the auto-login URL and check
   the app is really authenticated — a signed-in surface, and API calls returning
   200 rather than 401.

**The browser tool cannot reach `localhost` until you allow it.**
`security/ssrf.py` blocks the hostname `localhost` and the whole of `127.0.0.0/8`
outright, and `browser` sitting in `allowed_tools` does not change that — the
grant gets you the tool, not the destination. Allow the destination first:

```
config_praestoclaw(action="patch", path="tools.browser.allowed_domains",
                   value=["localhost", "127.0.0.1"])
```

`browser.py` skips SSRF validation for a host named in `allowed_domains`, and this
key takes effect **immediately**: `BrowserTool` holds the very config object the
patch assigns through. Do not generalise that — nearly every other key is saved
and then ignored until a restart, and the tool says so in its reply. Read the
reply: if it mentions a restart, the change is not live and the browser will still
refuse.

A run that skips this gets `Request to 'localhost' blocked (SSRF protection)` on
its first navigate, then spends the next ten minutes hand-writing a Playwright
script through `shell` to take the screenshots it was already granted a tool for.

**Choosing a browser — try the machine's own first, download only as a fallback.**
In that order:

1. **The browser already installed**, via Playwright's `channel` option —
   `channel="msedge"`, then `channel="chrome"`. This needs no download, works on a
   machine whose network blocks the Playwright CDN, and is the normal case here.
2. **Only if both channels fail**, download Playwright's own build
   (`playwright install chromium`). Expect this to be the slow path and expect it
   to fail on a restricted network; if it does, say so with the real error rather
   than concluding a browser is unavailable.

`executable_path` reporting a path is *not* evidence a binary exists — it is a
computed location, and it resolves happily for a browser that was never
downloaded. Launch it, or you have not checked.

**If the app cannot be brought up, that is a Callout**, with every command you ran
and its real error — not a sentence in the evidence file and a run that continues
as though Layer 2 were optional. The one thing you may not do is proceed to the
implementation and then start the app for the GREEN.

**Restore afterwards** (step 8 reminds you again): `ENABLE_STRESS_TOKEN=false`,
**stop every service this run started — including any you restarted during
cleanup** — and confirm `git status --short` shows the production tree unchanged.

Restarting the backend to prove the auth bypass is off is a good check; **leaving
it running afterwards is not cleanup**. Record which services were running before
you began, and return the machine to exactly that set. A service the user did not
start and did not ask for is a leftover even when it is harmless, and "I left it
up for safety" is not a reason — stop it, and say in the evidence file that you
verified the bypass was dead before you did.

### 6. Current-state evidence (before)

Run the Layer 1 checks **against unmodified code**, and write `evidence-before.md`.

**When the criterion is user-visible, the Layer 2 RED is captured here.** The app
is already running (step 5), so there is no startup cost left to weigh and no
"the frontend was not running" to record — perform the case's `Action` against
unmodified code, screenshot, and show that the `Visible signal` is **absent**.
That image is what makes the later GREEN mean something; without it the pair is
"a browser saw the feature" versus "nothing looked", which proves nothing about
your change.

This must happen **before any production code changes**. Confirm it: `git status
--short` and `git diff --stat` should show the new test files and the artifacts,
and no change to the code under test. Say so in the file.

Capture three things, each with the exact command, the exit code, and the real
output — never a summary, never a reconstruction:

**"The real output" means the tool's words about your check, not everything the
tool printed.** `frontend/jest.config.js` sets `collectCoverage: true`, so running
a single test file prints a coverage table for the whole project. A run captured
**1,081,784 bytes** into `evidence-before.md` to record a result whose entire
content was the last two lines it printed:

```text
Test Suites: 1 failed, 1 total
Tests:       1 failed, 27 passed, 28 total
```

Keep the command, the exit code, the failing assertion, and the counts. Leave the
full capture on disk and cite its path instead of inlining it. Per-file coverage
for code this change never touches is not evidence about this change, and pasting
it does not make the RED more true. **"Never a summary" forbids inventing a result
you did not see; it does not oblige you to transcribe output about something
else.** If you did not read a line, it is not evidence — it is volume.

1. **The acceptance check fails.** This is the RED. It is the one piece of evidence
   in this entire run that cannot be produced by accident, and it is what separates
   a delivered feature from a PR that merely compiles.
2. **It fails for the right reason.** Read the failure. An `ImportError`, a
   `NameError`, a syntax error, or a missing fixture is **not** the feature being
   absent — it is your test being broken. Fix the test and re-run until the failure
   message describes the missing behaviour.
3. **The baseline around it.** Run the whole test files you will touch, on the
   **target branch's** state, with the **same command** you will use afterwards. A
   test that already fails before your change is not a regression you caused, and
   the only way to know that is to have run it first.

If the acceptance check **passes** before you have implemented anything, stop. The
feature already exists, the check is asserting something else, or the slice is
wrong. Any of the three invalidates the run — say which, via the Callout contract.

### 7. Implement, and prove the criterion

Make the smallest change that satisfies the slice, following the repository's own
conventions for the directories you touch. Implement **the design in `design.md`**
— if you find mid-way that the design is wrong, say so and update the file; do not
quietly build something else and leave the artifact describing work that never
happened.

The acceptance check already exists and already fails: step 4 wrote it and step 6
captured the RED. **Do not rewrite the check to fit the implementation.** If the
check turns out to assert the wrong thing, that is a finding — record it in
`evidence-after.md` with the old and new assertion side by side, and say why the
first was wrong. Silently editing an assertion until it passes converts the run's
one trustworthy piece of evidence into a tautology.

Choose the boundary the criterion is observable at, and read the instruction file
that owns that surface before writing the check. **Never select a lower boundary
because it is easier**: "it isn't really visual", "it is observable in logs", or
"it is easier to test at the unit level" are not reasons. If the criterion names a
user-visible behaviour, it is proved on the surface a user sees.

**Discover the checks; do not assume a toolchain.** Read the repository's
instructions and run the gates that apply to the directories you changed. If the
package commits build output, rebuild it — editing a source that compiles into a
committed artifact ships nothing without that step.

### 8. Verify evidence (after)

Re-run **exactly the commands step 6 ran**, and write `evidence-after.md`. Same
commands, same scope — a different command produces a comparison that means
nothing, and the whole value of the before/after pair is that the only variable is
your change.

Capture, with real output and exit codes:

1. **The acceptance check now passes.** This is the GREEN. Pair it with the RED
   from `evidence-before.md` so a reviewer sees the transition, not just the
   endpoint.
2. **The baseline is unchanged.** Run the same whole test files, not selected
   cases: a selection can only confirm your own work and can never show you a
   neighbour you broke. Compare against the before run **case by case**, not by
   total count — a suite that goes from 103 passed to 103 passed can still have
   swapped which ones.
3. **The repository's own gates** for the directories you changed — lint,
   typecheck, format, whatever the instructions name.

   **Each gate gets a one-line verdict, not just its output.** Write
   `<gate>: PASS`, `FAIL`, or `BLOCKED — <reason>`. Pasting a wall of log that
   ends in `[ERROR]` and moving on leaves a reviewer to work out for themselves
   whether a required gate was satisfied, and the honest answer gets buried in
   the one place nobody rereads. A gate the repository's own instructions mark
   as required for a path you changed, and which did not pass, is stated again
   in the PR under `Not run` with its reason — a run that reaches the PR with a
   required gate quietly failed has mis-stated its own readiness.

   **A gate that repairs dependencies can break the checkout it runs in.** Some
   `typecheck`/`build` entry points reinstall packages before doing anything,
   and against a private feed with no credentials they exit having deleted a
   working install rather than restored one. If a gate leaves the working
   checkout less usable than it found it, that belongs in the evidence with the
   exact command and what is now missing — the next person to run tests here
   needs to know before they lose an hour to it.

If something that passed in `evidence-before.md` fails now, that is a regression
you introduced, not an outdated expectation. The honest fix is to make your change
additive; editing the assertion to match your new behaviour is a decision to break
that surface, and if you truly intend it, say so in the PR under `Behaviour
deliberately changed` and name who is affected.

**Capture the Layer 2 GREEN**: perform the case's `Action` again on the changed
code, screenshot, and confirm the image shows exactly what `test-plan.md` said
under `Screenshot shows`. Put the RED and GREEN images side by side in the file.

**Check the image, do not assume it.** A screenshot proves what is *in* it. If the
plan said the image would show an attachment card labelled `Example.java` and the
image shows a signed-in landing page, the case did not pass — it ran and produced
the wrong evidence, which is worse than not running, because it looks like proof.
Say what the image actually shows.

When the criterion is user-visible and you have no image, do not describe the
pixels in prose as though you had seen them — record that the visual evidence is
missing and that it needs a human or a deployed-environment run.

Finally, restate the Layer 3 e2e cases as **not run**, with the reason (no
deployed build of this branch). Never let the after-evidence read as if the
deployed suite passed.

**A GREEN may not contain the failure of the action it proves.** Save the browser
snapshot beside the screenshot, write the plan's `Screenshot must not` lines to a
file, and check one against the other:

```sh
cd -- '<repo_path>/.workflow-run/<feature-slug>'
test -s layer2-green-snapshot.txt || {
  echo "LAYER2_CHECK=FAIL green snapshot not saved"; exit 1; }
bad= ; used=0
while IFS= read -r s || [ -n "$s" ]; do
  [ -n "$(printf '%s' "$s" | tr -d '[:space:]')" ] || continue
  used=$((used + 1))
  if grep -qiF -- "$s" layer2-green-snapshot.txt; then
    printf 'LAYER2_SAW %s\n' "$s"; bad=1
  fi
done < layer2-must-not.txt
printf 'LAYER2_STRINGS_USED=%s\n' "$used"
[ "$used" -ge 1 ] || {
  echo "LAYER2_CHECK=FAIL no must-not strings declared"; exit 1; }
[ -z "$bad" ] && echo "LAYER2_CHECK=OK" || { echo "LAYER2_CHECK=FAIL"; exit 1; }
```

`read` returns non-zero on a final line with no newline after it, so the loop is
written `read -r s || [ -n "$s" ]`: without that, a must-not file saved by hand
loses its last string in silence. Declaring two and comparing one printed `OK`
over a snapshot containing the string that was dropped.

Both files are required, and the count that matters is `LAYER2_STRINGS_USED` —
the lines the loop actually compared, not the bytes on disk. `test -s` passes on a
file holding nothing but blank lines, every one of which the loop then skips, and
the check reports a pass having compared nothing. A check with nothing to look
for and a check with nothing to look in are the same green light over nothing, and
file size does not tell them apart. `LAYER2_SAW` names the string that fired, so a
failure says which expectation was violated rather than that one was.

On `LAYER2_CHECK=FAIL` the Layer 2 GREEN does not exist. Do not record it as
passing with the failure noted alongside as out of scope; that is the sentence the
run under discussion wrote, and it is how a red banner became evidence.

**Size the working files before you leave this step.** The rule above says to keep
the counts and the failing assertion and cite the capture's path; this checks that
you did:

```sh
cd -- '<repo_path>/.workflow-run/<feature-slug>' || {
  echo "EVIDENCE_CHECK=FAIL no such directory"; exit 1; }
bad= ; n=0
for f in requirement-analysis.md design.md test-plan.md evidence-before.md evidence-after.md; do
  if [ ! -f "$f" ]; then printf 'EVIDENCE_MISSING %s\n' "$f"; bad=1; continue; fi
  b=$(wc -c < "$f" | tr -d ' ')
  n=$((n + 1))
  printf 'EVIDENCE_BYTES %s=%s\n' "$f" "$b"
  [ "$b" -le 65536 ] || bad=1
done
printf 'EVIDENCE_FILES_MEASURED=%s\n' "$n"
[ "$n" -eq 5 ] || bad=1
[ -z "$bad" ] && echo "EVIDENCE_CHECK=OK" || { echo "EVIDENCE_CHECK=FAIL"; exit 1; }
```

**A check that measured nothing must not print `OK`.** The first version of this
block did: an unhandled `cd` left it in the wrong directory, every file missed
`[ -f ]`, every iteration `continue`d, `bad` stayed unset, and it reported a pass
having weighed nothing. `EVIDENCE_FILES_MEASURED` is printed so the count is on the
record, and a run that produced four of the five files fails on the fifth instead
of being congratulated for the four.

65536 is six times what these files need. Measured on a real run: the three
analysis files came in at 8.5 KB, 8.0 KB and 9.9 KB, and `evidence-after.md`
would have been **10 KB** — except that five captured logs were pasted into it
whole, three of them near-identical coverage tables of about 155 KB each, taking
it to **517 KB**. Nothing in it was false. None of it was read.

On `EVIDENCE_CHECK=FAIL`, do not trim by deleting findings. Find the pasted
capture, leave it on disk, and cite its path — that is the same instruction as
step 6, and this is the check that it happened.

### 9. Acceptance review

**This is an acceptance check, not a code review.** The PR's own reviewers cover
correctness; a second opinion on syntax and logic is the slow half and buys
nothing. The reviewer answers one question — *does this change deliver what the
criterion promised, no more and no less* — and must not go looking for bugs.

Compute the diff and write it **outside** the repository so no `git add -A` can
sweep it in. **`git add -N` first, or the review is blind to every new file:**

```
cd -- '<repo_path>' \
  && base=$(git merge-base '<target>' HEAD) \
  && git add -N -- <changed_paths> \
  && git diff --stat "$base" -- <changed_paths> > "$HOME/.praestoclaw/workspace/review-{feature_id}.stat" \
  && git diff "$base" -- <changed_paths> > "$HOME/.praestoclaw/workspace/review-{feature_id}.diff"
```

**Also capture what you did *not* nominate.** The two diffs above cover the paths
you chose; everything the run disturbed outside that list is invisible to them, and
to the reviewer reading them:

```
cd -- '<repo_path>' \
  && git -c color.status=false status --porcelain --untracked-files=all \
     > "$HOME/.praestoclaw/workspace/review-{feature_id}.tree"
```

`--porcelain` is the format Git documents as stable for scripts; `--short` is for
people and shifts with the reader's config. Both flags are pinned for the same
reason: colour codes and a repository-level `status.showUntrackedFiles` would
otherwise decide what the reviewer is allowed to see.

A run picking its own review scope is the suspect choosing the evidence. One run
handed the reviewer five files and 150 insertions while the working tree also held
a lockfile rewritten by the test suites (**4842 lines**), a file carrying the user's
own local debug flags, and an unrelated doc edit. The reviewer answered *is any file
here unnecessary* correctly, over a set that had already been filtered.

`<changed_paths>` is the list of paths this change owns. It is **the same list
every time it appears** — the three commands above, and the `git reset` below
that undoes them. Substitute it once and reuse it verbatim: a diff taken over a
narrower set than the intent-to-add is a diff with holes in exactly the place
this step exists to cover.

`git diff` says nothing about an untracked file. It does not warn, it does not
fail — naming one on the command line simply produces no output for it, and the
review proceeds over whatever remains. A run once handed the reviewer a 154-line
diff of five code files while five new artefacts sat beside them unlisted, one of
them **3789 lines**. The reviewer's second question is *is any file here not
required by the criterion* — it asked, and the file was not in front of it.

**`HEAD` is the wrong base here.** Step 1 may reuse a task branch that already
carries a prior run's commits, and `git diff HEAD` shows only what is *un*committed
— the committed half of the same change never reaches the reviewer. The merge-base
against the target branch covers both halves. Do not reach for `<target>...HEAD`
instead: the three-dot form compares two commits and never consults the working
tree, so it drops everything not yet committed, which at this step is normally the
entire change.

`git add -N` records intent-to-add: new files appear in the diff with their
contents, and no content is staged. **Undo it before you leave this step** —

```
cd -- '<repo_path>' && git reset -- <changed_paths>
```

— because until you do, `git status` reports those files as `A` rather than
untracked, and step 10 stages by explicit path against exactly that reading. The
files themselves are untouched by the reset.

**Give the reviewer the `--stat` first.** A per-file line count is the cheapest
signal there is and it does not require reading anything: an artefact far larger
than the production change it documents is a finding on sight, before a word of
its content has been read.

Spawn the reviewer with `agent="explorer"`, giving it the criterion verbatim, the
stat path, the diff path, the tree path, and exactly these four questions:

1. **Enough?** Does the diff satisfy the criterion as written? Name any part of the
   criterion nothing in the diff serves.
2. **Too much?** Is any file in the diff not required by that criterion? Name it
   and say what it does instead. **Read the `--stat` before the diff**, and treat
   size as evidence: a file whose line count dwarfs the production change is
   either in the wrong place or full of something nobody will read. Say so — that
   is a finding, not a style note.
3. **Connected?** Trace the chain from where the data is produced to where a user
   sees it, one `file:line` per hop. If a hop is missing, say which one.
4. **Anything else touched?** Read the tree listing. Name every path that is dirty
   there but absent from the `--stat`, and for each say whether the criterion
   needed it. A lockfile the suites rewrote, a file the user already had open work
   in, an unrelated doc — none of those belong in this change, and none of them
   appear in the diff you were given. This question exists because the diff was
   scoped by the same run that dirtied the tree.

Tell it plainly: *"Do not report syntax errors, logic bugs, style, naming, missing
tests, or anything CI can find. If the code is wrong but delivers the criterion,
that is not your finding. Read the diff first; open a file only when the diff alone
cannot answer one of the three questions, and at most three files. Answer in one
pass."*

Note the reviewer is read-only and cannot reach a repository outside the workspace
— give it the diff, and name any file it may need by absolute path in the prompt.

Do not tell it your own verdict. Treat its answer as work, not an opinion: fix it,
or write in the PR why it is wrong. Re-review **only if you changed something**,
once. Remaining findings go into the PR under `Review findings not addressed`, in
the reviewer's words.

### 10. Draft pull request and hand off

Verify the checkout is not on the target branch; create a feature branch following
Societas conventions. **Write the design note now** — distil the five working
files into one, per *The shape of the deliverable* — and commit it with the code
change. A PR that carries the diff without it ships the half a reviewer cannot
check. Commit and push the **feature** branch — never the target.

**The working files do not go in the commit.** `.workflow-run/` is scratch; the
note is the deliverable. Check before you stage: if the diff contains a file with
raw command output in it, that file is in the wrong place.

**Commit the design note. Do not commit the screenshots.** They are
review material, not source: a few hundred kilobytes each, never diffable, and
permanent once merged. Upload them to the PR and link them, so a reviewer sees
them without the product repository carrying them forever.

**A filename is not a link.** A run that wrote ``RED `red-html-upload.png` ``
into the description had done the hard part — the images existed, they showed
the right thing, and they had correctly stayed out of the commit — and a
reviewer still could not open either one. The description must carry a URL the
attachment upload returned, rendered as an image or a link. Paste the upload
command and its response into the evidence, so "attached" is a fact with a
receipt rather than a claim.

Where the platform cannot take an attachment, say so with the exact command that
failed and give the manual upload step — do not fall back to committing the
binary, and do not leave a bare filename standing in for an image nobody can
reach.

**An image that maps to no acceptance criterion is not evidence and is not
delivered.** A login probe, a "the app is up" shot, a screenshot taken while
finding the right selector — those are working material. Ship the RED and the
GREEN for the criterion, and nothing else.

**Stage by explicit path.** `git add -A` in this repository sweeps up whatever the
suites regenerated — a lockfile rewritten with the same number of lines added and
removed is the usual one, and in a diff it is indistinguishable from a dependency
the feature actually needed.

**Prove the staged set, do not assert it.** Stage, then check what is actually
there against what you meant:

```sh
cd -- '<repo_path>'
git add -- <changed_paths> <design_note_path>
STAGED=$(git diff --cached --name-only | LC_ALL=C sort)
WANT=$(printf '%s\n' <changed_paths> <design_note_path> | LC_ALL=C sort)
if [ "$STAGED" = "$WANT" ]; then echo "STAGE_CHECK=OK"; else
  echo "STAGE_CHECK=FAIL"; echo "--- < declared, > staged ---"
  d=$(mktemp -d) || exit 1
  printf '%s\n' "$WANT" > "$d/want"; printf '%s\n' "$STAGED" > "$d/got"
  diff "$d/want" "$d/got"; rm -rf "$d"; exit 1
fi
```

`LC_ALL=C` so both sides sort the same way whatever the shell's locale is, and
`mktemp -d` rather than `/tmp/<pid>` — a predictable path in a world-writable
directory is a collision at best and a symlink someone else planted at worst.

Do not commit on `STAGE_CHECK=FAIL`. The failure prints the difference both ways,
so an extra path and a missing one read differently.

A run reached this point with a lockfile carrying **4842 changed lines** beside two
lines of production code, plus a file holding the user's own uncommitted debug
flags. Nothing was wrong with its intent — it never ran `git add -A`. The staged
set was simply never compared to the list it had just written down.

Before opening the PR, call
`plan(action='checkpoint', summary=…, next_step='Open the draft PR for the stated
branch, target, requirements source and acceptance evidence', ask_user=true)` and **wait for
approval**. The summary must state the criterion served and whether the acceptance
check went RED→GREEN or is missing. When the evidence is missing, do not bury it:
say the functional checks passed but the draft would ship without proof the
criterion is met, and name the gap. Map the buttons: Approve opens the draft PR
with the evidence gap recorded; Reject stops here.

Only after approval:

```
az repos pr create … --draft --target-branch <resolved> …
```

Pass `--target-branch` **explicitly**, using the value resolved in step 1 — never
omit it (ADO falls back to the repo default branch) and never re-derive it here.
Before creating the PR, confirm the diff is scoped: `git diff --stat <target>...HEAD`.
A count in the hundreds of files means the target is wrong — stop and say so rather
than opening the PR. Link the work item when one exists.


**Attaching the images: use this call, it is the one that works.** ADO takes PR
attachments over its REST API and nowhere else — `az repos pr attachment` is not a
subcommand and exits 2, and `az rest --method put` without `--resource` answers
`Method Not Allowed`. Both were tried by real runs; each cost a step and one of
them shipped a PR whose images had to be attached by hand.

```sh
token=$(az account get-access-token --resource '499b84ac-1321-427f-aa17-267ca6975798' \
        --query accessToken -o tsv)
base='<collection>/<project>/_apis/git/repositories/<repo_id>/pullRequests/<pr_id>/attachments'
for f in <red>.png <green>.png; do
  curl -fsSL -X POST --oauth2-bearer "$token" \
       -H 'Content-Type: application/octet-stream' \
       --data-binary "@$f" "$base/$(basename "$f")?api-version=7.1-preview.1"
done
```

`499b84ac-1321-427f-aa17-267ca6975798` is Azure DevOps' own resource id; the token
will not work without it. `--oauth2-bearer` sends the same bearer header
`-H "Authorization: …"` would, and is used instead because redaction layers scrub
an explicit `Authorization:` value -- a reviewer reading this file through one
reported the header as `******` and concluded the command could not
authenticate. The flag carries no header text to scrub. A success returns JSON carrying `id`, `displayName` and
a `url` — that `url` is what the description links to. If the POST fails, say so
with the command and its real error, and name the files a human must attach; do
not describe an attachment that is not there.

**A passing check does not go under `Not run`.** That heading means *checks this
repository has and this run did not perform*; a reader who sees a browser RED/GREEN
pair there concludes the browser was never driven. A run put its screenshots there
because this template used to list them there, and the same run's committed design
note said `Local browser check: PASS` — one run, two records, disagreeing. The
images belong under `Visual evidence`; only the failure to obtain them belongs
under `Not run`.

Keep the description at or below **3900 characters**; ADO rejects over 4000.

That limit does not mean cutting evidence — it means each thing goes where it
belongs. The design note carries the conclusions and is committed, so the
description links to it. The images are attachments, so the description links
to those. The coverage ledger is review material for this PR, so it goes in the
description if it fits and becomes an attachment if it does not. The working
files stay in `.workflow-run/` and are linked from nowhere, because nobody
outside this run needs them.

**What never happens is dropping a finding to make the character count work.**
If the description is over, something in it is a transcript rather than a
conclusion — find that and move it, do not delete a gate verdict or a contract
difference to buy room.

**Count it, do not estimate it.** Write the description to a file and measure it
before `pr create` sees it:

```sh
CHARS=$(wc -m < "<description_path>" | tr -d ' ')
echo "DESC_CHARS=$CHARS"
[ "$CHARS" -le 3900 ] && echo "DESC_CHECK=OK" || { echo "DESC_CHECK=FAIL"; exit 1; }
```

`wc -m` counts characters, not bytes — `wc -c` over-counts every non-ASCII
character and will send you trimming a description that fits. Do not open the PR
on `DESC_CHECK=FAIL`.

3900 is not the real ceiling; 4000 is. The hundred characters between them exist
so a description that grows by a line during review still posts. A run that lands
on 3986 has not passed — it has spent the margin and left fourteen characters for
everything that comes next. Every other numeric gate in this recipe is machine-
checked, and those are the ones that hold.

```
### Delivery readiness
<READY | CONDITIONAL | NOT_READY>
Conditions before merge: <numbered, or "none">

### Summary
<one line: what this PR delivers>. Refs <work item, or the spec path>.

### Design note
docs/design/<feature-slug>.md — scope, contract differences, implementation, gate verdicts.

### Coverage ledger
<the effect ledger table from step 4a, with its summary block and both check outputs>

### Acceptance mapping
Criterion served: <verbatim from the source>
RED  `<command>` → <the failing assertion, one line>
GREEN `<same command>` → <the passing result, one line>
Not served by this PR: <the other criteria, and why>

### Scope of change
<files changed, grouped by what each group does>

### Out of scope but touched
<any file the slice did not require, justified or reverted — "none" if none>

### Implementation
<why this is the smallest change that delivers the criterion>

### Validation performed
Command: `<command>`  Exit: <code>
<tail of output>
Baseline unchanged: <before → after, case-level, not just totals>

### Acceptance review
Findings addressed: <one line each, with the fix>
Review findings not addressed: <in the reviewer's words, with why — or none>

### Visual evidence
Local browser check: RED <attachment> / GREEN <attachment> — and what each image shows.

### Not run
<every check that exists in this repo and was NOT run, and why>
Local browser check: if it could not be reached, the exact commands run and their real errors.
e2e (test/e2e_test): not run — targets deployed environments; this branch is not deployed.

### Quality judgment
<does this deliver the criterion, and what would you not yet rely on>

### Risks
- Blast radius: <files changed, who calls them>
- Reversibility: <how to undo>
```

**`Delivery readiness` is not the plan's status.** Finishing the plan means every
item ran; being ready to merge means nothing is left that a reviewer would stop
for. They come apart routinely, and the gap is invisible from the outside: a run
that reports nine of ten items done reads as *nearly shippable* to anyone who
does not go looking, while a required gate sits failed and a lockfile sits in the
diff. Decide this from what the evidence shows, not from how far the plan got.
`READY` means merge it as is. `CONDITIONAL` requires the numbered list, and each
condition names something checkable. `NOT_READY` is the honest answer when the
criterion is not proven, and it is not a failed run — it is a run that knows what
it did not establish.

**`Not run` is mandatory and must be honest.** If you ran one test file, say so and
list the gates you skipped. Writing "all tests pass" when you ran a subset is a
false report and is worse than saying nothing.

**`Quality judgment` is your own assessment, not a restatement of the results.**
Say what you would not yet rely on. A PR whose evidence is one unit test and whose
judgment says "delivers the criterion" is claiming more than it proved.

Record the PR URL in the item's evidence. A local branch or drafted PR text is not
a deliverable — only a real PR URL is.

#### Hand off

Mark the Plan complete and reply with: the PR URL, the criterion served verbatim,
the acceptance evidence (RED and GREEN), the path of the design note, what you
deferred, which checks you did not run, and what a human needs to do next.

Then stop. Do not poll CI, do not wait for review comments, do not start another
cycle.
