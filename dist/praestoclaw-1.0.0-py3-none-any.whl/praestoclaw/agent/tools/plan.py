"""Plan tool — structured TODO / SOP runtime for long-running tasks.

The agent uses ``plan`` to:
  - break a long task into ordered, verifiable items (``create``)
  - track progress (``update``)
  - check in with the user at SOP-defined gates (``checkpoint``)
  - emit non-blocking progress (``report``)
  - validate that "done" actually means done (``verify``)
  - inspect current state (``show``)

Plans are stored at ``<data_dir>/plans/<session_id>.json`` so they survive
process restarts and can be resumed via ``praestoclaw resume``. The store
is intentionally a single JSON file per session — small, human-readable,
and trivial to back up or hand-edit.

This tool is the foundation for steps 3-8 of the long-task design
(see design/features/long-task-workflows.md, future).
"""

from __future__ import annotations

import asyncio
import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.plan_wait import (
    DEFAULT_PLAN_WAIT_SECONDS,
    MAX_PLAN_WAIT_SECONDS,
    PLAN_WAIT_SECONDS_PATTERN,
    resolve_plan_wait_seconds,
)
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

# ── Constants ────────────────────────────────────────────────────────────────

_VALID_STATUSES = ("not_started", "in_progress", "blocked", "done", "skipped")
_TERMINAL_STATUSES = ("done", "skipped")
_VALID_VERIFICATIONS = ("pending", "passed", "failed")
_FAIL_PATTERNS = re.compile(
    r"\b(fail|failed|failure|error|traceback|exit\s*code\s*[1-9])\b",
    re.IGNORECASE,
)
_MAX_ITEMS = 50
_MAX_TITLE_LEN = 200
_MAX_TEXT_LEN = 4000
# Bounds for the persisted workflow ``params`` (see ``_normalize_plan_params``).
# _MAX_PARAMS mirrors workflow._MAX_PARAMS; the name rule mirrors
# workflow._PARAM_NAME_RE (kept local so plan.py doesn't depend on the tool).
_MAX_PARAMS = 30
_MAX_PARAM_VALUE_LEN = 512
_PARAM_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_DEFAULT_WAIT_SECONDS = DEFAULT_PLAN_WAIT_SECONDS
_MAX_WAIT_SECONDS = MAX_PLAN_WAIT_SECONDS
_WAIT_SECONDS_ERROR = (
    f"'seconds' must be an integer or ASCII digit string from 1 to {_MAX_WAIT_SECONDS}"
)

# Short ceilings for the two best-effort channel pushes so a stuck channel /
# outbound handler can never hang a turn (the registry execute ceiling is much
# larger when a checkpoint is blocking on the user — see resolve_call_timeout).
_LIVE_UPDATE_TIMEOUT_S = 10
_CARD_SEND_TIMEOUT_S = 10


# Sort floor for a plan whose timestamp is missing or unreadable, so it ranks as
# the oldest instead of wherever its raw string happens to fall.
_OLDEST = datetime.min.replace(tzinfo=UTC)


def _now() -> str:
    return datetime.now(UTC).isoformat()


def _parse_stamp(raw: Any) -> datetime | None:
    """Parse a persisted ISO timestamp, or ``None`` if it is missing/unreadable.

    A persisted naive timestamp is read as UTC. ``_now`` writes offset-aware
    values, so naive only shows up in hand-edited or legacy plan files.
    """
    text = str(raw or "").strip()
    if not text:
        return None
    try:
        stamp = datetime.fromisoformat(text)
    except ValueError:
        return None
    return stamp if stamp.tzinfo is not None else stamp.replace(tzinfo=UTC)


def _is_before(raw: Any, cutoff: datetime) -> bool:
    """True iff the persisted ISO timestamp *raw* is strictly older than *cutoff*.

    Fail-SAFE on anything unparseable (missing, blank, hand-edited garbage):
    returns False, i.e. "not old enough to retire". An undatable plan is never
    aged out on a guess — the per-recipe count rule still bounds it.
    """
    stamp = _parse_stamp(raw)
    return stamp is not None and stamp < cutoff


def _as_bool(value: Any) -> bool:
    """Coerce a persisted flag that *should* be a bool but may arrive as a string.

    A hand-edited plan JSON can store ``superseded`` as the string ``"false"`` —
    and ``bool("false")`` is ``True``, which would wrongly hide an active plan
    (superseded ⇒ excluded from ``list_active``). Only a real ``True`` or a
    ``"true"``-ish string counts; everything else stays ``False``. Mirrors
    ``workflow._as_bool`` (kept local so plan.py doesn't depend on the tool).
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "on"}
    return False


def _norm_verification(raw: Any) -> str:
    """Coerce a persisted verification value into the allowed set.

    Guards against null / missing / typo values (which ``str(...)`` would turn
    into ``"None"`` / ``""``) so the field is always one of pending|passed|failed.
    Surrounding whitespace is trimmed and case is folded so a hand-edited
    "Passed" / "passed " round-trips to its verdict instead of silently
    downgrading to "pending".
    """
    value = str(raw or "pending").strip().lower()
    return value if value in _VALID_VERIFICATIONS else "pending"


def _norm_status(raw: Any) -> str:
    """Coerce a persisted status into the known set (case/whitespace-tolerant).

    Mirrors ``_norm_verification``: a hand-edited "Done" / "done " must still
    register as terminal so load-time invariant repair (done ⇒ passed) and the
    terminal-state checks fire, and an unrecognized status falls back to
    "not_started" rather than persisting an unknown state.
    """
    value = str(raw or "not_started").strip().lower()
    return value if value in _VALID_STATUSES else "not_started"


def _norm_text(raw: Any) -> str:
    """Coerce a persisted text value to a string, mapping only null → "".

    Unlike ``str(raw or "")``, a falsy-but-valid value (e.g. 0, False) is
    preserved as its ``str()`` rather than blanked; only a JSON null (None)
    becomes "". This keeps the null-guard without dropping valid content.
    """
    return "" if raw is None else str(raw)


def _normalize_plan_params(raw: Any) -> dict[str, str]:
    """Coerce a workflow run's resolved parameters into a safe ``{name: value}``.

    Applied on BOTH write (``PlanTool._create``) and read (``Plan.from_dict``) so
    a hand-edited plan file and a freshly-created one obey the same bounds. This
    matters more than for the other persisted fields: ``workflow resume`` feeds
    these values back through ``_substitute_params`` into the resumed run's
    prompt, so an unbounded value would be unbounded prompt text.

    Names must be ``{placeholder}``-safe (they are matched by the substitution
    regex), values are stringified/stripped/capped, blanks are dropped, and the
    entry count is bounded. Anything that isn't a dict yields ``{}``.
    """
    if not isinstance(raw, dict):
        return {}
    out: dict[str, str] = {}
    for key, value in raw.items():
        if len(out) >= _MAX_PARAMS:
            break
        name = str(key)
        if not _PARAM_NAME_RE.match(name):
            continue
        if value is None:
            continue
        text = str(value).strip()[:_MAX_PARAM_VALUE_LEN]
        if not text:
            continue
        out[name] = text
    return out


def _safe_session_filename(session_id: str) -> str:
    """Sanitize a session id into a safe plan filename component."""
    safe = session_id.replace(":", "_").replace("/", "_").replace("\\", "_")
    safe = re.sub(r"[^A-Za-z0-9_\-.]", "_", safe)
    return safe[:200] or "default"


# ── Data model ──────────────────────────────────────────────────────────────


def _find_dependency_cycle(items: list[PlanItem]) -> list[str] | None:
    """Return one cycle in ``depends_on`` as a readable id chain, or None.

    Ids that name no item are ignored rather than treated as edges: a typo
    should not be reported as a cycle, and traversal already treats an unknown
    dependency as satisfied so it cannot deadlock a run.

    Iterative DFS with an explicit stack — a plan is small, but recursion depth
    should never be a function of caller-supplied data.
    """
    graph = {str(it.id): [str(d) for d in (it.depends_on or [])] for it in items}
    known = set(graph)
    WHITE, GREY, BLACK = 0, 1, 2
    colour = dict.fromkeys(graph, WHITE)

    for root in graph:
        if colour[root] != WHITE:
            continue
        stack: list[tuple[str, int]] = [(root, 0)]
        path: list[str] = [root]
        colour[root] = GREY
        while stack:
            node, index = stack[-1]
            deps = [d for d in graph[node] if d in known]
            if index >= len(deps):
                colour[node] = BLACK
                stack.pop()
                path.pop()
                continue
            stack[-1] = (node, index + 1)
            nxt = deps[index]
            if colour[nxt] == GREY:
                start = path.index(nxt)
                return [*path[start:], nxt]
            if colour[nxt] == WHITE:
                colour[nxt] = GREY
                stack.append((nxt, 0))
                path.append(nxt)
    return None


@dataclass
class PlanItem:
    id: str
    title: str
    acceptance: str = ""
    status: str = "not_started"
    note: str = ""
    evidence: str = ""
    depends_on: list[str] = field(default_factory=list)
    started_at: str = ""
    completed_at: str = ""
    # Verification verdict. Invariant: a "done" item is always "passed"
    # (status=="done" ⇒ verification=="passed"). "skipped" is terminal for
    # completion but is not gated, so it is not required to be "passed".
    # Dormant in Tier-0 (recorded, not yet enforced); the strict done-gate that
    # *reads* it lands in the verification step.
    verification: str = "pending"  # pending | passed | failed
    # Opt-in objective-verification command (shell/assert) for this item.
    # DECLARATIVE ONLY — plan.py never runs it; the verify action nudges the
    # agent to run it via the shell tool (already approval-gated) and pass the
    # output as evidence. Declaring a check does NOT gate ``done`` — only a
    # non-empty ``acceptance`` (with evidence) does; a check-only item can be
    # marked done without running the check (guided, not enforced).
    check: str = ""

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> PlanItem:
        return cls(
            id=str(d.get("id") or uuid.uuid4().hex[:8]),
            title=_norm_text(d.get("title")).strip()[:_MAX_TITLE_LEN],
            acceptance=_norm_text(d.get("acceptance")).strip()[:_MAX_TEXT_LEN],
            status=_norm_status(d.get("status")),
            # ``_norm_text`` maps a persisted JSON null to "" (not the literal
            # "None" — which would, e.g., let _verify read "None" as real
            # evidence) while preserving a falsy-but-valid value like 0/False.
            note=_norm_text(d.get("note"))[:_MAX_TEXT_LEN],
            evidence=_norm_text(d.get("evidence"))[:_MAX_TEXT_LEN],
            depends_on=[str(x) for x in (d.get("depends_on") or [])],
            # ``_norm_text`` maps a persisted JSON null to "" (not the literal
            # "None", which would read as a present timestamp).
            started_at=_norm_text(d.get("started_at")),
            completed_at=_norm_text(d.get("completed_at")),
            # Faithful deserialization only — the load-time grandfather
            # (terminal status ⇒ passed) lives in Plan.from_dict, never here, so
            # the create path (which also calls this) can clamp instead.
            # ``_norm_verification`` guards null/typo values from breaking the
            # pending|passed|failed contract.
            verification=_norm_verification(d.get("verification")),
            # Declarative verify command; blank/whitespace -> "" (treated as no
            # check) so a truthiness test can't fire on "   ". Capped at
            # _MAX_TEXT_LEN like the other persisted text fields.
            check=_norm_text(d.get("check")).strip()[:_MAX_TEXT_LEN],
        )


@dataclass
class Checkpoint:
    ts: str
    summary: str
    next_step: str = ""
    asked_user: bool = False
    # True once a blocking ask_user checkpoint has been resolved (approved/denied/
    # expired). An approved checkpoint keeps asked_user=true and no follow-up
    # checkpoint is appended, so `resolved` is what distinguishes "still waiting"
    # from "was approved and the run moved on" for status classification.
    resolved: bool = False
    # Persisted approval result. Empty is legacy/unknown and must remain
    # fail-closed. Values mirror ApprovalStatus.value.
    outcome: str = ""


@dataclass
class Plan:
    session_id: str
    items: list[PlanItem] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)
    # Label only: which SOP this plan follows (e.g. "implement-feature"). It is
    # NOT an execution handle — a WorkflowTool run sets it so status/resume can
    # correlate the plan back to its recipe, but setting it here runs nothing.
    workflow: str = ""
    created_at: str = ""
    updated_at: str = ""
    # ISO timestamp of the agent loop iteration that received the
    # "plan just completed — deliver the result" nudge. Used to fire
    # that nudge exactly once per completion (prevents nagging on every
    # follow-up user turn). Empty until the nudge has been delivered.
    delivered_at: str = ""
    # The background_task_id of the run that created this plan (workflow 6d-1).
    # Lets `workflow status` correlate an in-flight run to its plan EXACTLY (by
    # task id, which is owner-scoped) instead of by recipe name — no cross-session
    # leak. Empty for plans not created inside a background workflow run.
    origin_task: str = ""
    # The owner (caller/parent session) of the workflow run that created this
    # plan (workflow 6d-3). Lets `workflow status`/`resume` scope interrupted
    # (orphaned) runs to the caller — an active plan from another session must
    # NOT be surfaced or discarded. Empty for non-workflow plans.
    owner: str = ""
    # The resolved parameter values of the workflow run that created this plan.
    # `workflow resume` restores them so a parameterized recipe can be resumed
    # without the user re-typing every value. It MUST live here rather than on
    # the in-memory BackgroundTask record: that record dies with the process (and
    # is evicted after `result_retention` finishes), while the whole point of an
    # orphan plan is that it survives the crash/restart that stranded the run.
    # Empty for non-workflow plans and for unparameterized recipes.
    params: dict[str, str] = field(default_factory=dict)
    # Retired-as-a-resumable-orphan marker (workflow 6d-3). A superseded plan is
    # KEPT on disk (its record survives) but excluded from ``list_active`` so it
    # neither re-surfaces as interrupted nor accumulates in active scans. Set by
    # ``PlanStore.supersede`` when a resume run takes over.
    superseded: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "workflow": self.workflow,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "delivered_at": self.delivered_at,
            "origin_task": self.origin_task,
            "owner": self.owner,
            "params": dict(self.params),
            "superseded": self.superseded,
            "items": [asdict(it) for it in self.items],
            "checkpoints": [asdict(cp) for cp in self.checkpoints],
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Plan:
        items = [PlanItem.from_dict(x) for x in (d.get("items") or [])]
        # Load-time normalization: a persisted "done" item must be "passed" to
        # satisfy the invariant (done ⇒ passed). This both upgrades plans
        # written before the verification field existed and repairs any
        # inconsistent persisted value. "skipped" is not gated, so it is left
        # as-is; the create path clamps rather than normalizes.
        for it in items:
            if it.status == "done":
                it.verification = "passed"
        return cls(
            session_id=str(d.get("session_id", "")),
            # Collapse whitespace/newlines + cap the same way _create does, so a
            # legacy or hand-edited plan with an embedded newline can't break the
            # exact-string `resume name=<recipe>` match or the `wf in
            # inflight_recipes` live-run suppression.
            workflow=" ".join(str(d.get("workflow", "") or "").split())[:200],
            created_at=str(d.get("created_at", "")),
            updated_at=str(d.get("updated_at", "")),
            delivered_at=str(d.get("delivered_at", "")),
            # Normalize the same way _create does (null → "", strip, cap 64) so a
            # persisted null/whitespace value can't become "None" or a padded id
            # and break exact task-id correlation.
            origin_task=str(d.get("origin_task") or "").strip()[:64],
            owner=str(d.get("owner") or "").strip()[:200],
            # Normalized on load as well as on create: these values are replayed
            # into a resumed run's prompt, so a hand-edited plan must not be able
            # to smuggle an unbounded / non-placeholder-safe value through.
            # Earlier revisions of PR #631 persisted this as ``workflow_params``
            # before #637 established ``params`` as the canonical Plan field.
            # Keep a load-only fallback for Plans written by those builds; all
            # new writes use ``params``.
            params=_normalize_plan_params(d.get("params") or d.get("workflow_params")),
            superseded=_as_bool(d.get("superseded", False)),
            items=items,
            checkpoints=[Checkpoint(**x) for x in (d.get("checkpoints") or [])],
        )

    @property
    def progress(self) -> tuple[int, int]:
        """(done_count, total_count) — skipped counts as done for progress."""
        done = sum(1 for it in self.items if it.status in _TERMINAL_STATUSES)
        return done, len(self.items)

    @property
    def active_item(self) -> PlanItem | None:
        for it in self.items:
            if it.status == "in_progress":
                return it
        return None

    @property
    def is_complete(self) -> bool:
        return bool(self.items) and all(it.status in _TERMINAL_STATUSES for it in self.items)


# ── Persistent store ────────────────────────────────────────────────────────


class PlanStore:
    """Per-session JSON-file plan storage.

    Each session has at most one plan. The store is process-safe via atomic
    write (write-temp + rename) and tolerates concurrent reads.
    """

    def __init__(self, data_dir: Path | None = None) -> None:
        if data_dir is None:
            from praestoclaw.utils.helpers import get_data_dir

            data_dir = get_data_dir()
        self._root = data_dir / "plans"
        self._root.mkdir(parents=True, exist_ok=True)

    def path_for(self, session_id: str) -> Path:
        return self._root / f"{_safe_session_filename(session_id)}.json"

    def exists(self, session_id: str) -> bool:
        return self.path_for(session_id).is_file()

    def load(self, session_id: str) -> Plan | None:
        path = self.path_for(session_id)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            logger.warning("Plan file unreadable: {} ({})", path, exc)
            return None
        return Plan.from_dict(data)

    def save(self, plan: Plan) -> None:
        plan.updated_at = _now()
        path = self.path_for(plan.session_id)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(plan.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        tmp.replace(path)

    def delete(self, session_id: str) -> bool:
        path = self.path_for(session_id)
        if path.is_file():
            path.unlink()
            return True
        return False

    def supersede(
        self,
        session_id: str,
        *,
        expect_owner: str | None = None,
        expect_workflow: str | None = None,
    ) -> bool:
        """Retire a plan as a resumable workflow orphan — but KEEP it on disk.

        Clears ``origin_task`` (the resumable-orphan link ``_orphan_runs`` keys
        off) so a superseded run stops showing as interrupted, while its record
        (done vs remaining) survives. Used by ``workflow resume``: unlike a
        delete, if the resume run crashes before persisting its own plan the old
        one is still recoverable, not lost. Returns True if a plan was updated.

        ``expect_owner`` / ``expect_workflow`` scope the retire: when given, the
        target plan is only superseded if its ``owner`` / ``workflow`` match. The
        deferred-supersede path (``_create`` via ``workflow_supersede_prev``)
        passes both so a resume run can retire ONLY its own predecessor — a
        forged/guessed session id pointing at another owner's or another recipe's
        plan is refused, never retired.
        """
        plan = self.load(session_id)
        if plan is None or plan.superseded:
            return False
        if expect_owner is not None and plan.owner != expect_owner:
            return False
        if expect_workflow is not None and plan.workflow != expect_workflow:
            return False
        plan.superseded = True
        plan.origin_task = ""  # also drop the orphan link (belt-and-braces)
        self.save(plan)
        return True

    def list_active(self) -> list[Plan]:
        """Non-complete, non-superseded plans with items, newest first.

        Superseded plans (retired workflow orphans, 6d-3) are kept on disk for
        recovery but excluded here so they don't accumulate in active scans.
        """
        plans: list[Plan] = []
        for path in sorted(
            self._root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True
        ):
            try:
                p = Plan.from_dict(json.loads(path.read_text(encoding="utf-8")))
            except Exception as exc:  # noqa: BLE001
                logger.debug("Skipping unreadable plan {}: {}", path, exc)
                continue
            if not p.is_complete and not p.superseded and p.items:
                plans.append(p)
        return plans

    def prune_stale_orphans(self, *, max_age_days: int, max_per_recipe: int) -> int:
        """Retire workflow orphans that will never be resumed. Returns the count.

        An interrupted workflow run leaves an active plan behind, and there are
        only two ways out of ``list_active``: the plan completes, or a ``resume``
        supersedes it. A user who answers a timeout by re-running from scratch
        instead of resuming takes neither exit, so that orphan stays "interrupted"
        forever — and every later timeout adds one more, monotonically. Once a
        recipe has several, ``resume`` stops being one-click ("N interrupted runs
        — provide task_id") and ``status`` fills with runs nobody will ever finish.

        Two independent rules, both scoped to plans that are unambiguously
        workflow orphans (``workflow`` AND ``origin_task`` set, not yet
        superseded) so an ordinary long-lived user plan is never touched:

        * age — untouched for longer than ``max_age_days``;
        * count — beyond the newest ``max_per_recipe`` per ``(owner, workflow)``.

        Retires via :meth:`supersede`, so nothing is deleted: the file stays on
        disk and the run's record survives, it just stops being offered as
        resumable. Best-effort — never raises (a failed prune must not block
        startup).
        """
        if max_age_days <= 0 and max_per_recipe <= 0:
            return 0
        try:
            orphans = [p for p in self.list_active() if p.workflow and p.origin_task]
        except Exception as exc:  # noqa: BLE001 - pruning is best-effort
            logger.debug("Orphan prune skipped (plan scan failed): {}", exc)
            return 0
        # Newest first, so the per-recipe cap keeps the most recent runs. Sort on
        # the PARSED stamp: a raw-string sort would rank hand-edited garbage like
        # "not-a-date" above real ISO stamps (lexicographically 'n' > '2') and let
        # it survive the count rule at a newer plan's expense. Missing/unreadable
        # stamps sort last (treated as oldest) rather than crashing the sort.
        orphans.sort(
            key=lambda p: _parse_stamp(p.updated_at or p.created_at) or _OLDEST, reverse=True
        )
        cutoff = datetime.now(UTC) - timedelta(days=max_age_days) if max_age_days > 0 else None
        seen_per_recipe: dict[tuple[str, str], int] = {}
        pruned = 0
        for plan in orphans:
            reason = ""
            key = (plan.owner, plan.workflow)
            seen = seen_per_recipe[key] = seen_per_recipe.get(key, 0) + 1
            if max_per_recipe > 0 and seen > max_per_recipe:
                reason = f"more than {max_per_recipe} orphans for this recipe"
            elif cutoff is not None and _is_before(plan.updated_at or plan.created_at, cutoff):
                reason = f"untouched for over {max_age_days}d"
            if not reason:
                continue
            try:
                if self.supersede(plan.session_id):
                    pruned += 1
                    logger.info(
                        "Retired stale workflow orphan session={} workflow={} reason={}",
                        plan.session_id,
                        plan.workflow,
                        reason,
                    )
            except Exception as exc:  # noqa: BLE001 - one bad plan must not stop the sweep
                logger.debug("Orphan prune failed for {}: {}", plan.session_id, exc)
        return pruned

    def list_all(self) -> list[Plan]:
        plans: list[Plan] = []
        for path in sorted(
            self._root.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True
        ):
            try:
                plans.append(Plan.from_dict(json.loads(path.read_text(encoding="utf-8"))))
            except Exception as exc:  # noqa: BLE001
                logger.debug("Skipping unreadable plan {}: {}", path, exc)
                continue
        return plans


# Module-level singleton — the agent loop uses it to read the active plan
# without instantiating the tool itself.
_default_store: PlanStore | None = None


def get_plan_store() -> PlanStore:
    global _default_store  # noqa: PLW0603
    if _default_store is None:
        _default_store = PlanStore()
    return _default_store


# ── Rendering helpers ───────────────────────────────────────────────────────

_STATUS_ICON = {
    "not_started": "[ ]",
    "in_progress": "[▶]",
    "blocked": "[!]",
    "done": "[✓]",
    "skipped": "[~]",
}

# Pretty-print status icons for live-update messages (rendered in chat
# clients that support emoji + Markdown; falls back to monochrome blocks
# in plain terminals).
_STATUS_PILL = {
    "not_started": ("⚪", "Default"),
    "in_progress": ("🔵", "Accent"),
    "blocked": ("🟡", "Warning"),
    "done": ("🟢", "Good"),
    "skipped": ("⚫", "Default"),
}

# Adaptive Card schema constants — duplicated here (rather than imported
# from channels/teams_cards) to keep the agent-tool layer free of
# channel-specific imports. Cards are pure dicts the channel forwards
# verbatim; both teams_cards.wrap_for_teams and the cloud channel's
# _extract_card_from_activity_json key off the same content type.
_AC_SCHEMA = "http://adaptivecards.io/schemas/adaptive-card.json"
_AC_VERSION = "1.4"
_AC_CONTENT_TYPE = "application/vnd.microsoft.card.adaptive"


def _blocked_detail(item: PlanItem) -> str:
    """Return the user-visible blocker detail, preferring the explicit note."""
    detail = item.note.strip() or item.evidence.strip()
    return " ".join(redact_credentials(detail).split())


def render_plan(plan: Plan, *, compact: bool = False) -> str:
    """Render a plan as a short text block suitable for tool output / prompts."""
    if not plan.items:
        return "(plan is empty)"
    done, total = plan.progress
    header_bits = [f"Plan ({done}/{total} done)"]
    if plan.workflow:
        header_bits.append(f"workflow={plan.workflow}")
    lines = [" — ".join(header_bits)]
    for i, it in enumerate(plan.items, 1):
        icon = _STATUS_ICON.get(it.status, "[?]")
        line = f"  {i}. {icon} {it.title}"
        if it.status == "blocked":
            blocked_detail = _blocked_detail(it)
            if blocked_detail:
                line += f"   ⚠ {blocked_detail[:120]}"
        lines.append(line)
    if not compact and plan.checkpoints:
        last = plan.checkpoints[-1]
        lines.append(f"\nLast checkpoint: {last.summary[:200]}")
    return "\n".join(lines)


# Per-item evidence cap inside the completion nudge. Each item's evidence
# is already capped at _MAX_TEXT_LEN at write time; we cap again here so a
# plan with many items can't blow up the nudge into a multi-thousand-token
# system message that itself competes for attention.
_NUDGE_EVIDENCE_PER_ITEM = 1200


def _plan_complete_nudge(plan: Plan) -> str:
    """Build the 'plan just finished — deliver the result' nudge.

    Inlines each item's collected evidence so the actual data the user
    asked for sits right next to the deliver instruction. Without this,
    the LLM tends to produce a vague "task complete — see above" reply
    even though the original tool output is buried many turns earlier
    in the conversation.
    """
    lines: list[str] = []
    for it in plan.items:
        ev = (it.evidence or "").strip()
        if not ev:
            continue
        if len(ev) > _NUDGE_EVIDENCE_PER_ITEM:
            ev = ev[:_NUDGE_EVIDENCE_PER_ITEM] + " […evidence truncated]"
        lines.append(f"- **{it.title}** — evidence:\n{ev}")
    evidence_block = ""
    if lines:
        evidence_block = (
            "\n\n**Evidence collected during this plan** "
            "(this is the actual data the user asked for; quote or "
            "paraphrase it directly in your reply):\n\n" + "\n\n".join(lines)
        )
    return (
        "\n\n🎯 **All plan items are now done.**"
        + evidence_block
        + "\n\nYour next message MUST be your final assistant reply to "
        "the user, and it MUST contain the actual answer / data the "
        "user asked for — not just a 'task complete / 任务完成' "
        "acknowledgement, and not a vague 'see above / 以上是…' that "
        "points at the plan card. If any item's title was about "
        "reporting / telling / 报告 / 告诉 / 汇报 the user, the "
        "substance of that report goes into the assistant reply "
        "itself — not into another tool call."
    )


# ── Adaptive Card builder for live progress (Teams / Web Chat) ─────────────


def _ac_text(
    text: str,
    *,
    weight: str | None = None,
    size: str | None = None,
    color: str | None = None,
    is_subtle: bool = False,
    spacing: str | None = None,
    wrap: bool = True,
    font_type: str | None = None,
    horizontal_alignment: str | None = None,
) -> dict[str, Any]:
    """Tiny helper to build an Adaptive Card TextBlock dict."""
    block: dict[str, Any] = {"type": "TextBlock", "text": text, "wrap": wrap}
    if weight:
        block["weight"] = weight
    if size:
        block["size"] = size
    if color:
        block["color"] = color
    if is_subtle:
        block["isSubtle"] = True
    if spacing:
        block["spacing"] = spacing
    if font_type:
        block["fontType"] = font_type
    if horizontal_alignment:
        block["horizontalAlignment"] = horizontal_alignment
    return block


# Unicode block characters used to draw the progress bar. ▰ (U+25B0) for
# filled cells, ▱ (U+25B1) for empty — both visually balanced in
# proportional and monospace fonts, so the bar renders the same on
# Teams desktop, Teams web, and Outlook actionable messages.
_BAR_FILLED = "\u25b0"
_BAR_EMPTY = "\u25b1"


def _ac_progress_text(done: int, total: int, *, segments: int = 14) -> dict[str, Any]:
    """Render the progress bar as a single bold monospace TextBlock.

    Avoids the multi-Container approach (which Teams rendered as one
    flat grey strip — the per-cell ``style`` colours were collapsed by
    the host's column compaction). Block characters always render and
    align identically across renderers.
    """
    total_safe = max(total, 1)
    filled = round(segments * done / total_safe)
    bar = _BAR_FILLED * filled + _BAR_EMPTY * (segments - filled)
    pct = round(100 * done / total_safe)
    color = "Good" if done == total else ("Accent" if done > 0 else "Default")
    return _ac_text(
        f"{bar}  {pct}%",
        font_type="Monospace",
        weight="Bolder",
        size="Medium",
        color=color,
        spacing="Medium",
    )


def _ac_item_row(item: PlanItem) -> dict[str, Any]:
    """Render a single plan item as a 2-column row (status pill + title).

    No leading numeric prefix — Adaptive Card's markdown renderer
    re-numbers ordered lists per TextBlock, which made every item show
    up as "1." in Teams. The status pill carries the visual anchor
    instead.
    """
    pill_glyph, _ac_color = _STATUS_PILL.get(item.status, ("\u26aa", "Default"))
    if item.status == "done":
        title_color: str | None = "Good"
        title_subtle = True
        title_weight: str | None = None
        title_text = f"~~{item.title}~~"
    elif item.status == "in_progress":
        title_color = "Accent"
        title_subtle = False
        title_weight = "Bolder"
        title_text = item.title
    elif item.status == "blocked":
        title_color = "Warning"
        title_subtle = False
        title_weight = "Bolder"
        title_text = item.title
    elif item.status == "skipped":
        title_color = "Default"
        title_subtle = True
        title_weight = None
        title_text = f"~~{item.title}~~"
    else:  # not_started
        title_color = None
        title_subtle = True
        title_weight = None
        title_text = item.title

    title_block = _ac_text(
        title_text,
        weight=title_weight,
        color=title_color,
        is_subtle=title_subtle,
    )
    extras: list[dict[str, Any]] = [title_block]
    if item.status == "blocked":
        blocked_detail = _blocked_detail(item)
        if blocked_detail:
            extras.append(
                _ac_text(
                    f"\u26a0 {blocked_detail[:120]}",
                    color="Warning",
                    is_subtle=True,
                    spacing="None",
                )
            )
    return {
        "type": "ColumnSet",
        "spacing": "Small",
        "columns": [
            {
                "type": "Column",
                "width": "auto",
                "verticalContentAlignment": "Center",
                "items": [
                    _ac_text(pill_glyph, size="Medium"),
                ],
            },
            {
                "type": "Column",
                "width": "stretch",
                "items": extras,
            },
        ],
    }


# Footer styles — pick a Container `style` that matches the action
# semantics so the action banner reads at a glance.
_FOOTER_STYLE_DEFAULT = "default"
_FOOTER_STYLE_BY_OUTCOME: dict[str, str] = {
    "good": "good",
    "accent": "accent",
    "warning": "warning",
    "attention": "attention",
    "default": "default",
}


def _ac_footer(text: str, style: str) -> dict[str, Any]:
    """Wrap a footer line in a coloured Container — gives it card-pill prominence."""
    return {
        "type": "Container",
        "style": _FOOTER_STYLE_BY_OUTCOME.get(style, _FOOTER_STYLE_DEFAULT),
        "spacing": "Medium",
        "bleed": True,
        "items": [
            _ac_text(text, weight="Bolder", wrap=True),
        ],
    }


def build_progress_card(
    plan: Plan,
    *,
    action: str,
    last_item: PlanItem | None = None,
    last_status: str = "",
    note: str = "",
) -> dict[str, Any]:
    """Build a Bot Framework activity wrapping an Adaptive Card.

    The card is the same dict shape ``teams_cards.wrap_for_teams`` produces
    so the cloud channel's ``_extract_card_from_activity_json`` hoists it
    transparently into the gateway notify body's ``content.card`` field.

    Args:
        plan: The current plan after the action has been applied.
        action: The plan action that triggered this update — drives the
            footer message ("Plan created", "Verified: X", "Plan complete").
        last_item: Item touched by the action (for ``update`` / ``verify``).
        last_status: Outcome string from ``_verify`` ("FAILED" / "PARTIAL"
            / "" for success).
        note: Free-form note (used for checkpoint / report summaries).
    """
    done, total = plan.progress
    is_complete = plan.is_complete
    pct = round(100 * done / max(total, 1))

    # Header band: title + progress fraction badge.
    header_color = "Good" if is_complete else ("Accent" if 0 < done else "Default")
    header_text = "\U0001f4cb \u8ba1\u5212\u8fdb\u5ea6"  # 📋 计划进度
    if action == "create":
        header_text = "\U0001f4cb \u4efb\u52a1\u8ba1\u5212\u5df2\u521b\u5efa"  # 任务计划已创建
    if is_complete:
        header_text = "\U0001f389 \u8ba1\u5212\u5b8c\u6210"  # 🎉 计划完成
    header = {
        "type": "ColumnSet",
        "columns": [
            {
                "type": "Column",
                "width": "stretch",
                "items": [
                    _ac_text(
                        header_text,
                        weight="Bolder",
                        size="Large",
                        color=header_color,
                    ),
                ],
            },
            {
                "type": "Column",
                "width": "auto",
                "verticalContentAlignment": "Center",
                "items": [
                    _ac_text(
                        f"{done}/{total} \u00b7 {pct}%",
                        weight="Bolder",
                        size="Medium",
                        color=header_color,
                        horizontal_alignment="Right",
                    ),
                ],
            },
        ],
    }
    body: list[dict[str, Any]] = [header]

    # Workflow tag line (optional).
    if plan.workflow:
        body.append(
            _ac_text(
                f"workflow \u00b7 {plan.workflow}",
                size="Small",
                is_subtle=True,
                spacing="None",
            )
        )

    # Unicode-block progress bar — single bold monospace TextBlock, so
    # all rendering hosts (Teams desktop / web / mobile, Outlook,
    # bf-emulator) draw it identically.
    body.append(_ac_progress_text(done, total))

    # Item list — emphasis container clusters the rows visually and
    # provides a subtle background tint that separates them from the
    # header / progress bar above.
    body.append(
        {
            "type": "Container",
            "style": "emphasis",
            "spacing": "Medium",
            "items": [_ac_item_row(it) for it in plan.items],
        }
    )

    # Footer: a colour-styled Container so the latest action reads as
    # a prominent banner, not a plain sentence.
    footer_text = ""
    footer_style = "accent"
    if action == "create":
        footer_text = f"\U0001f680 \u5df2\u751f\u6210 {total} \u4e2a\u6b65\u9aa4\uff0c\u5f00\u59cb\u6267\u884c..."
        footer_style = "accent"
    elif action == "update" and last_item is not None:
        if last_item.status == "done":
            footer_text = f"\u2713 \u5df2\u5b8c\u6210\uff1a{last_item.title}"
            footer_style = "good"
        elif last_item.status == "in_progress":
            footer_text = f"\u25b6 \u6b63\u5728\u6267\u884c\uff1a{last_item.title}"
            footer_style = "accent"
        elif last_item.status == "blocked":
            footer_text = f"\u26a0 \u53d7\u963b\uff1a{last_item.title}"
            footer_style = "warning"
        elif last_item.status == "skipped":
            footer_text = f"\u21b7 \u5df2\u8df3\u8fc7\uff1a{last_item.title}"
            footer_style = "default"
        else:
            footer_text = f"\u25cb \u5f85\u529e\uff1a{last_item.title}"
            footer_style = "default"
    elif action == "verify" and last_item is not None:
        if last_status == "FAILED":
            footer_text = f"\u274c \u9a8c\u8bc1\u5931\u8d25\uff1a{last_item.title}"
            footer_style = "attention"
        elif last_status == "PARTIAL":
            footer_text = f"\u26a0 \u9a8c\u8bc1\u90e8\u5206\u901a\u8fc7\uff1a{last_item.title}"
            footer_style = "warning"
        else:
            footer_text = f"\u2705 \u5df2\u9a8c\u8bc1\uff1a{last_item.title}"
            footer_style = "good"
    elif action == "checkpoint" and note:
        footer_text = f"\U0001f4cd \u68c0\u67e5\u70b9\uff1a{note[:160]}"
        footer_style = "accent"
    elif action == "report" and note:
        footer_text = f"\U0001f4e3 \u8fdb\u5ea6\uff1a{note[:160]}"
        footer_style = "accent"

    if is_complete:
        footer_text = (
            "\U0001f389 \u5168\u90e8\u6b65\u9aa4\u5df2\u5b8c\u6210 "
            "\u2014 \u73b0\u5728\u7528\u4e00\u6bb5\u8bdd\u628a\u5b9e\u9645"
            "\u7ed3\u679c\u544a\u8bc9\u7528\u6237\u3002"
        )
        footer_style = "good"

    if footer_text:
        body.append(_ac_footer(footer_text, footer_style))

    card = {
        "type": "AdaptiveCard",
        "$schema": _AC_SCHEMA,
        "version": _AC_VERSION,
        "body": body,
    }
    return {
        "type": "message",
        "attachments": [
            {"contentType": _AC_CONTENT_TYPE, "content": card},
        ],
    }


# ── The Tool ────────────────────────────────────────────────────────────────


class PlanTool(Tool):
    """Structured task plan with persistence and self-verification."""

    risk_range = (0, 2)

    def __init__(self, store: PlanStore | None = None, bus: Any = None) -> None:
        self._store = store or get_plan_store()
        self._session_resolver: Any = None  # set by runtime → returns current session_id
        self._bus = bus  # optional MessageBus — used to push live progress messages
        # Optional approval wiring. When both are set, a
        # ``checkpoint(ask_user=true)`` blocks on the ApprovalManager until the
        # user resolves it — so a detached background worker can await a dry-run
        # confirmation out of band (see ``_await_user_approval``). Left unset in
        # internal/test setups, where checkpoint keeps its legacy "end turn" flow.
        self._approval_manager: Any = None
        self._session_store: Any = None
        self._channel_manager: Any = None
        # Upper bound (seconds) a checkpoint will wait for the user before it
        # gives up and tells the model to stop. Also drives the registry
        # timeout ceiling (see ``metadata``) so the await is not killed early.
        self._ask_timeout: int = 1800
        # When True, checkpoint(ask_user=true) auto-approves instead of blocking
        # on a human. Set from security.approval.full_auto via set_full_auto().
        self._full_auto: bool = False
        # Strong refs for fire-and-forget receipt pushes. asyncio only holds a
        # weak reference to a running task, so a bare ``create_task`` can be
        # collected mid-flight and the frame never sent.
        self._receipt_tasks: set[asyncio.Task[None]] = set()

    def set_bus(self, bus: Any) -> None:
        """Inject the message bus so each plan action pushes a live update."""
        self._bus = bus

    def set_approval_manager(self, mgr: Any) -> None:
        """Inject the ApprovalManager so ``checkpoint(ask_user=true)`` can block."""
        self._approval_manager = mgr

    def set_session_store(self, store: Any) -> None:
        """Inject the SQLite session store used for approval-card persistence."""
        self._session_store = store

    def set_full_auto(self, enabled: bool) -> None:
        """Enable/disable full_auto mode for checkpoint auto-approval."""
        self._full_auto = enabled

    def set_channel_manager(self, cm: Any) -> None:
        """Inject the channel manager so the interactive approval card is pushed live."""
        self._channel_manager = cm

    def set_session_resolver(self, fn: Any) -> None:
        """Inject a callable returning the *current* session id for the agent.

        The runtime wires this so the LLM doesn't have to pass session_id on
        every call. If unset, callers must pass ``session_id`` explicitly.
        """
        self._session_resolver = fn

    @property
    def name(self) -> str:
        return "plan"

    @property
    def description(self) -> str:
        return (
            "Manage a persistent, structured task plan for long-running work. "
            "Always create a plan first when the task has 3+ steps or follows a workflow SOP. "
            "Actions: "
            "create (start a plan with ordered items), "
            "update (change item status: not_started|in_progress|blocked|done|skipped), "
            "checkpoint (summarize progress and optionally pause for user input), "
            "wait (general session pacing before checking an external operation again; "
            "no existing Plan required), "
            "report (non-blocking progress note), "
            "verify (validate evidence for a 'done' item — prevents false-completes), "
            "show (return the current plan). "
            "Plans persist across sessions and survive restart."
        )

    @property
    def metadata(self) -> ToolMetadata:
        # Plan writes finish in milliseconds, so 15s is the right static
        # ceiling. The one exception — checkpoint(ask_user=true) blocking on
        # the user — is handled per-call via resolve_call_timeout(), so the
        # long approval wait does NOT inflate the timeout of every other plan
        # action (a stuck channel send on create/update must still fail fast).
        return ToolMetadata(timeout=15, tier="core")

    def resolve_call_timeout(self, args: dict[str, Any]) -> int:
        """Per-call registry timeout (consulted by ToolRegistry.execute).

        Only a ``checkpoint(ask_user=true)`` that will actually block on the
        ApprovalManager needs the approval ceiling, and ``wait`` gets its
        requested delay plus 15 seconds. Every other plan action keeps the fast
        15-second timeout. A group turn never blocks (see
        ``_checkpoint_blocks_on_user``), so it keeps the fast ceiling too.
        """
        if args.get("action") == "checkpoint" and self._checkpoint_blocks_on_user(args):
            return self._ask_timeout + 60
        if args.get("action") == "wait":
            seconds = resolve_plan_wait_seconds(args.get("seconds"))
            return seconds + 15 if seconds is not None else 15
        return 15

    def _checkpoint_blocks_on_user(self, kwargs: dict[str, Any]) -> bool:
        """Whether ``checkpoint(ask_user=true)`` will push a card and block.

        A borrowed-identity group turn (praesto tag exp) answers in the
        conversation, not on a card: the group already confirms scope and diff
        in plain language via ``kb_draft(action="approve")``, and that reply is
        the gate ``kb_publish`` enforces. Pushing an Approve/Deny card on top
        asks the same question twice in two different idioms, and — because the
        card resolves out of band — lets the model treat a button click as the
        group's answer without ever recording their words. So in a group the
        checkpoint degrades to a plain note: say it in chat, end the turn, and
        record the reply when it arrives.
        """
        if not bool(kwargs.get("ask_user")) or self._approval_manager is None:
            return False
        # full_auto mode: auto-approve all checkpoints instead of blocking.
        if self._full_auto:
            return False
        meta = kwargs.get("_metadata")
        return not praesto_tag_exp_is_active(meta if isinstance(meta, dict) else {})

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = args.get("action", "")
        if action == "show":
            return RiskScore(0, reason="Read-only / informational")
        if action == "wait":
            return RiskScore(0, reason="Paced wait - no side effects")
        if action == "report":
            return RiskScore(1, reason="Local plan progress write")
        return RiskScore(1, reason="Local plan-file write")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "create",
                        "update",
                        "checkpoint",
                        "wait",
                        "report",
                        "verify",
                        "show",
                        "delete",
                    ],
                    "description": "Action to perform.",
                },
                "items": {
                    "type": "array",
                    "description": (
                        "For 'create': ordered list of plan items. Each item: "
                        "{title (required), acceptance (recommended — concrete "
                        "completion criterion), check (optional declarative "
                        "verify command), id (optional), depends_on "
                        "(optional list of prior item ids)}."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string"},
                            "title": {"type": "string"},
                            "acceptance": {"type": "string"},
                            "check": {
                                "type": "string",
                                "description": (
                                    "Optional shell command that objectively "
                                    "verifies this item (e.g. 'pytest -q'). "
                                    "DECLARATIVE — the plan tool does not run it; "
                                    "run it yourself and pass output as evidence. "
                                    "Does not gate done."
                                ),
                            },
                            "depends_on": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                        },
                        "required": ["title"],
                    },
                },
                "workflow": {
                    "type": "string",
                    "description": (
                        "For 'create': a label recording which SOP this plan follows "
                        "(e.g. 'implement-feature'). Optional and inert — naming a "
                        "workflow recipe here does NOT run it. To execute a recipe, "
                        "call workflow(action='run', name=...) instead."
                    ),
                },
                "id": {
                    "type": "string",
                    "description": "Item id (or 1-based index as string). Required for update/verify.",
                },
                "status": {
                    "type": "string",
                    "enum": list(_VALID_STATUSES),
                    "description": "New status (for 'update').",
                },
                "note": {
                    "type": "string",
                    "description": "Free-form note (for update / blocked items).",
                },
                "check": {
                    "type": "string",
                    "description": (
                        "Optional declarative verify command for an item (set on "
                        "create's items[] or via update). The plan tool does not "
                        "run it; run it yourself and pass output as evidence."
                    ),
                },
                "evidence": {
                    "type": "string",
                    "description": (
                        "Concrete proof for 'done' items: test output, file diff, "
                        "URL, or shell exit. Required for 'verify'."
                    ),
                },
                "summary": {
                    "type": "string",
                    "description": "For 'checkpoint' or 'report': what just happened.",
                },
                "next_step": {
                    "type": "string",
                    "description": "For 'checkpoint': what you plan to do next.",
                },
                "ask_user": {
                    "type": "boolean",
                    "description": "For 'checkpoint': true = pause and wait for user 'go'.",
                },
                "seconds": {
                    "oneOf": [
                        {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": _MAX_WAIT_SECONDS,
                        },
                        {
                            "type": "string",
                            "pattern": PLAN_WAIT_SECONDS_PATTERN,
                        },
                    ],
                    "default": _DEFAULT_WAIT_SECONDS,
                    "description": (
                        "For 'wait': seconds before the next external-status check; "
                        "accepts an integer or a string containing only ASCII digits."
                    ),
                },
                "session_id": {
                    "type": "string",
                    "description": "Optional override; usually auto-resolved.",
                },
                "replace": {
                    "type": "boolean",
                    "description": (
                        "For 'create': if true, replace any existing plan for this "
                        "session. Default false → reject if a plan already exists."
                    ),
                },
            },
            "required": ["action"],
        }

    def validate(self, args: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        action = args.get("action", "")
        if action not in {
            "create",
            "update",
            "checkpoint",
            "wait",
            "report",
            "verify",
            "show",
            "delete",
        }:
            errors.append(f"Unknown action: {action!r}")
        if action == "create":
            items = args.get("items") or []
            if not isinstance(items, list) or not items:
                errors.append("'items' must be a non-empty list for action='create'")
            elif len(items) > _MAX_ITEMS:
                errors.append(f"Too many items (max {_MAX_ITEMS})")
        if action == "update":
            if not args.get("id"):
                errors.append("'id' is required for action='update'")
            status = args.get("status")
            if status and status not in _VALID_STATUSES:
                errors.append(f"Invalid status: {status!r}")
        if action == "verify":
            if not args.get("id"):
                errors.append("'id' is required for action='verify'")
        if action == "wait" and resolve_plan_wait_seconds(args.get("seconds")) is None:
            errors.append(_WAIT_SECONDS_ERROR)
        return errors

    # ── Execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")
        sid = self._resolve_session_id(kwargs)
        if not sid:
            return (
                "Error: cannot resolve current session_id. "
                "Pass session_id explicitly or ensure the runtime wired the resolver."
            )

        try:
            if action == "create":
                result = self._create(sid, kwargs)
            elif action == "update":
                result = self._update(sid, kwargs)
            elif action == "checkpoint":
                result = self._checkpoint(sid, kwargs)
            elif action == "wait":
                seconds = resolve_plan_wait_seconds(kwargs.get("seconds"))
                if seconds is None:
                    return f"Error: {_WAIT_SECONDS_ERROR}"
                await asyncio.sleep(seconds)
                result = f"Waited {seconds} seconds. Re-check the external operation now."
            elif action == "report":
                result = self._report(sid, kwargs)
            elif action == "verify":
                result = self._verify(sid, kwargs)
            elif action == "show":
                result = self._show(sid)
            elif action == "delete":
                result = self._delete(sid)
            else:
                return f"Error: unknown action {action!r}"
        except Exception as exc:  # noqa: BLE001
            logger.exception("Plan tool error")
            return f"Error: {exc}"

        # A checkpoint(ask_user=true) that's about to render its own
        # interactive Approve/Reject card should NOT also emit the generic
        # "plan progress" card — that produces two stacked cards (the user saw
        # a "计划进度" card immediately followed by the approval card). Detect
        # that case up front and suppress the progress push for it.
        will_await_user = (
            action == "checkpoint"
            and not str(result).startswith("Error")
            and self._checkpoint_blocks_on_user(kwargs)
        )
        meta = kwargs.get("_metadata")
        tag_mode = praesto_tag_exp_is_active(meta if isinstance(meta, dict) else {})

        # Push a short live update to the user's channel so they see
        # intermediate progress (not just the final lump). Skip 'show' and
        # the no-op delete; CLI channel already echoes tool output. Tag-mode
        # meeting tasks keep Plan as internal state only: their final result is
        # delivered to the group, without progress messages or Adaptive Cards.
        if action not in ("show", "wait") and not will_await_user and not tag_mode:
            await self._push_live_update(sid, action, kwargs, result)
            await self._push_progress_frame(sid, kwargs)

        # A checkpoint(ask_user=true) blocks here until the user resolves it,
        # when an approval gate is wired. This is what lets a detached
        # background worker await a dry-run confirmation out of band — its
        # forked session has no inbound routing, so a plain "end turn and wait
        # for the next message" checkpoint could never resume.
        if will_await_user:
            result, delivered = await self._await_user_approval(sid, kwargs, result)
            # The approval card *replaces* the progress card only when it
            # actually reached the user. On any fallback (no channel / CLI /
            # registration or delivery failure) the progress card was
            # suppressed for nothing — emit it now so the user still sees
            # feedback instead of silence. _push_live_update self-skips CLI and
            # missing channel_id, so this is a no-op except on a genuine
            # delivery failure where _channel_id is present (the one case the
            # up-front suppression got wrong).
            if not delivered and action not in ("show",):
                await self._push_live_update(sid, action, kwargs, result)
        return result

    async def _push_progress_frame(self, sid: str, kwargs: dict[str, Any]) -> None:
        """Emit a structured ``task_progress`` frame for a detached run.

        ``_push_live_update`` already sends a one-line note, but that renders as
        an ordinary chat message — the clients' progress panels key off a typed
        frame and had nothing to bind to, so a workflow's plan looked frozen while
        it was in fact advancing. Both front ends already handle this payload
        (chat.js upsertTaskCard, the GUI's ProgressPanel via upsertProgress); the
        only thing missing was a producer for local runs, since the sole existing
        emitter is the A2A/gateway task protocol.

        Only for plans carrying ``origin_task`` — i.e. a background/workflow run
        the user cannot watch inline. A plan created in the user's own turn needs
        no panel entry.

        Routed with ``route_hint=plan.owner`` (the originating connection's
        session_key) so it lands on the tab that started the run rather than
        fanning out to every client.

        Best-effort: never let progress reporting break a plan update.
        """
        if self._bus is None:
            return
        channel_raw = str(kwargs.get("_channel", "") or "")
        channel_id = str(kwargs.get("_channel_id", "") or "")
        if not channel_raw or not channel_id:
            return
        try:
            import json as _json
            from datetime import datetime

            from praestoclaw.bus.events import OutboundMessage
            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
            if ch == ChannelType.INTERNAL:
                return  # nothing renders a panel there
            plan = self._store.load(sid)
            if plan is None or not plan.origin_task or not plan.items:
                return

            # A Teams surface has no consumer for this frame. The browser SPA
            # and the Electron client route it by ``payload.type`` into their
            # progress panels (``routeStructured``), but the Teams bot can only
            # render an activity, so the JSON body lands in the chat as a text
            # bubble — observed twice per plan update, stacked directly beneath
            # the workflow's own progress card. That card is the Teams-side
            # equivalent and is already sent by ``_push_live_update``
            # (``is_teams and ch == ChannelType.CLOUD`` there, same discriminator
            # as here), so suppressing the frame removes noise, not information.
            meta_probe = kwargs.get("_metadata") or {}
            if isinstance(meta_probe, dict):
                probe_source = str(meta_probe.get("source", "")).strip().casefold()
                if probe_source in ("cloud_teams", "teams_bridge"):
                    return

            done, total = plan.progress
            current = next((i for i in plan.items if i.status == "in_progress"), None)
            title = str(getattr(current, "title", "") or "")
            stage = f"{done}/{total}" + (f" {title}" if title else "")

            elapsed_ms: int | None = None
            if plan.created_at:
                try:
                    started = datetime.fromisoformat(plan.created_at)
                    if started.tzinfo is None:
                        started = started.replace(tzinfo=UTC)
                    elapsed_ms = int((datetime.now(UTC) - started).total_seconds() * 1000)
                except ValueError:
                    elapsed_ms = None

            frame = {
                "type": "task_progress",
                "task_id": plan.origin_task,
                "stage": stage,
                "elapsed_ms": elapsed_ms,
                "summary": title or (plan.workflow or "workflow"),
                "details": {"workflow": plan.workflow, "done": done, "total": total},
            }
            metadata: dict[str, Any] = {"keep_context": True}
            meta_in = kwargs.get("_metadata") or {}
            if isinstance(meta_in, dict):
                source = str(meta_in.get("source") or "").strip().casefold()
                push_target = str(meta_in.get("push_target") or "").strip().casefold()
                if source in {"cron", "heartbeat"} and push_target == "teams":
                    metadata["push_target"] = push_target
            # This frame drives the client's progress panels; Teams has none, so
            # there it arrives as a wall of raw JSON between the cards that say
            # the same thing. Emit it where something consumes it.
            if self._plan_owner_is_teams(sid, plan):
                return
            await asyncio.wait_for(
                self._bus.publish_outbound(
                    OutboundMessage(
                        channel=ch,
                        channel_id=channel_id,
                        content=_json.dumps(frame, ensure_ascii=False),
                        route_hint=plan.owner or None,
                        metadata=metadata,
                    )
                ),
                timeout=_LIVE_UPDATE_TIMEOUT_S,
            )
        except Exception as exc:  # noqa: BLE001 - progress must never break a plan write
            logger.debug("plan progress frame skipped: {}", exc)

    async def _push_live_update(
        self, sid: str, action: str, kwargs: dict[str, Any], result: str
    ) -> None:
        """Send a one-line progress message to the originating channel.

        Silent on errors and on channels where it would be redundant (CLI
        already prints tool output inline).
        """
        if self._bus is None:
            return
        if str(result).startswith("Error"):
            return
        channel_raw = kwargs.get("_channel", "")
        channel_id = kwargs.get("_channel_id", "")
        if not channel_raw or not channel_id:
            return
        try:
            from praestoclaw.bus.events import OutboundMessage
            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
            # CLI users already see tool output inline — skip to avoid noise.
            if ch == ChannelType.INTERNAL:
                return
        except Exception:  # noqa: BLE001
            return

        # Loaded once for everything below: the rendered body, the owner check,
        # the card build, and the update_key. Each used to fetch it for itself,
        # so one Teams workflow tick read the same file three times.
        plan = self._store.load(sid)
        body = self._format_live_update(sid, action, kwargs, result, plan)
        if not body:
            return

        # Build a richer Adaptive Card payload when the originating
        # conversation is on Teams (detected via the inbound metadata
        # source the runtime injected as ``_metadata``). Other surfaces
        # keep the markdown body — Web Chat / web UI already render
        # markdown well enough that the spam is acceptable, and we
        # avoid a routing decision (push_target=teams) on conversations
        # that aren't Teams-originated.
        metadata: dict[str, Any] = {"keep_context": True}
        meta_in = kwargs.get("_metadata") or {}
        source = ""
        push_target = ""
        if isinstance(meta_in, dict):
            source = str(meta_in.get("source", "")).strip().casefold()
            push_target = str(meta_in.get("push_target") or "").strip().casefold()
        if source in {"cron", "heartbeat"} and push_target == "teams":
            metadata["push_target"] = push_target
        is_teams = source in ("cloud_teams", "teams_bridge") or self._plan_owner_is_teams(sid, plan)
        outbound_content = body
        if is_teams and ch == ChannelType.CLOUD:
            try:
                activity = self._build_progress_activity(sid, action, kwargs, result, plan)
                if activity is not None:
                    import json as _json

                    outbound_content = _json.dumps(activity, ensure_ascii=False)
                    metadata["push_target"] = "teams"
                    # Pin every progress emit for this plan to the same
                    # Teams activity so the bridge animates one card in
                    # place instead of stacking a new card per tick.
                    # Including ``plan.created_at`` keeps successive plans
                    # in the same session on separate cards (a fresh
                    # ``create`` action gets a fresh activity, then all
                    # its updates / completion overwrite that card).
                    if plan is not None and plan.created_at:
                        metadata["update_key"] = f"plan:{sid}:{plan.created_at}"
            except Exception as exc:  # noqa: BLE001
                logger.debug("Plan progress card build failed (falling back to markdown): {}", exc)

        try:
            await asyncio.wait_for(
                self._bus.publish_outbound(
                    OutboundMessage(
                        channel=ch,
                        channel_id=channel_id,
                        content=outbound_content,
                        # keep_context=True → cloud channel sends as "notification"
                        # frame so the gateway preserves the conversation reply
                        # context for subsequent updates and the final answer.
                        metadata=metadata,
                    )
                ),
                timeout=_LIVE_UPDATE_TIMEOUT_S,
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Plan live-update push failed: {}", exc)

    async def _await_user_approval(
        self, sid: str, kwargs: dict[str, Any], result: str
    ) -> tuple[str, bool]:
        """Block on the ApprovalManager until the user resolves the checkpoint.

        Registers a generic "ask" approval, persists an interactive
        ``approval_request`` row to the session (so the web/cloud surface
        renders Approve/Reject buttons that resolve via
        ``/api/approvals/{id}/resolve``), then awaits the resolution.

        Returns ``(result, delivered)``. ``delivered`` is True once the
        interactive approval card actually reached the channel — the caller
        relies on it to decide whether the generic progress card it suppressed
        still needs to be emitted. On the happy path ``result`` is augmented
        with a clear verdict line the model must obey.

        Never raises into the turn: any wiring error degrades to the legacy
        behaviour (return the original ``result`` and let the turn end).
        """
        mgr = self._approval_manager
        summary = str(kwargs.get("summary", "")).strip() or "Checkpoint"
        next_step = str(kwargs.get("next_step", "")).strip()
        channel_raw = kwargs.get("_channel", "")
        channel_id = str(kwargs.get("_channel_id", "") or "")
        agent_name = str(kwargs.get("_agent_name", "") or "")

        from praestoclaw.config.schema import ChannelType

        ch = ChannelType.of(channel_raw) if channel_raw else None
        # The out-of-band approval round-trip only works on push surfaces with
        # a card-resolve path (cloud / web / Teams). With no usable channel
        # (e.g. a background spawn that carried none → CLI default) or a plain
        # CLI turn, there is nothing to click — NEVER block; fall back to the
        # legacy checkpoint note so a worker can't hang on an invisible card.
        if ch is None or ch == ChannelType.INTERNAL:
            logger.info(
                "event_loop.checkpoint_no_channel session={} ch={} — legacy fallback",
                sid,
                ch.value if ch else "none",
            )
            return result, False

        try:
            request = await mgr.request_ask(
                prompt=summary,
                next_step=next_step,
                agent_name=agent_name,
                channel=ch,
                channel_id=channel_id,
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Checkpoint ask registration failed: {}", exc)
            return result, False

        # Actively push the interactive Approve/Reject card to the channel and
        # only block if the user can still act on it. Persisting the row alone
        # only reaches portal/reload; the live webchat/Teams surface needs the
        # pushed approval frame (mirrors the security hook's
        # _send_approval_prompt).
        #
        # "Undelivered" splits in two, because the right answer differs:
        #
        # * Nobody was listening on a channel the client can RE-ASK — the web
        #   channel exposes GET /api/approvals, so a pending request is still
        #   reachable. Keep it pending and block: closing a tab mid-run must not
        #   silently cancel the gate. Observed live: the browser WS closed six
        #   minutes before the checkpoint fired and the card went nowhere.
        #   Caveat worth knowing: only the static chat page actually reconciles
        #   on reconnect; the SPA listens for pushes and never polls, so there a
        #   dropped card is not resurfaced until it is abandoned (see #632 for
        #   scoped server-side replay, which needs an owner on ApprovalRequest).
        # * Anything else — no channel manager, a formatter error, a surface with
        #   no pull-based fallback — leaves nothing to act on, so drop the pending
        #   ask and degrade to the legacy note instead of blocking forever.
        delivered = await self._deliver_approval_card(request, kwargs)
        recoverable = request.channel == ChannelType.WEB
        if not delivered and not recoverable:
            mgr.discard(request.id)
            logger.warning(
                "event_loop.checkpoint_undelivered id={} session={} — legacy fallback",
                request.id,
                sid,
            )
            return result, False
        if not delivered:
            # Escalate to Teams immediately rather than waiting. Unlike the tool
            # approval gate — which waits out its window because the card WAS
            # delivered and the user may simply not have looked yet — we already
            # know nobody received this one. Waiting only delays the checkpoint.
            #
            # This matters most for a detached workflow run: its origin is the
            # one-shot request id frozen at spawn, which is dead within seconds,
            # so every card it raises lands nowhere. Observed 2026-08-05: a run
            # reached the pre-PR checkpoint and blocked for 16 minutes on a card
            # no surface ever showed (242 dropped sends on that one route).
            escalated = await self._escalate_card_to_teams(request)
            if escalated:
                logger.info(
                    "event_loop.checkpoint_escalated_teams id={} session={}",
                    request.id,
                    sid,
                )
            else:
                logger.warning(
                    "event_loop.checkpoint_pending_no_listener id={} session={} — "
                    "kept pending and listed by GET /api/approvals; the static chat "
                    "page reconciles it on reconnect, the SPA does not (#632)",
                    request.id,
                    sid,
                )

        # Persist the row for the portal/reload surface, then block.
        persistence = asyncio.create_task(
            self._persist_approval_request(sid, request, summary, next_step, agent_name)
        )
        try:
            await asyncio.shield(persistence)
        except asyncio.CancelledError:
            # The worker cannot be cancelled once started. Wait for its
            # approval_request row before recording the terminal state, or a
            # a late persistence completion can make an abandoned checkpoint look pending.
            await persistence
            self._abandon_checkpoint(mgr, request, sid, kwargs)
            raise

        logger.info(
            "event_loop.checkpoint_await id={} session={} agent={}",
            request.id,
            sid,
            agent_name,
        )
        try:
            resolved = await mgr.wait_for_resolution(request.id, reject_timeout=self._ask_timeout)
        except asyncio.CancelledError:
            # The ToolRegistry ceiling (_ask_timeout + 60) cancels this await, and
            # CancelledError derives from BaseException — the `except Exception`
            # below never saw it. Record the outcome, then let cancellation
            # propagate; swallowing it would break the caller's timeout.
            self._abandon_checkpoint(mgr, request, sid, kwargs)
            raise
        except Exception as exc:  # noqa: BLE001
            logger.debug("Checkpoint await failed: {}", exc)
            # Mark it anyway: leaving asked_user=True / resolved=False makes every
            # later status read report "waiting for approval" forever, which is
            # the state found on disk after the run that prompted this fix.
            self._abandon_checkpoint(mgr, request, sid, kwargs)
            # The card was already shown — do NOT ask the caller to stack a
            # progress card on top of it; report delivered.
            return result, True

        from praestoclaw.security.approval import ApprovalStatus

        if resolved.status == ApprovalStatus.APPROVED:
            verdict = "✅ User APPROVED this checkpoint — proceed with the next step."
        elif resolved.status == ApprovalStatus.DENIED:
            verdict = (
                "🛑 User REJECTED this checkpoint — stop now, do not proceed; "
                "report back what you have so far and wait for new instructions."
            )
        elif resolved.status == ApprovalStatus.EXPIRED:
            verdict = (
                "⌛ Checkpoint approval EXPIRED with no response — stop, do not "
                "proceed; report that the approval request expired and wait for "
                "new instructions."
            )
        else:
            verdict = (
                "⌛ Checkpoint approval timed out with no response — stop, do not "
                "proceed; report that you are waiting on the user's go-ahead."
            )
        logger.info(
            "event_loop.checkpoint_resolved id={} status={}",
            request.id,
            resolved.status.value,
        )
        # The ask is no longer pending (approved/denied/expired): mark the
        # checkpoint resolved so status classification stops treating this run as
        # "waiting for approval" once it moves on.
        self._mark_checkpoint_resolved(sid, resolved.status.value)
        return f"{result}\n\n{verdict}", True

    def _abandon_checkpoint(self, mgr: Any, request: Any, sid: str, kwargs: dict[str, Any]) -> None:
        """Give up on a checkpoint whose await died, and drop its pending ask.

        Marking the plan alone is not enough: the ApprovalManager entry would
        stay PENDING until max-age (24h), keeping a waiter alive and continuing
        to appear in ``GET /api/approvals`` as a decision on a run that no
        longer exists.

        A card may already be on screen, and neither surface retires one on its
        own, so the receipt is scheduled before the discard. Note *scheduled*,
        not delivered — the push is a task, and this runs from cancellation
        handlers where awaiting it is not safe. A client that never receives it
        is therefore still possible, and its retry answers 404 once the discard
        lands. On web that case is closed at the client (the GUI collapses 404
        to ``stale``, same as 409); on Teams the card would stay actionable.

        Best-effort throughout; none of it may break teardown.
        """
        self._mark_checkpoint_resolved(sid, "abandoned")
        self._push_abandon_receipt(request, kwargs)
        try:
            mgr.discard(request.id)
        except Exception as exc:  # noqa: BLE001 - cleanup is best-effort
            logger.debug("checkpoint discard skipped id={}: {}", request.id, exc)

    def _push_abandon_receipt(self, request: Any, kwargs: dict[str, Any]) -> None:
        """Retire an already-visible card for a checkpoint nobody will answer.

        The two surfaces retire a card in genuinely different ways, so this
        branches rather than sending one payload to both:

        * **Teams** — a *resolved Adaptive Card* re-sent under the original
          ``approval:<id>`` update key, which is what makes the bot update the
          original card in place. A bare frame there would leave the card
          actionable and surface the JSON as ordinary message text, the exact
          failure #627 fixed on the initial-card path.
        * **Everything else (web, cloud-webchat)** — a bare
          ``approval_resolved`` frame, the same shape the ApprovalGate and the
          web resolve endpoint emit, so no client needs a special case.
          ``status="abandoned"`` distinguishes "the run gave up" from a real
          approve/deny.

        Teams-ness comes from :meth:`_teams_push_target`, the same call
        ``_deliver_approval_card`` makes — ``ChannelType.CLOUD`` alone does not
        mean Teams, and a retirement formatted differently from its own prompt
        is worse than none.
        """
        cm = self._channel_manager
        if cm is None:
            return
        request_id = str(getattr(request, "id", "") or "")
        channel_raw = str(kwargs.get("_channel", "") or "")
        channel_id = str(kwargs.get("_channel_id", "") or "")
        if not request_id or not channel_raw or not channel_id:
            return
        try:
            import json as _json

            from praestoclaw.config.schema import ChannelType

            ch = ChannelType.of(channel_raw)
            if ch == ChannelType.INTERNAL:
                return
            channel = cm.get(ch)
            if channel is None:
                return

            send_kwargs: dict[str, Any] = {"keep_context": True}
            if self._teams_push_target(ch, kwargs) == "teams":
                from praestoclaw.channels.teams_cards import wrap_for_teams
                from praestoclaw.hooks.handlers import _approval_update_key
                from praestoclaw.security.approval_format import (
                    action_preview,
                    build_resolved_card,
                )

                tool_name = getattr(request, "tool_name", "") or "plan:checkpoint"
                card = build_resolved_card(
                    tool_name=tool_name,
                    # Same helper the prompt card used, so the retired card reads
                    # identically to the one it replaces.
                    action_preview=action_preview(tool_name, getattr(request, "args", {}) or {}),
                    score=getattr(request, "score", None),
                    outcome="abandoned",
                    agent_name=getattr(request, "agent_name", "") or "",
                    reason="The run that asked for this ended before you answered.",
                )
                frame = _json.dumps(wrap_for_teams(card))
                send_kwargs["push_target"] = "teams"
                # ``:resolved`` keeps this distinct from the prompt's own
                # push_request_id; the update_key is what pins it to the same card.
                send_kwargs["push_request_id"] = f"{request_id}:resolved"
                send_kwargs["update_key"] = _approval_update_key(request_id)
            else:
                frame = _json.dumps(
                    {
                        "type": "approval_resolved",
                        "request_id": request_id,
                        "status": "abandoned",
                        "resolver": "system",
                        "tool_name": getattr(request, "tool_name", "") or "plan:checkpoint",
                    }
                )

            async def _send() -> None:
                # The outer try/except cannot see into this task; an escaping
                # exception here would surface as "Task exception was never
                # retrieved" at GC time instead.
                try:
                    ok = await channel.send(channel_id, frame, **send_kwargs)
                except Exception as exc:  # noqa: BLE001 - receipt is best-effort
                    logger.debug("checkpoint abandon receipt failed id={}: {}", request_id, exc)
                    return
                if ok is False:
                    # The card stays on screen. On web the client's retry will
                    # 404 and collapse it as stale; on Teams it stays actionable.
                    # Log it so "why is that card still there" is greppable
                    # rather than invisible.
                    logger.warning(
                        "checkpoint abandon receipt undelivered id={} channel={} channel_id={}",
                        request_id,
                        channel_raw,
                        channel_id,
                    )

            task = asyncio.get_running_loop().create_task(_send())
            self._receipt_tasks.add(task)
            task.add_done_callback(self._receipt_tasks.discard)
        except Exception as exc:  # noqa: BLE001 - receipt is best-effort
            logger.debug("checkpoint abandon receipt skipped id={}: {}", request_id, exc)

    def _mark_checkpoint_resolved(self, sid: str, outcome: str) -> None:
        """Record how the latest checkpoint ended.

        Best-effort — never let status bookkeeping break the resolution path.
        Called from both the resolved branch and the await-failure branch; the
        latter used to skip it, which left ``asked_user=True`` with
        ``resolved=False`` permanently.
        """
        try:
            _p = self._store.load(sid)
            if _p and _p.checkpoints:
                _p.checkpoints[-1].resolved = True
                _p.checkpoints[-1].outcome = outcome
                self._store.save(_p)
        except Exception as exc:  # noqa: BLE001 - best-effort status bookkeeping
            logger.debug("checkpoint resolved-mark skipped: {}", exc)

    # Not a @staticmethod: the workflow fallback below needs the plan store to
    # ask who owns the conversation.
    def _teams_push_target(self, channel: Any, kwargs: dict[str, Any]) -> str | None:
        """Return ``"teams"`` when this checkpoint's card belongs on a Teams card.

        ``ChannelType.CLOUD`` covers Teams *and* cloud-webchat, so the channel
        alone does not decide the format — the originating ``_metadata.source``
        (or a push-mode channel_id) does.

        Single source of truth on purpose: the prompt card and its later
        retirement MUST agree. They did not when the retirement carried its own
        hand-rolled copy of this rule, and a cloud-webchat session got a plain
        prompt followed by a Teams-enveloped receipt.
        """
        from praestoclaw.config.schema import ChannelType

        channel_id = str(kwargs.get("_channel_id", "") or "")
        meta_in = kwargs.get("_metadata") or {}
        source = str(meta_in.get("source", "")) if isinstance(meta_in, dict) else ""
        used_push_mode = (
            not channel_id
            or channel_id.startswith(("scheduler:", "cron:", "agent-", "copilot-", "claude-"))
            or channel_id == ChannelType.CLOUD.value
        )
        if source in ("cloud_teams", "teams_bridge") or (
            channel == ChannelType.CLOUD and used_push_mode
        ):
            return "teams"
        # A workflow run as a background task reports source "workflow", and its
        # channel_id is the one-shot request id of the turn that started it —
        # neither says Teams, and neither is push mode. The approval card then
        # went to webchat while the user sat in Teams waiting for a card that
        # was never coming, and the run blocked on `checkpoint_await` for an
        # answer nobody could give. The plan's owner still knows.
        if channel == ChannelType.CLOUD and self._plan_owner_is_teams(
            self._resolve_session_id(kwargs)
        ):
            return "teams"
        return None

    async def _deliver_approval_card(self, request: Any, kwargs: dict[str, Any]) -> bool:
        """Push the interactive Approve/Reject card to the originating channel.

        Mirrors the security hook's ``_send_approval_prompt``: format the
        request for the channel (Adaptive Card for Teams, structured frame for
        web/cloud) and ``channel.send`` it with ``push_request_id`` so the
        Approve/Reject buttons resolve via ``/api/approvals/{id}/resolve``.

        Returns ``True`` only if the card was actually handed to a channel
        without error — the caller MUST NOT block on the approval otherwise, or
        a worker would wait on a card nobody can see. Best-effort; never raises
        into the await.
        """
        cm = self._channel_manager
        if cm is None:
            return False

        try:
            channel = cm.get(request.channel)
        except Exception:  # noqa: BLE001
            channel = None
        if channel is None:
            return False

        channel_id = str(kwargs.get("_channel_id", "") or "")
        push_target = self._teams_push_target(request.channel, kwargs)
        effective_cid = channel_id or (request.channel.value if request.channel else "")

        try:
            from praestoclaw.security.approval_format import get_approval_formatter

            formatter = get_approval_formatter(request.channel, push_target=push_target)
            classify = RiskScore(0, reason=request.reason or "User confirmation requested.")
            content = formatter.format_request(
                request, classify, None, reject_timeout=self._ask_timeout
            )
            payload = json.dumps(content) if isinstance(content, dict) else str(content)
            send_kwargs: dict[str, Any] = {
                "keep_context": True,
                "push_request_id": request.id,
                # On every channel, not just Teams: a checkpoint is a blocking
                # ask, so it must be distinguishable from the plan progress
                # cards this same tool emits. WebChannel uses this to decide
                # which payload may take a one-shot request's single response
                # slot (issue #663).
                "notify_category": "approval_prompt",
            }
            if push_target:
                send_kwargs["push_target"] = push_target
            if push_target == "teams":
                # A checkpoint card only ever reaches this path on a personal
                # turn — a borrowed-identity group turn degrades to a plain
                # chat note before it gets here (see
                # ``_checkpoint_blocks_on_user``). So this is unconditionally a
                # permission-style approval addressed to the one person who can
                # answer it, and it is redirected to their DM like any other.
                # The ``approval:``-prefixed ``update_key`` is the routing key
                # the Teams bot maps to the card's activityId, so the card can
                # still be swapped in place when it resolves.
                from praestoclaw.hooks.handlers import _approval_update_key

                send_kwargs["update_key"] = _approval_update_key(request.id)
            # Short ceiling: a stuck channel send must not hang the worker; the
            # long wait belongs to wait_for_resolution, not the card push.
            sent = await asyncio.wait_for(
                channel.send(effective_cid, payload, **send_kwargs),
                timeout=_CARD_SEND_TIMEOUT_S,
            )
            if sent is False:
                # The channel took the call and had nobody to hand it to. Do NOT
                # claim it was sent: this used to log checkpoint_card_sent right
                # after the channel logged "Response dropped", and the caller then
                # blocked for the whole timeout on a card nobody could see.
                logger.warning(
                    "event_loop.checkpoint_no_listener id={} channel={} cid={} "
                    "— nothing connected right now",
                    request.id,
                    request.channel.value if request.channel else "",
                    effective_cid,
                )
                return False
            logger.info(
                "event_loop.checkpoint_card_sent id={} channel={} push_target={}",
                request.id,
                request.channel.value if request.channel else "",
                push_target or "",
            )
            return True
        except Exception as exc:  # noqa: BLE001
            logger.debug("Checkpoint approval card delivery failed: {}", exc)
            return False

    async def _escalate_card_to_teams(self, request: Any) -> bool:
        """Push a checkpoint card to Teams when its own surface could not take it.

        The tool approval gate has had this since it was written
        (``hooks/handlers.py`` escalates to unattempted channels); the checkpoint
        path never did, so a card its originating surface dropped simply blocked
        the run forever. Teams is the only escalation target here on purpose: it
        is a long-lived conversation with a real push path, whereas the surfaces
        that lose these cards — a detached run's frozen one-shot HTTP route, or
        an API client with no inbound channel at all — have nowhere to push to.

        Addressed by channel *name* rather than a request id: this is a push, not
        a reply to something in flight.
        """
        from praestoclaw.config.schema import ChannelType

        cm = self._channel_manager
        if cm is None:
            return False
        try:
            channel = cm.get(ChannelType.CLOUD)
        except Exception:  # noqa: BLE001
            return False
        if channel is None or not getattr(channel, "is_connected", False):
            return False
        try:
            from praestoclaw.hooks.handlers import _approval_update_key
            from praestoclaw.security.approval_format import get_approval_formatter

            formatter = get_approval_formatter(ChannelType.CLOUD, push_target="teams")
            classify = RiskScore(0, reason=request.reason or "User confirmation requested.")
            content = formatter.format_request(
                request, classify, None, reject_timeout=self._ask_timeout
            )
            payload = json.dumps(content) if isinstance(content, dict) else str(content)
            sent = await asyncio.wait_for(
                channel.send(
                    ChannelType.CLOUD.value,
                    payload,
                    keep_context=True,
                    push_target="teams",
                    push_request_id=request.id,
                    update_key=_approval_update_key(request.id),
                    notify_category="approval_prompt",
                ),
                timeout=_CARD_SEND_TIMEOUT_S,
            )
            return sent is not False
        except Exception as exc:  # noqa: BLE001 — escalation must never break the run
            logger.debug("Checkpoint Teams escalation failed: {}", exc)
            return False

    async def _persist_approval_request(
        self,
        sid: str,
        request: Any,
        summary: str,
        next_step: str,
        agent_name: str,
    ) -> None:
        """Write an interactive ``approval_request`` row to the session.

        Mirrors the security hook's persistence so the web/cloud approval
        surface renders the same Approve/Reject card (resolved via
        ``/api/approvals/{id}/resolve``). Best-effort; never raises.
        """
        if self._session_store is None:
            return
        try:
            summary_preview = summary[:200]
            preview = summary_preview
            if next_step:
                preview = f"{preview}\nNext: {next_step[:160]}"
            args: dict[str, Any] = {"summary": summary_preview}
            if next_step:
                args["next_step"] = next_step[:200]
            await self._session_store.add_message(
                sid,
                {
                    "role": "approval_request",
                    "content": json.dumps(
                        {
                            "request_id": request.id,
                            "tool_name": "plan:checkpoint",
                            "action_preview": preview,
                            "risk_level": "low",
                            "risk_color": "good",
                            "args": args,
                            "score": None,
                            "reason": "Plan checkpoint — user confirmation requested",
                            "agent_name": agent_name,
                            "trigger": "",
                            "always_allow": False,
                            "status": "pending",
                        }
                    ),
                },
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Persist checkpoint approval_request failed: {}", exc)

    def _plan_owner_is_teams(self, sid: str, plan: Plan | None = None) -> bool:
        """Whether the conversation that started this workflow is a Teams one.

        ``_metadata.source`` names the *emitting* context, and for a workflow
        started as a background task that is ``"workflow"`` — the originating
        channel is gone by then. So a Teams conversation running a workflow got
        the markdown fallback while the same conversation running a foreground
        turn got the card, which is what a user actually notices.

        ``Plan.owner`` is what still knows: the **caller/parent session of the
        workflow run** that created the plan, persisted from
        ``_metadata.workflow_owner`` — not the plan's own ``session_id``, and
        empty for plans no workflow created. The cloud channel spells a Teams
        conversation ``cloud:<instance>:teams:…``, so a non-workflow plan
        simply reads as not-Teams and the existing source rule decides.

        Two owner shapes mean Teams and both are matched. A personal turn is
        ``cloud:<instance>:teams:…``. A group turn routed through praesto tag
        exp is ``cloud:praesto_tag_exp:<conversation_id>`` — a Teams group chat
        with no ``:teams:`` anywhere in it, which the first marker alone missed
        silently, in the surface where the most people would have seen it.

        Pass *plan* when the caller already has it loaded; this runs on every
        progress emit and ``PlanStore.load`` reads the file each time.
        """
        if plan is None:
            # An empty session id is not a lookup key. `_safe_session_filename`
            # ends in ``or "default"``, so loading one returns whatever
            # ``default.json`` happens to hold — an unrelated plan whose owner
            # would then decide this conversation's routing. Reproduced: a
            # stray default plan owned by a Teams conversation made an empty id
            # answer True.
            if not str(sid).strip():
                return False
            try:
                plan = self._store.load(sid)
            except Exception:  # noqa: BLE001
                return False
        owner = getattr(plan, "owner", "") or ""
        return ":teams:" in owner or ":praesto_tag_exp:" in owner

    def _build_progress_activity(
        self,
        sid: str,
        action: str,
        kwargs: dict[str, Any],
        result: str,
        plan: Plan | None = None,
    ) -> dict[str, Any] | None:
        """Build a Bot Framework activity dict (with Adaptive Card) for *action*.

        Returns ``None`` when there's nothing to render (no plan, or an
        action that doesn't produce a user-facing card).
        """
        if plan is None:
            plan = self._store.load(sid)
        if plan is None or not plan.items:
            return None
        last_item: PlanItem | None = None
        last_status = ""
        note = ""
        if action in ("update", "verify"):
            ref = str(kwargs.get("id", ""))
            last_item = self._find_item(plan, ref)
            if action == "verify":
                if "FAILED" in result:
                    last_status = "FAILED"
                elif "PARTIAL" in result:
                    last_status = "PARTIAL"
        elif action == "checkpoint":
            cp = plan.checkpoints[-1] if plan.checkpoints else None
            if cp:
                note = cp.summary
        elif action == "report":
            note = str(kwargs.get("summary", ""))
        return build_progress_card(
            plan,
            action=action,
            last_item=last_item,
            last_status=last_status,
            note=note,
        )

    def _format_live_update(
        self,
        sid: str,
        action: str,
        kwargs: dict[str, Any],
        result: str,
        plan: Plan | None = None,
    ) -> str:
        """Render a compact progress message per action. Returns "" to skip."""
        if plan is None:
            plan = self._store.load(sid)
        if plan is None or not plan.items:
            return ""
        done, total = plan.progress
        header = f"📋 **Plan progress** ({done}/{total})"
        if plan.workflow:
            header += f" — _{plan.workflow}_"

        if action == "create":
            lines = [header, "", "**Todo:**"]
            for i, it in enumerate(plan.items, 1):
                lines.append(f"{i}. ⬜ {it.title}")
            return "\n".join(lines)

        if action == "update":
            ref = str(kwargs.get("id", ""))
            item = self._find_item(plan, ref)
            if not item:
                return ""
            icon = _STATUS_ICON.get(item.status, "[?]")
            line = f"{icon} **{item.title}** → _{item.status}_"
            if item.status == "blocked":
                blocked_detail = _blocked_detail(item)
                if blocked_detail:
                    line += f"\n   ⚠ {blocked_detail[:160]}"
            return f"{header}\n{line}"

        if action == "checkpoint":
            cp = plan.checkpoints[-1] if plan.checkpoints else None
            if not cp:
                return ""
            prefix = (
                "🛑 **Checkpoint** — awaiting your input" if cp.asked_user else "📍 **Checkpoint**"
            )
            out = [f"{header}\n{prefix}", f"_{cp.summary[:300]}_"]
            if cp.next_step:
                out.append(f"Next: {cp.next_step[:200]}")
            return "\n".join(out)

        if action == "report":
            summary = str(kwargs.get("summary", "")).strip()[:300]
            if not summary:
                return ""
            return f"{header}\n📣 {summary}"

        if action == "verify":
            ref = str(kwargs.get("id", ""))
            item = self._find_item(plan, ref)
            if not item:
                return ""
            if "FAILED" in result:
                return f"{header}\n❌ Verify failed: **{item.title}** — reset to in_progress"
            if "PARTIAL" in result:
                return f"{header}\n⚠ Verify partial: **{item.title}**"
            return f"{header}\n✅ Verified: **{item.title}**"

        return ""

    # ── Helpers ──────────────────────────────────────────────────────────

    def _resolve_session_id(self, kwargs: dict[str, Any]) -> str:
        # ``_plan_session_id`` is a registry-injected, runtime-only override
        # used when a promoted worker should update the originating conversation's
        # visible plan card while keeping its own ``_session_id`` for other tool
        # provenance. ToolRegistry strips caller-supplied values before injecting
        # this trusted override.
        plan_owner = kwargs.get("_plan_session_id")
        if plan_owner:
            return str(plan_owner)
        # ``_session_id`` is injected by ToolRegistry from the *current
        # turn's* session_id in loop_v2. It cannot be stomped by another
        # concurrent loop on the shared PlanTool singleton (unlike
        # ``self._session_resolver``), and the LLM cannot influence it
        # (unlike the public ``session_id`` argument, which we've seen
        # populated with arbitrary ULIDs lifted from ``tool_status`` update_keys).
        injected = kwargs.get("_session_id")
        if injected:
            return str(injected)
        if self._session_resolver:
            try:
                resolved = self._session_resolver()
                if resolved:
                    return str(resolved)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Session resolver failed: {}", exc)
        # Last-resort fallback for callers that don't go through
        # ToolRegistry (CLI, tests) and don't wire a session resolver.
        sid = kwargs.get("session_id")
        return str(sid) if sid else ""

    def _find_item(self, plan: Plan, ref: str) -> PlanItem | None:
        # try id match first
        for it in plan.items:
            if it.id == ref:
                return it
        # try 1-based index
        if ref.isdigit():
            idx = int(ref) - 1
            if 0 <= idx < len(plan.items):
                return plan.items[idx]
        return None

    # ── Action implementations ───────────────────────────────────────────

    def _create(self, sid: str, kwargs: dict[str, Any]) -> str:
        items_raw = kwargs.get("items") or []
        replace = bool(kwargs.get("replace"))
        existing = self._store.load(sid)
        if existing and existing.items and not replace:
            done, total = existing.progress
            return (
                f"Error: a plan already exists for this session ({done}/{total} done). "
                "Use action='show' to inspect it, action='update' to advance items, "
                "or pass replace=true to start over."
            )

        items: list[PlanItem] = []
        seen_ids: set[str] = set()
        for raw in items_raw:
            if not isinstance(raw, dict):
                continue
            it = PlanItem.from_dict(raw)
            if not it.title:
                continue
            # A brand-new item must not start already-complete: reset any
            # done/skipped status to not_started so there's no "create item
            # already done/skipped" shortcut. (from_dict's _norm_status has
            # already mapped any unknown status to not_started.)
            if it.status in _TERMINAL_STATUSES or (
                it.status == "blocked" and not it.evidence.strip()
            ):
                it.status = "not_started"
            # Create never trusts caller-supplied timestamps or verdicts: a
            # fresh item is never done (so no completion stamp, pending verdict),
            # and its started_at is derived from its status — set to now iff it
            # begins in_progress — rather than copied from the caller, so a stray
            # timestamp can't make a new item read as already started/finished.
            it.completed_at = ""
            it.verification = "pending"
            it.started_at = _now() if it.status == "in_progress" else ""
            if it.id in seen_ids:
                it.id = uuid.uuid4().hex[:8]
            seen_ids.add(it.id)
            items.append(it)

        if not items:
            return "Error: no valid items provided."

        cycle = _find_dependency_cycle(items)
        if cycle:
            # Refused here rather than at traversal: by the time the scheduler
            # notices, the run has already paid for building the plan, and a
            # cycle has no runnable item so it would present as a silent stall
            # (#706, phase 1).
            return (
                "Error: depends_on forms a cycle: " + " -> ".join(cycle) + ". "
                "Remove one edge so the plan is acyclic."
            )

        # Link the plan to its originating background run (6d-1) so
        # ``workflow status`` can correlate the run to this plan by task id, and
        # record the run's owner (caller session) so an interrupted run is scoped
        # to its owner for resume (6d-3) — never surfaced/discarded cross-session.
        meta_in = kwargs.get("_metadata") or {}
        origin_task = ""
        owner = ""
        if isinstance(meta_in, dict):
            origin_task = str(meta_in.get("background_task_id") or "").strip()[:64]
            owner = str(meta_in.get("workflow_owner") or "").strip()[:200]
        plan = Plan(
            session_id=sid,
            items=items,
            # Normalize the SOP/recipe name: collapse whitespace (it's a
            # single-line label used in status/resume output) and cap.
            workflow=" ".join(str(kwargs.get("workflow", "") or "").split())[:200],
            created_at=_now(),
            origin_task=origin_task,
            owner=owner,
        )
        # Persist the run's resolved parameters so `workflow resume` can restore
        # them (the caller would otherwise have to re-type every required param,
        # which made resuming a parameterized recipe fail outright). Gated on the
        # plan actually being a workflow plan, so a plain agent plan can never
        # pick up a stray metadata key.
        if plan.workflow and isinstance(meta_in, dict):
            plan.params = _normalize_plan_params(meta_in.get("workflow_params"))
        self._store.save(plan)
        # Deferred supersede (6d-3): when this plan is the successor created by a
        # `workflow resume` run, retire the predecessor plan ONLY NOW — after the
        # successor is safely persisted. If we retired it at resume-spawn time and
        # the resumed run crashed before reaching here, the old plan would be
        # hidden (superseded ⇒ excluded from list_active) yet no successor would
        # exist, stranding the run with no resumable orphan. Tying supersede to
        # "the successor exists" keeps exactly one resumable orphan at all times.
        # Scoped to the SAME owner + workflow (and only when this run has a
        # non-blank owner) so a forged/guessed `workflow_supersede_prev` can never
        # retire another session's or another recipe's plan. Inert for every
        # non-resume create (the key is absent).
        if isinstance(meta_in, dict) and owner:
            prev_sid = str(meta_in.get("workflow_supersede_prev") or "").strip()
            if prev_sid and prev_sid != sid:
                # Best-effort: the successor plan is already persisted above, so a
                # supersede failure (e.g. transient IO) must NOT turn a successful
                # create into an error — that would make the caller think creation
                # failed and retry / duplicate. Worst case the old plan lingers as
                # an orphan (recoverable), never lost.
                try:
                    self._store.supersede(
                        prev_sid, expect_owner=owner, expect_workflow=plan.workflow
                    )
                except Exception as exc:  # noqa: BLE001 - supersede is best-effort
                    logger.debug(
                        "Deferred supersede of {} failed (create still ok): {}", prev_sid, exc
                    )
        return f"Plan created with {len(items)} item(s).\n" + render_plan(plan)

    def _update(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            return "Error: no plan exists for this session. Create one first."
        ref = str(kwargs.get("id", ""))
        item = self._find_item(plan, ref)
        if not item:
            return f"Error: item {ref!r} not found."
        # A status update applies only for a non-blank string naming a target
        # state, which is then normalized (case/whitespace-tolerant, unknown →
        # not_started). Anything else — absent/None, a blank/whitespace-only
        # string, or a non-string value (0/False, easy via JSON) — is a
        # deliberate no-op, NOT a destructive reset to not_started, since none
        # of those name a target state (mirrors note/evidence below, which only
        # apply when explicitly provided).
        raw_status = kwargs.get("status")
        new_status = (
            _norm_status(raw_status) if isinstance(raw_status, str) and raw_status.strip() else None
        )
        note = kwargs.get("note")
        evidence = kwargs.get("evidence")

        effective_status = new_status or item.status
        if effective_status == "blocked":
            final_evidence = item.evidence if evidence is None else str(evidence)
            if not final_evidence.strip():
                return (
                    f"Refusing to mark item {ref!r} as 'blocked' without evidence. "
                    "Pass evidence=... describing the concrete blocker."
                )

        if new_status:
            if new_status == "in_progress" and not item.started_at:
                item.started_at = _now()
            if new_status == "done":
                # structural verify gate — prevents 'done' without acceptance
                # evidence. Require *non-blank* proof (whitespace-only doesn't
                # count); a falsy-but-provided value (0/False) does count since
                # it is serialized to a non-empty string below. Check the freshly
                # provided evidence first, then any already-stored one.
                provided_evidence = "" if evidence is None else str(evidence)
                if item.acceptance and not (provided_evidence.strip() or item.evidence.strip()):
                    return (
                        f"Refusing to mark item {ref!r} as 'done' without evidence. "
                        "Pass evidence=... (test output / diff / URL) or call "
                        "action='verify' first."
                    )
                item.completed_at = _now()
                # Invariant (done ⇒ passed): a done transition that cleared the
                # evidence gate is recorded as passed. The strict gate that
                # *requires* passed before allowing done lands in the
                # verification step.
                item.verification = "passed"
            elif item.status == "done":
                # Reopening a done item via update (done → in_progress / blocked /
                # not_started / skipped): clear the completion + verification it
                # carried so a non-done item never looks completed or verified,
                # mirroring _verify's reopen logic.
                item.completed_at = ""
                item.verification = "pending"
            item.status = new_status
        if note is not None:
            item.note = str(note)[:_MAX_TEXT_LEN]
        if evidence is not None:
            item.evidence = str(evidence)[:_MAX_TEXT_LEN]
        check = kwargs.get("check")
        if check is not None:
            item.check = str(check).strip()[:_MAX_TEXT_LEN]  # strip so blank == no check
        self._store.save(plan)
        out = f"Updated item {ref}.\n" + render_plan(plan, compact=True)
        # Plan-completion nudge — fires inline in the tool result so the
        # LLM sees it on THIS iteration (active_plan_block is computed
        # once per user turn, so a mid-turn completion would otherwise
        # miss the "deliver the result" reminder until the next turn,
        # by which point the agent has already replied with a useless
        # "task complete" acknowledgement).
        if plan.is_complete:
            out += _plan_complete_nudge(plan)
        return out

    def _checkpoint(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            # A checkpoint can stand alone — e.g. a one-off "approve before I
            # act" gate — without the caller first building a full plan. Auto-
            # create a minimal (item-less) plan so the checkpoint records,
            # instead of erroring and forcing the agent to call create() first.
            # That extra create() is what emitted a stray "plan progress" card
            # right before the approval card (issue: stacked cards).
            plan = Plan(session_id=sid)
        cp = Checkpoint(
            ts=_now(),
            summary=str(kwargs.get("summary", ""))[:_MAX_TEXT_LEN],
            next_step=str(kwargs.get("next_step", ""))[:_MAX_TEXT_LEN],
            asked_user=bool(kwargs.get("ask_user")),
        )
        plan.checkpoints.append(cp)
        self._store.save(plan)
        prefix = "🛑 Checkpoint (waiting for user)" if cp.asked_user else "📍 Checkpoint"
        out = [f"{prefix}: {cp.summary}"]
        if cp.next_step:
            out.append(f"Next: {cp.next_step}")
        if cp.asked_user:
            meta = kwargs.get("_metadata")
            if praesto_tag_exp_is_active(meta if isinstance(meta, dict) else {}):
                # No card, no out-of-band resolution: the group answers in the
                # conversation. Saying so here stops the model from waiting on
                # a button that will never appear.
                out.append(
                    "\n→ Ask the group in the chat, in your own words, and END YOUR TURN. "
                    "There is no approval button in a group session — their reply "
                    "arrives as an ordinary message on a later turn."
                )
            else:
                out.append("\n→ Stop and ask the user before proceeding.")
        return "\n".join(out)

    def _report(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        summary = str(kwargs.get("summary", "")).strip()
        if not summary:
            return "Error: 'summary' is required for action='report'."
        if plan:
            plan.checkpoints.append(Checkpoint(ts=_now(), summary=summary, asked_user=False))
            self._store.save(plan)
        return f"📣 Progress: {summary[:300]}"

    def _verify(self, sid: str, kwargs: dict[str, Any]) -> str:
        plan = self._store.load(sid)
        if not plan:
            return "Error: no plan exists for this session."
        ref = str(kwargs.get("id", ""))
        item = self._find_item(plan, ref)
        if not item:
            return f"Error: item {ref!r} not found."
        # Treat an explicit evidence=None as "absent" (fall back to the stored
        # evidence) rather than letting ``str(None)`` become the literal "None",
        # which would read as real evidence and skew the failure heuristics.
        raw_evidence = kwargs.get("evidence")
        evidence = str(raw_evidence if raw_evidence is not None else item.evidence)
        if not evidence.strip():
            if item.check:
                return (
                    f"ℹ️ Item {ref} declares a check: {item.check!r}. Run it yourself via "
                    "the shell tool (it goes through the normal approval/sandbox path), then "
                    "call verify again with its output as evidence — make sure that evidence "
                    "also visibly addresses the acceptance criterion, otherwise verify may "
                    "return PARTIAL. (The plan tool does not run checks.)"
                )
            return (
                f"Verification FAILED for item {ref}: no evidence provided. "
                "Pass evidence=... with concrete proof (test output, diff, URL)."
            )

        # Heuristic signal scan — catches the most common false-completes.
        if _FAIL_PATTERNS.search(evidence):
            item.status = "in_progress"
            item.completed_at = ""  # reopened — no longer complete
            item.verification = "failed"
            item.note = "Verification failed — evidence contains failure signal."
            item.evidence = evidence[:_MAX_TEXT_LEN]
            self._store.save(plan)
            return (
                f"❌ Verification FAILED for item {ref}: evidence contains a "
                "failure signal (fail/error/traceback). Item reset to in_progress."
            )

        if item.acceptance and item.acceptance.lower() not in evidence.lower():
            # Soft, advisory warning. A PARTIAL (inconclusive) re-verify must NOT
            # silently undo a completed item — only a hard failure signal (the
            # branch above) reopens a done item, matching long-standing behaviour.
            # We only clear a stale 'passed' on a not-yet-done item so it isn't
            # left looking verified; a genuinely done item stays done (and passed).
            item.evidence = evidence[:_MAX_TEXT_LEN]
            # Only neutralize a stale 'passed' on a not-yet-done item so it isn't
            # left looking verified; a 'failed' verdict is preserved — a vague
            # re-verify is not a success signal and must not silently erase a
            # recorded failure.
            if item.status != "done" and item.verification == "passed":
                item.verification = "pending"
            self._store.save(plan)
            return (
                f"⚠ Verification PARTIAL for item {ref}: evidence does not visibly "
                f"address the acceptance criterion. Acceptance: {item.acceptance[:200]!r}. "
                "Provide more relevant evidence (test output / diff / URL) that "
                "demonstrates the acceptance criterion."
            )

        item.evidence = evidence[:_MAX_TEXT_LEN]
        item.status = "done"
        item.verification = "passed"
        item.completed_at = _now()
        self._store.save(plan)
        out = f"✅ Verified item {ref} as done.\n" + render_plan(plan, compact=True)
        if plan.is_complete:
            out += _plan_complete_nudge(plan)
        return out

    def _show(self, sid: str) -> str:
        plan = self._store.load(sid)
        if not plan or not plan.items:
            return "(no plan for this session)"
        return render_plan(plan)

    def _delete(self, sid: str) -> str:
        if self._store.delete(sid):
            return "Plan deleted."
        return "(no plan to delete)"


# ── Helpers used by the agent loop ──────────────────────────────────────────


def active_plan_block(session_id: str) -> str:
    """Return a system-message body describing the active plan, or "".

    Called by the agent loop on every turn so the LLM never loses sight of
    its own plan, even after compaction.
    """
    if not session_id:
        return ""
    store = get_plan_store()
    plan = store.load(session_id)
    if not plan or not plan.items:
        return ""
    if plan.is_complete:
        # Plan just finished — give the LLM one strong push to actually
        # report the result. Without this, models tend to call
        # plan(update,status=done) on a "report to user" item and then
        # reply with a one-liner like "✅ task complete!" without ever
        # writing the substantive result the user asked for.
        #
        # We re-emit this nudge on every iteration while the plan stays
        # complete. delivered_at is only used to soften the wording on
        # follow-up turns (after the agent has had at least one chance
        # to produce a final reply); the chat history already carries
        # the delivered result so a softer reminder is enough.
        first_time = not plan.delivered_at
        if first_time:
            plan.delivered_at = _now()
            try:
                store.save(plan)
            except Exception as exc:  # noqa: BLE001
                logger.debug("Could not persist plan delivered_at: {}", exc)
        if first_time:
            body = ["## Plan Just Completed (DELIVER THE RESULT)"]
            body.append(render_plan(plan))
            body.append(_plan_complete_nudge(plan).lstrip())
            return "\n".join(body)
        # Soft reminder on subsequent turns — the prior turn already
        # delivered the result; just keep the plan visible as context.
        body = ["## Plan (already completed and delivered)"]
        body.append(render_plan(plan))
        body.append(
            "\nThe result was already delivered in your earlier reply. "
            "If the user is asking a follow-up, answer that — don't "
            "re-emit the original report unless explicitly asked."
        )
        return "\n".join(body)
    body = ["## Active Plan (persistent across turns and sessions)"]
    body.append(render_plan(plan))
    body.append(
        "\nUse plan(action='update', id=..., status=...) to advance items. "
        "Use plan(action='checkpoint', summary=..., ask_user=true) at SOP gates. "
        "Do NOT mark items 'done' without evidence."
    )
    body.append(
        "**Reporting items**: any item whose title contains "
        "'report' / 'tell' / 'show' / 'announce' / '报告' / '告诉' / "
        "'汇报' / '展示' is only complete when your assistant reply for "
        "this turn contains the actual content. Calling "
        "plan(action='update', status='done') is bookkeeping, not "
        "delivery. The user sees your assistant text, not the tool call."
    )
    return "\n".join(body)
