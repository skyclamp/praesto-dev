"""Submit a PraestoClaw feedback issue without exposing shell or filesystem access."""

from __future__ import annotations

import asyncio
import json
import os
import re
from dataclasses import dataclass
from time import monotonic
from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.leak import redact_credentials
from praestoclaw.security.risk import RiskAssessment, RiskScore

if TYPE_CHECKING:
    from praestoclaw.security.audit import AuditLogger

_TITLE_PREFIXES = ("[Feedback] ", "[fix societas bug] ")
_MAX_SUMMARY_CHARS = 80
_MAX_BODY_BYTES = 256 * 1024
_REPO = "gim-home/PraestoClaw"
_ACTIONS = frozenset({"create", "comment", "edit", "assign"})
_MAX_ASSIGNEES = 10
_GH_TIMEOUT_SECONDS = 20.0
_ASSIGNMENT_TIMEOUT_SECONDS = 110.0
_FALLBACK_TIMEOUT_SECONDS = 5.0
_LOGIN_RE = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9_-]{0,37}[A-Za-z0-9])?")
_ISSUE_URL_RE = re.compile(r"https://github\.com/gim-home/PraestoClaw/issues/(?P<number>[1-9]\d*)")
_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_POSIX_HOME_RE = re.compile(r"(?P<prefix>/(?:Users|home)/)[^/\s]+")
_WINDOWS_HOME_RE = re.compile(r"(?P<prefix>[A-Z]:\\Users\\)[^\\\s]+", re.IGNORECASE)
_DIAGNOSTICS_HEADING_RE = re.compile(r"(?im)^##[ \t]+Session diagnostics[ \t]*$")
_DIAGNOSTICS_HEADING = "## Session diagnostics"


@dataclass(frozen=True, slots=True)
class _IssueRef:
    number: int
    url: str


class _AssignmentError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


class FeedbackSubmitTool(Tool):
    """Create feedback, assign repository issues, and amend session-owned issues."""

    risk_range = (6, 6)

    def __init__(
        self,
        *,
        command: tuple[str, ...] = ("gh",),
        diagnostics: AuditLogger | None = None,
    ) -> None:
        self._command = command
        self._diagnostics = diagnostics
        self._issues_by_session: dict[str, dict[int, _IssueRef]] = {}

    @property
    def name(self) -> str:
        return "feedback_submit"

    @property
    def description(self) -> str:
        return (
            "Create a PraestoClaw feedback issue, optionally assigning explicit GitHub "
            "logins, or assign an existing issue by ID. The repository and create label "
            "are fixed. Assignment adds owners without removing existing ones. Only "
            "comment/edit require an issue created in the current conversation session."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=120, tier="core")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": sorted(_ACTIONS),
                    "description": "Create an issue, assign owners, add a comment, or edit it.",
                },
                "issue_number": {
                    "type": "integer",
                    "minimum": 1,
                    "description": (
                        "Required for assign: any explicit issue ID in gim-home/PraestoClaw. "
                        "For comment/edit: an issue ID returned by create in this session."
                    ),
                },
                "title": {
                    "type": "string",
                    "description": (
                        "For create/edit: title beginning with '[Feedback] ' or the "
                        "workflow-specific '[fix societas bug] '."
                    ),
                    "maxLength": max(map(len, _TITLE_PREFIXES)) + _MAX_SUMMARY_CHARS,
                },
                "body": {
                    "type": "string",
                    "description": "Issue body, comment, or replacement body.",
                },
                "assignees": {
                    "type": "array",
                    "items": {"type": "string", "pattern": f"^{_LOGIN_RE.pattern}$"},
                    "maxItems": _MAX_ASSIGNEES,
                    "description": (
                        "Explicit GitHub logins to add, preserving existing owners. "
                        "Optional for create; required and nonempty for assign. "
                        "Not accepted for comment/edit. Do not infer logins from diagnostics."
                    ),
                },
            },
            "required": ["action"],
            "additionalProperties": False,
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = str(args.get("action") or "create")
        return RiskScore(6, reason=f"{action.title()} a public issue in {_REPO}")

    def audit_args(self, args: dict[str, Any]) -> dict[str, Any]:
        body = args.get("body") if isinstance(args.get("body"), str) else ""
        title = args.get("title") if isinstance(args.get("title"), str) else ""
        assignees = self._validate_assignees(args.get("assignees", []))
        return {
            "action": str(args.get("action") or ""),
            **({"issue_number": args["issue_number"]} if "issue_number" in args else {}),
            **({"title": self._sanitize_text(title)} if title else {}),
            **({"body": f"[omitted: {len(body)} chars]"} if body else {}),
            **(
                {"assignees": "[invalid]" if isinstance(assignees, str) else assignees}
                if "assignees" in args
                else {}
            ),
        }

    @staticmethod
    def _validate_title(title: str) -> str:
        prefix = next(
            (candidate for candidate in _TITLE_PREFIXES if title.startswith(candidate)), ""
        )
        if not prefix or not title[len(prefix) :].strip():
            return (
                "Refused: title must begin with '[Feedback] ' or "
                "'[fix societas bug] ' and include a summary."
            )
        if len(title[len(prefix) :]) > _MAX_SUMMARY_CHARS:
            return f"Refused: title summary exceeds {_MAX_SUMMARY_CHARS} characters."
        if any(char in title for char in ("\0", "\r", "\n")):
            return "Refused: title contains an invalid control character."
        return ""

    @staticmethod
    def _sanitize_text(value: str) -> str:
        sanitized = redact_credentials(value)
        sanitized = _EMAIL_RE.sub("[email]", sanitized)
        sanitized = _POSIX_HOME_RE.sub(r"\g<prefix>~", sanitized)
        return _WINDOWS_HOME_RE.sub(r"\g<prefix>~", sanitized)

    @staticmethod
    def _encode_body(body: str) -> tuple[bytes, str]:
        if not body.strip():
            return b"", "Refused: body must not be empty."
        sanitized = FeedbackSubmitTool._sanitize_text(body)
        try:
            encoded = sanitized.encode("utf-8")
        except UnicodeEncodeError:
            return b"", "Refused: body contains invalid Unicode."
        if len(encoded) > _MAX_BODY_BYTES:
            return b"", f"Refused: body is too large (maximum {_MAX_BODY_BYTES} bytes)."
        return encoded, ""

    def _append_session_diagnostics(self, body: str, session_id: str) -> str:
        """Append trusted, session-filtered diagnostics without exposing a selector."""
        if _DIAGNOSTICS_HEADING_RE.search(body):
            return body
        timeline = ""
        if self._diagnostics is not None:
            timeline = self._diagnostics.recent_session_diagnostics(session_id)
        timeline = timeline or "_No session diagnostics were available._"
        section_prefix = f"\n\n{_DIAGNOSTICS_HEADING}\n"

        # Size the addition after deterministic sanitization. Preserve the
        # user's report and trim only the automatically generated timeline.
        sanitized_body = self._sanitize_text(body)
        prefix_bytes = self._sanitize_text(section_prefix).encode("utf-8")
        remaining = _MAX_BODY_BYTES - len(sanitized_body.encode("utf-8")) - len(prefix_bytes)
        if remaining <= 0:
            return body
        sanitized_timeline = self._sanitize_text(timeline)
        encoded_timeline = sanitized_timeline.encode("utf-8")
        if len(encoded_timeline) > remaining:
            marker = "\n… diagnostics truncated to fit issue body limit …"
            marker_bytes = marker.encode("utf-8")
            budget = max(0, remaining - len(marker_bytes))
            encoded_timeline = encoded_timeline[:budget]
            while True:
                try:
                    sanitized_timeline = encoded_timeline.decode("utf-8")
                    break
                except UnicodeDecodeError:
                    encoded_timeline = encoded_timeline[:-1]
            if len(marker_bytes) <= remaining:
                sanitized_timeline += marker
        return f"{body}{section_prefix}{sanitized_timeline}"

    def _session_issue(self, session_id: str, issue_number: Any) -> _IssueRef | str:
        if not session_id:
            return "Refused: a trusted session is required for feedback follow-ups."
        if isinstance(issue_number, bool) or not isinstance(issue_number, int) or issue_number < 1:
            return "Refused: issue_number must be a positive integer."
        issue = self._issues_by_session.get(session_id, {}).get(issue_number)
        if issue is None:
            return "Refused: that issue was not created by feedback_submit in the current session."
        return issue

    @staticmethod
    def _validate_assignees(value: Any) -> list[str] | str:
        if not isinstance(value, list) or len(value) > _MAX_ASSIGNEES:
            return f"Refused: assignees must be a list of at most {_MAX_ASSIGNEES} GitHub logins."
        if any(not isinstance(login, str) or not _LOGIN_RE.fullmatch(login) for login in value):
            return "Refused: assignees must contain valid GitHub logins, not mentions or URLs."
        unique: dict[str, str] = {}
        for login in value:
            unique.setdefault(login.casefold(), login)
        return list(unique.values())

    @staticmethod
    def _result(action: str, issue: _IssueRef, assignment: dict[str, Any] | None = None) -> str:
        return json.dumps(
            {
                "action": action,
                "issue_number": issue.number,
                "url": issue.url,
                **({"assignment": assignment} if assignment is not None else {}),
            },
            ensure_ascii=False,
        )

    async def _api(
        self,
        method: str,
        endpoint: str,
        payload: dict[str, Any] | None = None,
        *,
        deadline: float,
    ) -> Any:
        argv = (*self._command, "api", "--hostname", "github.com", "--method", method, endpoint)
        stdin_data = b""
        if payload is not None:
            argv += ("--input", "-")
            stdin_data = json.dumps(payload).encode("utf-8")
        outcome = await self._run_bounded(argv, stdin_data, deadline - _FALLBACK_TIMEOUT_SECONDS)
        if isinstance(outcome, str):
            code = "transport_error" if "before completion" in outcome else "unavailable"
            raise _AssignmentError(code, self._sanitize_text(outcome)[:500])
        stdout, stderr, returncode = outcome
        if returncode:
            code = "transport_error"
            message = stderr or "GitHub request failed."
            try:
                error = json.loads(stdout)
            except ValueError:
                error = None
            if isinstance(error, dict):
                if isinstance(error.get("message"), str):
                    message = error["message"]
                status = str(error.get("status", ""))
                if re.fullmatch(r"[45]\d{2}", status):
                    code = f"http_{status}"
            if code == "transport_error":
                match = re.search(r"\(HTTP ([45]\d{2})\)", stderr)
                if match:
                    code = f"http_{match.group(1)}"
            raise _AssignmentError(code, self._sanitize_text(message)[:500])
        if not stdout:
            return None
        try:
            return json.loads(stdout)
        except ValueError as exc:
            raise _AssignmentError("invalid_response", "GitHub returned invalid JSON.") from exc

    @staticmethod
    def _issue_assignees(payload: Any, issue: _IssueRef) -> list[str]:
        if (
            not isinstance(payload, dict)
            or type(payload.get("number")) is not int
            or payload["number"] != issue.number
            or payload.get("html_url") != issue.url
            or payload.get("repository_url") != f"https://api.github.com/repos/{_REPO}"
        ):
            raise _AssignmentError("invalid_response", "GitHub did not return the requested issue.")
        if "pull_request" in payload:
            raise _AssignmentError(
                "not_an_issue", "Assignment is limited to issues, not pull requests."
            )
        assignees = payload.get("assignees")
        if not isinstance(assignees, list) or any(
            not isinstance(user, dict)
            or not isinstance(user.get("login"), str)
            or not user["login"]
            for user in assignees
        ):
            raise _AssignmentError("invalid_response", "GitHub did not return an assignees list.")
        return [user["login"] for user in assignees]

    @staticmethod
    def _assignment_summary(
        requested: list[str],
        existing: list[str],
        errors: dict[str, _AssignmentError],
        *,
        uncertain: bool = False,
    ) -> dict[str, Any]:
        current = {login.casefold(): login for login in existing}
        confirmed = [
            current[login.casefold()] for login in requested if login.casefold() in current
        ]
        failures = []
        for login in requested:
            if login.casefold() in current:
                continue
            error = errors.get(login) or _AssignmentError(
                "not_applied",
                "GitHub did not apply this assignment; the response does not establish why.",
            )
            failures.append({"login": login, "code": error.code, "message": str(error)})
        if not failures:
            status = "succeeded"
        elif uncertain:
            status = "unknown"
        else:
            status = "partial" if confirmed else "failed"
        return {
            "status": status,
            "requested": requested,
            "confirmed": confirmed,
            "errors": failures,
            "fallback": {"status": "not_needed" if not failures else "not_applicable"},
        }

    async def _assign_issue(
        self,
        issue: _IssueRef,
        requested: list[str],
        existing: list[str],
        session_id: str,
        deadline: float,
    ) -> dict[str, Any]:
        current = {login.casefold() for login in existing}
        eligible: list[str] = []
        errors: dict[str, _AssignmentError] = {}
        for login in requested:
            if login.casefold() in current:
                continue
            try:
                response = await self._api(
                    "GET", f"repos/{_REPO}/assignees/{login}", deadline=deadline
                )
                if response is not None:
                    raise _AssignmentError(
                        "invalid_response", "GitHub did not confirm assignability."
                    )
                eligible.append(login)
            except _AssignmentError as exc:
                errors[login] = (
                    _AssignmentError(
                        "not_assignable",
                        "The user is not assignable or not visible in this repository.",
                    )
                    if exc.code == "http_404"
                    else exc
                )

        uncertain = False
        if eligible:
            try:
                payload = await self._api(
                    "POST",
                    f"repos/{_REPO}/issues/{issue.number}/assignees",
                    {"assignees": eligible},
                    deadline=deadline,
                )
                existing = self._issue_assignees(payload, issue)
            except _AssignmentError as exc:
                errors.update({login: exc for login in eligible})
                uncertain = exc.code in {
                    "transport_error",
                    "invalid_response",
                    "timeout",
                } or exc.code.startswith("http_5")
                if uncertain:
                    try:
                        payload = await self._api(
                            "GET", f"repos/{_REPO}/issues/{issue.number}", deadline=deadline
                        )
                        existing = self._issue_assignees(payload, issue)
                    except _AssignmentError as recovery_error:
                        for login in eligible:
                            errors[login] = _AssignmentError(
                                "verification_failed",
                                f"Assignment could not be confirmed: {str(recovery_error)[:400]}",
                            )
                    confirmed = {login.casefold() for login in existing}
                    uncertain = any(login.casefold() not in confirmed for login in eligible)

        assignment = self._assignment_summary(requested, existing, errors, uncertain=uncertain)
        await self._assignment_fallback(issue, assignment, session_id, deadline)
        return assignment

    async def _assignment_fallback(
        self, issue: _IssueRef, assignment: dict[str, Any], session_id: str, deadline: float
    ) -> None:
        if assignment["status"] == "succeeded" or isinstance(
            self._session_issue(session_id, issue.number), str
        ):
            return
        body = (
            "## Requested assignment\n\n"
            f"Assignment status: {assignment['status']}. Only confirmed owners were verified.\n\n"
            + "\n".join(
                f"- `{error['login']}`: {error['code']} - {error['message']}"
                for error in assignment["errors"]
            )
        )
        encoded, refusal = self._encode_body(body)
        if refusal:
            assignment["fallback"] = {"status": "failed", "message": refusal}
            return
        argv = (
            *self._command,
            "issue",
            "comment",
            str(issue.number),
            "--repo",
            _REPO,
            "--body-file",
            "-",
        )
        try:
            outcome = await self._run_bounded(
                argv, encoded, min(deadline, monotonic() + _FALLBACK_TIMEOUT_SECONDS)
            )
        except _AssignmentError as exc:
            assignment["fallback"] = {
                "status": "not_attempted" if exc.code == "deadline_exceeded" else "unknown",
                "message": str(exc),
            }
            return
        if isinstance(outcome, str):
            message = outcome
        elif outcome[2]:
            message = outcome[1] or "The assignment fallback comment failed."
        else:
            assignment["fallback"] = {"status": "recorded"}
            return
        assignment["fallback"] = {"status": "failed", "message": self._sanitize_text(message)[:500]}

    async def _run_bounded(
        self, argv: tuple[str, ...], stdin_data: bytes, deadline: float
    ) -> tuple[str, str, int] | str:
        remaining = min(_GH_TIMEOUT_SECONDS, deadline - monotonic())
        if remaining <= 0:
            raise _AssignmentError(
                "deadline_exceeded", "Time budget exhausted; request not attempted."
            )
        try:
            return await asyncio.wait_for(self._run(argv, stdin_data), timeout=remaining)
        except TimeoutError as exc:
            raise _AssignmentError(
                "timeout", "GitHub request timed out; its result is unconfirmed."
            ) from exc

    async def _run(self, argv: tuple[str, ...], stdin_data: bytes) -> tuple[str, str, int] | str:
        try:
            process = await asyncio.create_subprocess_exec(
                *argv,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={**os.environ, "GH_PROMPT_DISABLED": "1"},
            )
        except FileNotFoundError:
            return "Feedback submission unavailable: GitHub CLI (`gh`) is not installed."
        except OSError as exc:
            return f"Feedback submission unavailable: {exc}"

        try:
            stdout, stderr = await process.communicate(stdin_data)
        except asyncio.CancelledError:
            if process.returncode is None:
                process.kill()
            await process.wait()
            raise
        except Exception as exc:
            if process.returncode is None:
                process.kill()
            await process.wait()
            return f"Feedback submission failed before completion: {exc}"

        return (
            stdout.decode("utf-8", errors="replace").strip(),
            stderr.decode("utf-8", errors="replace").strip(),
            int(process.returncode or 0),
        )

    async def execute(self, **kwargs: Any) -> str:
        action = str(kwargs.get("action") or "").strip().lower()
        if action not in _ACTIONS:
            return f"Refused: action must be one of {', '.join(sorted(_ACTIONS))}."
        if any(
            key not in self.parameters["properties"] for key in kwargs if not key.startswith("_")
        ):
            return "Refused: unsupported feedback parameter."

        # A promoted worker has an isolated execution session. The registry's
        # hidden, non-model-facing owner override keeps issue ownership and
        # diagnostics bound to the conversation that launched it.
        session_id = str(kwargs.get("_plan_session_id") or kwargs.get("_session_id") or "").strip()
        raw_title = kwargs.get("title")
        raw_body = kwargs.get("body")
        title: str = raw_title if isinstance(raw_title, str) else ""
        body: str = raw_body if isinstance(raw_body, str) else ""

        if "assignees" in kwargs and action not in {"create", "assign"}:
            return "Refused: assignees are accepted only for create or assign."
        assignees = self._validate_assignees(kwargs.get("assignees", []))
        if isinstance(assignees, str):
            return assignees
        deadline = monotonic() + _ASSIGNMENT_TIMEOUT_SECONDS
        if action == "assign":
            if "title" in kwargs or "body" in kwargs:
                return "Refused: assign does not accept title or body."
            if not assignees:
                return "Refused: assign requires nonempty assignees."
            issue_number = kwargs.get("issue_number")
            if type(issue_number) is not int or issue_number < 1:
                return "Refused: issue_number must be a positive integer."
            if not session_id:
                return "Refused: a trusted session is required to assign an issue."
            issue = _IssueRef(issue_number, f"https://github.com/{_REPO}/issues/{issue_number}")
            try:
                payload = await self._api(
                    "GET", f"repos/{_REPO}/issues/{issue.number}", deadline=deadline
                )
                existing = self._issue_assignees(payload, issue)
            except _AssignmentError as exc:
                return self._result(
                    action,
                    issue,
                    self._assignment_summary(assignees, [], {login: exc for login in assignees}),
                )
            assignment = await self._assign_issue(issue, assignees, existing, session_id, deadline)
            return self._result(action, issue, assignment)

        if action == "create":
            refusal = self._validate_title(title)
            if refusal:
                return refusal
            metadata = kwargs.get("_metadata")
            if (
                title.startswith("[Feedback] ")
                and isinstance(metadata, dict)
                and metadata.get("praesto_tag_exp") is True
                and session_id
            ):
                body = self._append_session_diagnostics(body, session_id)
            body_bytes, refusal = self._encode_body(body)
            if refusal:
                return refusal
            if not session_id:
                return "Refused: a trusted session is required to create feedback."
            sanitized_title = self._sanitize_text(title)
            try:
                sanitized_title.encode("utf-8")
            except UnicodeEncodeError:
                return "Refused: title contains invalid Unicode."
            argv = (
                *self._command,
                "issue",
                "create",
                "--repo",
                _REPO,
                "--title",
                sanitized_title,
                "--body-file",
                "-",
                "--label",
                "bug",
            )
            try:
                outcome = (
                    await self._run_bounded(argv, body_bytes, deadline - _FALLBACK_TIMEOUT_SECONDS)
                    if assignees
                    else await self._run(argv, body_bytes)
                )
            except _AssignmentError as exc:
                return (
                    f"Feedback issue may have been created, but creation is unconfirmed: {exc} "
                    "Do not automatically retry creation."
                )
            if isinstance(outcome, str):
                return outcome
            stdout_text, stderr_text, returncode = outcome
            if returncode != 0:
                detail = stderr_text or stdout_text or "no error output"
                return f"Feedback submission failed (exit {returncode}): {detail}"
            match = _ISSUE_URL_RE.search(stdout_text)
            if match is None:
                return "Feedback issue may have been created, but its URL could not be parsed."
            created_issue = _IssueRef(number=int(match.group("number")), url=match.group(0))
            self._issues_by_session.setdefault(session_id, {})[created_issue.number] = created_issue
            if assignees:
                assignment = await self._assign_issue(
                    created_issue, assignees, [], session_id, deadline
                )
                return self._result(action, created_issue, assignment)
            return self._result(action, created_issue)

        if action == "edit" and not title and not body:
            return "Refused: edit requires a title or body."

        session_issue = self._session_issue(session_id, kwargs.get("issue_number"))
        if isinstance(session_issue, str):
            return session_issue

        if action == "comment":
            body_bytes, refusal = self._encode_body(body)
            if refusal:
                return refusal
            argv = (
                *self._command,
                "issue",
                "comment",
                str(session_issue.number),
                "--repo",
                _REPO,
                "--body-file",
                "-",
            )
        else:
            argv_parts = [
                *self._command,
                "issue",
                "edit",
                str(session_issue.number),
                "--repo",
                _REPO,
            ]
            if title:
                refusal = self._validate_title(title)
                if refusal:
                    return refusal
                sanitized_title = self._sanitize_text(title)
                try:
                    sanitized_title.encode("utf-8")
                except UnicodeEncodeError:
                    return "Refused: title contains invalid Unicode."
                argv_parts.extend(("--title", sanitized_title))
            if body:
                body_bytes, refusal = self._encode_body(body)
                if refusal:
                    return refusal
                argv_parts.extend(("--body-file", "-"))
            else:
                body_bytes = b""
            argv = tuple(argv_parts)

        outcome = await self._run(argv, body_bytes)
        if isinstance(outcome, str):
            return outcome
        stdout_text, stderr_text, returncode = outcome
        if returncode != 0:
            detail = stderr_text or stdout_text or "no error output"
            return f"Feedback submission failed (exit {returncode}): {detail}"
        return self._result(action, session_issue)
