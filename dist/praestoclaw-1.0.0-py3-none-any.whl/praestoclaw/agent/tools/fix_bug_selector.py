"""Deterministic, read-only candidate selection for the fix-bug workflow."""

from __future__ import annotations

import asyncio
import json
import os
import re
import shutil
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, unquote, urlsplit

from praestoclaw.agent.tools.ado_query_active_prs import (
    AdoQueryActivePrsTool,
    _normalize_organization,
    _work_item_pull_request_refs,
)
from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.security.risk import RiskAssessment, RiskScore

ArgvRunner = Callable[[list[str]], Awaitable[str]]

_DEFAULT_MAX_ITEMS = 100
_MAX_ITEMS = 100
_MAX_REPO_PATH_LENGTH = 4096
_MAX_QUERY_URL_LENGTH = 8192
_MAX_TEXT_INPUT_LENGTH = 1024
_MAX_ISSUE_REF_LENGTH = 256
_MAX_RESULT_LENGTH = 16_000
_MAX_GITHUB_PULL_REQUEST_REFERENCES = 100
_MAX_GITHUB_PULL_REQUEST_READS = 200
_GITHUB_NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
_GITHUB_QUERY_PATH_RE = re.compile(r"^/([^/]+)/([^/]+)/issues$")
_GITHUB_ISSUE_PATH_RE = re.compile(r"^/([^/]+)/([^/]+)/issues/([1-9][0-9]*)$")
_SAVED_QUERY_RE = re.compile(
    r"^saved:([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$"
)
_COMMON_ADO_TERMINAL_STATES = frozenset(
    {"canceled", "cancelled", "closed", "completed", "done", "rejected", "removed", "resolved"}
)
_GITHUB_FIELDS = "number,state,url,closedByPullRequestsReferences"
_RUNTIME_PARAMETERS = frozenset(
    {"_channel", "_channel_id", "_thread_id", "_session_id", "_plan_session_id", "_metadata"}
)
_PUBLIC_PARAMETERS = frozenset(
    {
        "action",
        "provider",
        "repo_path",
        "query_url",
        "organization",
        "project",
        "source",
        "issue_ref",
        "max_items",
    }
)


@dataclass
class _GitHubReadBudget:
    pull_request_reads: int = 0


def _has_control(value: str) -> bool:
    return any(ord(character) < 32 or ord(character) == 127 for character in value)


def _safe_segment(value: str) -> str | None:
    decoded = unquote(value)
    if not decoded or _has_control(decoded) or "/" in decoded or "\\" in decoded:
        return None
    return decoded


def _positive_decimal(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value > 0 else None
    text = str(value or "").strip()
    if re.fullmatch(r"[1-9][0-9]*", text) is None:
        return None
    return int(text)


def _parse_github_https(
    value: str, path_pattern: re.Pattern[str]
) -> tuple[Any, re.Match[str]] | None:
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme.casefold() != "https"
        or parsed.hostname is None
        or parsed.hostname.casefold() != "github.com"
        or parsed.username is not None
        or parsed.password is not None
        or port is not None
        or parsed.fragment
    ):
        return None
    match = path_pattern.fullmatch(parsed.path)
    if match is None:
        return None
    if "%" in match.group(1) or "%" in match.group(2):
        return None
    owner = _safe_segment(match.group(1))
    repository = _safe_segment(match.group(2))
    if (
        owner is None
        or repository is None
        or _GITHUB_NAME_RE.fullmatch(owner) is None
        or _GITHUB_NAME_RE.fullmatch(repository) is None
    ):
        return None
    return parsed, match


def _parse_github_query(value: str) -> tuple[str, str, str] | None:
    parsed_match = _parse_github_https(value, _GITHUB_QUERY_PATH_RE)
    if parsed_match is None:
        return None
    parsed, match = parsed_match
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if len(pairs) != 1 or pairs[0][0] != "q":
        return None
    query = pairs[0][1]
    if not query.strip() or _has_control(query):
        return None
    owner = unquote(match.group(1))
    repository = unquote(match.group(2))
    slug = f"{owner}/{repository}"
    qualifiers = re.findall(r"(?:^|\s)repo:([^\s]+)", query, flags=re.IGNORECASE)
    if any(qualifier.casefold() != slug.casefold() for qualifier in qualifiers):
        return None
    return slug, query, value


def _parse_github_issue_url(value: str) -> tuple[str, int, str] | None:
    parsed_match = _parse_github_https(value, _GITHUB_ISSUE_PATH_RE)
    if parsed_match is None:
        return None
    parsed, match = parsed_match
    if parsed.query:
        return None
    owner = unquote(match.group(1))
    repository = unquote(match.group(2))
    number = int(match.group(3))
    canonical_url = f"https://github.com/{owner}/{repository}/issues/{number}"
    if value != canonical_url:
        return None
    return f"{owner}/{repository}", number, canonical_url


def _parse_github_origin(value: str) -> str | None:
    text = value.strip()
    scp_match = re.fullmatch(r"git@github\.com:([^/]+)/([^/]+)", text, flags=re.IGNORECASE)
    if scp_match is not None:
        owner, repository = scp_match.groups()
    else:
        try:
            parsed = urlsplit(text)
            port = parsed.port
        except ValueError:
            return None
        scheme = parsed.scheme.casefold()
        if (
            scheme not in {"https", "ssh"}
            or (parsed.hostname or "").casefold() != "github.com"
            or parsed.password is not None
            or port is not None
            or parsed.query
            or parsed.fragment
        ):
            return None
        if scheme == "https" and parsed.username is not None:
            return None
        if scheme == "ssh" and parsed.username != "git":
            return None
        match = re.fullmatch(r"/([^/]+)/([^/]+)", parsed.path)
        if match is None:
            return None
        owner, repository = match.groups()
    repository = repository.removesuffix(".git")
    owner = _safe_segment(owner) or ""
    repository = _safe_segment(repository) or ""
    if _GITHUB_NAME_RE.fullmatch(owner) is None or _GITHUB_NAME_RE.fullmatch(repository) is None:
        return None
    return f"{owner}/{repository}"


def _organization_name(value: str) -> str | None:
    normalized = _normalize_organization(value)
    if normalized is None:
        return None
    parsed = urlsplit(normalized)
    if parsed.hostname == "dev.azure.com":
        return parsed.path.removeprefix("/").casefold()
    return (parsed.hostname or "").removesuffix(".visualstudio.com").casefold()


def _parse_ado_origin(value: str) -> tuple[str, str, str] | None:
    text = value.strip()
    scp_match = re.fullmatch(
        r"git@ssh\.dev\.azure\.com:v3/([^/]+)/([^/]+)/([^/]+)",
        text,
        flags=re.IGNORECASE,
    )
    if scp_match is not None:
        organization_raw, project_raw, repository_raw = scp_match.groups()
        organization = _safe_segment(organization_raw)
    else:
        try:
            parsed = urlsplit(text)
            port = parsed.port
        except ValueError:
            return None
        if (
            parsed.scheme.casefold() != "https"
            or parsed.hostname is None
            or parsed.username is not None
            or parsed.password is not None
            or port is not None
            or parsed.query
            or parsed.fragment
        ):
            return None
        host = parsed.hostname.casefold()
        segments = [segment for segment in parsed.path.split("/") if segment]
        if host == "dev.azure.com" and len(segments) == 4 and segments[2].casefold() == "_git":
            organization_raw, project_raw, _, repository_raw = segments
            organization = _safe_segment(organization_raw)
        elif (
            host.endswith(".visualstudio.com")
            and len(segments) == 3
            and segments[1].casefold() == "_git"
        ):
            project_raw, _, repository_raw = segments
            organization = host.removesuffix(".visualstudio.com")
        else:
            return None
    project = _safe_segment(project_raw)
    repository = _safe_segment(repository_raw)
    if organization is None or project is None or repository is None:
        return None
    repository = repository.removesuffix(".git")
    if not repository:
        return None
    return organization.casefold(), project, repository


def _canonical_source(value: Any) -> str | None:
    match = _SAVED_QUERY_RE.fullmatch(str(value or "").strip())
    return f"saved:{match.group(1).lower()}" if match is not None else None


async def _run_cli(executable_name: str, args: list[str]) -> str:
    executable = shutil.which(executable_name)
    if not executable:
        raise RuntimeError(f"{executable_name} executable was not found")
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    process = await asyncio.create_subprocess_exec(
        executable,
        *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )
    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=120)
    except TimeoutError:
        process.kill()
        await process.wait()
        raise RuntimeError(f"{executable_name} timed out") from None
    except asyncio.CancelledError:
        try:
            process.kill()
        except ProcessLookupError:
            pass
        await process.wait()
        raise
    if process.returncode != 0:
        detail = (stderr or stdout).decode("utf-8", errors="replace").strip()
        raise RuntimeError(detail or f"{executable_name} exited with {process.returncode}")
    return stdout.decode("utf-8-sig", errors="replace")


async def _run_git(args: list[str]) -> str:
    return await _run_cli("git", args)


async def _run_gh(args: list[str]) -> str:
    return await _run_cli("gh", args)


async def _run_az(args: list[str]) -> str:
    return await _run_cli("az", args)


def _json_payload(raw: str, provider: str) -> Any:
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise RuntimeError(f"{provider} provider returned malformed data") from exc


def _result(
    *,
    provider: str,
    complete: bool,
    eligible: bool,
    issue_ref: str | None,
    item_id: int | None,
    scope: dict[str, Any],
    reason: str,
) -> str:
    payload = {
        "complete": complete,
        "eligible": eligible,
        "issue_ref": issue_ref,
        "item_id": item_id,
        "provider": provider,
        "reason": reason,
        "scope": scope,
    }
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


class FixBugSelectorTool(Tool):
    """Select and freshly revalidate one fix-bug candidate."""

    risk_range = (3, 3)

    def __init__(
        self,
        *,
        git_runner: ArgvRunner | None = None,
        gh_runner: ArgvRunner | None = None,
        az_runner: ArgvRunner | None = None,
    ) -> None:
        self._git_runner = git_runner or _run_git
        self._gh_runner = gh_runner or _run_gh
        self._az_runner = az_runner or _run_az
        self._ado = AdoQueryActivePrsTool(az_runner=self._az_runner)

    def _eligible_result(
        self,
        *,
        provider: str,
        issue_ref: str,
        item_id: int,
        scope: dict[str, Any],
    ) -> str:
        """Return the fixed selector shape after every freshness check passed."""
        return _result(
            provider=provider,
            complete=True,
            eligible=True,
            issue_ref=issue_ref,
            item_id=item_id,
            scope=scope,
            reason="eligible",
        )

    @property
    def name(self) -> str:
        return "fix_bug_selector"

    @property
    def description(self) -> str:
        return (
            "Deterministically select or freshly revalidate one GitHub issue or Azure DevOps "
            "work item for fix-bug without reading report prose."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        base_properties: dict[str, Any] = {
            "action": {"type": "string", "enum": ["select", "revalidate"]},
            "provider": {"type": "string", "enum": ["github", "ado"]},
            "repo_path": {"type": "string", "minLength": 1, "maxLength": _MAX_REPO_PATH_LENGTH},
            "query_url": {"type": "string", "minLength": 1, "maxLength": _MAX_QUERY_URL_LENGTH},
            "organization": {"type": "string", "minLength": 1, "maxLength": _MAX_TEXT_INPUT_LENGTH},
            "project": {"type": "string", "minLength": 1, "maxLength": _MAX_TEXT_INPUT_LENGTH},
            "source": {"type": "string", "minLength": 1, "maxLength": _MAX_TEXT_INPUT_LENGTH},
            "issue_ref": {
                "oneOf": [
                    {"type": "string", "minLength": 1, "maxLength": _MAX_ISSUE_REF_LENGTH},
                    {"type": "integer", "minimum": 1, "maximum": 9_007_199_254_740_991},
                ]
            },
            "max_items": {"type": "integer", "minimum": 1, "maximum": _MAX_ITEMS},
        }
        return {
            "type": "object",
            "properties": base_properties,
            "required": ["action", "provider", "repo_path"],
            "additionalProperties": False,
            "oneOf": [
                {
                    "type": "object",
                    "properties": {
                        "action": {"const": "select"},
                        "provider": {"const": "github"},
                        "repo_path": base_properties["repo_path"],
                        "query_url": base_properties["query_url"],
                        "max_items": base_properties["max_items"],
                    },
                    "required": ["action", "provider", "repo_path", "query_url"],
                    "additionalProperties": False,
                },
                {
                    "type": "object",
                    "properties": {
                        "action": {"const": "revalidate"},
                        "provider": {"const": "github"},
                        "repo_path": base_properties["repo_path"],
                        "issue_ref": base_properties["issue_ref"],
                    },
                    "required": ["action", "provider", "repo_path", "issue_ref"],
                    "additionalProperties": False,
                },
                {
                    "type": "object",
                    "properties": {
                        "action": {"const": "select"},
                        "provider": {"const": "ado"},
                        "repo_path": base_properties["repo_path"],
                        "organization": base_properties["organization"],
                        "project": base_properties["project"],
                        "source": base_properties["source"],
                        "max_items": base_properties["max_items"],
                    },
                    "required": [
                        "action",
                        "provider",
                        "repo_path",
                        "organization",
                        "project",
                        "source",
                    ],
                    "additionalProperties": False,
                },
                {
                    "type": "object",
                    "properties": {
                        "action": {"const": "revalidate"},
                        "provider": {"const": "ado"},
                        "repo_path": base_properties["repo_path"],
                        "organization": base_properties["organization"],
                        "project": base_properties["project"],
                        "source": base_properties["source"],
                        "issue_ref": base_properties["issue_ref"],
                        "max_items": base_properties["max_items"],
                    },
                    "required": ["action", "provider", "repo_path", "organization", "issue_ref"],
                    "additionalProperties": False,
                },
            ],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=600, max_output_chars=_MAX_RESULT_LENGTH)

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(3, reason="Deterministic read-only issue and pull-request queries")

    def validate(self, args: dict[str, Any]) -> list[str]:
        public_keys = {key for key in args if key not in _RUNTIME_PARAMETERS}
        unexpected = sorted(public_keys - _PUBLIC_PARAMETERS)
        if unexpected:
            return [f"unexpected parameter(s): {', '.join(unexpected)}"]

        errors: list[str] = []
        action = str(args.get("action") or "").strip()
        provider = str(args.get("provider") or "").strip()
        repo_path = str(args.get("repo_path") or "").strip()
        if action not in {"select", "revalidate"}:
            errors.append("action must be select or revalidate")
        if provider not in {"github", "ado"}:
            errors.append("provider must be github or ado")
        if (
            not repo_path
            or len(repo_path) > _MAX_REPO_PATH_LENGTH
            or not Path(repo_path).is_absolute()
            or _has_control(repo_path)
        ):
            errors.append("repo_path must be a non-empty absolute path")
        max_items = args.get("max_items", _DEFAULT_MAX_ITEMS)
        if (
            isinstance(max_items, bool)
            or not isinstance(max_items, int)
            or not 1 <= max_items <= _MAX_ITEMS
        ):
            errors.append(f"max_items must be an integer between 1 and {_MAX_ITEMS}")

        valid_by_shape = {
            ("github", "select"): {"action", "provider", "repo_path", "query_url", "max_items"},
            ("github", "revalidate"): {
                "action",
                "provider",
                "repo_path",
                "issue_ref",
            },
            ("ado", "select"): {
                "action",
                "provider",
                "repo_path",
                "organization",
                "project",
                "source",
                "max_items",
            },
            ("ado", "revalidate"): {
                "action",
                "provider",
                "repo_path",
                "organization",
                "project",
                "source",
                "issue_ref",
                "max_items",
            },
        }
        allowed = valid_by_shape.get((provider, action))
        if allowed is not None:
            invalid_for_shape = sorted(public_keys - allowed)
            if invalid_for_shape:
                errors.append(
                    f"parameter(s) not valid for {provider} {action}: "
                    + ", ".join(invalid_for_shape)
                )

        if provider == "github" and action == "select":
            query_url = str(args.get("query_url") or "")
            if len(query_url) > _MAX_QUERY_URL_LENGTH or _parse_github_query(query_url) is None:
                errors.append(
                    "query_url must be a canonical repository-specific GitHub issues URL with exactly one non-empty q"
                )
        elif provider == "github" and action == "revalidate":
            issue_ref = args.get("issue_ref")
            issue_number = _positive_decimal(issue_ref)
            if (
                len(str(issue_ref or "")) > _MAX_ISSUE_REF_LENGTH
                or issue_number is None
                and _parse_github_issue_url(str(issue_ref or "")) is None
            ):
                errors.append(
                    "issue_ref must be a positive issue number or canonical GitHub issue URL"
                )
            elif issue_number is not None and issue_number > 9_007_199_254_740_991:
                errors.append(
                    "issue_ref must be a positive issue number or canonical GitHub issue URL"
                )
        elif provider == "ado" and action == "select":
            if _normalize_organization(args.get("organization")) is None:
                errors.append(
                    "organization must be a canonical Azure DevOps HTTPS organization URL"
                )
            if not str(args.get("project") or "").strip():
                errors.append("project is required")
            if _canonical_source(args.get("source")) is None:
                errors.append("source must be saved:<GUID> with strict 8-4-4-4-12 hex form")
        elif provider == "ado" and action == "revalidate":
            if _normalize_organization(args.get("organization")) is None:
                errors.append(
                    "organization must be a canonical Azure DevOps HTTPS organization URL"
                )
            if _positive_decimal(args.get("issue_ref")) is None:
                errors.append("issue_ref must be a positive decimal work-item id")
            has_project = bool(str(args.get("project") or "").strip())
            has_source = bool(str(args.get("source") or "").strip())
            if has_project != has_source:
                errors.append(
                    "project and source must be supplied together for saved-query revalidation"
                )
            if has_source and _canonical_source(args.get("source")) is None:
                errors.append("source must be saved:<GUID> with strict 8-4-4-4-12 hex form")
        return errors

    async def _repository_identity(self, repo_path: str) -> tuple[str, str]:
        try:
            top_level_raw = await self._git_runner(
                ["-C", repo_path, "rev-parse", "--show-toplevel"]
            )
            top_level = top_level_raw.strip()
            if not top_level or Path(top_level).resolve() != Path(repo_path).resolve():
                raise ValueError("top level mismatch")
            origin = (
                await self._git_runner(["-C", repo_path, "remote", "get-url", "origin"])
            ).strip()
        except (OSError, RuntimeError, ValueError):
            raise RuntimeError("repository identity validation failed") from None
        if not origin or "\n" in origin or "\r" in origin:
            raise RuntimeError("repository identity validation failed")
        return top_level, origin

    async def revalidate_for_workflow(self, **kwargs: Any) -> str:
        """Trusted workflow adapter with provider inference from canonical origin.

        The public tool keeps its strict explicit-provider schema. Manual workflow
        launches use this narrower internal seam so they never parse profile prose.
        """
        requested_repo_path = str(kwargs.get("repo_path") or "").strip()
        issue_ref = kwargs.get("issue_ref")
        try:
            repo_path, origin = await self._repository_identity(requested_repo_path)
        except RuntimeError:
            return "Error: repository identity validation failed; no candidate returned"
        provider = kwargs.get("provider")
        if provider is None:
            provider = "ado" if _parse_ado_origin(origin) is not None else "github"
        if provider == "github":
            origin_repository = _parse_github_origin(origin)
            query_url = str(kwargs.get("query_url") or "").strip()
            if query_url:
                parsed_query = _parse_github_query(query_url)
                if parsed_query is None:
                    return "Error: selector query scope is invalid"
                query_repository, query, canonical_query_url = parsed_query
                if origin_repository is None or (
                    query_repository.casefold() != origin_repository.casefold()
                ):
                    return "Error: repository origin does not match the GitHub query scope"
                expected_number = _positive_decimal(issue_ref)
                parsed_issue = _parse_github_issue_url(str(issue_ref or ""))
                if expected_number is not None:
                    canonical_issue_url = (
                        f"https://github.com/{query_repository}/issues/{expected_number}"
                    )
                elif parsed_issue is not None:
                    issue_repository, expected_number, canonical_issue_url = parsed_issue
                    if issue_repository.casefold() != query_repository.casefold():
                        return "Error: issue_ref does not match the GitHub query scope"
                else:
                    return (
                        "Error: issue_ref must be a positive issue number or canonical "
                        "GitHub issue URL"
                    )
                scope = {
                    "query_url": canonical_query_url,
                    "repo_path": repo_path,
                    "repository": query_repository,
                }
                try:
                    rows, truncated = await self._github_query(
                        repository=query_repository,
                        query=query,
                        max_items=_DEFAULT_MAX_ITEMS,
                    )
                except (OSError, RuntimeError):
                    return "Error: GitHub provider read failed; no candidate returned"
                if truncated:
                    return "Error: GitHub query exceeded max_items; no candidate returned"
                if expected_number not in {number for number, _, _ in rows}:
                    return _result(
                        provider="github",
                        complete=True,
                        eligible=False,
                        issue_ref=canonical_issue_url,
                        item_id=expected_number,
                        scope=scope,
                        reason="issue is not in the GitHub query",
                    )
            result = await self._github_revalidate(
                repo_path=repo_path,
                origin=origin,
                issue_ref=issue_ref,
            )
            return self._with_scope(result, scope) if query_url else result
        if provider != "ado":
            return "Error: unsupported selector provider; no candidate returned"
        identity = _parse_ado_origin(origin)
        if identity is None:
            return "Error: repository origin is not a supported Azure DevOps remote"
        organization = f"https://dev.azure.com/{identity[0]}"
        project_name = str(kwargs.get("project") or "").strip() or None
        source = str(kwargs.get("source") or "").strip() or None
        if bool(project_name) != bool(source):
            return "Error: project and source must be supplied together"
        result = await self._ado_revalidate(
            repo_path=repo_path,
            origin=origin,
            organization=organization,
            issue_ref=issue_ref,
            project_name=project_name,
            source=source,
            max_items=_DEFAULT_MAX_ITEMS,
        )
        return result

    @staticmethod
    def _with_scope(raw: str, scope: dict[str, Any]) -> str:
        """Bind exact-item revalidation output to its freshly read query scope."""
        if not raw.startswith("{"):
            return raw
        try:
            payload = json.loads(raw)
        except (json.JSONDecodeError, UnicodeError):
            return raw
        if not isinstance(payload, dict):
            return raw
        payload["scope"] = dict(scope)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)

    @staticmethod
    def _github_pull_request_reference(raw: Any, *, repository: str) -> int:
        if not isinstance(raw, dict):
            raise RuntimeError("GitHub provider returned malformed data")
        number = raw.get("number")
        url = raw.get("url")
        repository_details = raw.get("repository")
        owner_details = (
            repository_details.get("owner") if isinstance(repository_details, dict) else None
        )
        owner = owner_details.get("login") if isinstance(owner_details, dict) else None
        name = repository_details.get("name") if isinstance(repository_details, dict) else None
        if (
            isinstance(number, bool)
            or not isinstance(number, int)
            or number <= 0
            or not isinstance(url, str)
            or not isinstance(owner, str)
            or not isinstance(name, str)
            or f"{owner}/{name}" != repository
            or url != f"https://github.com/{repository}/pull/{number}"
        ):
            raise RuntimeError("GitHub provider returned malformed data")
        return number

    @staticmethod
    def _github_item(
        raw: Any,
        *,
        repository: str,
        expected_number: int | None = None,
    ) -> tuple[int, str, list[int]]:
        if not isinstance(raw, dict):
            raise RuntimeError("GitHub provider returned malformed data")
        number = raw.get("number")
        state = raw.get("state")
        url = raw.get("url")
        pull_requests = raw.get("closedByPullRequestsReferences")
        if (
            isinstance(number, bool)
            or not isinstance(number, int)
            or number <= 0
            or not isinstance(state, str)
            or state.upper() not in {"OPEN", "CLOSED"}
            or not isinstance(url, str)
            or not isinstance(pull_requests, list)
            or (expected_number is not None and number != expected_number)
        ):
            raise RuntimeError("GitHub provider returned malformed data")
        expected_url = f"https://github.com/{repository}/issues/{number}"
        if url != expected_url:
            raise RuntimeError("GitHub provider returned a non-canonical issue URL")
        if len(pull_requests) > _MAX_GITHUB_PULL_REQUEST_REFERENCES:
            raise RuntimeError("GitHub provider returned malformed data")
        pull_request_numbers = [
            FixBugSelectorTool._github_pull_request_reference(
                pull_request,
                repository=repository,
            )
            for pull_request in pull_requests
        ]
        return number, state.upper(), pull_request_numbers

    async def _github_pull_request_state(
        self,
        repository: str,
        number: int,
        budget: _GitHubReadBudget,
    ) -> str:
        if budget.pull_request_reads >= _MAX_GITHUB_PULL_REQUEST_READS:
            raise RuntimeError("GitHub provider call budget exceeded")
        budget.pull_request_reads += 1
        raw = await self._gh_runner(
            [
                "pr",
                "view",
                str(number),
                "--repo",
                repository,
                "--json",
                "number,state,url",
            ]
        )
        payload = _json_payload(raw, "GitHub")
        if not isinstance(payload, dict):
            raise RuntimeError("GitHub provider returned malformed data")
        actual_number = payload.get("number")
        state = payload.get("state")
        url = payload.get("url")
        if (
            isinstance(actual_number, bool)
            or actual_number != number
            or not isinstance(state, str)
            or state.upper() not in {"OPEN", "CLOSED", "MERGED"}
            or url != f"https://github.com/{repository}/pull/{number}"
        ):
            raise RuntimeError("GitHub provider returned malformed data")
        return state.upper()

    async def _github_has_open_pull_request(
        self,
        repository: str,
        pull_request_numbers: list[int],
        budget: _GitHubReadBudget,
    ) -> bool:
        for pull_request_number in pull_request_numbers:
            if (
                await self._github_pull_request_state(
                    repository,
                    pull_request_number,
                    budget,
                )
                == "OPEN"
            ):
                return True
        return False

    async def _github_read(self, repository: str, number: int) -> tuple[int, str, list[int]]:
        raw = await self._gh_runner(
            [
                "issue",
                "view",
                str(number),
                "--repo",
                repository,
                "--json",
                _GITHUB_FIELDS,
            ]
        )
        return self._github_item(
            _json_payload(raw, "GitHub"),
            repository=repository,
            expected_number=number,
        )

    async def _github_query(
        self,
        *,
        repository: str,
        query: str,
        max_items: int,
    ) -> tuple[list[tuple[int, str, list[int]]], bool]:
        raw = await self._gh_runner(
            [
                "issue",
                "list",
                "--repo",
                repository,
                "--search",
                query,
                "--limit",
                str(max_items + 1),
                "--json",
                _GITHUB_FIELDS,
            ]
        )
        rows = _json_payload(raw, "GitHub")
        if not isinstance(rows, list):
            raise RuntimeError("GitHub provider returned malformed data")
        if len(rows) > max_items:
            return [], True
        return (
            [self._github_item(raw_item, repository=repository) for raw_item in rows],
            False,
        )

    async def _github_select(
        self,
        *,
        repo_path: str,
        origin: str,
        query_url: str,
        max_items: int,
    ) -> str:
        parsed_query = _parse_github_query(query_url)
        if parsed_query is None:
            return "Error: invalid GitHub query URL; no candidate returned"
        repository, query, canonical_query_url = parsed_query
        origin_repository = _parse_github_origin(origin)
        if origin_repository is None:
            return "Error: repository origin is not a supported GitHub remote"
        if origin_repository.casefold() != repository.casefold():
            return "Error: repository origin does not match the GitHub query scope"
        scope = {
            "query_url": canonical_query_url,
            "repo_path": repo_path,
            "repository": repository,
        }
        budget = _GitHubReadBudget()
        try:
            rows, truncated = await self._github_query(
                repository=repository,
                query=query,
                max_items=max_items,
            )
            if truncated:
                return "Error: GitHub query exceeded max_items; no candidate returned"
            refreshed_numbers: set[int] | None = None
            for number, state, _ in rows:
                if state != "OPEN":
                    continue
                if refreshed_numbers is None:
                    refreshed_rows, refreshed_truncated = await self._github_query(
                        repository=repository,
                        query=query,
                        max_items=max_items,
                    )
                    if refreshed_truncated:
                        return "Error: GitHub query exceeded max_items; no candidate returned"
                    refreshed_numbers = {item_number for item_number, _, _ in refreshed_rows}
                if number not in refreshed_numbers:
                    continue
                _, fresh_state, fresh_pull_request_numbers = await self._github_read(
                    repository=repository,
                    number=number,
                )
                if fresh_state != "OPEN" or await self._github_has_open_pull_request(
                    repository,
                    fresh_pull_request_numbers,
                    budget,
                ):
                    continue
                canonical_issue_url = f"https://github.com/{repository}/issues/{number}"
                return self._eligible_result(
                    provider="github",
                    issue_ref=canonical_issue_url,
                    item_id=number,
                    scope=scope,
                )
        except (OSError, RuntimeError) as exc:
            if str(exc) == "GitHub provider returned malformed data":
                return "Error: GitHub provider returned malformed data; no candidate returned"
            if str(exc) == "GitHub provider returned a non-canonical issue URL":
                return "Error: GitHub provider returned a non-canonical issue URL; no candidate returned"
            return "Error: GitHub provider read failed; no candidate returned"
        return _result(
            provider="github",
            complete=True,
            eligible=False,
            issue_ref=None,
            item_id=None,
            scope=scope,
            reason="query complete; no eligible item",
        )

    async def _github_revalidate(
        self,
        *,
        repo_path: str,
        origin: str,
        issue_ref: Any,
    ) -> str:
        origin_repository = _parse_github_origin(origin)
        if origin_repository is None:
            return "Error: repository origin is not a supported GitHub remote"
        parsed_url = _parse_github_issue_url(str(issue_ref or ""))
        if parsed_url is not None:
            repository, number, canonical_issue_url = parsed_url
            if repository.casefold() != origin_repository.casefold():
                return "Error: issue_ref does not match the repository origin"
        else:
            parsed_number = _positive_decimal(issue_ref)
            if parsed_number is None:
                return "Error: invalid GitHub issue_ref"
            number = parsed_number
            repository = origin_repository
            canonical_issue_url = f"https://github.com/{repository}/issues/{number}"
        scope = {"mode": "exact-issue", "repo_path": repo_path, "repository": repository}
        budget = _GitHubReadBudget()
        try:
            _, state, pull_request_numbers = await self._github_read(repository, number)
            has_open_pull_request = state == "OPEN" and await self._github_has_open_pull_request(
                repository,
                pull_request_numbers,
                budget,
            )
        except (OSError, RuntimeError) as exc:
            if str(exc) == "GitHub provider returned a non-canonical issue URL":
                return "Error: GitHub provider returned a non-canonical issue URL; no candidate returned"
            if str(exc) == "GitHub provider returned malformed data":
                return "Error: GitHub provider returned malformed data; no candidate returned"
            return "Error: GitHub provider read failed; no candidate returned"
        eligible = state == "OPEN" and not has_open_pull_request
        reason = (
            "eligible"
            if eligible
            else "issue is not open"
            if state != "OPEN"
            else "issue has an open linked pull request"
        )
        return _result(
            provider="github",
            complete=True,
            eligible=eligible,
            issue_ref=canonical_issue_url,
            item_id=number,
            scope=scope,
            reason=reason,
        )

    @staticmethod
    def _ado_validate_project(details: dict[str, Any], work_item_id: int, project_name: str) -> str:
        fields = details.get("fields")
        if not isinstance(fields, dict):
            raise RuntimeError("Azure DevOps provider returned malformed data")
        team_project = str(fields.get("System.TeamProject") or "").strip()
        if team_project.casefold() != project_name.casefold():
            raise RuntimeError("Azure DevOps work item is outside the query project")
        if details.get("id") != work_item_id:
            raise RuntimeError("Azure DevOps provider returned malformed data")
        state = fields.get("System.State")
        if not isinstance(state, str) or not state.strip():
            raise RuntimeError("Azure DevOps provider returned malformed data")
        return state.strip().casefold()

    async def _ado_has_active_pull_request(
        self,
        details: dict[str, Any],
        *,
        work_item_id: int,
        organization: str,
        default_project: str,
        cache: dict[tuple[str, str], dict[int, dict[str, Any]]] | None = None,
    ) -> bool:
        refs = _work_item_pull_request_refs(
            details,
            work_item_id=work_item_id,
            organization=organization,
            default_project=default_project,
        )
        active_by_repo = cache if cache is not None else {}
        for pull_request_ref in refs:
            repo_key = (pull_request_ref.project, pull_request_ref.repository)
            if repo_key not in active_by_repo:
                active_by_repo[repo_key] = await self._ado._list_active_pull_requests(
                    organization=organization,
                    project=pull_request_ref.project,
                    repository=pull_request_ref.repository,
                )
            if pull_request_ref.pull_request_id in active_by_repo[repo_key]:
                return True
        return False

    async def _ado_select(
        self,
        *,
        repo_path: str,
        origin: str,
        organization: str,
        requested_project: str,
        source: str,
        max_items: int,
    ) -> str:
        origin_identity = _parse_ado_origin(origin)
        normalized_organization = _normalize_organization(organization)
        requested_organization_name = _organization_name(organization)
        if origin_identity is None:
            return "Error: repository origin is not a supported Azure DevOps remote"
        origin_organization, repository_project, repository_name = origin_identity
        if normalized_organization is None or requested_organization_name != origin_organization:
            return "Error: repository origin does not match the Azure DevOps organization"
        canonical_source = _canonical_source(source)
        if canonical_source is None:
            return "Error: source must be saved:<GUID> with strict 8-4-4-4-12 hex form"
        try:
            project = await self._ado._resolve_project(normalized_organization, requested_project)
            work_item_ids, truncated = await self._ado._query_work_item_ids(
                canonical_source,
                organization=normalized_organization,
                project=project,
                max_items=max_items,
            )
            if truncated:
                return "Error: Azure DevOps query exceeded max_items; no candidate returned"
            details = (
                await self._ado._hydrate_work_items(
                    work_item_ids,
                    organization=normalized_organization,
                    project=project.project_id,
                )
                if work_item_ids
                else []
            )
            active_cache: dict[tuple[str, str], dict[int, dict[str, Any]]] = {}
            for work_item_id, item in zip(work_item_ids, details, strict=True):
                state = self._ado_validate_project(item, work_item_id, project.name)
                if state in _COMMON_ADO_TERMINAL_STATES:
                    continue
                if await self._ado_has_active_pull_request(
                    item,
                    work_item_id=work_item_id,
                    organization=normalized_organization,
                    default_project=project.project_id,
                    cache=active_cache,
                ):
                    continue

                fresh_ids, fresh_truncated = await self._ado._query_work_item_ids(
                    canonical_source,
                    organization=normalized_organization,
                    project=project,
                    max_items=max_items,
                )
                if fresh_truncated:
                    return "Error: Azure DevOps query exceeded max_items; no candidate returned"
                if work_item_id not in fresh_ids:
                    continue
                fresh_item = (
                    await self._ado._hydrate_work_items(
                        [work_item_id],
                        organization=normalized_organization,
                        project=project.project_id,
                    )
                )[0]
                fresh_state = self._ado_validate_project(
                    fresh_item,
                    work_item_id,
                    project.name,
                )
                if fresh_state in _COMMON_ADO_TERMINAL_STATES:
                    continue
                if await self._ado_has_active_pull_request(
                    fresh_item,
                    work_item_id=work_item_id,
                    organization=normalized_organization,
                    default_project=project.project_id,
                ):
                    continue
                scope = {
                    "organization": normalized_organization,
                    "project": project.name,
                    "project_id": project.project_id,
                    "repo_path": repo_path,
                    "repository": f"{repository_project}/{repository_name}",
                    "source": canonical_source,
                }
                return self._eligible_result(
                    provider="ado",
                    issue_ref=str(work_item_id),
                    item_id=work_item_id,
                    scope=scope,
                )
            scope = {
                "organization": normalized_organization,
                "project": project.name,
                "project_id": project.project_id,
                "repo_path": repo_path,
                "repository": f"{repository_project}/{repository_name}",
                "source": canonical_source,
            }
            return _result(
                provider="ado",
                complete=True,
                eligible=False,
                issue_ref=None,
                item_id=None,
                scope=scope,
                reason="query complete; no eligible item",
            )
        except (OSError, RuntimeError, TypeError, ValueError):
            return "Error: Azure DevOps provider read failed; no candidate returned"

    @staticmethod
    def _validate_exact_ado_item(
        payload: Any,
        *,
        organization: str,
        work_item_id: int,
    ) -> dict[str, Any]:
        if not isinstance(payload, dict) or payload.get("id") != work_item_id:
            raise RuntimeError("Azure DevOps provider returned malformed data")
        fields = payload.get("fields")
        if not isinstance(fields, dict) or not str(fields.get("System.State") or "").strip():
            raise RuntimeError("Azure DevOps provider returned malformed data")
        item_url = str(payload.get("url") or "")
        expected_url = f"{organization.rstrip('/')}/_apis/wit/workItems/{work_item_id}"
        if item_url.casefold() != expected_url.casefold():
            raise RuntimeError("Azure DevOps provider returned malformed data")
        return payload

    async def _ado_revalidate(
        self,
        *,
        repo_path: str,
        origin: str,
        organization: str,
        issue_ref: Any,
        project_name: str | None,
        source: str | None,
        max_items: int,
    ) -> str:
        origin_identity = _parse_ado_origin(origin)
        normalized_organization = _normalize_organization(organization)
        requested_organization_name = _organization_name(organization)
        if origin_identity is None:
            return "Error: repository origin is not a supported Azure DevOps remote"
        origin_organization, repository_project, repository_name = origin_identity
        if normalized_organization is None or requested_organization_name != origin_organization:
            return "Error: repository origin does not match the Azure DevOps organization"
        work_item_id = _positive_decimal(issue_ref)
        if work_item_id is None:
            return "Error: issue_ref must be a positive decimal work-item id"
        try:
            if project_name is not None and source is not None:
                canonical_source = _canonical_source(source)
                if canonical_source is None:
                    return "Error: source must be saved:<GUID> with strict 8-4-4-4-12 hex form"
                project = await self._ado._resolve_project(normalized_organization, project_name)
                work_item_ids, truncated = await self._ado._query_work_item_ids(
                    canonical_source,
                    organization=normalized_organization,
                    project=project,
                    max_items=max_items,
                )
                if truncated:
                    return "Error: Azure DevOps query exceeded max_items; no candidate returned"
                scope = {
                    "organization": normalized_organization,
                    "project": project.name,
                    "project_id": project.project_id,
                    "repo_path": repo_path,
                    "repository": f"{repository_project}/{repository_name}",
                    "source": canonical_source,
                }
                if work_item_id not in work_item_ids:
                    return _result(
                        provider="ado",
                        complete=True,
                        eligible=False,
                        issue_ref=str(work_item_id),
                        item_id=work_item_id,
                        scope=scope,
                        reason="work item is not in the saved query",
                    )
                details = (
                    await self._ado._hydrate_work_items(
                        [work_item_id],
                        organization=normalized_organization,
                        project=project.project_id,
                    )
                )[0]
                state = self._ado_validate_project(details, work_item_id, project.name)
                terminal = state in _COMMON_ADO_TERMINAL_STATES
                has_active_pull_request = (
                    False
                    if terminal
                    else await self._ado_has_active_pull_request(
                        details,
                        work_item_id=work_item_id,
                        organization=normalized_organization,
                        default_project=project.project_id,
                    )
                )
                eligible = not terminal and not has_active_pull_request
                reason = (
                    "eligible"
                    if eligible
                    else "work item is in a common terminal state"
                    if terminal
                    else "work item has an active linked pull request"
                )
            else:
                raw = await self._az_runner(
                    [
                        "boards",
                        "work-item",
                        "show",
                        "--id",
                        str(work_item_id),
                        "--organization",
                        normalized_organization,
                        "--expand",
                        "all",
                        "-o",
                        "json",
                        "--only-show-errors",
                    ]
                )
                details = self._validate_exact_ado_item(
                    _json_payload(raw, "Azure DevOps"),
                    organization=normalized_organization,
                    work_item_id=work_item_id,
                )
                fields = details["fields"]
                state = str(fields["System.State"]).strip().casefold()
                team_project = str(fields.get("System.TeamProject") or repository_project).strip()
                has_active_pull_request = await self._ado_has_active_pull_request(
                    details,
                    work_item_id=work_item_id,
                    organization=normalized_organization,
                    default_project=team_project,
                )
                terminal = state in _COMMON_ADO_TERMINAL_STATES
                eligible = not terminal and not has_active_pull_request
                reason = (
                    "eligible"
                    if eligible
                    else "work item is in a common terminal state"
                    if terminal
                    else "work item has an active linked pull request"
                )
                scope = {
                    "mode": "exact-work-item",
                    "organization": normalized_organization,
                    "repo_path": repo_path,
                    "repository": f"{repository_project}/{repository_name}",
                }
            return _result(
                provider="ado",
                complete=True,
                eligible=eligible,
                issue_ref=str(work_item_id),
                item_id=work_item_id,
                scope=scope,
                reason=reason,
            )
        except (OSError, RuntimeError, TypeError, ValueError):
            return "Error: Azure DevOps provider read failed; no candidate returned"

    async def execute(self, **kwargs: Any) -> str:
        errors = self.validate(kwargs)
        if errors:
            return "Error: " + "; ".join(errors)
        action = str(kwargs["action"])
        provider = str(kwargs["provider"])
        requested_repo_path = str(kwargs["repo_path"]).strip()
        try:
            repo_path, origin = await self._repository_identity(requested_repo_path)
        except RuntimeError:
            return "Error: repository identity validation failed; no candidate returned"
        max_items = int(kwargs.get("max_items", _DEFAULT_MAX_ITEMS))
        if provider == "github" and action == "select":
            return await self._github_select(
                repo_path=repo_path,
                origin=origin,
                query_url=str(kwargs["query_url"]),
                max_items=max_items,
            )
        if provider == "github":
            return await self._github_revalidate(
                repo_path=repo_path,
                origin=origin,
                issue_ref=kwargs["issue_ref"],
            )
        organization = str(kwargs["organization"]).strip()
        if action == "select":
            return await self._ado_select(
                repo_path=repo_path,
                origin=origin,
                organization=organization,
                requested_project=str(kwargs["project"]).strip(),
                source=str(kwargs["source"]).strip(),
                max_items=max_items,
            )
        project_name = str(kwargs.get("project") or "").strip() or None
        source = str(kwargs.get("source") or "").strip() or None
        return await self._ado_revalidate(
            repo_path=repo_path,
            origin=origin,
            organization=organization,
            issue_ref=kwargs["issue_ref"],
            project_name=project_name,
            source=source,
            max_items=max_items,
        )
