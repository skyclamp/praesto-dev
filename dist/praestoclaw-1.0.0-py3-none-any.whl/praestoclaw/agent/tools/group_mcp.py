"""Model-facing lifecycle tool for group-owned remote MCP servers."""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.group_mcp import GroupMCPService
from praestoclaw.security.praesto_tag_exp import praesto_tag_exp_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupMCPTool(Tool):
    def __init__(self, service: GroupMCPService) -> None:
        self._service = service

    @property
    def name(self) -> str:
        return "mcp"

    @property
    def description(self) -> str:
        return "Manage HTTP or stdio MCP servers owned by this group: list, get, add, remove, login, or logout."

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(tier="core", timeout=360)

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "get", "add", "remove", "login", "logout"],
                },
                "name": {"type": "string"},
                "url": {
                    "type": "string",
                    "description": "Remote HTTP(S) MCP endpoint; required by add.",
                },
                "command": {
                    "type": "string",
                    "description": "stdio executable; use instead of url.",
                },
                "args": {"type": "array", "items": {"type": "string"}},
                "env": {"type": "object", "additionalProperties": {"type": "string"}},
                "headers": {"type": "object", "additionalProperties": {"type": "string"}},
                "client_id": {"type": "string"},
                "scopes": {"type": "array", "items": {"type": "string"}},
                "callback_port": {"type": "integer", "minimum": 0, "maximum": 65535},
                "auth_server_url": {"type": "string"},
            },
            "required": ["action"],
        }

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(
            0 if args.get("action") in {"list", "get"} else 3, "Group-local MCP lifecycle"
        )

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata")
        if not isinstance(metadata, dict) or not praesto_tag_exp_is_active(metadata):
            return "Error: mcp is available only in a shared group session."
        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "Error: current group chat id is missing."
        action = str(kwargs.get("action") or "")
        name = str(kwargs.get("name") or "").strip()
        try:
            if action == "list":
                return self._service.list(cid)
            if action == "get":
                return self._service.get(cid, name)
            if action == "add":
                actor = str(metadata.get("sender_oid") or metadata.get("sender_id") or "")
                result = await self._service.add(
                    chat_id=cid,
                    name=name,
                    url=kwargs.get("url"),
                    command=kwargs.get("command"),
                    args=kwargs.get("args"),
                    env=kwargs.get("env"),
                    headers=kwargs.get("headers"),
                    actor=actor,
                    client_id=kwargs.get("client_id"),
                    scopes=kwargs.get("scopes"),
                    callback_port=kwargs.get("callback_port"),
                    auth_server_url=kwargs.get("auth_server_url"),
                )
                self._refresh_turn_tools(metadata, cid)
                return result
            if action == "remove":
                result = await self._service.remove(cid, name)
                self._refresh_turn_tools(metadata, cid)
                return result
            if action == "login":
                result = await self._service.login(cid, name, kwargs.get("scopes"))
                self._refresh_turn_tools(metadata, cid)
                return result
            if action == "logout":
                result = await self._service.logout(cid, name)
                self._refresh_turn_tools(metadata, cid)
                return result
        except (ValueError, OSError) as exc:
            return f"Error: {exc}"
        return "Error: unknown action."

    def _refresh_turn_tools(self, metadata: dict[str, Any], cid: str) -> None:
        metadata["group_mcp_tool_names"] = self._service.tool_names(cid)
