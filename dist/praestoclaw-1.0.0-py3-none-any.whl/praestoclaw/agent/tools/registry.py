"""
Tool registry — central registry for tool discovery and execution.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool
from praestoclaw.bus.events import EventType, StreamingChunk
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.security.audit import AuditLogger
from praestoclaw.security.leak import redact_credentials

_ERROR_HINT = "\n\n[Analyze the error above and try a different approach.]"

PROTECTED_TOOLS = frozenset(
    {
        "ado_query_active_prs",  # fixed read-only ADO query/active-PR boundary
        "feedback_submit",  # fixed repo/label boundary for public feedback issues
        "fix_bug_selector",  # fixed deterministic fix-bug admission boundary
        "societas_pr_submit",  # fixed O365 Core/Societas draft-PR boundary
        "video_evidence",  # runtime-owned local temporal evidence ledger
        "tools",  # meta-tool: controls tool discovery/activation
        "spawn",  # creates sub-agents with scoped permissions
        "cron",  # schedules future agent/tool execution
        "notify",  # sends messages to user channels
        "group_notify",  # sends native mentions to the current Teams conversation
        "config_praestoclaw",  # modifies runtime configuration
        "skill",  # group-scoped skill lifecycle control plane
        "mcp",  # group-scoped MCP lifecycle control plane
    }
)


class ToolRegistry:
    """Central tool registry with execution tracking and audit logging.

    Supports progressive loading: core-tier tools are always in the function
    calling schema; standard-tier tools must be activated via ``tools``
    before they appear in schemas.
    """

    def __init__(self, audit: AuditLogger | None = None) -> None:
        self._tools: dict[str, Tool] = {}
        self._audit = audit or AuditLogger()
        self._active: set[str] = set()  # names of tools in the function calling schema
        self._disabled: set[str] = set()  # explicitly disabled — won't auto-activate
        self._mcp_manager: Any = None  # set via set_mcp_manager()
        self._standard_summary_cache: str | None = None  # cached for prompt stability
        self._output_config: Any = None  # ToolOutputConfig, set via set_output_config()

    @property
    def output_config(self) -> Any:
        """Global tool output truncation config."""
        if self._output_config is not None:
            return self._output_config
        from praestoclaw.config.schema import ToolOutputConfig

        return ToolOutputConfig()

    def set_output_config(self, config: Any) -> None:
        """Set the global tool output truncation config."""
        self._output_config = config

    def register(self, tool: Tool) -> None:
        if tool.name in PROTECTED_TOOLS and tool.name in self._tools:
            raise ValueError(f"Cannot override protected built-in tool '{tool.name}'")
        self._tools[tool.name] = tool
        # Core-tier auto-activates; standard and MCP start inactive
        if tool.metadata.tier == "core":
            self._active.add(tool.name)
        # Invalidate cached summary when a non-MCP standard tool is added
        if tool.metadata.tier == "standard" and tool.metadata.category != "mcp":
            self._standard_summary_cache = None
        logger.debug(f"Tool registered: {tool.name} (tier={tool.metadata.tier})")

    def unregister(self, name: str) -> None:
        self._tools.pop(name, None)

    def unregister_prefix(self, prefix: str) -> list[str]:
        """Remove all tools whose names start with *prefix*. Returns removed names."""
        to_remove = [name for name in self._tools if name.startswith(prefix)]
        for name in to_remove:
            del self._tools[name]
            self._active.discard(name)
            self._disabled.discard(name)
        if to_remove:
            logger.debug(f"Unregistered {len(to_remove)} tools with prefix '{prefix}'")
        return to_remove

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    _TIER_ORDER = {"core": 0, "standard": 1, "hidden": 2}
    _CATEGORY_ORDER = {"builtin": 0, "custom": 1, "mcp": 2}

    def list_tools(self) -> list[Tool]:
        """Return all registered tools in insertion order (no sorting).

        For sorted display output, use ``list_tools_sorted()`` instead.
        """
        return list(self._tools.values())

    def list_tools_sorted(self) -> list[Tool]:
        """Return all registered tools sorted for display.

        Sort order: tier (core → standard → hidden), then category
        (builtin → custom → mcp), then name (case-insensitive).
        Use this for user/LLM-facing output. For internal iteration prefer ``list_tools()``.
        """
        return sorted(
            self._tools.values(),
            key=lambda t: (
                self._TIER_ORDER.get(t.metadata.tier, 9),
                self._CATEGORY_ORDER.get(t.metadata.category, 8),
                t.name.casefold(),
            ),
        )

    def is_disabled(self, name: str) -> bool:
        """Whether *name* was explicitly turned off via :meth:`deactivate`.

        Exposed so the execution gate can fail closed: ``execute`` only skips
        auto-activation for a disabled tool, it still runs it.
        """
        return name in self._disabled

    def get_schemas(
        self,
        names: list[str] | None = None,
        *,
        exclude: list[str] | None = None,
        include_inactive: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Get OpenAI-format tool schemas for the tools visible this call.

        Progressive loading: core-tier and explicitly activated tools, plus any
        per-call exceptions named in *include_inactive*. Standard-tier tools must
        otherwise be activated via ``tools``.

        Args:
            names: Optional allowlist of tool names to include (after activation).
            exclude: Denylist — remove these tools from the result.
            include_inactive: Explicit per-call exceptions that may appear without
                mutating the registry's shared progressive-activation state. Use
                this for a one-turn exception; ``activate()`` would leak the tool
                into every later turn and into concurrent sessions. A tool that
                was explicitly turned off is NEVER re-exposed this way —
                ``deactivate()`` is a deliberate decision and outranks a caller's
                exception.
        """
        exception = {n for n in (include_inactive or []) if n not in self._disabled}
        visible = self._active | exception
        tools: list[Tool] = [t for t in self._tools.values() if t.name in visible]
        if names:
            name_set = set(names)
            tools = [t for t in tools if t.name in name_set]
        if exclude:
            exclude_set = set(exclude)
            tools = [t for t in tools if t.name not in exclude_set]
        return [t.to_openai_schema() for t in tools]

    # ── Progressive loading ────────────────────────────────────────────────

    def activate(self, name: str) -> bool:
        """Activate a tool so it appears in the function calling schema.

        Clears disabled state if set. Returns True if newly activated.
        """
        if name in self._active:
            return False
        if name not in self._tools:
            return False
        self._active.add(name)
        self._disabled.discard(name)
        logger.debug(f"Tool activated: {name}")
        return True

    def deactivate(self, name: str) -> bool:
        """Deactivate a standard-tier tool (core tools cannot be deactivated).

        Adds to _disabled set so auto-activate on execute won't re-enable it.
        Returns True if deactivated, False if core or unknown.
        """
        tool = self._tools.get(name)
        if not tool or tool.metadata.tier == "core":
            return False
        self._active.discard(name)
        self._disabled.add(name)
        logger.debug(f"Tool deactivated: {name}")
        return True

    def get_active_tools(self) -> list[Tool]:
        """Return tools currently in the function calling schema."""
        return [t for t in self._tools.values() if t.name in self._active]

    def get_inactive_tools(self) -> list[Tool]:
        """Return tools available but not yet activated (excludes hidden tier)."""
        return [
            t
            for t in self._tools.values()
            if t.name not in self._active and t.metadata.tier != "hidden"
        ]

    def set_mcp_manager(self, mcp_manager: Any | None) -> None:
        """Store MCP manager reference for ``is_available()`` checks."""
        self._mcp_manager = mcp_manager

    def is_available(self, name: str) -> bool:
        """Return True if a tool or MCP server with *name* is available.

        For MCP server names (``MCP_<server>``): checks via MCPManager whether
        the server is configured and enabled — does NOT require the server to
        be connected or its tools to be registered. This makes the check stable
        at startup (config-based, no runtime state dependency).
        """
        if name in self._tools:
            return True
        # MCP server check via manager: "MCP_teams" → server "teams" configured + enabled
        if name.startswith("MCP_") and self._mcp_manager is not None:
            server_name = name[len("MCP_") :]
            servers = self._mcp_manager.list_servers()
            return any(s.name == server_name and s.enabled for s in servers)
        return False

    def get_standard_tools_summary(self) -> str:
        """Summary of standard-tier non-MCP tools for system prompt.

        Lists ALL standard tools except MCP (regardless of activation state).
        Includes builtin and custom categories. Stable across enable/disable
        operations during a conversation, which preserves the LLM prompt cache.
        May change if new standard tools are registered after startup.
        """
        if self._standard_summary_cache is not None:
            return self._standard_summary_cache
        # Exclude MCP tools (own section in _list_all)
        standard = [
            t
            for t in self.list_tools_sorted()
            if t.metadata.tier == "standard" and t.metadata.category != "mcp"
        ]
        if not standard:
            self._standard_summary_cache = ""
            return ""
        lines = ["## Additional Tools\n\nUse `tools(name='<name>')` to enable if needed:\n"]
        for t in standard:
            first_line = t.description.split("\n")[0]
            brief = first_line.split(". ")[0].rstrip(".")
            lines.append(f"- {t.name}: {brief}")
        self._standard_summary_cache = "\n".join(lines)
        return self._standard_summary_cache

    def scoped_copy(
        self, tool_names: list[str], *, audit: AuditLogger | None = None
    ) -> ToolRegistry:
        """Create a new registry containing only the named tools.

        Used for sub-agent spawning — the child gets a restricted toolset.
        """
        scoped = ToolRegistry(audit=audit or self._audit)
        scoped._output_config = self._output_config
        name_set = set(tool_names)
        for name, tool in self._tools.items():
            if name in name_set:
                if name == "tools":
                    from praestoclaw.agent.tools.tools import ToolsTool

                    if isinstance(tool, ToolsTool):
                        # Scoped agents may activate only tools already copied
                        # here; never mutate or connect through the parent registry.
                        tool = tool.clone_for_registry(scoped)
                scoped._tools[name] = tool
                if name in self._active:
                    scoped._active.add(name)
        return scoped

    async def execute(
        self,
        name: str,
        args: dict[str, Any],
        *,
        actor: str = "agent",
        session_id: str | None = None,
        bus: MessageBus | None = None,
        channel: ChannelType | None = None,
        channel_id: str | None = None,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        tool_call_id: str | None = None,
        plan_session_id: str | None = None,
        ephemeral: list[str] | None = None,
    ) -> str:
        """Execute a tool by name with audit logging and optional progress streaming.

        ``tool_call_id`` (optional) — the LLM-supplied id from the
        triggering ``tool_calls`` entry. Passed through to ``tool.progress``
        events so subscribers (ToolStatusCard) can correlate live
        progress text with the matching pre/post tool hook row instead
        of mutating a wrong sibling row when several tools run in the
        same turn.
        """
        tool = self._tools.get(name)
        if tool is None:
            return f"Error: unknown tool '{name}'{_ERROR_HINT}"

        # Auto-activate standard tools on first use (LLM may call tools it
        # discovered from the system prompt inactive summary without explicitly
        # enabling them via tools()).  Skip if explicitly disabled or hidden.
        # A tool exposed for one turn only (get_schemas(include_inactive=...))
        # must not join shared activation just because the model called it —
        # that would make the "per-turn" exception permanent from first use.
        if name not in self._active and name not in self._disabled:
            if tool.metadata.tier != "hidden" and name not in set(ephemeral or []):
                self._active.add(name)
                logger.debug(f"Tool auto-activated on first use: {name}")

        # Pass channel context as kwargs so tools can use it without mutable state.
        # (CopilotDelegateTool reads these for notification routing.)
        if channel and channel_id:
            args.setdefault("_channel", channel)
            args.setdefault("_channel_id", channel_id)
            if thread_id:
                args.setdefault("_thread_id", thread_id)
        # Overwrite (not setdefault) — the session id is runtime provenance
        # that several tools key access control off of (tasks owner, plan
        # locking, a2a/u2u sender). A model that could spoof it from its own
        # args could enumerate or disturb another conversation's state.
        args.pop("_session_id", None)
        if session_id:
            args["_session_id"] = session_id
        if name in {"plan", "workflow", "cron", "feedback_submit", "video_evidence"}:
            # ``_plan_session_id`` is a hidden runtime-only override. Strip
            # caller-supplied values first so model/scheduler args cannot
            # redirect conversation ownership; only this trusted registry
            # parameter may inject it for promoted workers.
            args.pop("_plan_session_id", None)
            # Plan cards and workflow lifecycle are conversation-owned, not
            # worker-owned. A promoted worker still runs with its own
            # ``_session_id`` for security provenance, but plan progress and
            # workflow status/resume and feedback diagnostics must target the
            # original main session.
            #
            # ``cron`` needs it for the same reason and with the same meaning:
            # a watcher job installed BY a workflow run records which
            # conversation owns the Plan it will later offer to resume. Its own
            # ``_session_id`` is the run's isolated session, which is gone by
            # the time the job fires.
            if plan_session_id:
                args["_plan_session_id"] = plan_session_id

        # Pass metadata so spawn can propagate cron/heartbeat source to child agents.
        # Always strip the caller value first: a turn without runtime metadata
        # must fail closed instead of trusting model-supplied provenance.
        args.pop("_metadata", None)
        if metadata is not None:
            args["_metadata"] = metadata

        # Wire progress callback for streaming-capable tools
        prev_callback = tool._progress
        if tool.metadata.streaming and bus and channel and channel_id:

            async def _progress(text: str) -> None:
                # Redact secrets before streaming to user
                sanitized = redact_credentials(text)
                await bus.dispatch_outbound(
                    StreamingChunk(
                        channel=channel,
                        channel_id=channel_id,
                        content=sanitized,
                        chunk_type="tool_progress",
                    )
                )
                # Fan out the same signal as a typed event so subscribers
                # (e.g. ToolStatusCard) can render live progress under the
                # running row of a Teams per-turn status card. The event
                # bus is fire-and-forget, so this never blocks the tool.
                bus.events.emit(
                    EventType.TOOL_PROGRESS,
                    {
                        "tool_call_id": tool_call_id or "",
                        "tool_name": name,
                        "text": sanitized,
                        "session_id": session_id or "",
                        "channel": channel,
                        "channel_id": channel_id,
                        "metadata": metadata or {},
                    },
                )

            tool.set_progress_callback(_progress)

        start = time.monotonic()
        # Per-call timeout: a tool may need a longer ceiling for one specific
        # action (e.g. plan checkpoint(ask_user=true) blocking on the user)
        # without inflating the timeout of its other, fast actions. Tools that
        # expose ``resolve_call_timeout(args)`` decide per-call; the rest use
        # the static metadata timeout.
        if hasattr(tool, "resolve_call_timeout"):
            try:
                tool_timeout = tool.resolve_call_timeout(args)
            except Exception:  # noqa: BLE001
                tool_timeout = getattr(tool.metadata, "timeout", 600)
        else:
            tool_timeout = getattr(tool.metadata, "timeout", 600)
        try:
            result = await asyncio.wait_for(tool.execute(**args), timeout=tool_timeout) or ""
            if name in {"kb_inspect", "kb_scope"}:
                from praestoclaw.security.kb_curation import record_scheduled_kb_read

                record_scheduled_kb_read(
                    metadata,
                    session_id=session_id or "",
                    tool=name,
                    action=str(args.get("action") or ""),
                    result=result,
                )
            elapsed = (time.monotonic() - start) * 1000
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=tool.audit_args(args),
                result=result,
                session_id=session_id,
                conversation_session_id=plan_session_id or session_id,
                duration_ms=elapsed,
            )
            return result
        except Exception as exc:
            elapsed = (time.monotonic() - start) * 1000
            # `TimeoutError` from `asyncio.wait_for` has an empty `str()`,
            # which produces "Error executing X: " in audit logs and the
            # LLM-visible error string. Fall back to the type name so
            # callers always get an actionable message. (`CancelledError`
            # derives from `BaseException` on 3.11+ and bypasses this
            # `except Exception` block, so it doesn't apply here.)
            exc_text = str(exc)
            if not exc_text:
                exc_text = type(exc).__name__
                # Only fabricate the registry-timeout context when the
                # original TimeoutError carried no message of its own;
                # tools that raise TimeoutError with their own details
                # (e.g. MCPClient encodes method/id/timeout) keep them.
                if isinstance(exc, TimeoutError):
                    exc_text = f"TimeoutError: tool exceeded {tool_timeout}s"
            error_msg = f"Error executing {name}: {exc_text}{_ERROR_HINT}"
            if name in {"kb_inspect", "kb_scope"}:
                from praestoclaw.security.kb_curation import record_scheduled_kb_read

                record_scheduled_kb_read(
                    metadata,
                    session_id=session_id or "",
                    tool=name,
                    action=str(args.get("action") or ""),
                    result=error_msg,
                )
            logger.error(f"Error executing {name}: {exc_text}")
            self._audit.log_tool(
                tool=name,
                actor=actor,
                args=tool.audit_args(args),
                result=exc_text,
                is_error=True,
                session_id=session_id,
                conversation_session_id=plan_session_id or session_id,
                duration_ms=elapsed,
            )
            return error_msg
        finally:
            # Restore previous callback (avoid clearing another in-flight callback)
            tool.set_progress_callback(prev_callback)
