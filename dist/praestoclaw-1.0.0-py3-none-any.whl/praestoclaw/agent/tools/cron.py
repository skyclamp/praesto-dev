"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, disable, run, and inspect jobs.
Dynamic jobs persist to ~/.praestoclaw/cron/jobs.json.

Three execution modes (mutually exclusive):
- message: static text delivered as-is (zero execution cost)
- prompt:  intent for LLM agent (agent selects tools via skills)
- tool:    direct tool call (no LLM)

Delivery is handled by ``notify_channels`` — the executing agent never
needs to know about delivery channels or mechanisms.
"""

from __future__ import annotations

import json
import re
from dataclasses import replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.config.schema import ChannelType
from praestoclaw.cron.job import (
    ScheduledKbCapability,
    normalize_channel_list,
    prompt_requires_current_kb_scope,
)
from praestoclaw.kb.scope import RepoAmbiguousError, RepoNotAllowedError, resolve_allowed_repo
from praestoclaw.security.risk import RiskAssessment, RiskPrompt, RiskScore

if TYPE_CHECKING:
    from praestoclaw.agent.tools.registry import ToolRegistry
    from praestoclaw.cron.service import SchedulerService


_SOCIETAS_SCANNER_JOB_ID = "societas-bug-watcher"
_SOCIETAS_SCANNER_TOOL = "societas_scanner_v4"

# Reserved watcher job ids → the one tool-mode tool each may run. Prompt/message
# mode is refused for these ids: a watcher that runs an LLM prompt improvises its
# queries, can trigger an approval nobody is there to answer, and silently reports
# nothing when the query fails.
_WATCHER_JOB_TOOLS: dict[str, str] = {
    _SOCIETAS_SCANNER_JOB_ID: _SOCIETAS_SCANNER_TOOL,
}

# Version-agnostic prefixes for the owner overwrite below. Matched on the prefix
# rather than the exact tool name so a schema bump (``…_v4`` → ``…_v5``) does not
# silently drop the resume capability: the job would still be created, still run,
# and still be unable to resume the Plan it exists to serve.
_WATCHER_TOOL_PREFIXES = ("societas_scanner_v",)


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs."""

    risk_range = (0, 9)

    def __init__(self, scheduler: SchedulerService, registry: ToolRegistry | None = None) -> None:
        self._scheduler = scheduler
        self._registry = registry

    def _capture_kb_capability(
        self, job_id: str, kwargs: dict[str, Any]
    ) -> ScheduledKbCapability | None:
        """Snapshot a KB binding only from locally verified personal Teams provenance."""
        prompt = str(kwargs.get("prompt") or "")
        requires_scope = kwargs.get("use_current_kb_scope") is True or (
            prompt_requires_current_kb_scope(prompt)
        )
        if not requires_scope or not prompt:
            return None
        metadata = kwargs.get("_metadata")
        if not isinstance(metadata, dict):
            return None
        trusted_personal = metadata.get("_trusted_teams_personal")
        if not isinstance(trusted_personal, dict):
            return None
        channel = str(getattr(kwargs.get("_channel"), "value", kwargs.get("_channel") or ""))
        ctype = (
            str(metadata.get("ctype") or metadata.get("teams_conversation_type") or "")
            .strip()
            .casefold()
        )
        cid = str(metadata.get("cid") or "").strip()
        subject_id = str(trusted_personal.get("subject_id") or "").strip()
        tenant_id = str(trusted_personal.get("tenant_id") or "").strip()
        if channel.casefold() != ChannelType.CLOUD.value or ctype != "personal":
            return None
        if not all((cid, subject_id, tenant_id, self._registry)):
            return None

        scope_tool = self._registry.get("kb_scope") if self._registry else None
        scopes = getattr(scope_tool, "_scopes", None)
        scope = scopes.read(cid) if scopes is not None else None
        if scope is None or not scope.set_at:
            return None
        if (scope.subject_id and scope.subject_id != subject_id) or (
            scope.tenant_id and scope.tenant_id != tenant_id
        ):
            return None
        if not scope.subject_id or not scope.tenant_id:
            write = getattr(scopes, "write", None)
            if not callable(write):
                return None
            scope = write(
                cid,
                replace(scope, subject_id=subject_id, tenant_id=tenant_id),
            )
        allowed = getattr(scope_tool, "_allowed", None)
        if not callable(allowed):
            return None
        try:
            repo = resolve_allowed_repo(allowed(), scope.repo)
        except (RepoNotAllowedError, RepoAmbiguousError, AttributeError):
            return None
        return ScheduledKbCapability(
            version=1,
            job_id=job_id,
            conversation_id=cid,
            subject_id=subject_id,
            tenant_id=tenant_id,
            repo=repo,
            subfolder=scope.subfolder,
            scope_set_at=scope.set_at,
            granted_at=datetime.now(UTC).isoformat(),
            origin_session_id=str(
                kwargs.get("_plan_session_id") or kwargs.get("_session_id") or ""
            ).strip(),
        )

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled jobs. "
            "Job output is automatically delivered to the current user via notify_channels."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["add", "list", "remove", "enable", "disable", "run", "info"],
                    "description": (
                        "add = create or replace job; list = show all; "
                        "remove = delete; enable/disable = toggle; "
                        "run = trigger once now; info = show details."
                    ),
                },
                "job_id": {
                    "type": "string",
                    "description": (
                        "Short descriptive name, e.g. 'drink-water'. "
                        "Required for remove/enable/disable/run/info."
                    ),
                },
                "schedule": {
                    "anyOf": [{"type": "string"}, {"type": "integer"}],
                    "description": (
                        "'at:+300' = 5 min from now (seconds); "
                        "'at:2026-03-24T22:10:00' = absolute; "
                        "'3600' = every hour (interval in seconds); "
                        "'0 9 * * *' = cron. Required for add."
                    ),
                },
                # ── Content: three modes, mutually exclusive ──
                "message": {
                    "type": "string",
                    "description": (
                        "Static text delivered as-is (zero cost). "
                        "Default choice for reminders, alerts, greetings, and any fixed text. "
                        "e.g. 'remind me to drink water' → message='Drink water'."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Intent for LLM agent at trigger time — "
                        "only when the content requires real-time reasoning (summaries, lookups). "
                        "Write as the current user and do not repeat the USER.md. "
                        "Describe what to produce with a brief high-level plan in user's language. "
                    ),
                },
                "tool": {
                    "type": "string",
                    "description": "Tool name to execute directly. No LLM. Requires tool_args.",
                },
                "tool_args": {
                    "type": "object",
                    "description": "Arguments for tool (required when tool is set).",
                },
                # ── Delivery ──
                "notify_channels": {
                    "type": "array",
                    "items": {
                        "type": "string",
                        "enum": ["cloud", "web", "*"],
                    },
                    "description": (
                        "WHERE to route results. "
                        "User mentions Teams → ['cloud'] (NOT 'web'). "
                        "Browser → ['web']. * = all active. "
                        "Omit (defaults to all active) only if user states no channel preference."
                    ),
                },
                "timezone": {
                    "type": "string",
                    "description": (
                        "IANA timezone name for the schedule (e.g. 'Asia/Shanghai', "
                        "'America/Los_Angeles', 'UTC'). Only set when the user explicitly "
                        "states a timezone (e.g. '北京时间', 'Tokyo time', 'in PST'). "
                        "If omitted, the server's local timezone is used automatically."
                    ),
                },
                "use_current_kb_scope": {
                    "type": "boolean",
                    "description": (
                        "Set true only when this prompt-mode job explicitly depends on the "
                        "knowledge-base scope already bound in the current personal Teams chat. "
                        "Explicit pmo-grill prompts imply true automatically, so never set false "
                        "to bypass their required KB capability. "
                        "The scheduler captures a read-only scope snapshot; other chat types "
                        "cannot grant it."
                    ),
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=45, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        action = (args.get("action", "") or "").strip()
        if action in ("list", "info"):
            return RiskScore(0, reason=f"Read-only cron operation ({action})")
        if action == "run":
            return RiskScore(4, reason="Trigger immediate job execution")
        if action == "enable":
            return RiskScore(3, reason="Re-enable a scheduled job")
        if action == "disable":
            return RiskScore(4, reason="Pause a scheduled job")
        if action == "remove":
            job_id = (args.get("job_id", "") or "").strip()
            job = self._scheduler._jobs.get(job_id) if job_id else None
            if job and (job.message or str(job.schedule).startswith("at")):
                return RiskScore(4, reason="Delete a one-shot or message job")
            # Score 6: deleting a recurring scheduled job silently kills user
            # automation and the underlying job content can't be reconstructed.
            # Timeout-auto in standard gives the user a chance to intervene.
            return RiskScore(6, reason="Delete a scheduled job")
        # add action
        if args.get("message"):
            return RiskScore(1, reason="Schedule static message delivery")
        tool_name = args.get("tool")
        prompt = args.get("prompt")
        if tool_name and self._registry:
            target = self._registry.get(tool_name)
            if target:
                tool_args = args.get("tool_args") or {}
                tool_risk = target.assess_risk(tool_args)
                if isinstance(tool_risk, RiskScore):
                    return RiskScore(
                        tool_risk.score,
                        reason=f"Schedule {tool_name}: {tool_risk.reason}",
                    )
                # Shift range +1 (capped at 10) for unattended scheduling risk.
                sched_lo = min(tool_risk.range[0] + 1, 10)
                sched_hi = min(tool_risk.range[1] + 1, 10)
                return RiskPrompt(
                    context=(
                        f"Schedule recurring {tool_name} execution.\n"
                        f"Underlying tool: {tool_risk.context}\n"
                        f"Scheduling adds risk — recurring unattended execution."
                    ),
                    range=(sched_lo, sched_hi),
                    signals=tool_risk.signals + ("scheduled",),
                )
        if tool_name:
            return RiskScore(5, reason=f"Schedule tool '{tool_name}' (no registry to evaluate)")
        if prompt:
            preview = prompt[:100] + ("..." if len(prompt) > 100 else "")
            return RiskPrompt(
                context=(
                    f"Agent prompt execution.\n"
                    f"Prompt: {preview}\n"
                    f"Schedule: {args.get('schedule', '?')}"
                ),
                range=(2, 8),
                factors=(
                    "2: Local file reads only",
                    "3: Read external APIs",
                    "4: File modifications",
                    "5: Side effects (notifying current user is automatic, not counted)",
                    "6: External sends to OTHER recipients",
                    "7: Broad scope across multiple systems",
                    "8: Destructive or irreversible operations",
                ),
                exclude_args=frozenset({"notify_channels", "job_id"}),
            )
        return RiskScore(2, reason="Cron management")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            return self._handle_list()
        elif action == "add":
            return self._handle_add(kwargs)
        elif action == "remove":
            return self._handle_job_action(kwargs, "remove")
        elif action == "enable":
            return self._handle_job_action(kwargs, "enable")
        elif action == "disable":
            return self._handle_job_action(kwargs, "disable")
        elif action == "run":
            return await self._handle_run(kwargs)
        elif action == "info":
            return self._handle_info(kwargs)

        return f"Unknown action: {action}"

    # ── Action handlers ───────────────────────────────────────────────

    def _handle_list(self) -> str:
        jobs = self._scheduler.list_jobs()
        if not jobs:
            return "No scheduled jobs."
        lines = ["Scheduled jobs:"]
        for j in jobs:
            status = "enabled" if j["enabled"] else "DISABLED"
            next_run = j.get("next_run") or "N/A"
            mode = j.get("mode", "prompt")
            lines.append(
                f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                f"mode={mode} [{status}] next={next_run}"
            )
        return "\n".join(lines)

    def _handle_add(self, kwargs: dict[str, Any]) -> str:
        schedule = kwargs.get("schedule")
        tool_name = kwargs.get("tool")
        arguments = kwargs.get("tool_args")
        prompt = kwargs.get("prompt")
        message = kwargs.get("message")

        if not schedule:
            return "Error: 'schedule' is required for add."

        # Mutual exclusivity (three-way)
        modes_set = sum(1 for x in (message, prompt, tool_name) if x)
        if modes_set > 1:
            return "Error: 'message', 'prompt', and 'tool' are mutually exclusive."
        if modes_set == 0:
            return "Error: one of 'message', 'prompt', or 'tool' is required for add."
        if tool_name and arguments is None:
            return "Error: 'tool_args' is required when 'tool' is set."

        scanner_owner = ""
        is_scanner = bool(tool_name and str(tool_name).startswith(_WATCHER_TOOL_PREFIXES))
        if is_scanner:
            # A resume capability is valid only in the exact conversation that
            # owns the Plan, so record that conversation here and overwrite any
            # model-supplied value. Without it the scanner can only ever offer a
            # fresh run, which restarts a 6/7-complete workflow at step 1.
            #
            # Two things this gets from ``_plan_session_id`` rather than
            # ``_session_id``:
            #
            # * It is the SAME identity ``Plan.owner`` records, so the scanner's
            #   equality check can actually match. ``_session_id`` is a different
            #   string on every surface and would never compare equal.
            # * This job is normally installed BY a workflow run, whose
            #   ``_session_id`` is its own isolated session — transient, and gone
            #   by the time the job fires. ``_plan_session_id`` is the originating
            #   conversation, which is what outlives it.
            #
            # Any surface may claim ownership EXCEPT a shared one: in a group,
            # channel or meeting conversation everyone present would inherit a
            # resume capability over a Plan they do not own.
            #
            # Decided fail-CLOSED on the cloud channel: only ``personal`` opts
            # in, so a Teams conversation type we have never seen (and a cloud
            # turn arriving with no ctype at all, which renders as a group chat
            # elsewhere) gets run-only cards. Local surfaces — web, local
            # webchat, CLI — carry no ctype and are single-user by construction,
            # so they qualify without one.
            arguments = dict(arguments or {})
            metadata = kwargs.get("_metadata")
            conversation_type = (
                str(metadata.get("ctype") or "").strip().casefold()
                if isinstance(metadata, dict)
                else ""
            )
            channel = kwargs.get("_channel")
            channel_name = str(getattr(channel, "value", channel or "")).strip().casefold()
            private_surface = (
                conversation_type == "personal" if channel_name == ChannelType.CLOUD.value else True
            )
            owner = ""
            if private_surface:
                owner = str(
                    kwargs.get("_plan_session_id") or kwargs.get("_session_id") or ""
                ).strip()[:200]
            arguments.pop("plan_owner", None)
            scanner_owner = owner

        # Block config_praestoclaw — not permitted in cron jobs
        if tool_name == "config_praestoclaw":
            return "Error: config_praestoclaw cannot be scheduled as a cron job."

        # Tool existence check
        if tool_name and self._registry:
            target = self._registry.get(tool_name)
            if not target:
                return f"Error: unknown tool '{tool_name}'."

        # Job ID derivation (no auto-suffix — replace semantics)
        job_id = str(kwargs.get("job_id") or "").strip()
        if not job_id:
            source = message or prompt or tool_name or "job"
            # \w matches Unicode letters (Chinese, etc.) + digits + underscore
            slug = re.sub(r"[^\w]+", "-", source[:40], flags=re.UNICODE).strip("-")
            job_id = slug or "job"
        reserved_tool = _WATCHER_JOB_TOOLS.get(job_id)
        if reserved_tool and tool_name != reserved_tool:
            return (
                f"Error: '{job_id}' is reserved for deterministic "
                f"tool-mode '{reserved_tool}'; prompt/message mode is not allowed."
            )

        requires_kb_scope = kwargs.get("use_current_kb_scope") is True or (
            prompt_requires_current_kb_scope(str(prompt or ""))
        )
        kb_capability = self._capture_kb_capability(job_id, kwargs)
        if requires_kb_scope and kb_capability is None:
            return (
                "Error: this KB-backed scheduled prompt requires a trusted personal Teams "
                "chat with an existing timestamped KB binding. Rebind the KB scope if "
                "necessary, then create the scheduled job again."
            )

        notify_channels = normalize_channel_list(kwargs.get("notify_channels"))
        if notify_channels is None:
            notify_channels = ["*"]
        # For message-mode jobs, an empty list will fall back to the origin
        # channel in add_job. Reflect that in the confirmation summary so the
        # user sees the real delivery target, not an empty string.
        origin_channel = kwargs.get("_channel")
        display_channels = notify_channels
        if message and not notify_channels:
            if origin_channel:
                ch_value = (
                    origin_channel.value
                    if hasattr(origin_channel, "value")
                    else str(origin_channel)
                )
                display_channels = [ch_value]
            else:
                display_channels = ["*"]

        try:
            self._scheduler.add_job(
                name=job_id,
                schedule=schedule,
                prompt=prompt or "",
                message=message,
                tool=tool_name,
                arguments=arguments,
                session_mode="persistent" if kb_capability is not None else "isolated",
                notify_channels=notify_channels,
                timezone=kwargs.get("timezone") or None,
                dynamic=True,
                channel=kwargs.get("_channel"),
                channel_id=(scanner_owner or None) if is_scanner else kwargs.get("_channel_id"),
                kb_capability=kb_capability,
            )
        except ValueError as exc:
            return f"Error: {exc}"

        # Rich return value with summary
        from praestoclaw.cron import detect_trigger_type

        trigger_type = detect_trigger_type(schedule)
        if message:
            mode_line = "Mode: message"
            content_line = f"Content: {message[:100]}"
        elif prompt:
            mode_line = "Mode: prompt"
            content_line = f"Prompt: {prompt[:100]}"
        else:
            mode_line = f"Mode: tool ({tool_name})"
            content_line = f"Arguments: {json.dumps(arguments, ensure_ascii=False)}"

        deliver_str = ", ".join(display_channels)
        return (
            f"Job '{job_id}' added.\n"
            f"  Schedule: {schedule} ({trigger_type})\n"
            f"  {mode_line}\n"
            f"  Deliver to: {deliver_str}\n"
            f"  {content_line}\n"
            f"Use cron(action='run', job_id='{job_id}') to test now."
        )

    def _handle_job_action(self, kwargs: dict[str, Any], action: str) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return f"Error: 'job_id' is required for {action}."
        try:
            getattr(self._scheduler, f"{action}_job" if action == "remove" else action)(job_id)
        except ValueError as exc:
            return f"Error: {exc}"
        return f"Job '{job_id}' {action}d."

    async def _handle_run(self, kwargs: dict[str, Any]) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return "Error: 'job_id' is required for run."

        # prompt/tool mode → background (avoids timeout); message mode → sync
        job_obj = self._scheduler._jobs.get(job_id)
        run_in_background = bool(job_obj and not job_obj.message)

        try:
            if run_in_background:
                await self._scheduler.run_job(job_id, background=True)
                jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
                job = jobs_by_name.get(job_id, {})
                deliver_str = ", ".join(job.get("notify_channels", ["*"]))
                return (
                    f"Job '{job_id}' triggered in background.\n"
                    f"Result will be delivered to: {deliver_str}"
                )
            else:
                result = await self._scheduler.run_job(job_id)
                if result is None:
                    return f"Job '{job_id}' execution failed. Check logs."
                return f"Job '{job_id}' triggered.\n---\n{result}"
        except ValueError as exc:
            return f"Error: {exc}"

    def _handle_info(self, kwargs: dict[str, Any]) -> str:
        job_id = kwargs.get("job_id")
        if not job_id:
            return "Error: 'job_id' is required for info."
        jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
        job = jobs_by_name.get(job_id)
        if not job:
            return f"Error: job '{job_id}' not found."  # info is read-only, no service call needed
        mode = job.get("mode", "prompt")
        deliver_str = ", ".join(job.get("notify_channels", ["*"]))

        # Content line based on mode
        if mode == "message":
            content_line = f"Content: {job.get('message', '')}"
        elif mode == "tool":
            content_line = f"Tool: {job.get('tool', '')}"
            arguments = job.get("arguments")
            if isinstance(arguments, dict) and arguments:
                content_line += f"\nArguments: {json.dumps(arguments, ensure_ascii=False)}"
        else:
            # Prompt mode
            prompt = job.get("prompt", "")
            content_line = f"Prompt: {prompt[:1024]}" if prompt else ""

        lines = [
            f"Job: {job['name']}",
            f"Schedule: {job['trigger_type']} ({job['schedule']})",
            f"Mode: {mode}",
            f"Deliver to: {deliver_str}",
            f"Status: {'enabled' if job['enabled'] else 'DISABLED'}",
            f"Next run: {job.get('next_run') or 'N/A'}",
            f"Failures: {job['failure_count']}",
        ]
        if job.get("created_at"):
            lines.append(f"Created: {job['created_at'][:19]}")
        if job.get("updated_at"):
            lines.append(f"Updated: {job['updated_at'][:19]}")
        if content_line:
            lines.append(content_line)
        return "\n".join(lines)
