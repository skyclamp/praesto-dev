"""Durable admission state for recurring generic fix-bug runs."""

from __future__ import annotations

import json
import math
import os
import re
import secrets
import tempfile
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime
from hashlib import sha256
from pathlib import Path
from typing import Any, TypeVar
from urllib.parse import urlsplit

from filelock import FileLock

_SCHEMA_VERSION = 1
_CLAIMED = "claimed"
_ADMITTED = "admitted"
_PROVIDER_PENDING = "provider_pending"
_CALLOUT_SUPPRESSED = "callout_suppressed"
_PROVIDER_VISIBILITY_SECONDS = 900
DEFAULT_CLAIM_LEASE_SECONDS = 7_500
DEFAULT_ADMISSION_SECONDS = 600
_PLAN_PARAM_VALUE_LIMIT = 512
_CLAIM_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_ENTRY_STATES = frozenset({_CLAIMED, _ADMITTED, _PROVIDER_PENDING, _CALLOUT_SUPPRESSED})
_ADO_ORGANIZATION_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$")

T = TypeVar("T")


def _ado_organization_name(value: str) -> str:
    text = value.strip().casefold().rstrip("/")
    if _ADO_ORGANIZATION_RE.fullmatch(text):
        return text
    try:
        parsed = urlsplit(text)
    except ValueError as exc:
        raise ValueError("invalid Azure DevOps organization") from exc
    host = parsed.hostname or ""
    if (
        parsed.scheme != "https"
        or parsed.username is not None
        or parsed.password is not None
        or parsed.port is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("invalid Azure DevOps organization")
    if host == "dev.azure.com":
        organization = parsed.path.strip("/")
    elif host.endswith(".visualstudio.com") and not parsed.path.strip("/"):
        organization = host.removesuffix(".visualstudio.com")
    else:
        raise ValueError("invalid Azure DevOps organization")
    if _ADO_ORGANIZATION_RE.fullmatch(organization) is None:
        raise ValueError("invalid Azure DevOps organization")
    return organization


class SelectionStateError(RuntimeError):
    """The scheduled-selection ledger could not be read or updated safely."""


@dataclass(frozen=True, slots=True)
class FixBugIdentity:
    provider: str
    repository: str
    item_id: int
    organization: str = ""

    def __post_init__(self) -> None:
        provider = self.provider.strip().casefold()
        repository = self.repository.strip().casefold()
        organization = self.organization.strip().casefold()
        if provider not in {"github", "ado"}:
            raise ValueError("provider must be github or ado")
        if (
            not repository
            or isinstance(self.item_id, bool)
            or not isinstance(self.item_id, int)
            or self.item_id <= 0
        ):
            raise ValueError("repository and a positive item_id are required")
        if provider == "github" and organization:
            raise ValueError("GitHub identities do not carry an organization URL")
        if provider == "ado" and not organization:
            raise ValueError("Azure DevOps identities require an organization")
        if provider == "ado":
            organization = _ado_organization_name(organization)
        object.__setattr__(self, "provider", provider)
        object.__setattr__(self, "repository", repository)
        object.__setattr__(self, "organization", organization)

    @property
    def key(self) -> str:
        material = json.dumps(
            [self.provider, self.organization, self.repository, self.item_id],
            ensure_ascii=True,
            separators=(",", ":"),
        )
        return sha256(material.encode("ascii")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "organization": self.organization,
            "repository": self.repository,
            "item_id": self.item_id,
        }


class FixBugSelectionStore:
    """Atomic, restart-surviving claims and terminal Callout suppression."""

    def __init__(
        self,
        data_dir: Path,
        *,
        lock_timeout: float = 10.0,
        plans_fn: Callable[[], list[Any]] | None = None,
    ) -> None:
        self._path = data_dir / "workflows" / "fix-bug-selection" / "state.json"
        self._lock_path = self._path.with_suffix(".lock")
        self._lock_timeout = lock_timeout
        self._thread_lock = threading.RLock()
        self._plans_fn = plans_fn

    @staticmethod
    def _empty_state() -> dict[str, Any]:
        return {"version": _SCHEMA_VERSION, "next_generation": 1, "entries": {}}

    @staticmethod
    def _normalize_scope(
        raw: dict[str, Any] | None,
        *,
        value_limit: int | None = None,
    ) -> dict[str, str]:
        return {
            str(key): (
                str(value).strip()[:value_limit] if value_limit is not None else str(value).strip()
            )
            for key, value in (raw or {}).items()
        }

    def _read(self) -> dict[str, Any]:
        if not self._path.exists():
            return self._empty_state()
        try:
            state = json.loads(self._path.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError, UnicodeError) as exc:
            raise SelectionStateError("fix-bug selection state is unreadable") from exc
        if (
            not isinstance(state, dict)
            or state.get("version") != _SCHEMA_VERSION
            or isinstance(state.get("next_generation"), bool)
            or not isinstance(state.get("next_generation"), int)
            or not isinstance(state.get("entries"), dict)
        ):
            raise SelectionStateError("fix-bug selection state has an unsupported shape")
        max_generation = 0
        for key, entry in state["entries"].items():
            self._validate_entry(key, entry)
            max_generation = max(max_generation, entry["generation"])
        if state["next_generation"] <= max_generation:
            raise SelectionStateError("fix-bug selection generations are inconsistent")
        return state

    @staticmethod
    def _finite_number(value: Any) -> bool:
        return (
            isinstance(value, (int, float))
            and not isinstance(value, bool)
            and math.isfinite(float(value))
            and float(value) >= 0
        )

    @classmethod
    def _validate_entry(cls, key: Any, entry: Any) -> None:
        if not isinstance(key, str) or not isinstance(entry, dict):
            raise SelectionStateError("fix-bug selection entry is malformed")
        provider = entry.get("provider")
        organization = entry.get("organization")
        repository = entry.get("repository")
        item_id = entry.get("item_id")
        if (
            not isinstance(provider, str)
            or not isinstance(organization, str)
            or not isinstance(repository, str)
            or isinstance(item_id, bool)
            or not isinstance(item_id, int)
        ):
            raise SelectionStateError("fix-bug selection entry identity is invalid")
        try:
            identity = FixBugIdentity(
                provider=provider,
                organization=organization,
                repository=repository,
                item_id=item_id,
            )
        except (AttributeError, TypeError, ValueError) as exc:
            raise SelectionStateError("fix-bug selection entry identity is invalid") from exc
        if any(
            (
                entry.get("provider") != identity.provider,
                entry.get("organization") != identity.organization,
                entry.get("repository") != identity.repository,
                entry.get("item_id") != identity.item_id,
            )
        ):
            raise SelectionStateError("fix-bug selection entry identity is not canonical")
        if key != identity.key:
            raise SelectionStateError("fix-bug selection entry key is inconsistent")
        entry_state = entry.get("state")
        if entry_state not in _ENTRY_STATES:
            raise SelectionStateError("fix-bug selection entry state is invalid")
        if _CLAIM_ID_RE.fullmatch(str(entry.get("claim_id") or "")) is None:
            raise SelectionStateError("fix-bug selection claim id is invalid")
        generation = entry.get("generation")
        if isinstance(generation, bool) or not isinstance(generation, int) or generation <= 0:
            raise SelectionStateError("fix-bug selection generation is invalid")
        for field in ("created_at", "updated_at", "admission_deadline"):
            if not cls._finite_number(entry.get(field)):
                raise SelectionStateError(f"fix-bug selection {field} is invalid")
        deadline = entry.get("deadline")
        if entry_state == _CALLOUT_SUPPRESSED:
            if deadline is not None:
                raise SelectionStateError("suppressed fix-bug entry has a deadline")
        elif not cls._finite_number(deadline):
            raise SelectionStateError("fix-bug selection deadline is invalid")
        admitted_at = entry.get("admitted_at")
        if entry_state in {_ADMITTED, _PROVIDER_PENDING} and not cls._finite_number(admitted_at):
            raise SelectionStateError("fix-bug admission timestamp is invalid")
        plan_deadline = entry.get("plan_deadline")
        if entry_state in {_ADMITTED, _PROVIDER_PENDING} and not cls._finite_number(plan_deadline):
            raise SelectionStateError("fix-bug Plan receipt deadline is invalid")
        for field in ("admission_scope", "plan_scope"):
            scope = entry.get(field)
            if not isinstance(scope, dict) or any(
                not isinstance(scope_key, str) or not isinstance(scope_value, str)
                for scope_key, scope_value in scope.items()
            ):
                raise SelectionStateError(f"fix-bug selection {field} is invalid")
        if any(len(value) > _PLAN_PARAM_VALUE_LIMIT for value in entry["plan_scope"].values()):
            raise SelectionStateError("fix-bug plan scope exceeds its persistence bound")

    def _write(self, state: dict[str, Any]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temp_name = tempfile.mkstemp(
            prefix="state-",
            suffix=".tmp",
            dir=self._path.parent,
        )
        try:
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
                json.dump(state, stream, ensure_ascii=False, indent=2, sort_keys=True)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, self._path)
        except Exception:
            try:
                os.unlink(temp_name)
            except OSError:
                pass
            raise

    def _with_lock(self, operation: Callable[[], T]) -> T:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with (
                self._thread_lock,
                FileLock(
                    self._lock_path,
                    timeout=self._lock_timeout,
                ),
            ):
                return operation()
        except SelectionStateError:
            raise
        except Exception as exc:
            raise SelectionStateError("fix-bug selection state update failed") from exc

    def status(self, identity: FixBugIdentity) -> str | None:
        def read_status() -> str | None:
            entry = self._read()["entries"].get(identity.key)
            return str(entry.get("state")) if isinstance(entry, dict) else None

        return self._with_lock(read_status)

    def selection_record(self, identity: FixBugIdentity) -> tuple[str, str] | None:
        """Return reconciled state and generation token for one item."""

        def reconcile() -> tuple[str, str] | None:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if not isinstance(entry, dict):
                return None
            entry_state = entry.get("state")
            if entry_state == _PROVIDER_PENDING:
                deadline = entry.get("deadline")
                if isinstance(deadline, (int, float)) and deadline <= time.time():
                    del state["entries"][identity.key]
                    self._write(state)
                    return None
            elif entry_state in {_CLAIMED, _ADMITTED} and not self._reconcile_claim(
                state,
                identity,
                entry,
            ):
                return None
            current = state["entries"].get(identity.key)
            if not isinstance(current, dict):
                return None
            return str(current["state"]), str(current["claim_id"])

        return self._with_lock(reconcile)

    def selection_state(self, identity: FixBugIdentity) -> str | None:
        """Return the current state after applying time- and Plan-based recovery."""
        record = self.selection_record(identity)
        return record[0] if record is not None else None

    def is_excluded(
        self,
        *,
        provider: str,
        repository: str,
        item_id: int,
        organization: str = "",
    ) -> bool:
        identity = FixBugIdentity(
            provider=provider,
            repository=repository,
            item_id=item_id,
            organization=organization,
        )

        return self.selection_state(identity) is not None

    @staticmethod
    def _entry_in_repository(entry: Any, repository: FixBugIdentity) -> bool:
        return bool(
            isinstance(entry, dict)
            and str(entry.get("provider") or "").casefold() == repository.provider
            and str(entry.get("organization") or "").casefold() == repository.organization
            and str(entry.get("repository") or "").casefold() == repository.repository
        )

    def _repository_reservation_locked(
        self,
        state: dict[str, Any],
        repository: FixBugIdentity,
        *,
        query_item_ids: set[int] | None,
        query_scope: dict[str, Any] | None,
    ) -> tuple[str, int, str] | None:
        entries = state["entries"]
        matches = sorted(
            (
                (key, entry)
                for key, entry in entries.items()
                if self._entry_in_repository(entry, repository)
            ),
            key=lambda item: int(item[1].get("generation") or 0),
        )
        for key, entry in matches:
            try:
                item_id = int(entry["item_id"])
            except (KeyError, TypeError, ValueError) as exc:
                raise SelectionStateError("fix-bug selection entry is malformed") from exc
            identity = FixBugIdentity(
                provider=repository.provider,
                organization=repository.organization,
                repository=repository.repository,
                item_id=item_id,
            )
            entry_state = str(entry.get("state") or "")
            if entry_state in {_CLAIMED, _ADMITTED}:
                if not self._reconcile_claim(state, identity, entry):
                    continue
                current = entries.get(key)
                entry_state = str(current.get("state") or "") if isinstance(current, dict) else ""
            if entry_state == _CALLOUT_SUPPRESSED:
                continue
            if (
                entry_state == _PROVIDER_PENDING
                and query_item_ids is not None
                and item_id not in query_item_ids
                and self._query_scope_matches(entry, query_scope)
            ):
                del entries[key]
                self._write(state)
                continue
            if entry_state in {_CLAIMED, _ADMITTED, _PROVIDER_PENDING}:
                return entry_state, item_id, str(entry["claim_id"])
            raise SelectionStateError("fix-bug selection entry has an unsupported state")
        return None

    def repository_reservation(
        self,
        *,
        provider: str,
        repository: str,
        organization: str = "",
        query_item_ids: set[int] | None = None,
        query_scope: dict[str, Any] | None = None,
    ) -> tuple[str, int, str] | None:
        repository_identity = FixBugIdentity(
            provider=provider,
            organization=organization,
            repository=repository,
            item_id=1,
        )

        def read_reservation() -> tuple[str, int, str] | None:
            return self._repository_reservation_locked(
                self._read(),
                repository_identity,
                query_item_ids=query_item_ids,
                query_scope=query_scope,
            )

        return self._with_lock(read_reservation)

    @staticmethod
    def _timestamp(raw: Any) -> float | None:
        text = str(raw or "")
        if not text:
            return None
        if not raw:
            return None
        try:
            return datetime.fromisoformat(text.replace("Z", "+00:00")).timestamp()
        except (ValueError, OverflowError):
            return None

    @classmethod
    def _plan_created_after_claim(cls, plan: Any, claimed_at: float) -> bool:
        created_at = cls._timestamp(getattr(plan, "created_at", ""))
        return created_at is not None and created_at >= claimed_at

    @staticmethod
    def _same_path(left: Any, right: Any) -> bool:
        try:
            return Path(str(left)).resolve() == Path(str(right)).resolve()
        except (OSError, RuntimeError, ValueError):
            return False

    @staticmethod
    def _issue_ref_matches(entry: dict[str, Any], raw: Any) -> bool:
        text = str(raw or "").strip()
        expected_id = str(entry.get("item_id") or "")
        if text == expected_id:
            return True
        if entry.get("provider") != "github":
            return False
        try:
            parsed = urlsplit(text)
        except ValueError:
            return False
        match = re.fullmatch(r"/([^/]+)/([^/]+)/issues/([1-9][0-9]*)", parsed.path)
        return bool(
            parsed.scheme.casefold() == "https"
            and (parsed.hostname or "").casefold() == "github.com"
            and parsed.username is None
            and parsed.password is None
            and parsed.port is None
            and not parsed.query
            and not parsed.fragment
            and match is not None
            and f"{match.group(1)}/{match.group(2)}".casefold()
            == str(entry.get("repository") or "").casefold()
            and match.group(3) == expected_id
        )

    def _scope_matches(
        self,
        entry: dict[str, Any],
        raw: dict[str, Any],
        *,
        persisted_plan: bool,
    ) -> bool:
        expected = entry.get("plan_scope" if persisted_plan else "admission_scope")
        if not isinstance(expected, dict):
            return False
        actual = self._normalize_scope(
            raw,
            value_limit=_PLAN_PARAM_VALUE_LIMIT if persisted_plan else None,
        )
        if not self._issue_ref_matches(entry, actual.get("issue_ref")):
            return False
        if not self._same_path(actual.get("repo_path"), expected.get("repo_path")):
            return False
        query_url = str(expected.get("selector_query_url") or "")
        if query_url:
            return actual.get("selector_query_url") == query_url
        source = str(expected.get("selector_source") or "")
        project = str(expected.get("selector_project") or "")
        project_name = str(expected.get("selector_project_name") or "")
        actual_project = str(actual.get("selector_project") or "").casefold()
        return bool(
            source
            and actual.get("selector_source") == source
            and actual_project in {project.casefold(), project_name.casefold()}
        )

    def _query_scope_matches(self, entry: dict[str, Any], raw: dict[str, Any] | None) -> bool:
        expected = entry.get("admission_scope")
        if not isinstance(expected, dict) or raw is None:
            return False
        actual = self._normalize_scope(raw)
        if not self._same_path(actual.get("repo_path"), expected.get("repo_path")):
            return False
        query_url = str(expected.get("selector_query_url") or "")
        if query_url:
            return actual.get("selector_query_url") == query_url
        source = str(expected.get("selector_source") or "")
        project = str(expected.get("selector_project") or "")
        project_name = str(expected.get("selector_project_name") or "")
        actual_project = str(actual.get("selector_project") or "").casefold()
        return bool(
            source
            and actual.get("selector_source") == source
            and actual_project in {project.casefold(), project_name.casefold()}
        )

    def admit_claim(
        self,
        identity: FixBugIdentity,
        selector_scope: dict[str, Any],
        claim_id: str,
    ) -> bool:
        """Atomically consume one matching selector claim for workflow admission."""

        def admit() -> bool:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if (
                not isinstance(entry, dict)
                or entry.get("state") != _CLAIMED
                or entry.get("claim_id") != claim_id
            ):
                return False
            if not self._reconcile_claim(state, identity, entry):
                return False
            current = state["entries"].get(identity.key)
            if (
                not isinstance(current, dict)
                or current.get("state") != _CLAIMED
                or not self._scope_matches(
                    current,
                    selector_scope,
                    persisted_plan=False,
                )
            ):
                return False
            current["state"] = _ADMITTED
            current["updated_at"] = time.time()
            current["admitted_at"] = current["updated_at"]
            admission_window = max(
                float(current["admission_deadline"]) - float(current["created_at"]),
                0.0,
            )
            current["plan_deadline"] = current["admitted_at"] + admission_window
            self._write(state)
            return True

        return self._with_lock(admit)

    def _matching_plans(self, entry: dict[str, Any]) -> list[Any]:
        if self._plans_fn is None:
            return []
        plans = self._plans_fn()
        scope = entry.get("plan_scope")
        admitted_at = float(entry.get("admitted_at") or 0)
        if admitted_at <= 0:
            return []
        matches: list[Any] = []
        for plan in plans:
            if str(getattr(plan, "workflow", "") or "") != "fix-bug":
                continue
            if bool(getattr(plan, "superseded", False)):
                continue
            if not isinstance(scope, dict) or not self._plan_created_after_claim(
                plan,
                admitted_at,
            ):
                continue
            params = getattr(plan, "params", None)
            if not isinstance(params, dict):
                continue
            if self._scope_matches(entry, params, persisted_plan=True):
                matches.append(plan)
        return matches

    def _reconcile_claim(
        self,
        state: dict[str, Any],
        identity: FixBugIdentity,
        entry: dict[str, Any],
    ) -> bool:
        if entry.get("state") == _CLAIMED:
            admission_deadline = entry.get("admission_deadline")
            if not isinstance(admission_deadline, (int, float)) or admission_deadline > time.time():
                return True
            del state["entries"][identity.key]
            self._write(state)
            return False

        matching_plans = self._matching_plans(entry)
        if matching_plans:
            from praestoclaw.agent.tools.plan import PlanDisposition, get_plan_disposition
            from praestoclaw.agent.tools.workflow_runs import plan_waiting_for_approval

            if any(
                get_plan_disposition(plan) is PlanDisposition.CALLOUT_TERMINAL
                for plan in matching_plans
            ):
                entry["state"] = _CALLOUT_SUPPRESSED
                entry["updated_at"] = time.time()
                entry["deadline"] = None
                self._write(state)
                return True

            def is_complete(plan: Any) -> bool:
                try:
                    done, total = plan.progress
                except Exception:  # noqa: BLE001 - persisted plan is duck-typed here
                    return False
                return bool(total and done == total)

            complete_plans = [plan for plan in matching_plans if is_complete(plan)]
            if complete_plans:
                now = time.time()
                completion_times = [
                    timestamp
                    for plan in complete_plans
                    if (
                        timestamp := self._timestamp(getattr(plan, "updated_at", ""))
                        or self._timestamp(getattr(plan, "created_at", ""))
                    )
                    is not None
                ]
                deadline = (
                    max(completion_times) + _PROVIDER_VISIBILITY_SECONDS
                    if completion_times
                    else now + _PROVIDER_VISIBILITY_SECONDS
                )
                if deadline <= now:
                    del state["entries"][identity.key]
                    self._write(state)
                    return False
                entry["state"] = _PROVIDER_PENDING
                entry["updated_at"] = now
                entry["deadline"] = deadline
                self._write(state)
                return True
            if any(
                get_plan_disposition(plan) is PlanDisposition.PARKED
                or plan_waiting_for_approval(plan)
                for plan in matching_plans
            ):
                claim_deadline = entry.get("deadline")
                if isinstance(claim_deadline, (int, float)) and claim_deadline > time.time():
                    return True
                del state["entries"][identity.key]
                self._write(state)
                return False
            claim_deadline = entry.get("deadline")
            if not isinstance(claim_deadline, (int, float)) or claim_deadline > time.time():
                return True
        else:
            plan_deadline = entry.get("plan_deadline", entry.get("deadline"))
            if not isinstance(plan_deadline, (int, float)) or plan_deadline > time.time():
                return True
        del state["entries"][identity.key]
        self._write(state)
        return False

    def try_claim(
        self,
        identity: FixBugIdentity,
        *,
        lease_seconds: float,
        admission_seconds: float | None = None,
        selector_scope: dict[str, str] | None = None,
    ) -> str | None:
        if lease_seconds <= 0:
            raise ValueError("lease_seconds must be positive")
        admission_scope = self._normalize_scope(selector_scope)
        plan_scope = self._normalize_scope(
            selector_scope,
            value_limit=_PLAN_PARAM_VALUE_LIMIT,
        )

        def claim() -> str | None:
            state = self._read()
            if identity.key in state["entries"]:
                return None
            if (
                self._repository_reservation_locked(
                    state,
                    identity,
                    query_item_ids=None,
                    query_scope=None,
                )
                is not None
            ):
                return None
            claim_id = secrets.token_hex(16)
            claim_admission_scope = {
                **admission_scope,
                "selector_claim": claim_id,
            }
            claim_plan_scope = {
                **plan_scope,
                "selector_claim": claim_id,
            }
            generation = state["next_generation"]
            now = time.time()
            state["next_generation"] = generation + 1
            state["entries"][identity.key] = {
                **identity.to_dict(),
                "state": _CLAIMED,
                "claim_id": claim_id,
                "generation": generation,
                "created_at": now,
                "updated_at": now,
                "deadline": now + lease_seconds,
                "admission_deadline": now
                + (admission_seconds if admission_seconds is not None else lease_seconds),
                "admission_scope": claim_admission_scope,
                "plan_scope": claim_plan_scope,
            }
            self._write(state)
            return claim_id

        return self._with_lock(claim)

    def release(self, identity: FixBugIdentity, claim_id: str) -> bool:
        def release_claim() -> bool:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if (
                not isinstance(entry, dict)
                or entry.get("state") not in {_CLAIMED, _ADMITTED}
                or entry.get("claim_id") != claim_id
            ):
                return False
            del state["entries"][identity.key]
            self._write(state)
            return True

        return self._with_lock(release_claim)

    def mark_provider_pending(
        self,
        identity: FixBugIdentity,
        claim_id: str,
        *,
        visibility_seconds: float,
    ) -> bool:
        if visibility_seconds <= 0:
            raise ValueError("visibility_seconds must be positive")

        def mark_pending() -> bool:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if (
                not isinstance(entry, dict)
                or entry.get("state") != _ADMITTED
                or entry.get("claim_id") != claim_id
            ):
                return False
            now = time.time()
            entry["state"] = _PROVIDER_PENDING
            entry["updated_at"] = now
            entry["deadline"] = now + visibility_seconds
            self._write(state)
            return True

        return self._with_lock(mark_pending)

    def confirm_provider_visible(self, identity: FixBugIdentity, claim_id: str) -> bool:
        """Drop the propagation guard once the provider exposes the completed work."""

        def confirm() -> bool:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if (
                not isinstance(entry, dict)
                or entry.get("state") != _PROVIDER_PENDING
                or entry.get("claim_id") != claim_id
            ):
                return False
            del state["entries"][identity.key]
            self._write(state)
            return True

        return self._with_lock(confirm)

    def finalize_callout(self, identity: FixBugIdentity, claim_id: str) -> bool:
        def suppress() -> bool:
            state = self._read()
            entry = state["entries"].get(identity.key)
            if (
                not isinstance(entry, dict)
                or entry.get("state") not in {_CLAIMED, _ADMITTED}
                or entry.get("claim_id") != claim_id
            ):
                return False
            entry["state"] = _CALLOUT_SUPPRESSED
            entry["updated_at"] = time.time()
            entry["deadline"] = None
            self._write(state)
            return True

        return self._with_lock(suppress)
