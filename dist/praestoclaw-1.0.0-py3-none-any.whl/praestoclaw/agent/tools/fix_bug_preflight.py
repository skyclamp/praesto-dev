"""Trusted launch validation for the bundled ``fix-bug`` workflow."""

from __future__ import annotations

import json
import re
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

from praestoclaw.host.background_tasks import CompletionValidator
from praestoclaw.host.runtime_contracts import is_trusted_workflow_run

_RESULT_KEYS = frozenset(
    {
        "claim_id",
        "complete",
        "eligible",
        "issue_ref",
        "item_id",
        "provider",
        "reason",
        "scope",
    }
)
_GITHUB_SCOPE_KEYS = frozenset({"mode", "query_url", "repo_path", "repository"})
_ADO_SCOPE_KEYS = frozenset(
    {"mode", "organization", "project", "project_id", "repo_path", "repository", "source"}
)
_GITHUB_REPOSITORY_RE = re.compile(r"^([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)$")
_GITHUB_ISSUE_RE = re.compile(
    r"^https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)/issues/([1-9][0-9]*)$"
)
_ADO_ORGANIZATION_RE = re.compile(
    r"^https://(?:dev\.azure\.com/[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?"
    r"|[A-Za-z0-9](?:[A-Za-z0-9-]{0,62}[A-Za-z0-9])?\.visualstudio\.com)$",
    re.IGNORECASE,
)
_SAVED_SOURCE_RE = re.compile(
    r"^saved:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"
    r"[0-9a-f]{4}-[0-9a-f]{12}$"
)
_PROJECT_ID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_CLAIM_ID_RE = re.compile(r"^[0-9a-f]{32}$")


def revalidation_args(params: dict[str, Any]) -> dict[str, Any]:
    """Build the narrow selector call from bundled recipe parameters."""
    args: dict[str, Any] = {
        "action": "revalidate",
        "repo_path": params["repo_path"],
        "issue_ref": params["issue_ref"],
    }
    query_url = str(params.get("selector_query_url") or "").strip()
    project = str(params.get("selector_project") or "").strip()
    source = str(params.get("selector_source") or "").strip()
    claim_id = str(params.get("selector_claim") or "").strip()
    if bool(project) != bool(source):
        raise ValueError("selector_project and selector_source must be supplied together")
    if query_url and project:
        raise ValueError("GitHub and Azure DevOps selector scopes cannot be combined")
    if claim_id and not (query_url or project):
        raise ValueError("selector_claim requires selector scope")
    if (query_url or project) and _CLAIM_ID_RE.fullmatch(claim_id) is None:
        raise ValueError("selector_claim is required for a selector-scoped fix-bug run")
    if query_url:
        args["query_url"] = query_url
    if project:
        args["project"] = project
        args["source"] = source
    if claim_id:
        args["claim_id"] = claim_id
    return args


class FixBugRunPolicy:
    """Claim-based launch policy registered only for the bundled fix-bug recipe."""

    def __init__(
        self,
        revalidate_fn: Callable[..., Awaitable[str]] | None,
        *,
        completion_factory: Callable[[dict[str, Any], dict[str, Any]], CompletionValidator]
        | None = None,
    ) -> None:
        self._revalidate_fn = revalidate_fn
        self._completion_factory = completion_factory

    def completion_validator(
        self, params: dict[str, Any], metadata: dict[str, Any]
    ) -> CompletionValidator | None:
        """Use host-injected stores and reviewer without widening ordinary recipes."""
        if self._completion_factory is None:
            return None
        return self._completion_factory(params, metadata)

    def handles_approval_internally(self, args: dict[str, Any], metadata: dict[str, Any]) -> bool:
        """Delegate scheduled claim approval to preflight without consuming the claim."""
        if (
            args.get("action") != "run"
            or metadata.get("source") != "cron"
            or metadata.get("physical_ingress") != "local_scheduler"
            or not is_trusted_workflow_run(metadata)
            or self._revalidate_fn is None
        ):
            return False
        params = args.get("params")
        if not isinstance(params, dict):
            return False
        try:
            return bool(revalidation_args(params).get("claim_id"))
        except (KeyError, ValueError):
            return False

    async def preflight(self, params: dict[str, Any], metadata: dict[str, Any]) -> str:
        """Freshly validate and consume a selector-scoped claim before task creation."""
        if not any(
            str(params.get(key) or "").strip()
            for key in ("selector_query_url", "selector_project", "selector_source")
        ):
            return ""
        if self._revalidate_fn is None:
            return "Fix-bug did not start: selector revalidation is unavailable."
        try:
            args = revalidation_args(params)
            raw = await self._revalidate_fn(**args)
            refusal = validate_result(raw, args)
            return f"Fix-bug did not start: {refusal}." if refusal else ""
        except ValueError as exc:
            return f"Fix-bug did not start: {exc}."
        except Exception:
            return "Fix-bug did not start: selector revalidation failed safely."


def _positive_item_id(value: Any) -> int | None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        return None
    return value


def _requested_item(value: Any) -> tuple[int | None, str | None]:
    text = str(value or "")
    if re.fullmatch(r"[1-9][0-9]*", text):
        return int(text), None
    match = _GITHUB_ISSUE_RE.fullmatch(text)
    if match is None:
        return None, None
    return int(match.group(3)), "github"


def _github_query_repository(value: Any) -> str | None:
    try:
        parsed = urlsplit(str(value or ""))
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme != "https"
        or parsed.hostname != "github.com"
        or parsed.username is not None
        or parsed.password is not None
        or port is not None
        or parsed.fragment
    ):
        return None
    match = re.fullmatch(r"/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)/issues", parsed.path)
    pairs = parse_qsl(parsed.query, keep_blank_values=True)
    if match is None or len(pairs) != 1 or pairs[0][0] != "q" or not pairs[0][1].strip():
        return None
    return f"{match.group(1)}/{match.group(2)}"


def _canonical_ado_repository(value: Any) -> bool:
    text = str(value or "")
    parts = text.split("/")
    return (
        len(parts) == 2
        and all(parts)
        and all("\\" not in part and not any(ord(char) < 32 for char in part) for part in parts)
    )


def _same_physical_path(left: Any, right: Any) -> bool:
    """Compare repository paths after resolving aliases and ``..`` segments."""
    if not isinstance(left, str) or not isinstance(right, str) or not left or not right:
        return False
    try:
        return Path(left).resolve() == Path(right).resolve()
    except (OSError, RuntimeError):
        return False


def validate_result(raw: str, args: dict[str, Any]) -> str:
    """Return a safe refusal reason, or ``""`` for one matching eligible result."""
    try:
        payload = json.loads(raw)
    except (json.JSONDecodeError, TypeError, UnicodeError):
        return "selector returned malformed data"
    if not isinstance(payload, dict) or set(payload) != _RESULT_KEYS:
        return "selector returned malformed data"
    if payload.get("complete") is not True:
        return "selector revalidation was incomplete"
    eligible = payload.get("eligible")
    reason = payload.get("reason")
    provider = payload.get("provider")
    item_id = _positive_item_id(payload.get("item_id"))
    scope = payload.get("scope")
    claim_id = payload.get("claim_id")
    if (
        not isinstance(eligible, bool)
        or not isinstance(reason, str)
        or not reason
        or len(reason) > 200
        or any(ord(character) < 32 for character in reason)
        or provider not in {"github", "ado"}
        or item_id is None
        or not isinstance(payload.get("issue_ref"), str)
        or not isinstance(scope, dict)
        or (
            claim_id is not None
            and (not isinstance(claim_id, str) or _CLAIM_ID_RE.fullmatch(claim_id) is None)
        )
    ):
        return "selector returned malformed data"

    expected_item, issue_provider = _requested_item(args.get("issue_ref"))
    scope_provider = "github" if args.get("query_url") else "ado" if args.get("project") else None
    expected_provider = scope_provider or issue_provider
    if expected_item != item_id or (expected_provider and provider != expected_provider):
        return "selector result did not match this run"
    expected_claim = str(args.get("claim_id") or "")
    if eligible and expected_claim and claim_id != expected_claim:
        return "selector claim did not match this run"
    if not _same_physical_path(scope.get("repo_path"), args.get("repo_path")):
        return "selector scope did not match this run"

    if provider == "github":
        query_url = args.get("query_url")
        expected_keys = (
            {"repo_path", "repository", "query_url"}
            if query_url
            else {
                "mode",
                "repo_path",
                "repository",
            }
        )
        if not set(scope).issubset(_GITHUB_SCOPE_KEYS) or set(scope) != expected_keys:
            return "selector scope did not match this run"
        repository = scope.get("repository")
        if not isinstance(repository, str) or _GITHUB_REPOSITORY_RE.fullmatch(repository) is None:
            return "selector scope did not match this run"
        canonical_ref = f"https://github.com/{repository}/issues/{item_id}"
        if payload.get("issue_ref") != canonical_ref:
            return "selector issue did not match this run"
        if issue_provider == "github" and payload.get("issue_ref") != args.get("issue_ref"):
            return "selector issue did not match this run"
        if query_url:
            if (
                scope.get("query_url") != query_url
                or _github_query_repository(query_url) != repository
            ):
                return "selector query scope did not match this run"
        elif scope.get("mode") != "exact-issue":
            return "selector scope did not match this run"
        return "" if eligible else reason

    if provider != "ado" or payload.get("issue_ref") != str(item_id):
        return "selector issue did not match this run"
    if not set(scope).issubset(_ADO_SCOPE_KEYS):
        return "selector provider did not match this run"
    if (
        not isinstance(scope.get("organization"), str)
        or _ADO_ORGANIZATION_RE.fullmatch(scope["organization"]) is None
        or not _canonical_ado_repository(scope.get("repository"))
    ):
        return "selector scope did not match this run"
    project = args.get("project")
    source = args.get("source")
    if project:
        if set(scope) != {
            "organization",
            "project",
            "project_id",
            "repo_path",
            "repository",
            "source",
        }:
            return "selector scope did not match this run"
        returned_project = scope.get("project")
        returned_project_id = scope.get("project_id")
        if (
            not isinstance(returned_project, str)
            or not returned_project
            or not isinstance(returned_project_id, str)
            or _PROJECT_ID_RE.fullmatch(returned_project_id) is None
            or str(project).casefold()
            not in {returned_project.casefold(), returned_project_id.casefold()}
            or scope.get("source") != source
            or not isinstance(source, str)
            or _SAVED_SOURCE_RE.fullmatch(source) is None
        ):
            return "selector project/source scope did not match this run"
    elif (
        set(scope) != {"mode", "organization", "repo_path", "repository"}
        or scope.get("mode") != "exact-work-item"
    ):
        return "selector scope did not match this run"
    return "" if eligible else reason
