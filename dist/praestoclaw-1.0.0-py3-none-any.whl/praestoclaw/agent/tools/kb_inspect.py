"""Read the live knowledge base: its rules, its layout and its documents.

This is the tool that keeps the curation stage honest. The KB's structure is
not knowledge this agent is allowed to remember — repositories are reorganised,
READMEs are rewritten, new areas appear, and a stale mental map produces changes
that look plausible and violate the rules the humans actually wrote down. So
nothing here encodes a destination for a kind of knowledge. It clones the
repository and reads what it says about itself, now.

``rules`` is the action that matters most: it collects the rule-bearing
documents (root and per-directory READMEs, CONTRIBUTING, conventions) along the
path being edited, so the drafting step is grounded in that repository's stated
conventions rather than this agent's habits.

Everything is read-only. Writing is ``kb_draft``; publishing is ``kb_publish``.
"""

from __future__ import annotations

import asyncio
import fnmatch
import json
import re
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.agent.tools.kb_base import KbToolBase
from praestoclaw.kb.repo import KbPathError, KbRepo, KbRepoError
from praestoclaw.security.kb_curation import kb_curation_is_active
from praestoclaw.security.risk import RiskAssessment, RiskScore

_ACTIONS = ("repos", "sync", "rules", "tree", "read", "search")

# Filenames that carry a repository's own conventions. Discovered per directory
# along the path in question, not assumed to exist anywhere in particular.
_RULE_FILENAMES = (
    "README.md",
    "readme.md",
    "CONTRIBUTING.md",
    "AGENTS.md",
    "CLAUDE.md",
    "conventions.md",
    "CONVENTIONS.md",
    "index.md",
)

_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "dist", "build"}
_TEXT_SUFFIXES = {".md", ".markdown", ".txt", ".yml", ".yaml", ".json", ".csv", ".rst"}

# Documents a rule may delegate to. Narrower than _TEXT_SUFFIXES: a rule points
# at prose or a policy file, not at a data dump.
_RULE_REF_SUFFIXES = {".md", ".markdown", ".yml", ".yaml"}

# ``[text](./sources.md)`` and a bare ``sources.md`` mentioned in a sentence.
# Both bind: "只读取 sources.md 中的白名单来源" is a rule whether or not the
# author bothered to make it a link.
_MD_LINK = re.compile(r"\]\(\s*([^)\s]+)\s*\)")
_BARE_DOC = re.compile(r"(?<![\w./-])[\w][\w./-]*\.(?:md|markdown|ya?ml)(?![\w-])", re.IGNORECASE)

# Language that marks a line as stating a constraint rather than listing a
# document. Deliberately about obligation and permission — the words a rule
# uses — so an index entry ("- [Vision](./vision.md)：愿景说明") does not match.
_NORMATIVE = re.compile(
    r"(只|仅|必须|不得|不要|禁止|应当|应该|规则|白名单|允许|遵循|按照|依据|限制"
    r"|不复制|不保存|不记录|范围"
    r"|\bmust\b|\bonly\b|\bnever\b|\bdo not\b|\bdon't\b|\bshall\b|\bshould\b"
    r"|\brequired\b|\ballow(?:ed|list)?\b|\bwhitelist\b|\brule[sd]?\b|\bpolicy\b"
    r"|\bconvention[s]?\b|\bforbidden\b|\bprohibited\b|\brestrict)",
    re.IGNORECASE,
)

_DEFAULT_TREE_DEPTH = 2
_MAX_TREE_ENTRIES = 400
_DEFAULT_SEARCH_LIMIT = 40
_MAX_SEARCH_LIMIT = 200
_SEARCH_CONTEXT_CHARS = 160
_MAX_RULE_BYTES = 20_000


def _rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


class KbInspectTool(KbToolBase, Tool):
    """Read-only view of the configured knowledge-base repositories."""

    risk_range = (2, 2)

    @property
    def name(self) -> str:
        return "kb_inspect"

    @property
    def description(self) -> str:
        return (
            "Read the team knowledge base as it exists right now. Actions: "
            "'repos' lists the configured repositories; 'sync' clones or "
            "fast-forwards one and reports its head commit; 'rules' returns the "
            "repository's own conventions (READMEs along a path, CONTRIBUTING, "
            "conventions) — read these BEFORE drafting, because each repository "
            "states its own format and some forbid raw material outright; 'tree' "
            "lists a directory; 'read' returns one document; 'search' finds text "
            "across the repository. Read-only — kb_draft stages changes and "
            "kb_publish commits them."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=300, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(2, reason="Read-only inspection of a configured knowledge-base repo")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": list(_ACTIONS),
                    "description": (
                        "repos = list configured repositories; sync = clone/update one; "
                        "rules = that repository's stated conventions for a path; "
                        "tree = list a directory; read = one document; search = find text."
                    ),
                },
                "repo": {
                    "type": "string",
                    "description": (
                        "Optional. Defaults to the repository this group is bound to "
                        "(kb_scope). Pass it only to confirm that same repository."
                    ),
                },
                "path": {
                    "type": "string",
                    "description": (
                        "Repository-relative path. For 'rules' and 'tree' a directory "
                        "(default: repository root); for 'read' a file."
                    ),
                },
                "query": {
                    "type": "string",
                    "description": "For 'search': case-insensitive text to find.",
                },
                "glob": {
                    "type": "string",
                    "description": "For 'search': restrict to matching filenames, e.g. '*.md'.",
                },
                "depth": {
                    "type": "integer",
                    "description": f"For 'tree': directory levels (default {_DEFAULT_TREE_DEPTH}).",
                },
                "limit": {
                    "type": "integer",
                    "description": "For 'search': maximum matches to return.",
                },
                "offset": {
                    "type": "integer",
                    "description": "For 'read': first line to return (1-based).",
                },
            },
            "required": ["action"],
        }

    # ── configuration ────────────────────────────────────────────────────

    def _max_file_bytes(self) -> int:
        return int(getattr(self._config, "max_file_bytes", 200_000) or 200_000)

    # ── execution ────────────────────────────────────────────────────────

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        if not kb_curation_is_active(metadata):
            return (
                "kb_inspect is only available in a Teams group experiment or personal Teams chat."
            )
        if not self._enabled():
            return "Knowledge-base curation is disabled in this PraestoClaw config."

        action = str(kwargs.get("action") or "").strip()
        if action not in _ACTIONS:
            return f"Error: action must be one of {', '.join(_ACTIONS)}."

        cid = str(metadata.get("cid") or "").strip()
        if action == "repos":
            scope = self._scope(cid)
            return self._dump(
                {
                    "repos": self._allowlist(),
                    "this_group_uses": scope.repo if scope else "",
                    "preferred_subfolder": scope.subfolder if scope else "",
                }
            )

        resolved = self._repo_for_group(cid, str(kwargs.get("repo") or ""))
        if isinstance(resolved, str):
            return resolved
        repo = resolved

        try:
            if action == "sync":
                status = await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
                return self._dump({"synced": status.to_dict()})

            ready = await self._ensure_checkout(repo)
            if ready:
                return ready

            if action == "rules":
                return self._action_rules(repo, kwargs)
            if action == "tree":
                return self._action_tree(repo, kwargs)
            if action == "read":
                return self._action_read(repo, kwargs)
            return self._action_search(repo, kwargs)
        except KbRepoError as exc:
            return f"Knowledge base unavailable: {exc}"

    async def _ensure_checkout(self, repo: KbRepo) -> str:
        """Clone on first use so a read action never fails for a missing repo."""
        if repo.is_cloned:
            return ""
        logger.info("kb_inspect: first use of {} — cloning", repo.slug)
        await asyncio.to_thread(repo.sync, timeout=self._sync_timeout())
        return ""

    # ── path safety ──────────────────────────────────────────────────────

    def _resolve_path(self, repo: KbRepo, raw: str) -> Path | str:
        """Resolve a repository-relative path, refusing anything outside it."""
        cleaned = (raw or "").strip()
        if not cleaned:
            return repo.path.resolve()
        try:
            return repo.resolve_within(cleaned)
        except KbPathError as exc:
            return str(exc)

    # ── actions ──────────────────────────────────────────────────────────

    def _action_rules(self, repo: KbRepo, kwargs: dict[str, Any]) -> str:
        """Collect the conventions that govern *path*, root-first.

        Walking from the repository root down to the target directory matters:
        a repository states general rules at the top ("this repo holds curated
        knowledge") and refines them per area ("this folder keeps verbatim
        transcripts"). The narrower rule usually wins, and the model can only
        see that if it receives both.

        Rule documents also *delegate*. A README that says "only read the
        allowlisted sources in sources.md" states a real constraint, but the
        constraint itself lives somewhere else — and that somewhere is named by
        the repository, not by this code. Collecting only fixed filenames hands
        back the pointer while withholding the rule, which is worse than saying
        nothing: it looks complete. So one hop of same-repository references is
        followed and clearly marked as delegated.
        """
        target = self._resolve_path(repo, str(kwargs.get("path") or ""))
        if isinstance(target, str):
            return target
        root = repo.path.resolve()
        if target.is_file():
            target = target.parent

        directories: list[Path] = [root]
        if target != root:
            current = root
            for part in target.relative_to(root).parts:
                current = current / part
                if current.is_dir():
                    directories.append(current)

        documents: list[dict[str, Any]] = []
        seen: set[Path] = set()

        def add(path: Path, *, delegated_from: str = "") -> None:
            if not path.is_file() or path in seen:
                return
            seen.add(path)
            text = path.read_text(encoding="utf-8", errors="replace")
            entry: dict[str, Any] = {
                "path": _rel(path, root),
                "truncated": len(text.encode("utf-8")) > _MAX_RULE_BYTES,
                "content": text[:_MAX_RULE_BYTES],
            }
            if delegated_from:
                entry["delegated_from"] = delegated_from
            documents.append(entry)

        for directory in directories:
            for filename in _RULE_FILENAMES:
                add(directory / filename)
        # Repository-wide policy files live outside the walked path.
        for extra in (root / ".github" / "CONTRIBUTING.md", root / "CONTRIBUTING.md"):
            add(extra)

        # One hop only, and only where the citing sentence is normative. Rule
        # documents sit next to navigation indexes — a repository README lists
        # every document it owns — and following those links returns most of the
        # knowledge base as if it were policy. What separates the two is the
        # sentence doing the citing: "每次同步只读取 sources.md 中的白名单来源"
        # delegates a constraint; "- [Vision Synthesis](./vision/synthesis.md)"
        # is a table of contents.
        for entry in list(documents):
            source = root / entry["path"]
            for referenced in self._referenced_documents(entry["content"], source, root):
                add(referenced, delegated_from=entry["path"])

        return self._dump(
            {
                "repo": repo.slug,
                "head": repo.head(),
                "path": _rel(target, root) if target != root else "",
                "note": (
                    "These are the repository's own stated rules, root-first; the "
                    "narrower one usually wins. Documents marked 'delegated_from' were "
                    "pulled in because another rule pointed at them. Check the material "
                    "you intend to add against ALL of them — including constraints on "
                    "which sources may be used and what may be stored verbatim — and "
                    "record any conflict as a kb_draft blocker instead of drafting "
                    "around it."
                ),
                "rule_documents": documents,
            }
        )

    @staticmethod
    def _referenced_documents(content: str, source: Path, root: Path) -> list[Path]:
        """Same-repository documents a rule *delegates a constraint* to.

        Judged per line, because that is where the distinction lives. A README
        that lists every document in the repository is an index; a sentence
        saying a rule is defined elsewhere is a delegation. Following the former
        would return the whole knowledge base labelled as policy, which buries
        the one file that actually constrains the work.

        Both Markdown links and bare filenames count on a normative line: a rule
        binds just as hard when the author did not bother to make it a link.
        """
        found: list[Path] = []
        for line in content.splitlines():
            if not _NORMATIVE.search(line):
                continue
            refs = {match.group(1) for match in _MD_LINK.finditer(line)}
            refs |= {match.group(0) for match in _BARE_DOC.finditer(line)}
            for raw in refs:
                ref = raw.split("#", 1)[0].split("?", 1)[0].strip()
                if not ref or ref.startswith(("http://", "https://", "mailto:", "//")):
                    continue
                base = root if ref.startswith("/") else source.parent
                try:
                    resolved = (base / ref.lstrip("/")).resolve()
                    resolved.relative_to(root)
                except (ValueError, OSError):
                    continue
                if (
                    resolved.is_file()
                    and resolved != source
                    and resolved.suffix.lower() in _RULE_REF_SUFFIXES
                ):
                    found.append(resolved)
        return sorted(set(found))

    def _action_tree(self, repo: KbRepo, kwargs: dict[str, Any]) -> str:
        target = self._resolve_path(repo, str(kwargs.get("path") or ""))
        if isinstance(target, str):
            return target
        if not target.is_dir():
            return f"'{kwargs.get('path')}' is not a directory in this repository."
        root = repo.path.resolve()
        try:
            depth = int(kwargs.get("depth") or _DEFAULT_TREE_DEPTH)
        except (TypeError, ValueError):
            depth = _DEFAULT_TREE_DEPTH
        depth = max(1, min(depth, 6))

        entries: list[dict[str, Any]] = []
        truncated = False

        def walk(directory: Path, level: int) -> None:
            nonlocal truncated
            if level > depth or truncated:
                return
            for child in sorted(directory.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
                if child.name in _SKIP_DIRS:
                    continue
                if len(entries) >= _MAX_TREE_ENTRIES:
                    truncated = True
                    return
                if child.is_dir():
                    entries.append({"path": _rel(child, root) + "/", "type": "dir"})
                    walk(child, level + 1)
                else:
                    entries.append(
                        {
                            "path": _rel(child, root),
                            "type": "file",
                            "bytes": child.stat().st_size,
                        }
                    )

        walk(target, 1)
        return self._dump(
            {
                "repo": repo.slug,
                "head": repo.head(),
                "path": _rel(target, root) if target != root else "",
                "depth": depth,
                "truncated": truncated,
                "entries": entries,
            }
        )

    def _action_read(self, repo: KbRepo, kwargs: dict[str, Any]) -> str:
        raw_path = str(kwargs.get("path") or "").strip()
        if not raw_path:
            return "Error: read needs a path."
        target = self._resolve_path(repo, raw_path)
        if isinstance(target, str):
            return target
        if not target.is_file():
            return f"'{raw_path}' does not exist in this repository."
        size = target.stat().st_size
        if size > self._max_file_bytes():
            return (
                f"'{raw_path}' is {size:,} bytes, larger than the "
                f"{self._max_file_bytes():,}-byte limit. Use search to locate the part "
                "you need."
            )
        text = target.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        try:
            offset = max(1, int(kwargs.get("offset") or 1))
        except (TypeError, ValueError):
            offset = 1
        try:
            limit = int(kwargs.get("limit") or 0)
        except (TypeError, ValueError):
            limit = 0
        window = lines[offset - 1 :] if offset > 1 else lines
        if limit > 0:
            window = window[:limit]
        return self._dump(
            {
                "repo": repo.slug,
                "head": repo.head(),
                "path": raw_path,
                "total_lines": len(lines),
                "from_line": offset,
                "returned_lines": len(window),
                "content": "\n".join(window),
            }
        )

    def _action_search(self, repo: KbRepo, kwargs: dict[str, Any]) -> str:
        query = str(kwargs.get("query") or "").strip()
        if not query:
            return "Error: search needs a query."
        target = self._resolve_path(repo, str(kwargs.get("path") or ""))
        if isinstance(target, str):
            return target
        root = repo.path.resolve()
        pattern = str(kwargs.get("glob") or "").strip()
        try:
            limit = int(kwargs.get("limit") or _DEFAULT_SEARCH_LIMIT)
        except (TypeError, ValueError):
            limit = _DEFAULT_SEARCH_LIMIT
        limit = max(1, min(limit, _MAX_SEARCH_LIMIT))

        needle = query.lower()
        matches: list[dict[str, Any]] = []
        truncated = False
        for candidate in sorted(target.rglob("*")):
            if len(matches) >= limit:
                truncated = True
                break
            if not candidate.is_file():
                continue
            if any(part in _SKIP_DIRS for part in candidate.parts):
                continue
            if candidate.suffix.lower() not in _TEXT_SUFFIXES:
                continue
            if pattern and not fnmatch.fnmatch(candidate.name, pattern):
                continue
            if candidate.stat().st_size > self._max_file_bytes():
                continue
            try:
                text = candidate.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            for number, line in enumerate(text.splitlines(), start=1):
                if needle in line.lower():
                    matches.append(
                        {
                            "path": _rel(candidate, root),
                            "line": number,
                            "text": line.strip()[:_SEARCH_CONTEXT_CHARS],
                        }
                    )
                    break  # one hit per file keeps the result scannable

        return self._dump(
            {
                "repo": repo.slug,
                "head": repo.head(),
                "query": query,
                "glob": pattern or None,
                "truncated": truncated,
                "match_count": len(matches),
                "matches": matches,
            }
        )

    @staticmethod
    def _dump(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, indent=2)
