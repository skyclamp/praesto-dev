"""Send a message with native mentions to the current Teams conversation."""

from __future__ import annotations

from typing import Any

from praestoclaw.agent.tools.base import Tool, ToolMetadata
from praestoclaw.bus.events import OutboundMessage
from praestoclaw.bus.queue import MessageBus
from praestoclaw.config.schema import ChannelType
from praestoclaw.security.risk import RiskAssessment, RiskScore


class GroupNotifyTool(Tool):
    """A conversation-bound Teams native-mention tool."""

    risk_range = (0, 0)

    def __init__(self, bus: MessageBus) -> None:
        self._bus = bus

    @property
    def name(self) -> str:
        return "group_notify"

    @property
    def description(self) -> str:
        return (
            "Send a message to the CURRENT Teams group with native Teams mentions. "
            "The destination is always the current Teams conversation supplied by the runtime. "
            "Do not provide a destination chat ID or channel ID. "
            "Use this whenever the user asks to mention a person, tag, or everyone. "
            "The content must contain a matching @Name placeholder for each mention. "
            "After this call, give only a brief confirmation in the final response; "
            "do not repeat the sent message."
        )

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=30, tier="core")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        return RiskScore(0, reason="Message to the current Teams conversation")

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "Message content with matching @Name placeholders.",
                },
                "teams_mentions": {
                    "type": "array",
                    "minItems": 1,
                    "description": (
                        "Native Teams mentions. user needs name (UPN or id may disambiguate); "
                        "tag needs name and id; all uses name 'Everyone' and type 'all'."
                    ),
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "upn": {"type": "string"},
                            "id": {"type": "string"},
                            "type": {"type": "string", "enum": ["user", "tag", "all"]},
                        },
                        "required": ["name", "type"],
                    },
                },
            },
            "required": ["content", "teams_mentions"],
        }

    async def execute(self, **kwargs: Any) -> str:
        metadata = kwargs.get("_metadata") or {}
        cid = str(metadata.get("cid") or "").strip()
        if not cid:
            return "Error: group_notify requires the current Teams conversation."

        content = str(kwargs.get("content") or "")
        if not content.strip():
            return "Error: message content cannot be empty."

        mentions: list[dict[str, str]] = []
        for raw in kwargs.get("teams_mentions") or []:
            mention_type = str(raw.get("type") or "user").strip().lower()
            mention = {
                "name": str(raw.get("name") or "").strip(),
                "upn": str(raw.get("upn") or "").strip(),
                "id": str(raw.get("id") or "").strip(),
                "type": mention_type,
            }
            if mention_type == "user" and mention["name"]:
                mentions.append(mention)
            elif mention_type == "tag" and mention["name"] and mention["id"]:
                mentions.append(mention)
            elif mention_type == "all":
                mention["name"] = mention["name"] or "Everyone"
                mentions.append(mention)

        if not mentions:
            return "Error: at least one valid mention is required."

        delivered = await self._bus.publish_outbound(
            OutboundMessage(
                channel=ChannelType.CLOUD,
                channel_id=cid,
                content=content,
                metadata={
                    "keep_context": True,
                    "notify_category": "group_notify",
                    "push_target": "teams",
                    "committed_teams_conversation_id": cid,
                    "teams_mentions": mentions,
                },
            )
        )
        return (
            "Sent message to the current Teams group."
            if delivered
            else "Error: the current Teams group did not accept the message."
        )
