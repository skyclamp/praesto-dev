"""Packaged PraestoClaw runtime assets."""
