# 1ES Hibernation Delay Agent on a Dev Box initialization. Original location: https://dev.azure.com/mseng/1ES/_git/DevBox.HibernationDelayAgent?path=/scripts/setup/HibernationDelayAgent-Bootstrap.ps1

if (-not $env:COMPUTERNAME.StartsWith('CPC-')) { return }

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

#Requires -RunAsAdministrator

# Keep the logic to the minimum needed to launch HibernationDelayAgent-Install.ps1 since this script it not auto-updated by the agent
try {
    Write-Host '1ES Dev Box Hibernation Delay Agent initialization ...'

    $env:AZUREAUTH_VERSION = '0.9.1' # See https://github.com/AzureAD/microsoft-authentication-cli/releases for the latest.
    $env:AZUREAUTH_INSTALL_DIRECTORY = 'C:\.tools\AzureAuth' # Location where all Dev Box setup scripts are looking for the tool.
    $azureAuthExe = "$env:AZUREAUTH_INSTALL_DIRECTORY\$env:AZUREAUTH_VERSION\azureauth.exe"
    if (-not (Test-Path $azureAuthExe -PathType Leaf -ErrorAction SilentlyContinue)) {
        Invoke-Command { & ([ScriptBlock]::Create((Invoke-WebRequest "https://raw.githubusercontent.com/AzureAD/microsoft-authentication-cli/${env:AZUREAUTH_VERSION}/install/install.ps1").Content)) -NoUpdatePath } | Out-Null
    }

    $installScript = 'C:\.tools\Setup\HibernationDelayAgent\HibernationDelayAgent-Install.ps1'
    New-Item -Path (Join-Path -Path (Split-Path $installScript -Parent) -ChildPath 'Logs') -ItemType Directory -Force | Out-Null
    if (-not (Test-Path $installScript)) {
        $powerShellClientId = '1950a258-227b-4e31-a9cf-717495945fc2' # https://github.com/Azure/azure-powershell/blob/main/src/Accounts/Authentication/Constants.cs#L19
        $token = Invoke-Command { & $azureAuthExe aad --resource https://storage.azure.com --tenant 72f988bf-86f1-41af-91ab-2d7cd011db47 --client $powerShellClientId --mode broker --output token }
        if ($LASTEXITCODE -ne 0) { throw "Failed to authenticate with azureauth.exe. Exit code: $LASTEXITCODE" }
        Invoke-WebRequest -Uri "https://hibernationagentprimary.blob.core.windows.net/hibernationagent-executables/HibernationDelayAgent-Install.ps1" -Headers @{Authorization = "Bearer $token"; 'x-ms-version' = "2020-10-02" } -OutFile $installScript
    }

    Invoke-Command { & $installScript *>&1 } | Tee-Object -FilePath (Join-Path -Path (Split-Path $installScript -Parent) -ChildPath 'Logs\install.log') -Append
}
catch {
    # Provide the error details but never fail the caller script
    Write-Host "[ERROR] Failed to initialize 1ES Dev Box Hibernation Delay Agent`n$_`n$($_.ScriptStackTrace)" -ErrorAction Stop -ForegroundColor Red
}
