"""Per-meeting task-flow profile persistence."""

from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from copy import deepcopy
from pathlib import Path
from threading import RLock
from typing import Any

from praestoclaw.meeting_automation.models import (
    MeetingTaskGroupInstance,
    MeetingTaskGroupTemplate,
)

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def meeting_id_slug(meeting_id: str) -> str:
    """Stable readable directory name for a Teams meeting thread id."""
    value = str(meeting_id or "").strip()
    if not value:
        raise ValueError("meeting id is required")
    readable = _UNSAFE.sub("_", value).strip("_.")[:72]
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{readable}-{digest}" if readable else digest


class MeetingAutomationStore:
    """Store each flow under ``<data_dir>/meetings/<meeting-id>/flow.json``."""

    def __init__(self, data_dir: Path) -> None:
        self._root = data_dir / "meetings"
        self._lock = RLock()
        self._templates: dict[str, MeetingTaskGroupTemplate] = {}
        self._instances: dict[str, MeetingTaskGroupInstance] = {}
        self._load()

    def profile_dir(self, meeting_chat_id: str) -> Path:
        return self._root / meeting_id_slug(meeting_chat_id)

    def flow_path(self, meeting_chat_id: str) -> Path:
        return self.profile_dir(meeting_chat_id) / "flow.json"

    def get_template(self, meeting_chat_id: str) -> MeetingTaskGroupTemplate | None:
        with self._lock:
            value = self._templates.get(meeting_chat_id)
            return deepcopy(value) if value is not None else None

    def put_template(self, template: MeetingTaskGroupTemplate) -> None:
        if not template.meeting_chat_id:
            raise ValueError("meeting template requires meeting_chat_id")
        with self._lock:
            self._templates[template.meeting_chat_id] = deepcopy(template)
            self._persist_profile(template.meeting_chat_id)

    def templates(self) -> list[MeetingTaskGroupTemplate]:
        with self._lock:
            return deepcopy(list(self._templates.values()))

    def get_instance(self, instance_id: str) -> MeetingTaskGroupInstance | None:
        with self._lock:
            value = self._instances.get(instance_id)
            return deepcopy(value) if value is not None else None

    def put_instance(self, instance: MeetingTaskGroupInstance) -> None:
        meeting_chat_id = instance.meeting.chat_id
        if not meeting_chat_id:
            raise ValueError("meeting instance requires meeting.chat_id")
        with self._lock:
            self._instances[instance.instance_id] = deepcopy(instance)
            self._persist_profile(meeting_chat_id)

    def instances(self, *, meeting_chat_id: str | None = None) -> list[MeetingTaskGroupInstance]:
        with self._lock:
            values = deepcopy(list(self._instances.values()))
        if meeting_chat_id is None:
            return values
        return [item for item in values if item.meeting.chat_id == meeting_chat_id]

    def find_by_background_task(self, task_id: str) -> MeetingTaskGroupInstance | None:
        with self._lock:
            value = next(
                (item for item in self._instances.values() if item.background_task_id == task_id),
                None,
            )
            return deepcopy(value) if value is not None else None

    def _load(self) -> None:
        if not self._root.is_dir():
            return
        for path in self._root.glob("*/flow.json"):
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                if raw.get("version") != 1:
                    continue
                template = MeetingTaskGroupTemplate.from_dict(raw.get("template"))
                if not template.meeting_chat_id:
                    continue
                self._templates[template.meeting_chat_id] = template
                instances = raw.get("instances") or {}
                if isinstance(instances, dict):
                    for key, value in instances.items():
                        instance = MeetingTaskGroupInstance.from_dict(value)
                        if instance.meeting.chat_id == template.meeting_chat_id:
                            self._instances[str(key)] = instance
            except (OSError, ValueError, TypeError):
                # Leave an unreadable profile intact for operator inspection.
                continue

    def _persist_profile(self, meeting_chat_id: str) -> None:
        template = self._templates.get(meeting_chat_id)
        if template is None:
            return
        directory = self.profile_dir(meeting_chat_id)
        directory.mkdir(parents=True, exist_ok=True)
        id_path = directory / "MEETING_ID"
        if not id_path.exists():
            id_path.write_text(meeting_chat_id + "\n", encoding="utf-8")
        payload: dict[str, Any] = {
            "version": 1,
            "template": template.to_dict(),
            "instances": {
                key: value.to_dict()
                for key, value in self._instances.items()
                if value.meeting.chat_id == meeting_chat_id
            },
        }
        fd, tmp_name = tempfile.mkstemp(
            prefix="flow-", suffix=".json.tmp", dir=directory, text=True
        )
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(tmp, self.flow_path(meeting_chat_id))
        finally:
            tmp.unlink(missing_ok=True)
