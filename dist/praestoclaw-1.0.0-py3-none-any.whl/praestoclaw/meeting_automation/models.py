"""Persistent models for meeting task-group templates and instances."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

PhaseName = Literal["pre", "post"]
ScheduleType = Literal["meeting_relative", "weekly"]
InstanceState = Literal[
    "scheduled",
    "validating",
    "running",
    "waiting_user",
    "completed",
    "skipped",
    "failed",
    "paused",
]


@dataclass(slots=True)
class TaskGroupSkillConfig:
    """One explicit Group Skill dependency of a meeting task group."""

    name: str
    repo_url: str = ""

    @classmethod
    def from_dict(cls, raw: Any) -> TaskGroupSkillConfig:
        data = raw if isinstance(raw, dict) else {}
        return cls(
            name=str(data.get("name") or "").strip()[:100],
            repo_url=str(data.get("repo_url") or "").strip()[:4000],
        )


@dataclass(slots=True)
class MeetingRelativeSchedule:
    type: Literal["meeting_relative"] = "meeting_relative"
    anchor: Literal["start", "end"] = "start"
    offset_minutes: int = 0

    @classmethod
    def from_dict(cls, raw: Any) -> MeetingRelativeSchedule:
        if not isinstance(raw, dict):
            raise ValueError("meeting-relative schedule must be an object")
        anchor = raw.get("anchor")
        if anchor not in {"start", "end"}:
            raise ValueError("meeting-relative schedule anchor must be start or end")
        raw_offset = raw.get("offset_minutes")
        if raw_offset is None:
            raise ValueError("meeting-relative schedule offset_minutes is required")
        offset_minutes = int(raw_offset)
        if offset_minutes not in range(0, 7 * 24 * 60 + 1):
            raise ValueError("meeting-relative schedule offset_minutes must be between 0 and 10080")
        return cls(anchor=anchor, offset_minutes=offset_minutes)


@dataclass(slots=True)
class WeeklySchedule:
    type: Literal["weekly"] = "weekly"
    weekday: int = 1
    local_time: str = "09:00"

    @classmethod
    def from_dict(cls, raw: Any) -> WeeklySchedule:
        data = raw if isinstance(raw, dict) else {}
        raw_weekday = data.get("weekday")
        if raw_weekday is None:
            raise ValueError("weekly schedule weekday must be 1 through 7")
        weekday = int(raw_weekday)
        local_time = str(data.get("local_time") or "")
        if weekday not in range(1, 8):
            raise ValueError("weekly schedule weekday must be 1 through 7")
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", local_time):
            raise ValueError("weekly schedule local_time must be HH:mm")
        return cls(weekday=weekday, local_time=local_time)


TaskSchedule = MeetingRelativeSchedule | WeeklySchedule


def schedule_from_dict(raw: Any) -> TaskSchedule:
    if not isinstance(raw, dict):
        raise ValueError("schedule must be an object")
    if raw.get("type") == "weekly":
        return WeeklySchedule.from_dict(raw)
    if raw.get("type") == "meeting_relative":
        return MeetingRelativeSchedule.from_dict(raw)
    raise ValueError("schedule type must be meeting_relative or weekly")


@dataclass(slots=True)
class TaskGroupConfig:
    """One independently scheduled task group within a meeting phase."""

    key: str
    phase: PhaseName
    enabled: bool = True
    schedule: TaskSchedule = field(default_factory=MeetingRelativeSchedule)
    prompt: str = ""
    skills: list[TaskGroupSkillConfig] = field(default_factory=list)
    # User-spoken display-name/UPN fragments to resolve against the target
    # Teams conversation's live roster at delivery time.  Keeping these
    # separate from the free-form prompt means a member need not appear in the
    # calendar attendee list, and ambiguous partial names can fail closed in
    # the bridge instead of being guessed by the LLM.
    mentions: list[str] = field(default_factory=list)
    source_revision: int = 1

    @classmethod
    def from_dict(cls, raw: Any, *, index: int = 0) -> TaskGroupConfig:
        data = raw if isinstance(raw, dict) else {}
        phase: PhaseName = "post" if data.get("phase") == "post" else "pre"
        key = str(data.get("key") or f"{phase}-{index + 1}").strip()[:100]
        return cls(
            key=key or f"{phase}-{index + 1}",
            phase=phase,
            enabled=bool(data.get("enabled", True)),
            schedule=schedule_from_dict(data.get("schedule")),
            prompt=str(data.get("prompt") or "")[:20_000],
            skills=[
                TaskGroupSkillConfig.from_dict(item)
                for item in (data.get("skills") or [])
                if isinstance(item, dict)
            ][:100],
            mentions=[
                str(item).strip()[:1000]
                for item in (data.get("mentions") or [])
                if isinstance(item, str) and item.strip()
            ][:500],
            source_revision=max(1, int(data.get("source_revision") or 1)),
        )


@dataclass(slots=True)
class RoutingContext:
    """Trusted delivery context captured when the user configures the template."""

    channel: str = "cloud"
    channel_id: str = "meeting-automation"
    thread_id: str | None = None
    session_id: str = ""
    route_hint: str | None = None
    teams_conversation_id: str | None = None

    @classmethod
    def from_dict(cls, raw: Any) -> RoutingContext:
        data = raw if isinstance(raw, dict) else {}
        return cls(
            channel=str(data.get("channel") or "cloud")[:32],
            channel_id=str(data.get("channel_id") or "meeting-automation")[:500],
            thread_id=_optional_text(data.get("thread_id"), 500),
            session_id=str(data.get("session_id") or "")[:500],
            route_hint=_optional_text(data.get("route_hint"), 500),
            teams_conversation_id=_optional_text(data.get("teams_conversation_id"), 500),
        )


@dataclass(slots=True)
class MeetingTaskGroupTemplate:
    """Task-flow template owned by one Teams meeting series/chat."""

    meeting_chat_id: str = ""
    meeting_url: str = ""
    subject: str = ""
    series_master_id: str = ""
    enabled: bool = True
    timezone: str = "Asia/Shanghai"
    task_groups: list[TaskGroupConfig] = field(default_factory=list)
    routing: RoutingContext = field(default_factory=RoutingContext)
    version: int = 1
    tracker_generation: int = 0
    tracker_job_id: str = ""
    tracker_scheduled_for: str = ""
    conversation_created_at: str = ""
    discovery_attempts: int = 0
    discovery_burst_until: str = ""
    created_at: str = ""
    updated_at: str = ""
    latest_started_cycle_key: str = ""
    latest_started_cycle_start: str = ""

    @property
    def template_id(self) -> str:
        return f"meeting:{self.meeting_chat_id}"

    @classmethod
    def from_dict(cls, raw: Any) -> MeetingTaskGroupTemplate:
        data = raw if isinstance(raw, dict) else {}
        return cls(
            meeting_chat_id=str(data.get("meeting_chat_id") or "")[:1000],
            meeting_url=str(data.get("meeting_url") or "")[:4000],
            subject=str(data.get("subject") or "")[:1000],
            series_master_id=str(data.get("series_master_id") or "")[:2000],
            enabled=bool(data.get("enabled", True)),
            timezone="Asia/Shanghai",
            task_groups=[
                TaskGroupConfig.from_dict(item, index=index)
                for index, item in enumerate(data.get("task_groups") or [])
                if isinstance(item, dict)
            ],
            routing=RoutingContext.from_dict(data.get("routing")),
            version=max(1, int(data.get("version") or 1)),
            tracker_generation=max(0, int(data.get("tracker_generation") or 0)),
            tracker_job_id=str(data.get("tracker_job_id") or "")[:500],
            tracker_scheduled_for=str(data.get("tracker_scheduled_for") or ""),
            conversation_created_at=str(data.get("conversation_created_at") or ""),
            discovery_attempts=max(0, int(data.get("discovery_attempts") or 0)),
            discovery_burst_until=str(data.get("discovery_burst_until") or ""),
            created_at=str(data.get("created_at") or ""),
            updated_at=str(data.get("updated_at") or ""),
            latest_started_cycle_key=str(data.get("latest_started_cycle_key") or "")[:1000],
            latest_started_cycle_start=str(data.get("latest_started_cycle_start") or ""),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class MeetingOccurrence:
    """Normalized occurrence returned by the calendar source."""

    occurrence_key: str
    chat_id: str
    event_id: str
    ical_uid: str
    subject: str
    start_at: str
    end_at: str
    original_start: str
    series_master_id: str = ""
    event_type: str = ""
    change_key: str = ""
    organizer: str = ""
    attendees: list[str] = field(default_factory=list)
    # Teams-addressable identities captured from Graph calendarView.  Keep the
    # legacy display-name fields above for prompts/UI, while preserving UPNs so
    # a scheduled task can produce real proactive mention entities later.
    mention_candidates: list[dict[str, str]] = field(default_factory=list)
    location: str = ""
    join_url: str = ""
    web_link: str = ""
    body_preview: str = ""
    is_cancelled: bool = False
    response: str = ""

    @classmethod
    def from_dict(cls, raw: Any) -> MeetingOccurrence:
        data = raw if isinstance(raw, dict) else {}
        return cls(
            occurrence_key=str(data.get("occurrence_key") or "")[:1000],
            chat_id=str(data.get("chat_id") or "")[:1000],
            event_id=str(data.get("event_id") or "")[:1000],
            ical_uid=str(data.get("ical_uid") or "")[:1000],
            subject=str(data.get("subject") or "(no subject)")[:1000],
            start_at=str(data.get("start_at") or ""),
            end_at=str(data.get("end_at") or ""),
            original_start=str(data.get("original_start") or ""),
            series_master_id=str(data.get("series_master_id") or "")[:2000],
            event_type=str(data.get("event_type") or "")[:100],
            change_key=str(data.get("change_key") or "")[:1000],
            organizer=str(data.get("organizer") or "")[:1000],
            attendees=[str(x)[:1000] for x in (data.get("attendees") or [])][:500],
            mention_candidates=[
                {
                    "name": str(item.get("name") or "")[:1000],
                    "upn": str(item.get("upn") or "")[:1000],
                    "id": str(item.get("id") or "")[:1000],
                    "type": "user",
                }
                for item in (data.get("mention_candidates") or [])
                if isinstance(item, dict) and str(item.get("name") or "").strip()
            ][:500],
            location=str(data.get("location") or "")[:2000],
            join_url=str(data.get("join_url") or "")[:4000],
            web_link=str(data.get("web_link") or "")[:4000],
            body_preview=str(data.get("body_preview") or "")[:10_000],
            is_cancelled=bool(data.get("is_cancelled", False)),
            response=str(data.get("response") or "")[:100],
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class MeetingTaskGroupInstance:
    """Durable pre/post task-group instance for one meeting occurrence."""

    instance_id: str
    template_id: str
    task_key: str
    phase: PhaseName
    meeting: MeetingOccurrence
    state: InstanceState = "scheduled"
    scheduled_for: str = ""
    scheduler_job_id: str = ""
    schedule_generation: int = 0
    retry_count: int = 0
    background_task_id: str = ""
    template_version_started: int | None = None
    created_at: str = ""
    updated_at: str = ""
    started_at: str = ""
    finished_at: str = ""
    status_reason: str = ""
    cycle_key: str = ""
    cycle_start: str = ""
    plan_session_id: str = ""
    approval_request_id: str = ""
    approval_summary: str = ""
    approval_condition: str = ""
    approval_next_step: str = ""
    approval_outcome: str = ""
    approval_resolved_by: dict[str, str] = field(default_factory=dict)
    approval_resolved_at: str = ""
    approval_reply: str = ""
    approval_rationale: str = ""
    approval_responses: list[dict[str, Any]] = field(default_factory=list)
    continuation_generation: int = 0
    task_source_revision: int = 0
    last_action: str = ""
    last_action_at: str = ""
    last_action_succeeded: bool | None = None
    pending_delivery: str = ""
    delivery_attempts: int = 0
    finish_outcome: str = ""
    finish_note: str = ""
    run_epoch: str = ""
    run_turn_id: str = ""

    @classmethod
    def from_dict(cls, raw: Any) -> MeetingTaskGroupInstance:
        data = raw if isinstance(raw, dict) else {}
        phase: PhaseName = "post" if data.get("phase") == "post" else "pre"
        raw_state = str(data.get("state") or "scheduled")
        valid_states = {
            "scheduled",
            "validating",
            "running",
            "waiting_user",
            "completed",
            "skipped",
            "failed",
            "paused",
        }
        state: InstanceState = raw_state if raw_state in valid_states else "scheduled"  # type: ignore[assignment]
        return cls(
            instance_id=str(data.get("instance_id") or "")[:1000],
            template_id=str(data.get("template_id") or "")[:1000],
            task_key=str(data.get("task_key") or "")[:100],
            phase=phase,
            meeting=MeetingOccurrence.from_dict(data.get("meeting")),
            state=state,
            scheduled_for=str(data.get("scheduled_for") or ""),
            scheduler_job_id=str(data.get("scheduler_job_id") or "")[:500],
            schedule_generation=max(0, int(data.get("schedule_generation") or 0)),
            retry_count=max(0, int(data.get("retry_count") or 0)),
            background_task_id=str(data.get("background_task_id") or "")[:100],
            template_version_started=(
                int(data["template_version_started"])
                if data.get("template_version_started") is not None
                else None
            ),
            created_at=str(data.get("created_at") or ""),
            updated_at=str(data.get("updated_at") or ""),
            started_at=str(data.get("started_at") or ""),
            finished_at=str(data.get("finished_at") or ""),
            status_reason=str(data.get("status_reason") or "")[:4000],
            cycle_key=str(data.get("cycle_key") or "")[:1000],
            cycle_start=str(data.get("cycle_start") or ""),
            plan_session_id=str(data.get("plan_session_id") or "")[:1000],
            approval_request_id=str(data.get("approval_request_id") or "")[:1000],
            approval_summary=str(data.get("approval_summary") or "")[:4000],
            approval_condition=str(data.get("approval_condition") or "")[:4000],
            approval_next_step=str(data.get("approval_next_step") or "")[:4000],
            approval_outcome=str(data.get("approval_outcome") or "")[:100],
            approval_resolved_by={
                str(k): str(v) for k, v in (data.get("approval_resolved_by") or {}).items()
            },
            approval_resolved_at=str(data.get("approval_resolved_at") or ""),
            approval_reply=str(data.get("approval_reply") or "")[:20_000],
            approval_rationale=str(data.get("approval_rationale") or "")[:4000],
            approval_responses=list(data.get("approval_responses") or []),
            continuation_generation=max(0, int(data.get("continuation_generation") or 0)),
            task_source_revision=max(0, int(data.get("task_source_revision") or 0)),
            last_action=str(data.get("last_action") or "")[:4000],
            last_action_at=str(data.get("last_action_at") or ""),
            last_action_succeeded=(
                bool(data["last_action_succeeded"])
                if data.get("last_action_succeeded") is not None
                else None
            ),
            pending_delivery=str(data.get("pending_delivery") or "")[:100_000],
            delivery_attempts=max(0, int(data.get("delivery_attempts") or 0)),
            finish_outcome=str(data.get("finish_outcome") or "")[:20],
            finish_note=str(data.get("finish_note") or "")[:4000],
            run_epoch=str(data.get("run_epoch") or "")[:100],
            run_turn_id=str(data.get("run_turn_id") or "")[:100],
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _optional_text(value: Any, limit: int) -> str | None:
    text = str(value or "").strip()
    return text[:limit] if text else None
