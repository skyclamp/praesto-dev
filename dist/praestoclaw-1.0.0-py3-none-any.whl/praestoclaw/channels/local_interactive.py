"""Local interactive adapter for the browser webchat surface."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4

from agent_gateway_protocol.agent_link.v1 import InitiatedBy, LogicalChannel

from praestoclaw.channels.turn.context import ChannelTurnEnvelope, PhysicalIngress, TurnContext


class LocalInteractiveSurface(StrEnum):
    WEBCHAT = "webchat"


_LOGICAL_CHANNEL_BY_SURFACE = {
    LocalInteractiveSurface.WEBCHAT: LogicalChannel.LOCAL_WEBCHAT.value,
}

_PHYSICAL_INGRESS_BY_SURFACE = {
    LocalInteractiveSurface.WEBCHAT: PhysicalIngress.LOCAL_WEB_PORTAL.value,
}


@dataclass(frozen=True, slots=True)
class LocalInteractiveInbound:
    connection_id: str
    message_id: str
    sender_id: str
    content: str
    conversation_id: str | None = None
    attachments: tuple[Any, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    surface: str = LocalInteractiveSurface.WEBCHAT.value


class LocalInteractiveAdapter:
    def __init__(self, surface: str | LocalInteractiveSurface) -> None:
        self.surface = LocalInteractiveSurface(surface)
        self.logical_channel = _LOGICAL_CHANNEL_BY_SURFACE[self.surface]
        self.physical_ingress = _PHYSICAL_INGRESS_BY_SURFACE[self.surface]

    async def ingest(self, raw_event: object) -> ChannelTurnEnvelope:
        if not isinstance(raw_event, LocalInteractiveInbound):
            raise TypeError("LocalInteractiveAdapter expects LocalInteractiveInbound")

        event_surface = LocalInteractiveSurface(raw_event.surface)
        if event_surface is not self.surface:
            raise ValueError(
                f"LocalInteractiveAdapter({self.surface.value}) cannot ingest "
                f"{event_surface.value} events"
            )

        metadata = {
            "connection_id": raw_event.connection_id,
            "message_id": raw_event.message_id,
            "surface": self.surface.value,
            "supports_streaming": False,
            "supports_cards": False,
            **raw_event.metadata,
            "initiated_by": InitiatedBy.HUMAN.value,
            "source_scope": "local",
            "requires_human_visibility": False,
        }

        return ChannelTurnEnvelope(
            trace_id=str(uuid4()),
            physical_ingress=self.physical_ingress,
            logical_channel=self.logical_channel,
            content=raw_event.content,
            sender_id=raw_event.sender_id,
            conversation_id=raw_event.conversation_id or raw_event.connection_id,
            received_at=datetime.now(UTC).isoformat(),
            attachments=raw_event.attachments,
            raw_event=raw_event,
            metadata=metadata,
        )


@dataclass(slots=True)
class InMemoryLocalInteractiveDelivery:
    sent: list[tuple[object, TurnContext]] = field(default_factory=list)

    async def deliver(self, reply: object, context: TurnContext) -> None:
        self.sent.append((reply, context))


class LocalWebChatAdapter(LocalInteractiveAdapter):
    def __init__(self) -> None:
        super().__init__(LocalInteractiveSurface.WEBCHAT)


LocalWebChatInbound = LocalInteractiveInbound
InMemoryLocalWebChatDelivery = InMemoryLocalInteractiveDelivery
