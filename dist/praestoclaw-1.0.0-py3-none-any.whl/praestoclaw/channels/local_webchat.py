"""Compatibility exports for the shared local interactive adapter."""

from __future__ import annotations

from praestoclaw.channels.local_interactive import (
    InMemoryLocalWebChatDelivery,
    LocalWebChatAdapter,
    LocalWebChatInbound,
)

__all__ = [
    "InMemoryLocalWebChatDelivery",
    "LocalWebChatAdapter",
    "LocalWebChatInbound",
]
