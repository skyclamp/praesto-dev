"""Megaphone persistent state — deduplication across monitoring runs.

Stores independent state files under
``~/.praestoclaw/skills/megaphone/state/`` so Teams and email scans do not
overwrite each other's watermarks when they run at the same time.
"""

from __future__ import annotations

import json
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from loguru import logger

from praestoclaw.utils.helpers import get_data_dir

# ── Constants ─────────────────────────────────────────────────────────────────

MAX_SEEN_IDS: int = 500  # rolling window for email message IDs
DEFAULT_LOOKBACK_HOURS: int = 24  # fallback lookback for first run or stale state
STATE_DIR_NAME = "state"
TEAMS_STATE_FILENAME = "teams.json"
EMAIL_STATE_FILENAME = "email.json"
IDENTITY_STATE_FILENAME = "identity.json"


# ── Helpers ───────────────────────────────────────────────────────────────────


def _now_iso() -> str:
    """Return current UTC time as ISO-8601 string."""
    return datetime.now(UTC).isoformat()


def _parse_iso_datetime(value: Any) -> datetime | None:
    """Parse an ISO datetime string, normalizing naive values to UTC."""
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def _checked_today(value: Any) -> bool:
    """Return true when *value* is an ISO timestamp from the current UTC day."""
    dt = _parse_iso_datetime(value)
    return bool(dt and dt.astimezone(UTC).date() == datetime.now(UTC).date())


def _default_data() -> dict[str, Any]:
    """Return a fresh empty state structure."""
    return {
        "teams": {},
        "teams_id_cache": {},  # name → {"team_id": ..., "channel_id": ...}
        "user_identity": None,  # permanent cache for current-user mention/direct checks
        "email": {"last_checked": None, "seen_ids": []},
    }


def _default_teams_state() -> dict[str, Any]:
    """Return the on-disk Teams state shape."""
    return {"watermarks": {}, "id_cache": {}}


def _default_email_state() -> dict[str, Any]:
    """Return the on-disk email state shape."""
    return {"last_checked": None, "seen_ids": []}


# ── State Manager ─────────────────────────────────────────────────────────────


class MegaphoneState:
    """Persistent state for megaphone deduplication.

    Tracks:
    * **Teams** — per-channel watermark (``last_message_id``).
    * **Email** — rolling window of seen message IDs.
    """

    def __init__(self, state_dir: Path | None = None) -> None:
        self._state_dir: Path = state_dir or (
            get_data_dir() / "skills" / "megaphone" / STATE_DIR_NAME
        )
        self._teams_path = self._state_dir / TEAMS_STATE_FILENAME
        self._email_path = self._state_dir / EMAIL_STATE_FILENAME
        self._identity_path = self._state_dir / IDENTITY_STATE_FILENAME
        self._data: dict[str, Any] = _default_data()
        self._load()

    # ── Persistence ───────────────────────────────────────────────────────

    def _load(self) -> None:
        """Read split state files from disk. Missing files start empty."""
        teams_state = self._read_state_file(self._teams_path, _default_teams_state())
        if isinstance(teams_state.get("watermarks"), dict):
            self._data["teams"] = teams_state["watermarks"]
        if isinstance(teams_state.get("id_cache"), dict):
            self._data["teams_id_cache"] = teams_state["id_cache"]

        email_state = self._read_state_file(self._email_path, _default_email_state())
        self._data["email"] = {
            "last_checked": email_state.get("last_checked"),
            "seen_ids": email_state.get("seen_ids")
            if isinstance(email_state.get("seen_ids"), list)
            else [],
        }

        identity = self._read_identity_file()
        if isinstance(identity, dict):
            self._data["user_identity"] = identity

    def _read_state_file(self, path: Path, default: dict[str, Any]) -> dict[str, Any]:
        """Read a JSON object from *path*, returning *default* when absent or invalid."""
        if not path.exists():
            logger.debug("megaphone state file not found; starting fresh: {}", path)
            return deepcopy(default)
        try:
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError("top-level value is not a dict")
            logger.debug("megaphone state loaded from {}", path)
            merged = deepcopy(default)
            merged.update(data)
            return merged
        except Exception as exc:
            logger.warning("failed to load megaphone state from {}: {}", path, exc)
            return deepcopy(default)

    def _read_identity_file(self) -> dict[str, Any] | None:
        """Read the identity cache file."""
        if not self._identity_path.exists():
            logger.debug("megaphone state file not found; starting fresh: {}", self._identity_path)
            return None
        try:
            data = json.loads(self._identity_path.read_text(encoding="utf-8"))
            if data is None:
                return None
            if not isinstance(data, dict):
                raise ValueError("top-level value is not an object or null")
            logger.debug("megaphone state loaded from {}", self._identity_path)
            return data
        except Exception as exc:
            logger.warning("failed to load megaphone state from {}: {}", self._identity_path, exc)
            return None

    def save(self) -> None:
        """Persist all split state files."""
        self.save_teams()
        self.save_email()
        self.save_identity()

    def save_teams(self) -> None:
        """Persist Teams watermarks and Teams ID cache."""
        self._write_state_file(
            self._teams_path,
            {
                "watermarks": self._data["teams"],
                "id_cache": self._data["teams_id_cache"],
            },
        )

    def save_email(self) -> None:
        """Persist email watermarks and seen IDs."""
        self._write_state_file(self._email_path, self._data["email"])

    def save_identity(self) -> None:
        """Persist the current-user identity cache."""
        self._write_state_file(self._identity_path, self._data["user_identity"])

    def _write_state_file(self, path: Path, payload: Any) -> None:
        """Atomically write one state file."""
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.tmp")
        try:
            tmp.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
            tmp.replace(path)
            logger.debug("megaphone state saved to {}", path)
        except Exception as exc:
            logger.error("failed to save megaphone state to {}: {}", path, exc)
            raise

    # ── Time Window ─────────────────────────────────────────────────────

    def effective_since(
        self, source: str, lookback_hours: int = DEFAULT_LOOKBACK_HOURS
    ) -> datetime:
        """Return the effective 'since' cutoff for *source*.

        Logic:
        - If last_checked exists and is within *lookback_hours*: return last_checked.
        - Otherwise (first run or stale): return now - lookback_hours.

        *source* is one of 'teams', 'email'.
        For 'teams', pass the channel_id to get per-channel granularity.
        """
        now = datetime.now(UTC)
        max_lookback = now - timedelta(hours=lookback_hours)

        last = self._source_last_checked(source)
        if last is None:
            logger.info("megaphone {}: no last_checked, using lookback={}h", source, lookback_hours)
            return max_lookback
        if last < max_lookback:
            logger.info(
                "megaphone {}: last_checked {} is older than {}h, capping to lookback",
                source,
                last.isoformat(),
                lookback_hours,
            )
            return max_lookback
        return last

    def effective_since_teams(
        self, channel_id: str, lookback_hours: int = DEFAULT_LOOKBACK_HOURS
    ) -> datetime:
        """Return effective 'since' cutoff for a specific Teams channel."""
        now = datetime.now(UTC)
        max_lookback = now - timedelta(hours=lookback_hours)

        entry = self._data["teams"].get(channel_id)
        if entry is None:
            return max_lookback
        raw = entry.get("last_checked")
        if raw is None:
            return max_lookback
        try:
            last = datetime.fromisoformat(raw)
            if last.tzinfo is None:
                last = last.replace(tzinfo=UTC)
        except (ValueError, TypeError):
            return max_lookback
        return last if last >= max_lookback else max_lookback

    def _source_last_checked(self, source: str) -> datetime | None:
        """Parse last_checked timestamp for a top-level source."""
        bucket = self._data.get(source)
        if bucket is None:
            return None

        # email has top-level last_checked
        raw: str | None = None
        if isinstance(bucket, dict) and "last_checked" in bucket:
            raw = bucket["last_checked"]

        if raw is None:
            return None
        try:
            dt = datetime.fromisoformat(raw)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt
        except (ValueError, TypeError):
            return None

    def effective_since_iso(self, source: str, lookback_hours: int = DEFAULT_LOOKBACK_HOURS) -> str:
        """Convenience: return effective_since as ISO-8601 string (for use in API queries)."""
        return self.effective_since(source, lookback_hours).isoformat()

    def effective_since_teams_iso(
        self, channel_id: str, lookback_hours: int = DEFAULT_LOOKBACK_HOURS
    ) -> str:
        """Convenience: return effective_since for a Teams channel as ISO-8601 string."""
        return self.effective_since_teams(channel_id, lookback_hours).isoformat()

    # ── Teams ID Cache ─────────────────────────────────────────────────────

    def get_teams_ids(self, channel_name: str) -> dict[str, str] | None:
        """Return cached Teams IDs for *channel_name*, omitting unset keys."""
        result = self._data["teams_id_cache"].get(channel_name)
        if not isinstance(result, dict):
            return None
        return {
            key: str(result[key])
            for key in ("team_id", "channel_id")
            if result.get(key) is not None
        }

    def set_teams_ids(self, channel_name: str, team_id: str | None, channel_id: str) -> None:
        """Cache resolved Teams IDs for *channel_name*."""
        self._data["teams_id_cache"][channel_name] = {
            "team_id": team_id,
            "channel_id": channel_id,
            "checked_at": _now_iso(),
        }

    def teams_ids_refresh_due(self, channel_name: str) -> bool:
        """Return true when cached Teams IDs are missing or have not been checked today."""
        entry = self._data["teams_id_cache"].get(channel_name)
        if not isinstance(entry, dict):
            return True
        return not _checked_today(entry.get("checked_at"))

    def mark_teams_ids_checked(self, channel_name: str) -> None:
        """Record a daily Teams ID check attempt while preserving cached IDs."""
        entry = self._data["teams_id_cache"].get(channel_name)
        if isinstance(entry, dict):
            entry["checked_at"] = _now_iso()

    def invalidate_teams_ids(self, channel_name: str) -> bool:
        """Remove cached Teams IDs for *channel_name*, forcing re-resolution on next scan.

        Returns ``True`` if a cache entry was actually removed, ``False`` if none existed.
        """
        sentinel = object()
        removed = self._data["teams_id_cache"].pop(channel_name, sentinel) is not sentinel
        if removed:
            logger.info("megaphone: invalidated Teams ID cache for {!r}", channel_name)
        return removed

    # ── User Identity Cache ───────────────────────────────────────────────

    def get_user_identity(self) -> dict[str, str] | None:
        """Return cached current-user identity for mention/direct checks, if available."""
        identity = self._data.get("user_identity")
        if not isinstance(identity, dict):
            return None
        allowed = {"id", "mail", "userPrincipalName", "displayName"}
        result = {
            str(k): str(v) for k, v in identity.items() if k in allowed and v is not None and str(v)
        }
        return result or None

    def set_user_identity(self, identity: dict[str, Any]) -> None:
        """Permanently cache current-user identity fields returned by GetMyDetails."""
        allowed = {"id", "mail", "userPrincipalName", "displayName"}
        cleaned = {key: str(identity[key]) for key in allowed if identity.get(key)}
        if cleaned:
            cleaned["checked_at"] = _now_iso()
        self._data["user_identity"] = cleaned or None

    def user_identity_refresh_due(self) -> bool:
        """Return true when user identity is missing or has not been checked today."""
        identity = self._data.get("user_identity")
        if not isinstance(identity, dict):
            return True
        return not _checked_today(identity.get("checked_at"))

    def mark_user_identity_checked(self) -> None:
        """Record a daily identity check attempt while preserving cached identity."""
        identity = self._data.get("user_identity")
        if isinstance(identity, dict):
            identity["checked_at"] = _now_iso()

    # ── Teams ─────────────────────────────────────────────────────────────

    def teams_watermark(self, channel_id: str) -> str | None:
        """Return the last-seen message ID for *channel_id*, or ``None``."""
        entry = self._data["teams"].get(channel_id)
        if entry is None:
            return None
        last_id = entry.get("last_message_id")
        return None if last_id is None else str(last_id)

    def update_teams(self, channel_id: str, last_message_id: str) -> None:
        """Record the newest message ID for *channel_id*."""
        self._data["teams"][channel_id] = {
            "last_checked": _now_iso(),
            "last_message_id": last_message_id,
        }

    # ── Email ─────────────────────────────────────────────────────────────

    def is_email_seen(self, msg_id: str) -> bool:
        """Return ``True`` if *msg_id* is in the seen-IDs rolling window."""
        return msg_id in self._data["email"].get("seen_ids", [])

    def mark_emails_seen(self, msg_ids: list[str]) -> None:
        """Append *msg_ids* to the rolling window, trimming to :data:`MAX_SEEN_IDS`."""
        if not msg_ids:
            return
        seen: list[str] = self._data["email"].get("seen_ids", [])
        seen.extend(msg_ids)
        # Keep only the most recent entries.
        self._data["email"]["seen_ids"] = seen[-MAX_SEEN_IDS:]
        self._data["email"]["last_checked"] = _now_iso()

    def unseen_emails(self, msg_ids: list[str]) -> list[str]:
        """Return only those *msg_ids* **not** yet in the seen window."""
        seen_set = set(self._data["email"].get("seen_ids", []))
        return [mid for mid in msg_ids if mid not in seen_set]

    # ── Utility ───────────────────────────────────────────────────────────

    def reset(self) -> None:
        """Clear all in-memory state (call :meth:`save` to persist)."""
        self._data = _default_data()
        logger.info("megaphone state reset")
