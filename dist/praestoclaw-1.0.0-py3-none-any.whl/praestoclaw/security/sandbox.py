"""
Sandbox — enforces workspace boundaries and command restrictions.

Enterprise safety layer that prevents:
- Path traversal outside workspace
- Dangerous shell commands (rm -rf /, fork bombs, etc.)
- Access to sensitive system paths
"""

from __future__ import annotations

import os
import re
import sys
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Literal, NamedTuple, cast

from loguru import logger
from os_sandbox import (
    NoopSandbox,
    OsSandbox,
    SandboxSpec,
    is_likely_sandbox_denied,
    select_sandbox,
)
from os_sandbox.backends.bwrap import is_wsl1

from praestoclaw.config.schema import OsSandboxConfig, SecurityProfile, ShellConfig

# Env var that force-disables OS sandbox regardless of config. Rescue valve
# for the case where the sandbox itself is what's preventing the client from
# starting — users don't need to edit YAML to recover.
_DISABLE_ENV_VAR = "PRAESTOCLAW_OS_SANDBOX_DISABLE"


def _no_backend_hint(platform: str) -> str:
    """Platform-specific remediation hint for "sandbox enabled but no kernel
    backend" — shown alongside the WARNING so users know what to actually
    change instead of decoding "no backend on platform 'win32'".

    Three real cases today:

    - **Windows native (PowerShell/cmd)**: the native backend is a v2
      follow-up; running PraestoClaw inside WSL2 is the supported path
      (WSL2 reports ``sys.platform == 'linux'`` so the bwrap backend is
      picked automatically).
    - **WSL1**: the kernel has no user-namespace support, so bwrap cannot
      sandbox; users need WSL2.
    - **Native Linux without bwrap**: the binary is just missing.
    """
    if platform == "win32":
        return (
            "Native Windows sandbox is not yet implemented; "
            "run PraestoClaw inside WSL2 to enable sandboxing."
        )
    if platform.startswith("linux") and is_wsl1():
        return "WSL1 has no user namespaces; upgrade to WSL2 to enable PraestoClaw sandboxing."
    if platform.startswith("linux"):
        return "Install bubblewrap (`apt install bubblewrap`) to enable sandboxing."
    return ""


SandboxState = Literal["active", "inactive", "disabled", "danger"]


class SandboxStartupStatus(NamedTuple):
    """Structured snapshot of the OS sandbox state at runtime startup.

    CLI banners and ``praestoclaw status`` both consume this; keeping the
    fields plain strings means the renderer can choose its own palette
    without the sandbox layer pulling in ``rich`` as a dependency.

    Fields:
        state: One of ``active`` (kernel wrapping in effect), ``inactive``
            (user wanted it but platform can't deliver — actionable),
            ``disabled`` (config says off — silent in normal UX),
            ``danger`` (``danger_full_access`` mode — should be loud).
        summary: One-line headline ("workspace_write on bwrap",
            "INACTIVE on win32", ...).
        hint: Platform-specific remediation pointer; empty when irrelevant.
    """

    state: SandboxState
    summary: str
    hint: str


# ── Profile-linked defaults ──────────────────────────────────────────────────

_PROFILE_DEFAULTS: dict[str, dict[str, list[str]]] = {
    "open": {
        "allowed_paths": ["*"],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.gnupg",
        ],
    },
    "standard": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
        ],
    },
    "controlled": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
            "~/.config",
            "~/.local",
        ],
    },
    "restricted": {
        "allowed_paths": [],
        "denied_paths": [
            "/etc/shadow",
            "/etc/passwd",
            "~/.ssh",
            "~/.gnupg",
            "~/.aws/credentials",
            "~/.config",
            "~/.local",
        ],
    },
}


class CommandDeniedError(Exception):
    """Raised when a shell command is blocked by security rules."""


class PathDeniedError(Exception):
    """Raised when a file path is blocked by security rules."""


class Sandbox:
    """Workspace-scoped sandbox for file and command operations."""

    def __init__(
        self,
        workspace: Path,
        *,
        shell_config: ShellConfig | None = None,
        profile: SecurityProfile = SecurityProfile.STANDARD,
        allowed_paths: list[str] | None = None,
        denied_paths: list[str] | None = None,
        os_sandbox_config: OsSandboxConfig | None = None,
    ) -> None:
        self._workspace = workspace.resolve()

        # Shell command rules
        shell = shell_config or ShellConfig()
        self._shell = shell
        self._deny_re = [re.compile(p, re.IGNORECASE) for p in shell.deny_patterns]
        self._allow_re = [re.compile(p, re.IGNORECASE) for p in shell.allow_patterns]

        # Path rules — merge profile defaults ∪ user config
        defaults = _PROFILE_DEFAULTS.get(profile.value, _PROFILE_DEFAULTS["standard"])

        effective_allowed = set(defaults["allowed_paths"]) | set(allowed_paths or [])
        effective_denied = set(defaults["denied_paths"]) | set(denied_paths or [])

        self._unrestricted = "*" in effective_allowed
        self._allowed = [Path(p).expanduser().resolve() for p in effective_allowed if p != "*"]
        self._denied = [Path(p).expanduser().resolve() for p in effective_denied]

        # Snapshot profile defaults for set_allowed_paths() reset
        self._profile_allowed_defaults = frozenset(defaults["allowed_paths"])

        # OS-level sandbox wrapper (Seatbelt / bwrap / Windows Sandbox).
        # Off by default — preserves legacy "Python policy layer only" behaviour.
        self._os_sandbox_config = os_sandbox_config or OsSandboxConfig()
        self._rebuild_os_sandbox()

    # ── Command sandbox ──────────────────────────────────────────────────

    def match_deny_pattern(self, command: str) -> str | None:
        """Return the first matching deny pattern, or None if no match."""
        for pattern in self._deny_re:
            if pattern.search(command):
                return pattern.pattern
        return None

    def check_command(self, command: str) -> None:
        """Raise CommandDeniedError if the command matches a deny pattern."""
        matched = self.match_deny_pattern(command)
        if matched:
            logger.warning(f"Command blocked by deny pattern: {command!r}")
            raise CommandDeniedError(f"Command blocked by security policy (matched: {matched})")

        # If allow patterns are set, command must match at least one
        if self._allow_re:
            if not any(p.search(command) for p in self._allow_re):
                raise CommandDeniedError("Command not in allow list")

    # ── File sandbox ─────────────────────────────────────────────────────

    def resolve_path(self, path: str | Path) -> Path:
        """Resolve a path, enforcing denied_paths and workspace/allowed_paths fence.

        Check priority:
        1. denied_paths — highest priority, hard block
        2. ``"*"`` in allowed_paths — unrestricted mode, allow
        3. within workspace — primary fence
        4. within allowed_paths — explicit exceptions
        5. PathDeniedError
        """
        resolved = (self._workspace / Path(path).expanduser()).resolve()

        # 1. Deny list — highest priority
        if self.is_path_denied(resolved):
            raise PathDeniedError(f"Access denied to protected path: {path}")

        # 2. Unrestricted mode ("*")
        if self._unrestricted:
            return resolved

        # 3-4. Workspace + allowed paths fence
        if self._is_within(resolved, self._workspace):
            return resolved
        if any(self._is_within(resolved, p) for p in self._allowed):
            return resolved

        raise PathDeniedError(
            f"Path escapes workspace and is not in an allowed directory: {path} -> {resolved}"
        )

    def is_path_denied(self, resolved: Path) -> bool:
        """Check if a resolved path matches any entry in the deny list."""
        for deny_path in self._denied:
            if self._is_within(resolved, deny_path) or resolved == deny_path:
                return True
        return False

    # ── Dynamic operations ───────────────────────────────────────────────

    def switch_workspace(self, new_workspace: Path) -> None:
        """Switch workspace root. Safe because tool calls are sequential."""
        self._workspace = new_workspace.resolve()
        # No need to rebuild the OS backend — it's stateless. ``_build_spec``
        # already reads ``self._workspace`` on every ``wrap_argv`` call.

    def set_allowed_paths(self, paths: list[str] | None) -> None:
        """Replace allowed paths, merging with profile defaults.

        If *paths* is ``None``, revert to profile defaults only.
        Otherwise, compute profile defaults ∪ paths (same as __init__).
        """
        effective = set(self._profile_allowed_defaults) | set(paths or [])
        self._unrestricted = "*" in effective
        self._allowed = [Path(p).expanduser().resolve() for p in effective if p != "*"]

    def add_allowed_path(self, path: Path) -> None:
        """Add a path to the allowed list at runtime."""
        resolved = path.expanduser().resolve()
        if resolved not in self._allowed:
            self._allowed.append(resolved)

    def remove_allowed_path(self, path: Path) -> None:
        """Remove a path from the runtime allowed list."""
        resolved = path.expanduser().resolve()
        self._allowed = [p for p in self._allowed if p != resolved]

    def read_scoped_copy(self, extra_read_root: str | Path) -> Sandbox:
        """Return a copy that also admits paths under one extra root.

        For handing a sub-agent read access to a directory the parent fence
        excludes — a task repository outside the workspace, say — **without
        moving the fence for anything else**. The runtime's sandbox is a
        singleton shared by every tool in every session, so widening it (via
        ``set_allowed_paths``) grants the path to all of them, persists into the
        user's config, and stays granted if the run dies before restoring it.

        The copy is independent: it carries its own allowed-path list, so a
        later ``add_allowed_path`` on either side does not reach the other.
        ``denied_paths`` still wins — this cannot be used to reach a protected
        directory, and a root that is itself denied is refused outright.

        Read-only is a property of who gets the copy, not of the copy: hand it
        to read tools only. Nothing here stops a write tool from using it.
        """
        import copy as _copy

        # Validate the argument, not the Path built from it: `Path("")` is
        # `Path(".")`, whose str() is "." — non-empty, and it resolves to the
        # working directory. An empty string would have granted the child
        # whatever directory the process happens to be running in.
        if not str(extra_read_root).strip():
            raise ValueError("extra_read_root must not be empty")

        root = Path(extra_read_root).expanduser()
        # Refuse a relative path rather than choosing a base for it. `.resolve()`
        # would silently use the process working directory, which has nothing to
        # do with the run — and resolving against the workspace instead is the
        # one base that is almost certainly wrong here, since the whole premise
        # of this grant is that the task repository sits OUTSIDE the workspace.
        # Every other use of this path is `cd -- '<repo_path>'`, so it is
        # absolute by contract; a relative one is a caller bug and says so.
        if not root.is_absolute():
            raise ValueError(f"extra_read_root must be absolute: {extra_read_root}")

        resolved = root.resolve()

        # A root that does not exist grants nothing, and would do it silently —
        # the caller would get an audit that read no files and no reason why.
        if not resolved.is_dir():
            raise ValueError(f"extra_read_root is not a directory: {resolved}")

        if self.is_path_denied(resolved):
            raise PathDeniedError(f"extra_read_root is a protected path: {resolved}")

        # "Scoped" has to mean something. A filesystem root or the home
        # directory admits everything the fence exists to exclude. The root test
        # is `parent == self` rather than a comparison against "/", so it holds
        # for a Windows drive root (``D:\\``) as well — those are exactly as
        # broad, and naming only the POSIX one would have let them through.
        if resolved.parent == resolved or resolved == Path.home().resolve():
            raise ValueError(f"extra_read_root is too broad to be a scope: {resolved}")

        # And it has to be a repository. `/etc`, `/usr`, `C:\\Windows` are not
        # roots and not home, so the checks above admit every one of them — but
        # this grant exists for exactly one thing, reading the task repository a
        # run is already working in. Requiring the marker states that directly
        # instead of maintaining a blocklist of system directories, which would
        # be endless, platform-specific, and wrong the first time a new one
        # appeared. It also catches the ordinary case: a mistyped path.
        if not (resolved / ".git").exists():
            raise ValueError(f"extra_read_root is not a repository (no .git): {resolved}")

        scoped = _copy.copy(self)
        scoped._allowed = [*self._allowed, resolved]
        return scoped

    # ── OS-level sandbox wrapping ────────────────────────────────────────

    # On macOS, workspace_write mode also opens up the standard temp dirs so
    # tools like ``mktemp``, compilers, and package installers Just Work.
    # bwrap mounts a fresh tmpfs on /tmp itself, so this list is macOS-only.
    _MACOS_TMP_PATHS: tuple[Path, ...] = (
        Path("/tmp"),
        Path("/private/tmp"),
        Path("/var/tmp"),
        Path("/private/var/tmp"),
    )

    def _rebuild_os_sandbox(self) -> None:
        """Resolve the OS sandbox backend from current config.

        Resolution order, with explicit reasons logged for each downgrade:

        1. Env var ``PRAESTOCLAW_OS_SANDBOX_DISABLE=1`` → force disabled.
        2. ``enabled=False`` (default) → disabled, no log noise.
        3. ``mode == danger_full_access`` → disabled, audit-visible.
        4. Platform without a real backend (e.g. Windows today, or Linux
           without ``bwrap``) → disabled with a loud WARNING so the user
           doesn't believe a sandbox is in effect when it isn't.
        5. Otherwise → real backend, INFO banner with mode/backend/network.

        Only called from ``__init__``; backend is stateless after that.
        """
        cfg = self._os_sandbox_config

        if os.environ.get(_DISABLE_ENV_VAR) == "1":
            logger.warning(
                "[Sandbox] disabled via {}=1 (overrides config enabled={}, mode={})",
                _DISABLE_ENV_VAR,
                cfg.enabled,
                cfg.mode,
            )
            self._os_sandbox: OsSandbox = NoopSandbox()
            self._os_active = False
            return

        if not cfg.enabled:
            self._os_sandbox = NoopSandbox()
            self._os_active = False
            return

        if cfg.mode == "danger_full_access":
            logger.info("[Sandbox] enabled with mode=danger_full_access — no kernel wrapping")
            self._os_sandbox = NoopSandbox()
            self._os_active = False
            return

        backend = select_sandbox()
        if isinstance(backend, NoopSandbox):
            # The platform doesn't have a working backend (Windows native,
            # WSL1, or Linux without bwrap). The user asked for protection
            # we can't deliver — surface that loudly with a platform-specific
            # remediation hint rather than a generic "no backend" line.
            hint = _no_backend_hint(sys.platform)
            logger.warning(
                "[Sandbox] enabled=True mode={} requested, but no kernel backend "
                "available on platform {!r}. Sandbox is INACTIVE. {} "
                "Set {}=1 to silence this once acknowledged.",
                cfg.mode,
                sys.platform,
                hint,
                _DISABLE_ENV_VAR,
            )
            self._os_sandbox = backend
            self._os_active = False
            return

        self._os_sandbox = backend
        self._os_active = True
        logger.info(
            "[Sandbox] ENABLED: backend={} mode={} workspace={} writable_roots={} network={}",
            backend.name,
            cfg.mode,
            self._workspace,
            cfg.writable_roots or [],
            "allowed" if cfg.allow_network else "denied",
        )

    def _build_spec(self, extra_writable: tuple[Path, ...] = ()) -> SandboxSpec:
        """Translate the praestoclaw config + workspace into a :class:`SandboxSpec`.

        Only called when the sandbox is actually active; ``mode`` is one of
        ``read_only`` / ``workspace_write`` at this point.

        Writable set in ``workspace_write`` (matches codex's
        ``get_writable_roots_with_cwd``):

        - the workspace itself
        - explicit ``writable_roots`` from config — ``~`` is expanded;
          relative paths are resolved against the workspace (the closest
          thing we have to a meaningful base) and a warning is logged
        - per-call ``extra_writable`` (e.g. ShellTool passes the command's
          cwd when it lives inside the workspace)
        - ``$TMPDIR`` — covers macOS ``/var/folders/...`` where
          ``tempfile.gettempdir()`` actually lives. Skipped if non-absolute.
        - ``/tmp`` — added on both Linux and macOS so bwrap can mount a
          fresh tmpfs there and macOS Seatbelt can allow writes.
        - macOS only: the additional ``/private/tmp`` / ``/var/tmp`` aliases.

        Duplicates are removed in :class:`SandboxSpec.__post_init__` (which
        resolves each path), so dedup here is best-effort only.
        """
        cfg = self._os_sandbox_config
        writable: list[Path] = []

        if cfg.mode == "workspace_write":
            writable.append(self._workspace)
            for raw in cfg.writable_roots:
                resolved = self._normalize_writable_root(raw)
                if resolved is not None:
                    writable.append(resolved)
            writable.extend(extra_writable)
            tmpdir = os.environ.get("TMPDIR")
            if tmpdir and Path(tmpdir).is_absolute():
                writable.append(Path(tmpdir))
            # /tmp on every platform that has it. bwrap will mount tmpfs;
            # Seatbelt will simply allow file-write* there.
            writable.append(Path("/tmp"))
            if sys.platform == "darwin":
                writable.extend(self._MACOS_TMP_PATHS)
        # read_only: keep writable empty even if extra_writable was passed;
        # the caller asked for read-only, so honor it.

        return SandboxSpec(
            writable_paths=tuple(writable),
            allow_network=cfg.allow_network,
        )

    @staticmethod
    def _normalize_writable_root(raw: str) -> Path | None:
        """Expand ``~`` and reject non-absolute writable_roots.

        Returning ``None`` (with a warning) is safer than silently
        resolving against CWD, which could secretly widen the writable
        set to arbitrary unrelated directories.
        """
        expanded = Path(raw).expanduser()
        if not expanded.is_absolute():
            logger.warning(
                "[Sandbox] writable_roots entry {!r} is not an absolute path "
                "after expanduser; ignoring",
                raw,
            )
            return None
        return expanded

    def wrap_argv(
        self,
        argv: list[str],
        *,
        cwd: Path,
        env: Mapping[str, str],
        extra_writable: Iterable[Path] = (),
    ) -> tuple[list[str], dict[str, str]]:
        """Wrap ``argv`` with the OS sandbox if one is active.

        ``extra_writable`` lets the caller widen the writable set for this
        one call (e.g. add ``cwd`` when it lives outside the workspace).
        Returns ``(new_argv, new_env)``; safe to pass straight to
        :func:`asyncio.create_subprocess_exec`.

        Cheap passthrough when the sandbox is disabled — we short-circuit
        before building the spec so there's zero allocation overhead on the
        legacy path.
        """
        if not self._os_active:
            return list(argv), dict(env)
        spec = self._build_spec(tuple(extra_writable))
        result = self._os_sandbox.wrap(argv, cwd=cwd, env=env, spec=spec)
        return cast("tuple[list[str], dict[str, str]]", result)

    @staticmethod
    def is_sandbox_denied_output(stderr: str, exit_code: int | None) -> bool:
        """Heuristic: did this subprocess fail because the OS sandbox denied it?

        Re-exported from ``os_sandbox`` so call sites (ShellTool, GitTool)
        don't need to import the platform package directly.
        """
        return cast("bool", is_likely_sandbox_denied(stderr, exit_code))

    @property
    def os_sandbox_active(self) -> bool:
        """True when an OS-level wrapper is being applied (not noop)."""
        return self._os_active

    @property
    def os_sandbox_mode(self) -> str:
        return self._os_sandbox_config.mode

    @property
    def startup_status(self) -> SandboxStartupStatus:
        """Snapshot for startup banners / status commands.

        The CLI renders this once after Runtime init so users see whether
        the kernel sandbox is actually in effect — the loguru WARNING in
        ``_rebuild_os_sandbox`` is easy to miss in mixed log output.

        State decision table (matches ``_rebuild_os_sandbox`` order):

        - env-disable or ``enabled=False`` → ``disabled`` (silent in UX)
        - ``danger_full_access`` → ``danger`` (loud — user opted out of
          kernel protection)
        - ``_os_active`` → ``active`` (real backend in use)
        - else → ``inactive`` (user asked for it, platform can't deliver;
          ``hint`` points at the fix)
        """
        cfg = self._os_sandbox_config
        if os.environ.get(_DISABLE_ENV_VAR) == "1" or not cfg.enabled:
            return SandboxStartupStatus(
                state="disabled",
                summary=(
                    "Kernel-level sandbox is off — shell/git run with normal "
                    "process privileges (Python policy layer is still active)."
                ),
                hint="",
            )
        if cfg.mode == "danger_full_access":
            return SandboxStartupStatus(
                state="danger",
                summary="DANGER: kernel sandbox disabled (mode=danger_full_access)",
                hint="Switch mode to workspace_write or read_only to re-enable.",
            )
        if self._os_active:
            return SandboxStartupStatus(
                state="active",
                summary=f"{cfg.mode} on {self._os_sandbox.name}",
                hint="",
            )
        return SandboxStartupStatus(
            state="inactive",
            summary=f"INACTIVE on platform {sys.platform!r} (mode={cfg.mode})",
            hint=_no_backend_hint(sys.platform),
        )

    # ── Properties ───────────────────────────────────────────────────────

    @property
    def workspace(self) -> Path:
        return self._workspace

    @property
    def shell_timeout(self) -> int:
        return self._shell.timeout

    @staticmethod
    def _is_within(child: Path, parent: Path) -> bool:
        """Check if child path is within parent directory."""
        try:
            child.relative_to(parent)
            return True
        except ValueError:
            return False
