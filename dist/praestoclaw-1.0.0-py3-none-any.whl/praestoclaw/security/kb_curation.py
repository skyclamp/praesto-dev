"""Capability gate for knowledge-base curation tools.

KB curation is used from two different security contexts:

* ``praesto_tag_exp`` group turns, where the agent is acting in a borrowed-
  identity experiment and the group is allowed to use only a small built-in
  surface.
* Teams personal chats, where the profile owner is talking to their own agent.

Both contexts still rely on the same KB safety boundaries: configured repository
allowlists, proposal fingerprints, and explicit publish approval.
"""

from __future__ import annotations

from typing import Any

PRAESTO_KB_CURATION_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
    }
)


def kb_curation_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether KB curation tools may operate in this conversation."""
    data = metadata or {}
    if data.get("praesto_tag_exp"):
        return True
    ctype = str(data.get("ctype") or data.get("teams_conversation_type") or "").strip().lower()
    cid = str(data.get("cid") or "").strip()
    return bool(cid and ctype == "personal")
