"""Capability gate for knowledge-base curation tools.

KB curation is used from two different security contexts:

* ``praesto_tag_exp`` group turns, where the agent is acting in a borrowed-
  identity experiment and the group is allowed to use only a small built-in
  surface.
* Teams personal chats, where the profile owner is talking to their own agent.

Both contexts still rely on the same KB safety boundaries: configured repository
allowlists, proposal fingerprints, and explicit publish approval.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from threading import RLock
from typing import Any

PRAESTO_KB_CURATION_BUILTIN_TOOLS: frozenset[str] = frozenset(
    {
        "kb_change_history",
        "kb_draft",
        "kb_inspect",
        "kb_publish",
        "kb_scope",
    }
)

PRAESTO_KB_CURATION_READ_TOOLS: frozenset[str] = frozenset({"kb_inspect", "kb_scope"})


@dataclass(frozen=True, slots=True)
class TrustedTeamsPersonalProvenance:
    """Non-JSON runtime marker created only after local Gateway validation."""

    subject_id: str
    tenant_id: str


@dataclass(frozen=True, slots=True)
class ScheduledKbReadOutcome:
    """Structured completion signal for one scheduled KB-dependent run."""

    successful_content_read: bool = False
    error: str = ""


_SCHEDULED_READ_LOCK = RLock()
_SCHEDULED_READ_OUTCOMES: dict[str, ScheduledKbReadOutcome] = {}


def _kb_result_has_content(action: str, text: str) -> bool:
    if action not in {"read", "rules", "search"}:
        return False
    try:
        payload = json.loads(text)
    except (TypeError, ValueError):
        return False
    if not isinstance(payload, dict):
        return False
    if action == "read":
        return bool(str(payload.get("content") or "").strip())
    if action == "rules":
        documents = payload.get("rule_documents")
        return isinstance(documents, list) and bool(documents)
    matches = payload.get("matches")
    return isinstance(matches, list) and bool(matches) and int(payload.get("match_count") or 0) > 0


def begin_scheduled_kb_run(session_id: str) -> None:
    """Reset read outcome state before a scheduler session starts."""
    if session_id:
        with _SCHEDULED_READ_LOCK:
            _SCHEDULED_READ_OUTCOMES[session_id] = ScheduledKbReadOutcome()


def record_scheduled_kb_read(
    metadata: dict[str, Any] | None,
    *,
    session_id: str,
    tool: str,
    action: str,
    result: str,
) -> None:
    """Record a KB read result only for a trusted scheduler capability turn."""
    if scheduled_kb_capability(metadata) is None:
        return
    key = str((metadata or {}).get("agent_session_key") or session_id or "").strip()
    if not key:
        return
    text = str(result or "").lstrip()
    generic_failure = text.startswith(
        (
            "Error:",
            "Error executing",
            "Knowledge base unavailable:",
        )
    )
    tool_denial = tool in PRAESTO_KB_CURATION_READ_TOOLS and text.startswith(
        (f"{tool} requires ", f"{tool} is only")
    )
    failed = generic_failure or tool_denial
    with _SCHEDULED_READ_LOCK:
        current = _SCHEDULED_READ_OUTCOMES.get(key, ScheduledKbReadOutcome())
        if failed:
            _SCHEDULED_READ_OUTCOMES[key] = ScheduledKbReadOutcome(
                successful_content_read=current.successful_content_read,
                error=f"{tool}: {text[:240]}",
            )
        elif tool == "kb_inspect" and _kb_result_has_content(action, text):
            _SCHEDULED_READ_OUTCOMES[key] = ScheduledKbReadOutcome(
                successful_content_read=True,
                error="",
            )


def consume_scheduled_kb_run(session_id: str) -> ScheduledKbReadOutcome:
    """Return and clear the structured KB read outcome for a scheduler session."""
    with _SCHEDULED_READ_LOCK:
        return _SCHEDULED_READ_OUTCOMES.pop(session_id, ScheduledKbReadOutcome())


def scheduled_kb_capability(metadata: dict[str, Any] | None):
    """Return scheduler-issued KB provenance, never prompt-supplied metadata."""
    data = metadata or {}
    from praestoclaw.cron.job import ScheduledKbCapability
    from praestoclaw.host.runtime_contracts import is_trusted_workflow_run

    if not is_trusted_workflow_run(data):
        return None
    capability = ScheduledKbCapability.from_dict(data.get("scheduled_kb_capability"))
    job_name = str(data.get("job_name") or "").strip()
    if capability is None or capability.job_id != job_name:
        return None
    return capability


def kb_curation_read_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether read-only KB tools may operate in this turn."""
    return kb_curation_is_active(metadata) or scheduled_kb_capability(metadata) is not None


def kb_curation_is_active(metadata: dict[str, Any] | None) -> bool:
    """Whether KB curation tools may operate in this conversation."""
    data = metadata or {}
    if data.get("praesto_tag_exp"):
        return True
    ctype = str(data.get("ctype") or data.get("teams_conversation_type") or "").strip().lower()
    cid = str(data.get("cid") or "").strip()
    trusted_personal = data.get("_trusted_teams_personal")
    return bool(
        cid
        and ctype == "personal"
        and isinstance(trusted_personal, dict)
        and str(trusted_personal.get("subject_id") or "").strip()
        and str(trusted_personal.get("tenant_id") or "").strip()
    )
