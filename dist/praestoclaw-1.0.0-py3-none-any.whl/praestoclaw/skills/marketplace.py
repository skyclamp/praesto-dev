"""Skill Marketplace — discover and install skills from external repositories.

A marketplace is a local directory containing skill folders (SKILL.md or skill.md files).
Five formats are supported:

1. **Flat** — ``skills/<name>/SKILL.md`` (microsoft_skills_marketplace style)
2. **Plugin** — ``plugins/<name>/skills/<sub>/SKILL.md`` with a top-level README.md
   (edge-agents style). Each sub-skill is listed independently under the plugin name.
3. **Single** — the source path itself is one skill directory (opc style).
4. **Zip-archive** — ``skills/<name>-<version>.zip`` where each zip unpacks to a
   self-contained skill (Kosmos-cdn style). On install we unpack each archive
   into ``<source>/.unpacked/<stem>/`` and then walk the unpacked tree the
   same way ``flat`` does. Subsequent runs reuse the unpacked cache.
5. **GitHub org** — ``<org>/<repo>/.claude/skills/<name>/SKILL.md`` from
   sparse-cloned team repositories. Each repo becomes a group under one org
   marketplace source.

Installed skills are symlinked into ``~/.praestoclaw/skills/`` so the normal
SkillLoader picks them up automatically.
"""

from __future__ import annotations

import json
import re
import shutil
import zipfile
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import yaml
from loguru import logger

_METADATA_FILE = ".marketplace.json"
_SAFE_CHAR_RE = re.compile(r"[^a-zA-Z0-9_-]")
SUPPORTED_MARKETPLACE_FORMATS = frozenset({"flat", "plugin", "single", "zip-archive", "github-org"})


def _safe_skill_dirname(name: str) -> str:
    """Return a filesystem-safe directory name derived from a skill name.

    Raises ``ValueError`` on empty names, names containing path traversal
    segments, or names starting with ``.``.
    """
    if not name or not name.strip():
        raise ValueError("Skill name must not be empty")
    name = name.strip()
    if name.startswith("."):
        raise ValueError(f"Skill name must not start with '.': {name!r}")
    # Reject path traversal segments in the original name
    for part in re.split(r"[\\/]", name):
        if part in ("..", "."):
            raise ValueError(f"Skill name must not contain path traversal: {name!r}")
    # Convert / to -- then sanitize remaining chars
    safe = name.replace("/", "--")
    safe = _SAFE_CHAR_RE.sub("_", safe)
    if not safe or safe.startswith("."):
        raise ValueError(f"Skill name produces invalid directory: {name!r}")
    if ".." in safe:
        raise ValueError(f"Skill name produces invalid directory: {name!r}")
    return safe[:128]


@dataclass
class MarketplaceSkill:
    """A skill available in a marketplace (not yet installed)."""

    name: str
    description: str
    source: str  # marketplace source id
    source_label: str  # human-readable marketplace name
    plugin: str  # parent plugin name (same as name for flat skills)
    path: str  # absolute path to the skill directory
    installed: bool = False
    keywords: list[str] = field(default_factory=list)
    has_references: bool = False  # True if the skill dir has references/
    recommended: bool = False


@dataclass
class MarketplaceSource:
    """A configured marketplace source."""

    id: str
    label: str
    path: str  # absolute path to the marketplace root
    format: str  # "flat" or "plugin"
    skill_count: int = 0


def _parse_frontmatter(skill_md: Path) -> dict:
    """Extract YAML frontmatter from a skill markdown file."""
    try:
        text = skill_md.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return {}
    m = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return {}
    try:
        return yaml.safe_load(m.group(1)) or {}
    except Exception:
        return {}


def _extract_description(readme: Path) -> str:
    """Extract first non-heading, non-empty line from README.md."""
    try:
        for line in readme.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and not stripped.startswith("---"):
                return stripped[:200]
    except Exception:
        pass
    return ""


def _find_skill_markdown(skill_dir: Path, *, skill_file: str | None = None) -> Path | None:
    """Find a skill markdown file using the same case variants as external import."""
    candidates = ["SKILL.md", "skill.md"]
    if skill_file:
        candidates.insert(0, skill_file)
    for name in dict.fromkeys(candidates):
        path = skill_dir / name
        if path.is_file():
            return path
    return None


def discover_marketplace(source_path: Path, source_id: str, source_label: str) -> MarketplaceSource:
    """Probe a marketplace directory and return its metadata."""
    fmt = detect_format(source_path)
    return MarketplaceSource(
        id=source_id,
        label=source_label,
        path=str(source_path),
        format=fmt,
        skill_count=count_marketplace_skills(source_path, fmt),
    )


def unpack_zip_archive_marketplace(source_path: Path) -> Path:
    """Unpack ``<name>-<ver>.zip`` files in *source_path* into a sibling cache.

    Returns the path of the cache directory, which mirrors a ``flat`` marketplace
    layout (``<cache>/<name>/SKILL.md``). Subsequent calls reuse already-extracted
    archives, so this is cheap on repeated discovery.

    Each archive is validated against zip-slip path traversal: every member must
    resolve inside the destination directory, otherwise the archive is skipped.

    Some archives wrap their contents in a single top-level directory (common
    GitHub release pattern). When that happens we transparently descend into the
    wrapper so the cache layout stays uniform.
    """
    if not source_path.is_dir():
        raise NotADirectoryError(f"Marketplace source not found: {source_path}")

    cache_root = source_path / ".unpacked"
    cache_root.mkdir(exist_ok=True)
    cache_root_resolved = cache_root.resolve()

    for zip_path in sorted(source_path.glob("*.zip")):
        stem = _safe_skill_dirname(zip_path.stem)
        dest = cache_root / stem
        if dest.exists():
            continue  # already unpacked — idempotent

        staging = cache_root / f".{stem}.partial"
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir()

        try:
            with zipfile.ZipFile(zip_path) as zf:
                # zip-slip guard: validate every member up front
                staging_resolved = staging.resolve()
                for member in zf.namelist():
                    target = (staging / member).resolve()
                    if not _is_relative_to(target, staging_resolved):
                        raise ValueError(f"Unsafe zip entry in {zip_path.name}: {member}")
                zf.extractall(staging)
        except (zipfile.BadZipFile, ValueError, OSError) as exc:
            shutil.rmtree(staging, ignore_errors=True)
            logger.warning(f"[marketplace] skipping malformed archive {zip_path.name}: {exc}")
            continue

        # Flatten single-wrapper-directory archives so the cache always looks
        # like ``<cache>/<stem>/SKILL.md`` rather than
        # ``<cache>/<stem>/<wrapper>/SKILL.md``.
        kids = [c for c in staging.iterdir() if not c.name.startswith(".")]
        if len(kids) == 1 and kids[0].is_dir() and not (staging / "SKILL.md").is_file():
            wrapper = kids[0]
            wrapper.rename(dest)
            shutil.rmtree(staging, ignore_errors=True)
        else:
            staging.rename(dest)

        # Final safety: ensure dest is still inside the cache root.
        if not _is_relative_to(dest.resolve(), cache_root_resolved):
            shutil.rmtree(dest, ignore_errors=True)
            logger.warning(f"[marketplace] rejected {zip_path.name}: extracted path escaped cache")

    return cache_root


def _is_countable_skill_zip(zip_path: Path) -> bool:
    """Return True for safe zip archives that appear to contain a skill."""
    try:
        check_root = (zip_path.parent / ".zip-count-check").resolve()
        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
            for member in names:
                target = (check_root / member).resolve()
                if not _is_relative_to(target, check_root):
                    return False
            return _zip_names_have_listable_skill(names)
    except (zipfile.BadZipFile, OSError):
        return False


def _zip_member_parts(member: str) -> list[str]:
    return [part for part in member.replace("\\", "/").split("/") if part]


def _zip_names_have_listable_skill(names: list[str]) -> bool:
    root_skill = False
    wrapper_skill: str | None = None
    top_levels: set[str] = set()
    for member in names:
        parts = _zip_member_parts(member)
        if not parts:
            continue
        if not parts[0].startswith("."):
            top_levels.add(parts[0])
        if len(parts) == 1 and parts[0].lower() == "skill.md":
            root_skill = True
        elif len(parts) == 2 and parts[1].lower() == "skill.md":
            wrapper_skill = parts[0]
    if root_skill:
        return True
    return wrapper_skill is not None and top_levels == {wrapper_skill}


def detect_format(source_path: Path) -> str:
    """Detect a marketplace source format."""
    if _find_skill_markdown(source_path) is not None:
        return "single"
    has_plugin = False
    has_flat = False
    has_zip = False
    for child in source_path.iterdir():
        if child.is_file() and child.suffix.lower() == ".zip":
            has_zip = True
            continue
        if not child.is_dir():
            continue
        if (child / ".claude" / "skills").is_dir():
            return "github-org"
        if (child / "skills").is_dir():
            has_plugin = True
        elif _find_skill_markdown(child) is not None:
            has_flat = True
    if has_plugin:
        return "plugin"
    if has_flat:
        return "flat"
    if has_zip:
        return "zip-archive"
    return "flat"


def count_marketplace_skills(
    source_path: Path,
    fmt: str,
    *,
    skill_file: str | None = None,
) -> int:
    """Count marketplace skills without parsing every ``SKILL.md`` frontmatter."""
    if fmt == "flat":
        return sum(
            1
            for child in source_path.iterdir()
            if child.is_dir() and _find_skill_markdown(child) is not None
        )

    if fmt == "plugin":
        count = 0
        for plugin_dir in source_path.iterdir():
            if not plugin_dir.is_dir():
                continue
            skills_dir = plugin_dir / "skills"
            if _find_skill_markdown(plugin_dir) is not None and not skills_dir.is_dir():
                count += 1
                continue
            if not skills_dir.is_dir():
                continue
            sub_skills = [sub for sub in skills_dir.iterdir() if sub.is_dir()]
            if len(sub_skills) == 1:
                count += int(_find_skill_markdown(sub_skills[0]) is not None)
            else:
                count += sum(1 for sub in sub_skills if _find_skill_markdown(sub) is not None)
        return count

    if fmt == "github-org":
        count = 0
        for repo_dir in source_path.iterdir():
            if not repo_dir.is_dir():
                continue
            skills_dir = repo_dir / ".claude" / "skills"
            if not skills_dir.is_dir():
                continue
            count += sum(
                1
                for child in skills_dir.iterdir()
                if child.is_dir() and _find_skill_markdown(child) is not None
            )
        return count

    if fmt == "zip-archive":
        return sum(
            1
            for child in source_path.iterdir()
            if child.is_file() and child.suffix.lower() == ".zip" and _is_countable_skill_zip(child)
        )

    if fmt == "single":
        return int(_find_skill_markdown(source_path, skill_file=skill_file) is not None)

    return 0


def list_marketplace_skills(
    source_path: Path,
    source_id: str,
    source_label: str,
    fmt: str,
    *,
    installed_names: set[str],
    skill_file: str | None = None,
    recommended: bool = False,
) -> list[MarketplaceSkill]:
    """List all skills available in a marketplace directory."""
    results: list[MarketplaceSkill] = []

    if fmt == "flat":
        # Flat: source_path/<name>/SKILL.md
        for child in sorted(source_path.iterdir()):
            if not child.is_dir():
                continue
            skill_md = _find_skill_markdown(child)
            if skill_md is None:
                continue
            fm = _parse_frontmatter(skill_md)
            name = fm.get("name", child.name)
            results.append(
                MarketplaceSkill(
                    name=name,
                    description=fm.get("description", "")[:300],
                    source=source_id,
                    source_label=source_label,
                    plugin=name,
                    path=str(child),
                    installed=name in installed_names,
                    keywords=fm.get("metadata", {}).get("activation", {}).get("keywords", [])
                    or fm.get("metadata", {})
                    .get("praestoclaw", {})
                    .get("activation", {})
                    .get("keywords", []),
                    has_references=(child / "references").is_dir(),
                )
            )

    elif fmt == "github-org":
        # GitHub org: source_path/<repo>/.claude/skills/<name>/SKILL.md
        for repo_dir in sorted(source_path.iterdir()):
            if not repo_dir.is_dir():
                continue
            skills_dir = repo_dir / ".claude" / "skills"
            if not skills_dir.is_dir():
                continue
            for child in sorted(skills_dir.iterdir()):
                if not child.is_dir():
                    continue
                skill_md = _find_skill_markdown(child)
                if skill_md is None:
                    continue
                fm = _parse_frontmatter(skill_md)
                skill_name = fm.get("name", child.name)
                name = f"{repo_dir.name}/{skill_name}"
                results.append(
                    MarketplaceSkill(
                        name=name,
                        description=fm.get("description", "")[:300],
                        source=source_id,
                        source_label=source_label,
                        plugin=repo_dir.name,
                        path=str(child),
                        installed=name in installed_names,
                        keywords=_extract_keywords(fm),
                        has_references=(child / "references").is_dir(),
                    )
                )

    elif fmt == "plugin":
        # Plugin: source_path/<plugin>/skills/<sub>/SKILL.md
        for plugin_dir in sorted(source_path.iterdir()):
            if not plugin_dir.is_dir():
                continue
            skills_dir = plugin_dir / "skills"
            # Check for a single top-level SKILL.md (some plugins use this)
            top_skill = _find_skill_markdown(plugin_dir)
            if top_skill is not None and not skills_dir.is_dir():
                fm = _parse_frontmatter(top_skill)
                name = fm.get("name", plugin_dir.name)
                results.append(
                    MarketplaceSkill(
                        name=name,
                        description=fm.get("description", "")[:300],
                        source=source_id,
                        source_label=source_label,
                        plugin=plugin_dir.name,
                        path=str(plugin_dir),
                        installed=name in installed_names,
                        keywords=_extract_keywords(fm),
                        has_references=(plugin_dir / "references").is_dir(),
                    )
                )
                continue

            if not skills_dir.is_dir():
                continue

            # Get plugin-level description from README.md
            plugin_desc = ""
            readme = plugin_dir / "README.md"
            if readme.is_file():
                plugin_desc = _extract_description(readme)

            sub_skills = list(skills_dir.iterdir())
            if len(sub_skills) == 1 and sub_skills[0].is_dir():
                # Single sub-skill — use plugin name
                sub = sub_skills[0]
                skill_md = _find_skill_markdown(sub)
                if skill_md is not None:
                    fm = _parse_frontmatter(skill_md)
                    name = plugin_dir.name  # Use plugin name for single-skill plugins
                    desc = fm.get("description", plugin_desc)
                    results.append(
                        MarketplaceSkill(
                            name=name,
                            description=desc[:300],
                            source=source_id,
                            source_label=source_label,
                            plugin=plugin_dir.name,
                            path=str(sub),
                            installed=name in installed_names,
                            keywords=_extract_keywords(fm),
                            has_references=(sub / "references").is_dir(),
                        )
                    )
            else:
                # Multiple sub-skills — prefix with plugin name
                for sub in sorted(sub_skills):
                    if not sub.is_dir():
                        continue
                    skill_md = _find_skill_markdown(sub)
                    if skill_md is None:
                        continue
                    fm = _parse_frontmatter(skill_md)
                    sub_name = fm.get("name", sub.name)
                    name = f"{plugin_dir.name}/{sub_name}"
                    results.append(
                        MarketplaceSkill(
                            name=name,
                            description=fm.get("description", "")[:300],
                            source=source_id,
                            source_label=source_label,
                            plugin=plugin_dir.name,
                            path=str(sub),
                            installed=name in installed_names,
                            keywords=_extract_keywords(fm),
                            has_references=(sub / "references").is_dir(),
                        )
                    )

    elif fmt == "zip-archive":
        # Zip-archive: source_path contains <name>-<ver>.zip files. Unpack on
        # demand and recurse as a flat marketplace.
        unpacked = unpack_zip_archive_marketplace(source_path)
        return list_marketplace_skills(
            unpacked,
            source_id,
            source_label,
            "flat",
            installed_names=installed_names,
            skill_file=skill_file,
            recommended=recommended,
        )

    elif fmt == "single":
        # Single: the source_path IS the skill directory
        skill_md = _find_skill_markdown(source_path, skill_file=skill_file)
        if skill_md is not None:
            fm = _parse_frontmatter(skill_md)
            name = fm.get("name", source_path.name)
            results.append(
                MarketplaceSkill(
                    name=name,
                    description=fm.get("description", "")[:300],
                    source=source_id,
                    source_label=source_label,
                    plugin=name,
                    path=str(source_path),
                    installed=name in installed_names,
                    keywords=_extract_keywords(fm),
                    has_references=(source_path / "references").is_dir(),
                    recommended=recommended,
                )
            )

    return results


def _extract_keywords(fm: dict) -> list[str]:
    """Extract keywords from frontmatter metadata (supports both flat and namespaced)."""
    meta = fm.get("metadata", {})
    wp = meta.get("praestoclaw", meta)
    act = wp.get("activation", {})
    keywords = act.get("keywords", [])
    return list(keywords) if isinstance(keywords, list) else []


def install_skill(
    skill: MarketplaceSkill,
    install_dir: Path,
    *,
    marketplace_root: Path | None = None,
    skill_file: str | None = None,
) -> Path:
    """Install a marketplace skill by copying it into the user skills directory.

    Returns the installed path.
    """
    install_dir.mkdir(parents=True, exist_ok=True)

    safe_name = _safe_skill_dirname(skill.name)
    install_dir_resolved = install_dir.resolve()
    dest = install_dir / safe_name
    # Verify dest stays inside install_dir after resolution
    try:
        dest_resolved = dest.resolve()
    except OSError as exc:
        raise ValueError(f"Invalid install destination for {skill.name!r}") from exc
    if not (
        dest_resolved == install_dir_resolved
        or _is_relative_to(dest_resolved, install_dir_resolved)
    ):
        raise ValueError(f"Install destination escapes skills directory: {dest_resolved}")

    source = Path(skill.path)
    if not source.exists():
        raise FileNotFoundError(f"Skill source not found: {source}")
    source_resolved = source.resolve()
    if not source_resolved.is_dir():
        raise NotADirectoryError(f"Skill source is not a directory: {source}")
    if marketplace_root is not None:
        mp_resolved = marketplace_root.resolve()
        if not _is_relative_to(source_resolved, mp_resolved):
            raise ValueError(
                f"Skill source {source_resolved} is outside marketplace root {mp_resolved}"
            )

    # If dest exists, decide based on metadata
    if dest.exists():
        meta = _read_install_metadata(dest)
        if meta is None:
            raise FileExistsError(
                f"Cannot install: {dest} already exists and is not a marketplace skill. "
                "Remove it manually if you want to install this skill."
            )
        if meta.get("name") != skill.name or meta.get("source") != skill.source:
            raise FileExistsError(
                f"Cannot install: {dest} is already used by "
                f"{meta.get('source')}::{meta.get('name')}."
            )
        shutil.rmtree(dest)

    shutil.copytree(
        source,
        dest,
        symlinks=True,
        ignore=shutil.ignore_patterns(".git", ".git/*", "__pycache__", "*.pyc", ".DS_Store"),
    )
    # Ensure SKILL.md exists (rename lowercase variant if needed)
    skill_md_upper = dest / "SKILL.md"
    if not skill_md_upper.is_file():
        alt = _find_skill_markdown(dest, skill_file=skill_file)
        if alt is not None:
            shutil.copy2(alt, skill_md_upper)

    _write_install_metadata(
        dest,
        {
            "name": skill.name,
            "source": skill.source,
            "source_label": skill.source_label,
            "installed_at": datetime.now(UTC).isoformat(),
        },
    )

    logger.info("Installed skill '{}' from {} to {}", skill.name, skill.source, dest)
    return dest


def uninstall_skill(name: str, install_dir: Path) -> bool:
    """Remove an installed marketplace skill. Returns True if removed.

    Refuses to remove directories that do not have a ``.marketplace.json``
    metadata file (i.e. skills the user authored or installed manually).
    """
    safe_name = _safe_skill_dirname(name)
    install_dir_resolved = install_dir.resolve()
    dest = install_dir / safe_name
    if not (dest.exists() and dest.is_dir()):
        for child in install_dir.iterdir() if install_dir.is_dir() else ():
            if not child.is_dir():
                continue
            meta = _read_install_metadata(child)
            if meta is not None and meta.get("name") == name:
                dest = child
                break
    try:
        dest_resolved = dest.resolve()
    except OSError:
        return False
    if not _is_relative_to(dest_resolved, install_dir_resolved):
        raise ValueError(f"Uninstall target escapes skills directory: {dest_resolved}")
    if not (dest.exists() and dest.is_dir()):
        return False
    if _read_install_metadata(dest) is None:
        raise ValueError(
            f"Refusing to remove {dest}: not a marketplace-installed skill "
            f"(missing {_METADATA_FILE})."
        )
    shutil.rmtree(dest)
    logger.info("Uninstalled skill '{}'", name)
    return True


def _is_relative_to(path: Path, other: Path) -> bool:
    try:
        path.relative_to(other)
        return True
    except ValueError:
        return False


def _read_install_metadata(dest: Path) -> dict | None:
    meta_file = dest / _METADATA_FILE
    if not meta_file.is_file():
        return None
    try:
        data = json.loads(meta_file.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def _write_install_metadata(dest: Path, meta: dict) -> None:
    (dest / _METADATA_FILE).write_text(
        json.dumps(meta, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def get_install_dir() -> Path:
    """Return the user skills installation directory."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "skills"


def get_installed_skill_names(install_dir: Path) -> set[str]:
    """Return names of skills installed via the marketplace.

    Only directories containing a ``.marketplace.json`` metadata file are
    considered marketplace-managed. The name returned is taken from the
    metadata (preserving the original ``plugin/sub`` form).
    """
    names: set[str] = set()
    if not install_dir.is_dir():
        return names
    for child in install_dir.iterdir():
        if not child.is_dir():
            continue
        if not (child / "SKILL.md").is_file():
            continue
        meta = _read_install_metadata(child)
        if meta is None:
            continue
        name = meta.get("name")
        if isinstance(name, str) and name:
            names.add(name)
    return names


# ── Built-in marketplace sources ───────────────────────────────────────────


@dataclass
class BuiltinMarketplace:
    """A built-in marketplace source that can be cloned from GitHub during init."""

    id: str
    label: str
    repo: str  # GitHub owner/name
    subpath: str  # path under the repo to use as marketplace root
    format: str  # "flat", "plugin", "single", or "zip-archive"
    description: str
    recommended: bool = False
    skill_file: str | None = None  # override for case-insensitive skill file (e.g. "skill.md")


BUILTIN_MARKETPLACES: list[BuiltinMarketplace] = [
    # general-purpose marketplaces
    BuiltinMarketplace(
        id="microsoft-skills",
        label="Microsoft Skills Marketplace",
        repo="gim-home/microsoft_skills_marketplace",
        subpath="skills",
        format="flat",
        description="Office docs (docx/xlsx/pptx/pdf), Edge dev & Git workflows (~22 skills)",
        recommended=True,
    ),
    BuiltinMarketplace(
        id="opc",
        label="One Person Company",
        repo="iamtouchskyer/opc",
        subpath=".",
        format="single",
        description="Full AI team with digraph pipeline, 16+ specialist roles, quality gates",
        recommended=True,
        skill_file="skill.md",
    ),
    # project-specific marketplaces
    BuiltinMarketplace(
        id="edge-skills",
        label="Edge Skills",
        repo="edge-microsoft/edge-agents",
        subpath="plugins",
        format="plugin",
        description="Edge/Chromium dev, ADO, debugging, PR/CR automation (~210 skills)",
    ),
    BuiltinMarketplace(
        id="societas-skills",
        label="Societas Skills",
        repo="gim-home/societas-skills",
        subpath="skills",
        format="flat",
        description="Societas development skills, including testing, data analysis etc.",
    ),
    # cross-project marketplaces
    BuiltinMarketplace(
        id="edge-societas-ml-skills",
        label="Edge × Societas ML Skills",
        repo="gim-home/edge-societas-ml-skills",
        subpath="skills",
        format="flat",
        description="ML skills shared between the Edge and Societas teams.",
    ),
    # role-specific marketplaces
    BuiltinMarketplace(
        id="studio8research-skills",
        label="Studio8 Research Skills",
        repo="gim-home/studio8research-skills",
        subpath="skills",
        format="flat",
        description="Research workflows from Studio8 — user-research and design exploration.",
    ),
    BuiltinMarketplace(
        id="design-skills",
        label="Design Skills",
        repo="gim-home/design-skills",
        subpath="skills",
        format="flat",
        description="Design-oriented skills (UX, visual, prototyping).",
    ),
    BuiltinMarketplace(
        id="kosmos-skills",
        label="Kosmos PM Skills",
        repo="gim-home/Kosmos-cdn",
        subpath="skills",
        format="zip-archive",
        description="PM-focused skills from KOSMOS CDN — product specs, market analysis, decision frameworks (~60 skills).",
    ),
]


def get_marketplace_cache_dir() -> Path:
    """Return the directory where cloned marketplace repos live."""
    from praestoclaw.utils.helpers import get_data_dir

    return get_data_dir() / "marketplaces"


def clone_or_update_github_repo(
    repo: str,
    cache_dir: Path,
    *,
    ref: str | None = None,
    timeout: int = 180,
) -> Path:
    """Clone a GitHub repo into ``cache_dir/<safe-name>`` or ``git pull`` if present.

    ``repo`` is ``owner/name``. Returns the local clone path. Raises
    ``RuntimeError`` with a clear message on failure.
    """
    import shutil as _shutil
    import subprocess

    if _shutil.which("git") is None:
        raise RuntimeError("git is not installed. Install git and try again.")

    if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
        raise ValueError(f"Invalid repo spec: {repo!r} (expected 'owner/name')")

    cache_dir.mkdir(parents=True, exist_ok=True)
    safe_dir = repo.replace("/", "__")
    dest = cache_dir / safe_dir
    url = f"https://github.com/{repo}.git"

    if (dest / ".git").is_dir():
        cmd = ["git", "-C", str(dest), "pull", "--ff-only", "--depth", "1"]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(
                f"git pull failed for {repo}: {result.stderr.strip() or result.stdout.strip()}"
            )
        logger.info("Updated marketplace repo {} at {}", repo, dest)
    else:
        cmd = ["git", "clone", "--depth", "1"]
        if ref:
            cmd += ["--branch", ref]
        cmd += [url, str(dest)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        if result.returncode != 0:
            raise RuntimeError(
                f"git clone failed for {repo}: {result.stderr.strip() or result.stdout.strip()}"
            )
        logger.info("Cloned marketplace repo {} to {}", repo, dest)

    return dest


def bulk_install_from_source(
    source_path: Path,
    source_id: str,
    source_label: str,
    fmt: str,
    install_dir: Path,
    *,
    skill_file: str | None = None,
    recommended: bool = False,
) -> tuple[int, int, list[tuple[str, str]]]:
    """Install every skill found under ``source_path``.

    Returns ``(installed, skipped, errors)`` where ``errors`` is a list of
    ``(skill_name, message)`` tuples. Skills that are already installed from
    the same source are re-installed (upgrade path). Skills whose target
    directory is occupied by a user-authored skill are skipped with an error.
    """
    resolved_fmt = fmt if fmt in SUPPORTED_MARKETPLACE_FORMATS else detect_format(source_path)
    # ``zip-archive`` marketplaces ship as a tree of ``<name>-<ver>.zip`` files.
    # We unpack into a sibling cache once, then treat the cache as a flat
    # marketplace from here on. Doing this *inside* bulk_install_from_source
    # (rather than at clone time) keeps the unpack step lazy — e.g. retries
    # from the Web Portal don't pay the cost twice.
    effective_source = source_path
    effective_fmt = resolved_fmt
    if resolved_fmt == "zip-archive":
        effective_source = unpack_zip_archive_marketplace(source_path)
        effective_fmt = "flat"
    skills = list_marketplace_skills(
        effective_source,
        source_id,
        source_label,
        effective_fmt,
        installed_names=set(),
        skill_file=skill_file,
        recommended=recommended,
    )
    installed = 0
    skipped = 0
    errors: list[tuple[str, str]] = []
    for skill in skills:
        try:
            install_skill(
                skill,
                install_dir,
                marketplace_root=effective_source,
                skill_file=skill_file,
            )
            installed += 1
        except FileExistsError as exc:
            skipped += 1
            errors.append((skill.name, str(exc)))
        except (ValueError, FileNotFoundError, NotADirectoryError, OSError) as exc:
            errors.append((skill.name, str(exc)))
    return installed, skipped, errors
