---
name: pmo-daily-check
description: "Use in PraestoClaw private chat or group chat for PMO daily progress sync: summarize each member's progress against weekly goals, risk, evidence completeness, and @mention needed follow-ups."
metadata:
  activation:
    keywords:
      - PMO daily check
      - PMO 日检查
      - PMO 每日同步
      - 每日项目进展
      - 本周目标进展
      - 进展百分比
      - 风险完成度
      - evidence completeness
      - daily PMO
      - daily project sync
    patterns:
      - "(?i)(pmo).{0,16}(daily|day|日|每日|日报|日检查)"
      - "(?i)(每日|今天|日常|daily).{0,20}(pmo|项目).{0,20}(同步|进展|风险|检查)"
      - "(?i)(本周目标|weekly goals?).{0,20}(进展|progress|百分比|risk|风险)"
      - "(?i)(统计|汇总).{0,20}(目标|成员|进展|风险).{0,20}(完成度|百分比|evidence)"
  os: [win32]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: kb_inspect
      match:
        action: "^repos$"
    - tool: kb_inspect
      match:
        action: "^sync$"
    - tool: kb_inspect
      match:
        action: "^rules$"
    - tool: kb_inspect
      match:
        action: "^tree$"
    - tool: kb_inspect
      match:
        action: "^read$"
    - tool: kb_inspect
      match:
        action: "^search$"
    - tool: kb_change_history
      match:
        action: "^latest$"
    - tool: kb_change_history
      match:
        action: "^show$"
    - tool: kb_change_history
      match:
        action: "^file$"
---

# PMO Daily Check

Use this skill in a direct PraestoClaw private chat or in the relevant project
group chat. It collects daily progress against this week's goals, produces a
daily table and follow-up list, uses `pmo-grill` only as a pre-send self-check
on the generated draft, and reports any recommended KB follow-up without writing
to the KB.

## Conversation visibility

Keep the visible chat quiet. Keep internal plan progress, checklist progress,
step-by-step verification messages, and background status cards out of the
visible conversation. The user should see only the daily table, concise
missing-update requests/reminders, PMO focus items, and source-read status when
KB/source access is blocked.

When the daily result is going to Teams/cloud, the complete report must be sent
with `notify(channel="cloud", content="...", teams_mentions=[...])`; do not put
the report itself in the normal final assistant reply. After the notify call,
the normal final reply should be only a short delivery receipt such as `已发送 PMO
daily check。`

Mention every distinct human owner/member represented in the daily table or
follow-up list, not only the sender and not only rows with missing updates. The
visible `content` passed to `notify` must use `@Full Name` for each owner/member
in the table row, owner section heading, and follow-up item. The
`teams_mentions` array must contain one object for every distinct mentioned
human, using the best available `name`, `upn`, or `id` from KB/person metadata.
If only a display name is available, include `{"name": "<display name>"}` so the
channel layer can attempt best-effort resolution. Do not use `@所有人`,
`@everyone`, or `type="all"` as a substitute for the per-person mentions unless
the user explicitly asks for a Teams-wide mention. Plain `@Full Name` text is
only a fallback when mention metadata is unavailable; if you fall back, state
that the follow-up used a plain-text mention fallback.

For owner-specific follow-ups, show a compact, copyable `pmo-grill` prompt under
that owner/goal. The group-visible message should show the owner, goal, missing
evidence, due date, and then the full prompt in a code block labelled `PMO grill
prompt`. The prompt must be self-contained so the owner can copy it into their
private chat and continue with `pmo-grill` without relying on group-chat history.

## Permission and approval model

Follow the same KB permission model as `pmo-grill`: KB tools are optional
capabilities for discovery and stay out of hard `requires.tools`. Safe KB read/discovery
actions are declared in `safe-tools`; KB write actions are outside this skill.
Use `kb_scope show`,
`kb_inspect` repos/sync/rules/tree/read/search, and `kb_change_history`
latest/show/file as the only KB read path. These KB read/discovery actions,
including `kb_inspect(action="sync")` even when it creates or updates the local
checkout, must run without interactive human approval. Do not ask the user to
approve KB reads, and do not substitute `shell`, `git`, `Remove-Item`, `curl`, or
filesystem commands for KB read/sync/discovery work. If a safe KB read tool is
missing or refused, report that exact capability as blocked and ask for the
needed KB text/link instead of requesting a shell approval. Do not call
KB write or KB binding mutation tools from daily check.

## External source boundary

Default evidence sources are the configured KB, the current PraestoClaw turn,
and text or links the user explicitly provides in this daily-check conversation.
Do not call Teams, M365 Copilot, M365 user, mail, calendar, SharePoint, WorkIQ,
or similar external MCP tools to discover updates, resolve people, search chat
history, inspect meetings, or fill missing evidence unless the current user
explicitly asks for that external search in this turn.

In particular, do not use or discover tools such as `MCP_teams_*`,
`MCP_m365-copilot_*`, `MCP_m365-user_*`, `MCP_mail_*`, `MCP_calendar_*`,
`MCP_sharepoint_*`, `MCP_workiq_*`, `teams_group_fetch`, or
`team_knowledge_capture` for a normal PMO daily check. If the user explicitly
asks to search Teams/M365, keep that search narrowly scoped to the named chat,
person, meeting, date range, or message link, and label the result as external
evidence. Otherwise mark unavailable updates as `not updated`, `partial`, or
`insufficient` instead of trying to recover them from Teams/M365.

For follow-up mentions, use mention metadata already present in the KB or in the
current turn. Do not query Teams/M365 only to resolve a mention; fall back to
plain `@Full Name` text when structured mention metadata is unavailable.

Daily check does not write KB content. Include a concise `Recommended KB
follow-up` section only when the available evidence shows a KB row should be
updated by a later `pmo-grill` run or a human maintainer.

## Mandatory preflight

Before daily work starts, perform the same KB preflight as `pmo-grill`:

1. Run `kb_scope(action="show")`.
2. If no KB is configured and the current user provided a GitHub URL under
  `gim-home/SocietasKnowledgeBase/tree/main/...`, derive the repo and subfolder
  for this run without saving a conversation binding. Ask the user for a KB URL
  or PMO folder scope only when no KB binding and no usable KB URL are present.
3. Run `kb_inspect(action="sync")` so a missing clone is created and an existing
  checkout is updated to the latest remote state. This is a safe KB read/sync
  action and must not be replaced by an approval-gated shell/git command.
4. If a KB capability is unavailable in the current chat context, keep the daily
  check moving. Ask the user for the KB URL or PMO folder scope when the
  destination cannot be resolved, continue from that provided source, and mark
  only the unavailable capability as blocked. Report the exact blocked
  capability: binding, live sync, or read.

## Reminder semantics

The daily check message itself is the reminder. Send the check result without
waiting for member responses inside this skill. Read the previous daily/weekly
PMO records and check whether each previously requested evidence/update has been
supplied. Carry unresolved items forward and increment or state the reminder
count.

Every missing-update row must @mention the responsible member when a mention form
is known, using the same spelling supplied by the KB or current conversation.
Example: `@Member：请在 <date/time> 前补 <goal> 的 evidence；这是第 2 次提醒。`

If a member replies later, the next daily check should detect the new evidence or
owner update and close or carry forward the follow-up in the next report. Keep
the current daily check on its scheduled path.

## Daily workflow

1. Resolve today's date, the active week, and the weekly goal list. In a new
  group-chat session, use the configured KB to discover this before asking the
  user for a goal list. Read the root/area README, weekly-cycle files, active
  weekly report, progress files, and recent daily/weekly PMO records as needed.
  Ask the user for the goal list only after KB read tools are unavailable or the
  configured source genuinely contains no active-week/goals signal.
2. For each goal, collect or confirm:
   - goal owner and participating members;
  - current progress percentage estimated from available evidence;
   - progress made since the last daily check;
   - evidence supplied today;
   - risk level and reason;
   - blocker or dependency;
   - next action, owner, due date, and requested PMO help.
3. Draft the daily table and follow-up list from the available information. When
   a row is missing evidence, owner, date, or risk reason, mark that missing
   state explicitly in the draft instead of hiding it.
4. Before sending the daily result, apply the `pmo-grill` evidence standard as
  an inline self-check on the draft. Use the standard directly inside daily
  check: every row needs status
   versus expectation, evidence or evidence gap, blocker/dependency, next action
  with date, risk reason, and recommended follow-up.

5. If the self-check finds a defect, revise the draft before sending. Ask a new
  question only when the defect makes the daily result materially misleading and
  the row cannot be represented as `partial`, `insufficient`, or `not updated`.
6. After sending the daily result, stop. Daily check remains read-only and
  keeps any KB follow-up as a recommendation in the chat response.

## Required daily table

Present the daily result as a table with these columns:

| Goal | Owner | Progress % | Risk | Evidence completeness | Missing update/evidence | Next action | PMO focus |
|---|---:|---:|---|---|---|---|---|

Do not replace this required table with an owner/risk summary table. The `Owner`
cell must contain the visible `@Full Name` form used by `teams_mentions`.

Use these values for `Evidence completeness`:

- `complete`: progress, risk, evidence, owner, next action, and date are all
  present;
- `partial`: enough to track the goal, but at least one useful detail is missing;
- `insufficient`: PMO cannot support the risk/progress judgment from the update;
- `not updated`: the member has not provided today's required update.

Keep percentages per goal rather than averaging unrelated goals. If a goal has
multiple owners, show the owner accountable for the next decision/action first.

Populate `Progress %` as the agent's PMO estimate from available evidence. Use
explicit percentages when present, but do not wait for a person to provide a
percent. Estimate from concrete signals such as completed checklist items,
accepted PRs, merged commits, shipped/deployed artifacts, test or trial results,
approved documents, closed issues, unresolved blockers, and remaining acceptance
criteria. Put the short basis for the estimate in `Evidence completeness` or
`Missing update/evidence`, for example `estimated from 3/5 release gates` or
`estimated from setup done, run evidence missing`.

Use conservative ranges when evidence is incomplete: `0-20%` for only setup or
planning, `20-50%` for partial implementation without validation, `50-80%` for
working implementation with incomplete evidence or open blockers, and `80-95%`
for validated work still missing closeout/owner confirmation. Use `100%` only
when completion evidence and closeout criteria are both present. Write `unknown`
only when the available sources give no usable progress signal at all.

Ask people for missing evidence, blockers, next action, or owner confirmation;
do not ask them merely to supply a percentage.

## Mentions and follow-up list

After the table, list exactly who still needs to do what. Mention the member in
the same spelling the user provided, using `@Full Name` when a mention form is known.
Include the reminder count when the same missing update was already requested in
a prior check:

- `@Full Name`: provide missing evidence for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: confirm risk/mitigation for `<goal>` by `<date>`; reminder #N.
- `@Full Name`: unblock dependency with `<team/person>` by `<date>`; reminder #N.

The daily table itself must also use the visible `@Full Name` form for each
owner or member row, and the `teams_mentions` array must contain one object for
every distinct mentioned human. Owner section headings must also be visible
mentions, for example `@Coraline Gao`, not plain `Coraline Gao`. If the same
person appears in multiple rows, mention them once in `teams_mentions` and use
the same visible spelling everywhere.

For each follow-up item, show a `PMO grill prompt` code block so the member can
copy it and update just that item without figuring out the prompt shape:

```text
Use pmo-grill: 执行 pmo grill skill，source="daily", date="<YYYY-MM-DD>", owner="<owner>", goal="<goal>", 缺口="<missing update/evidence>", 风险="<daily risk>", next_action="<requested action>", due="<date>", reminder_count=<N>, KB="<current KB scope>"。
```

For each owner follow-up, provide one visible prompt per owner/goal. If a person
who is not the named owner uses the copied prompt, `pmo-grill` will ask a
delegation question before continuing.

When the member runs that prompt, `pmo-grill` should filter to that current-user
goal, ask only the missing facts needed for risk judgment, and write the result
back to KB according to grill's approval rules.

Then list PMO focus items separately:

- escalations PMO should drive;
- decisions PMO should force this week;
- goals whose risk moved since yesterday;
- members/goals with repeated missing updates.

## Recommended KB follow-up

Prepare a daily PMO summary for the chat response:

- date and active week;
- daily table;
- member follow-up list;
- PMO focus list;
- evidence gaps and risk changes;
- recommendation for what a later `pmo-grill` run or human maintainer should
  write to the KB, when needed.

Daily check itself does not update the KB:

1. Read KB/source material only as needed to generate the daily PMO view.
2. Put follow-up recommendations in the chat response.
3. Use `pmo-grill` handoff lines for owner-specific evidence collection and KB
  updates.
