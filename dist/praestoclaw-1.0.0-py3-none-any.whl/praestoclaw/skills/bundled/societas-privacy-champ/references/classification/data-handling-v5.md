# Data Handling Standards — V5 (Current)
> Source: Data Handling Standards.xlsx, V5 tab (published 2024-03-18, last updated 2025-03-26)
> Site: O365GRCInfo/Partners SharePoint
> Scope: Enterprise Online Services — handling obligations by data type

## Overview
- O365 Data Handling Standard
- Mixed classification levels → classified at the **highest level** data type found
- Categories based on the Microsoft Enterprise Online Services Data Taxonomy: https://aka.ms/M365EDT

## Sheet List
1. V1 (previous)
2. V2 (previous)
3. V3 (previous)
4. V4 (before LBO formatting)
5. V4 - till Mar 2024
6. **V5 (current)** ← Primary Guidance
7. Version History

## Handling Dimensions (Column Categories)
| Category | Description |
|---|---|
| Data Retention | Min/max retention, active/passive deletion timelines |
| Data Transmission | Where data may be transmitted |
| Data Storage | In Region, In Boundary, In Country requirements |
| Data Use | Allowed/not allowed, model training rules, TRUST/CELA approval |
| Microsoft's Data Sharing with Third Parties | Microsoft-initiated/customer-initiated flows, approval, notification, contracts |
| Online Service | Notice/consent, tenant admin toggle, default settings |
| Customer Communications | Promotional/transactional email/SMS rules |
| Encryption | Transit (FIPS 140-2), at rest (FIPS 140-2) |
| Connected Apps | 1st party, O365 branded, API requirements |
| Telemetry / Data Outside Boundary | Acceptable redaction methods, cryptography requirements, spill cleanup |
| Employee Screening | U.S. Cloud screening, international exception, fingerprint, CJIS, PTP, citizenship |

## Handling by Data Type

### Access Control Data
- **Retention:** Active deletion 90 days, passive 180 days
- **Storage:** In Boundary
- **Encryption:** FIPS 140-2 required (transit + at rest)
- **Screening:** Required

### Customer Content
- **Retention:** Soft delete 7 days, limited account 90 days, passive delete 180 days
- **Storage:** In Region & In Boundary (or In Country & In Boundary)
- **Use:** Allowed; model retains classification of training data; DHS handling of model applies
- **Sharing:** Requires TRUST approval; new vendor = 180 day notice via Trust Center
- **Contracts:** MSSA/SSPA (Highly Confidential), EUMC, background checks, security/privacy addenda
- **Encryption:** FIPS 140-2 required

### End User Identifiable Information (EUII)
- **Retention:** Active 90 days, passive 180 days
- **Storage:** In Boundary (or In Country & In Boundary)
- **Use:** Allowed; privacy review required for new uses; no ads based on EUII
- **Redaction:** Encrypt, hash, replace, or truncate; keys/salts stored in boundary
- **Sharing:** Requires TRUST approval + CELA review

### Support Data
- **Retention:** 30/90/180 days (anonymized data exempt); max 18 months (except security/legal)
- **Use:** Allowed; not allowed in reports/audits if Support Data included
- **Sharing:** Requires TRUST approval + CELA review

### Feedback Data
- **Retention:** 30/90/180 days (anonymized exempt); max 18 months
- **Use:** Allowed; requires CDGB approval for certain uses
- **Sharing:** Requires TRUST approval

### Account Data
- **Retention:** Min 1 year, max 3 years; diagnostic 18 months exception
- **Use:** Allowed; marketing must approve message + opt-out; allowed for non-EDU O365 SKUs
- **Sharing:** Requires TRUST + GRC review

### Public Personal Data
- **Retention:** 30/90/180 days; max 18 months
- **Use:** Allowed subject to licensing terms
- **Sharing:** Requires TRUST + CELA review

### End User Pseudonymous Identifiers (EUPI)
- **Retention:** 30/90/180 days; max 18 months
- **Use:** Allowed; allowed as input to aggregate metric
- **Sharing:** Requires TRUST + CELA review

### Organization Identifiable Information (OII)
- **Retention:** Active 90 days, passive 180 days
- **Use:** Allowed; must exclude US Public Sector OII data
- **Notes:** OII datasets must pre-exist for existing processor or LBO purpose; cannot manufacture datasets; avoid EU government entities; use IDEAS managed OII datasets
- **Sharing:** Requires TRUST + CELA review

### System Metadata
- **Retention:** Security logs (min/max 1 year); general 18 months
- **Use:** Allowed; allowed for non-EDU O365 SKUs
- **Sharing:** Needs CELA review

### Public Non-Personal Data
- If obtained from third party → follow their instructions. Otherwise no obligation.

## Security Logs
| Type | Retention |
|---|---|
| Security Log | Min 1 year / Max 1 year |
| Exchange Online Archiving Logs | Min 3 years / Max 3 years |
| Diagnostic Personal Data | 18 months |

## Version History
| Date | Change | Author |
|---|---|---|
| 06/01/2013 | Initial Release | Aschwab |
| 06/01/2014 | Updates for Use Limitations, Data Protection | Aschwab |
| 08/01/2014 | Updates for Compliance Tiers and GoLocal | Aschwab |
| 12/01/2014 | Connected App Guidance | Aschwab |
| 06/05/2018 | Consistency updates for 3rd party data sharing | KenE |
| 03/18/2024 | Published V5 Tab as primary guidance | KenE |
| 03/05/2025 | Prohibit transfer of EUPI from GCC/GCCH/DoD to outside CONUS | MiStokes |
| 03/26/2025 | Column for retention of Personal Data in diagnostic data | MiStokes |
