# Scenarios — Edge Cases and Targeted Questions

Use this file when a user's question **doesn't fit neatly** into the main four stages (`01-decide` → `02-kickoff` → `03-execute` → `04-close`). This is the "miscellaneous but important" layer.

Each scenario: **Question → Short answer → Where to go for more.**

---

## Scope questions

### "Is DAR the same as Privacy Review?"
No. Data Access Request is a separate process. It does **not** replace privacy review. They can both exist for the same feature.

### "Is taxonomy classification enough by itself?"
No. Classifying data correctly is a prerequisite, not a substitute. Privacy review determines the actual outcome.
→ More: `classification/decision-guide.md`

### "We reviewed this ~1 year ago, do we need another?"
Yes. Annual cadence is itself a trigger. If the feature or its data use also changed, even more so.
→ More: `01-decide.md`

### "My feature is tiny, surely no review needed?"
Depends on the trigger list, not on size. Small features can still hit triggers (new data use, consent change, AI/ML).
→ More: `01-decide.md` Step 1

---

## Process confusion

### "What's the difference between consult and review?"
- **Consult** = early, informal, shape the design. No 1CS Assessment.
- **Review** = formal, concrete, 1CS Assessment + artifacts + signoff.

Unsure → consult first.
→ More: `01-decide.md` Step 2

### "What does pre-review mean? Is that approval?"
**No.** Pre-review is a completeness check by your champ before the Privacy Manager sees the package. Signoff is separate and comes after.
→ More: `04-close.md` Step 1

### "Can our regular champ sign this off?"
Only if:
- The User Story is tagged **Low risk** (or Safe Patterns)
- The champ is **L3**

Everything else → Privacy Manager.
→ More: `04-close.md` Step 2

### "Who handles DPIA updates?"
L3 champ or Privacy Manager. You flag the need and provide inputs. You don't do it yourself.
→ More: `03-execute.md` §DPIA

---

## Data / classification confusion

### "Should I use the current V5 or the old workbook?"
Current V5 for present-state recommendations. Old workbooks are historical context only.
→ More: `classification/data-handling-v5.md`

### "Which framework applies — Controller or Processor?"
MSA users → Controller (Controller Data Taxonomy + Controller Data Use Framework).
AAD/Entra ID users → Processor (Enterprise Data Taxonomy + Data Handling Standards V5).
Dual-identity → per data flow.
→ More: `classification/decision-guide.md`

### "Can we treat model output (embeddings, aggregates) as less sensitive than source data?"
Default: **no**. Derived data keeps the source classification; mixed datasets inherit highest sensitivity; hashing doesn't remove sensitivity. Trying to downgrade → escalate.
→ More: `03-execute.md` §Derived data

### "How do I fill the data profile / Data Scout?"
Describe the real processing. Per data element: type, source, purpose, flow, access, retention, sharing, model use. Align with 1CS Assessment, DFD, DSR plan.
→ More: `classification/data-scout-reference.md`

---

## Edge cases in execution

### "A generated Task doesn't seem to apply to our feature — can I just close it?"
No. Talk to your champ. You may need a waiver, or the Assessment answers may need correcting.
→ More: `03-execute.md`

### "My feature spans multiple teams. Who owns the review?"
One team owns the primary 1CS Assessment. Others contribute artifacts. Decide ownership **before** kickoff.
→ More: `ops-permissions.md` §4

### "Creator left / transferred. What happens to our review?"
Champ reassigns the User Story. Document the handover.
→ More: `ops-permissions.md` §5

### "Feature changed right after signoff. What now?"
Re-evaluate. Small changes may fit under existing review; material changes → new cycle (back to `01-decide.md`).

---

## When user is vague

If you can't tell which stage they're in, ask the minimum missing facts:

- Is this a new feature or a change to an existing one?
- Does it involve personal data or a new use of existing data?
- Is design still forming, or are you preparing artifacts?
- MSA users, AAD users, or both?

Then give a provisional answer based on the safest assumption. Don't wait for perfect information.

---

## Top newcomer mistakes (quick scan)

| # | Mistake | Correct stance | Where |
|---|---|---|---|
| 1 | Treating DAR = Privacy Review | Different processes | Scope questions above |
| 2 | Thinking pre-review = approval | Pre-review is a check, not a signoff | `04-close.md` |
| 3 | Artifacts as fragile links only | Durable evidence required | `03-execute.md` §Durable |
| 4 | Adding AI/ML, skipping re-review | AI/ML is a trigger; likely needs DPIA update | `01-decide.md`, `03-execute.md` |
| 5 | Trying to downgrade derived data | Derived keeps source classification; escalate | `03-execute.md` §Derived data |
| 6 | Assuming ~1 year gap = review stays fresh | ~1 year is itself a trigger | `01-decide.md` |
| 7 | Mixing Controller + Processor taxonomies | Confirm side first; OUTPUT GATE | `classification/decision-guide.md`, `common-mistakes.md` |
| 8 | Data Scout / DFD / DSR tell different stories | Must be consistent or pre-review bounces | `03-execute.md` §Rule #1 |
| 9 | Expecting any champ to sign off anything | Only L3, only Low-risk / Safe Patterns | `04-close.md` |
| 10 | Rushing 1CS answers | Wrong answers → wrong Tasks → rework | `02-kickoff.md` |
| 11 | Thinking classification alone = review done | Classification ≠ review | `classification/decision-guide.md` |
| 12 | Using old Controller Data Use Framework as current guidance | Prefer V5 / current | `classification/data-handling-v5.md` |

---

## Safe default language

When giving provisional answers, prefer wording like:

- "This likely needs at least a privacy consult, and possibly a formal review depending on implementation details."
- "If this changes how personal data is processed, assume privacy review involvement is needed."
- "If the User Story is tagged Low and your champ is L3, this may be eligible for champ signoff; otherwise route to the Privacy Manager."
- "For current handling expectations, prefer V5 over historical workbooks."
- "Classify the data first, then decide which Controller or Processor rules apply."
