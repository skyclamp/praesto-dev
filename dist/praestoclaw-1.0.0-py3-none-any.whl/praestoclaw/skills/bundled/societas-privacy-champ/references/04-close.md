# Stage 3 — Close

> **Entry:** All Tasks done, all artifacts attached and consistent (from `03-execute.md`).
> **Goal:** Get pre-review passed, get signoff, close the User Story, set up the next revisit.
> **Exit:** Review formally closed. Reminder set for ~1 year (or earlier if feature changes).

---

## Step 1 — Pre-review

**Pre-review is NOT approval.** It's a completeness check by your champ before the Privacy Manager sees the package.

What happens:

1. Book time with your champ; share the full package (User Story + all artifacts)
2. Champ walks through for gaps, inconsistencies, weak evidence
3. Champ flags issues; you fix them
4. Champ confirms the package is ready for signoff

**Common reasons pre-review bounces:**

- Data Scout / DFD / DSR inconsistent (most common)
- Artifacts are fragile links, not durable evidence
- Taxonomy terms from the wrong side (EUPI used in MSA scenario, etc.)
- Assessment answers don't match what the artifacts actually show
- DPIA update needed but not requested

If bounced → back to `03-execute.md` to fix, then re-submit for pre-review.

## Step 2 — Signoff

Signoff path depends on **risk level** (assigned to your User Story):

| Risk | Who signs |
|---|---|
| Low + you have an L3 champ available | **L3 champ** signs |
| Safe Patterns (specific low-risk category) | **L3 champ** signs |
| Medium / High | **Privacy Manager** signs |
| Novel, ambiguous, unusual privacy impact | **Privacy Manager** signs |

**Never pressure a champ to sign off something they flag as beyond their scope.** When in doubt, route up.

Signoff is recorded in the ADO User Story history — this is your audit trail.

## Step 3 — Close the User Story

- Mark User Story as closed
- Ensure all Tasks are closed
- Confirm signoff record is visible in history
- Make sure artifacts are stored durably (not just linked)

## Step 4 — Set the next revisit

- Calendar reminder: **~1 year** from now
- Earlier trigger if the feature changes materially (new data use, AI/ML added, consent changes, etc.)
- Annual cadence is itself a trigger to re-evaluate, even if nothing else changed

---

## Exit criteria

- [ ] Pre-review passed
- [ ] Signoff recorded in ADO User Story
- [ ] User Story closed
- [ ] All Tasks closed
- [ ] All artifacts durable and retrievable
- [ ] Next revisit reminder set

---

## Close-stage FAQs

| Question | Answer |
|---|---|
| "Pre-review passed, does that mean I'm done?" | No. Pre-review ≠ signoff. You still need the actual signer. |
| "Can my champ sign off everything?" | Only L3 champ, only for Low risk / Safe Patterns. Everything else → Privacy Manager. |
| "What if signoff takes forever?" | Normal to have back-and-forth. Respond promptly to questions; unclear issues → ask for a call. |
| "How long should I keep artifacts?" | At minimum until the next annual review. Ideally longer — they're audit evidence. |
| "Feature changed right after signoff, what now?" | Re-evaluate. Small changes may be covered by existing review; material ones → new review cycle. |

More → `scenarios.md`.
