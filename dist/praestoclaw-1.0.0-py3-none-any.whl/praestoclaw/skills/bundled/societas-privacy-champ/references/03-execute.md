# Stage 2 — Execute

> **Entry:** Assessment submitted, User Story + Tasks generated (from `02-kickoff.md`).
> **Goal:** Complete each Task with proper artifacts; keep everything consistent.
> **Exit:** All Tasks closed, artifacts attached, nothing contradicts anything. Move to `04-close.md`.

This stage is the **longest** and most work. This file is the **controller** — it tells you what Tasks look like and how to keep them consistent. For detailed how-to on data classification (especially Data Scout), go to `classification/`.

---

## The Task landscape

Tasks are auto-generated from your Assessment answers. The exact set varies, but most reviews include some mix of:

| Task type | What you produce | Where to get details |
|---|---|---|
| **Data inventory** | Data Scout entries for every data element | `classification/data-scout-reference.md` + `classification/decision-guide.md` |
| **Data Flow Diagram (DFD)** | Box-and-arrow diagram: sources → processing → storage → sharing | This file, §DFD |
| **DSR plan** | How users delete / export their data | This file, §DSR |
| **DPIA update** | Formal impact assessment update (only if triggered) | Handled by L3 champ / Privacy Manager |
| **UI/UX evidence** | Screenshots of notice / consent surfaces | This file, §UI |
| **Retention / encryption / access** | Configuration evidence | See `classification/data-handling-v5.md` (Processor side) |

---

## Rule #1 — Consistency is everything

The most common reason pre-review bounces a package: **artifacts don't match each other**.

Data Scout says "we collect X". DFD says "we collect X and Y". DSR says "we delete X". → Inconsistent. Rejected.

**Before moving to Stage 3, every artifact must tell the same story, with the same data element names.**

Checklist:

- [ ] Every data element in Data Scout also appears in DFD
- [ ] Every data flow in DFD has a DSR story (delete + export)
- [ ] Data classifications match across artifacts
- [ ] No "we removed X" in one artifact and "we use X" in another

---

## Data Scout / data inventory

The backbone artifact. Fill one entry per data element your feature touches.

**Before filling Data Scout:**

1. Confirm you know Controller vs Processor side (`classification/decision-guide.md`)
2. Know which field you're filling (#7 Enterprise vs #8 Controller — **only one**, the other is N/A)
3. Only use terms from the allow-list for your side (`classification/decision-guide.md`)

**During filling:**

For each data element capture: type, source, purpose, flow, access, retention, sharing/export, model usage.

**Common classification mistakes** — see `classification/common-mistakes.md`. The big ones:

- ❌ Access token → "EUPI" (wrong) → should be **Credentials Data** (Controller)
- ❌ Resource ID → "OII" (wrong) → should be **Product and Service Usage Data** (Controller)
- ❌ Mixing Enterprise and Controller terms in the same entry

---

## Data Flow Diagram (DFD)

A simple box-and-arrow is fine. What matters:

- Every data element in Data Scout has a path in the DFD
- Sources (where data enters), processing (what happens to it), storage (where it rests), sharing (who else sees it)
- Cross-boundary flows are called out (service boundary, tenant boundary, vendor boundary, geography)

**Tool**: whatever your team uses (Mermaid, Visio, drawio, PowerPoint). Store as a **file / image**, not a fragile link.

---

## DSR plan

For each personal data element, write:

- **Delete** — when a user requests deletion, what happens? Which systems are affected? How long does it take?
- **Export** — when a user requests their data, what format? What's included?
- **Retention** — how long do you keep it, and why?

DSR plan must match Data Scout (same data elements, same names).

---

## DPIA update (only if triggered)

Triggers: new processing, new purpose, consent/notice change, cookies, sharing, biometrics, location, profiling, AI/ML.

**You don't do this yourself.** L3 champ or Privacy Manager handles it. Your job: flag that you need one, and provide the inputs they ask for.

---

## UI/UX evidence

If your feature has notice or consent surfaces:

- Screenshot the actual UI at review time
- Save as a file (not a link to a design doc that will change)
- Show both the notice text and where the user acts (button, checkbox)

---

## Derived / inferred / model data

If your feature creates derived data (aggregates, embeddings, model outputs):

- **Default**: derived data keeps the source classification
- **Mixed datasets**: inherit the highest-sensitivity classification in the mix
- **Hashing / transformation** does NOT automatically remove sensitivity
- **Trying to downgrade?** → escalate to Privacy Manager. Don't self-approve.

---

## Durable evidence

Every artifact attached to a Task must be **durable**:

- ✅ File uploaded to the ADO work item
- ✅ Stable document ID in a system with version history
- ❌ SharePoint link that may 404
- ❌ Screenshot pasted into a Teams chat

Assume someone will re-read this in a year. Would they find everything?

---

## Exit criteria (before moving to Stage 3)

- [ ] All generated Tasks are closed
- [ ] All required artifacts are attached and durable
- [ ] Data Scout ↔ DFD ↔ DSR are internally consistent
- [ ] Data classifications pass the OUTPUT GATE (`classification/decision-guide.md`)
- [ ] DPIA update requested if triggered
- [ ] UI/UX evidence captured if notice/consent involved

All checked → go to `04-close.md`.

---

## Execute-stage FAQs

| Question | Answer |
|---|---|
| "Do we really need Data Scout?" | If your feature uses data, yes. |
| "What if a Task doesn't apply to us?" | Talk to champ; don't just close it. May need a waiver or the Assessment re-answered. |
| "Our DFD is just a few boxes, is that OK?" | Yes if it's accurate and matches Data Scout. Fidelity > polish. |
| "Can we treat model output as less sensitive?" | Default no. Escalate. |

More → `scenarios.md`.
