# Glossary — Quick Reference

One-page plain-language glossary. Each term: 1–2 line explanation + where to go for more.

If you're new to privacy review, read this first, then `00-overview.md`.

---

## Process terms

| Term | Plain meaning | Detail |
|---|---|---|
| **Privacy Consult** | Early, informal chat to shape design. No 1CS Assessment needed. | 01-decide.md |
| **Privacy Review** | The formal process: submit 1CS, prepare artifacts, get signoff. | 01-decide.md–§5 |
| **Pre-review** | A champ checks your package for completeness **before** the Privacy Manager. NOT approval. | 04-close.md |
| **Signoff** | The actual approval that closes the review. | 04-close.md |
| **Annual review** | ~1 year cadence; itself a trigger to re-evaluate. | 01-decide.md |

## Tools / artifacts

| Term | Plain meaning | Detail |
|---|---|---|
| **1CS Privacy Assessment** | The questionnaire you submit to start a formal review. Becomes an ADO User Story. Your answers auto-generate Tasks. | 02-kickoff.md |
| **ADO User Story / Tasks** | The work items tracking the review. User Story = overall review; Tasks = things you must do. | 02-kickoff.md |
| **Artifact** | Evidence attached to the review. Must be durable, not fragile links. | 03-execute.md |
| **Data Scout** | The data inventory tool. List every data element your feature touches. | 03-execute.md, classification/data-scout-reference.md |
| **Data Flow Diagram (DFD)** | Picture showing where data comes from, goes, and is stored. | 03-execute.md |
| **DSR plan** | Data Subject Request plan — how you will support delete/export requests. | 03-execute.md |
| **DPIA** | Data Protection Impact Assessment. Updated when privacy-impacting changes occur (consent, AI/ML, profiling…). | 03-execute.md |
| **DAR** | Data Access Request — a different process. **NOT a replacement** for privacy review. | scenarios.md |

## Roles

| Term | Plain meaning | Detail |
|---|---|---|
| **Privacy Champ (regular)** | Team member who helps with preparation, guidance, artifact review. Cannot sign off. | 04-close.md |
| **L3 Champ** | Senior champ who can sign off **low-risk** reviews and handle advanced tasks (e.g., DPIA updates). | 04-close.md |
| **Privacy Manager** | Formal authority for medium/high-risk, novel, or ambiguous reviews. | 04-close.md |
| **Safe Patterns** | A specific low-risk category eligible for champ signoff. | 04-close.md |

## Data-side concepts (critical — don't mix the two sides)

| Term | Plain meaning | Detail |
|---|---|---|
| **Controller (MSA)** | Microsoft IS the data controller. Users authenticate with MSA (Microsoft Account / consumer). | SKILL.md A0 |
| **Processor (AAD / Entra ID)** | Microsoft processes data on behalf of an enterprise customer. Users authenticate with AAD/Entra ID. | SKILL.md A0 |
| **Controller Data Taxonomy** | The list of data type names used on the Controller side (MSA). | classification/controller-taxonomy.md |
| **Enterprise Data Taxonomy** | The list of data type names used on the Processor side (AAD/Entra ID). | classification/enterprise-taxonomy.md |
| **Controller Data Use Framework** | Rules for how Controller-side data may be used. | classification/data-scout-reference.md |
| **Data Handling Standards V5** | Current handling obligations (retention, storage, encryption, etc.) on the Processor side. Prefer V5 over older tabs. | classification/data-handling-v5.md |

## Data type terms (Enterprise / Processor side)

| Term | Plain meaning |
|---|---|
| **EUII** | End User Identifiable Information — identifies an individual end user |
| **EUPI** | End User Pseudonymous Identifier — pseudonymous ID for an end user |
| **OII** | Organization Identifiable Information — identifies a customer organization |
| **Customer Content** | Content the customer puts into the service |
| **Account Data** | Info about the customer's account / tenant |
| **System Metadata** | Service-generated telemetry/metadata |
| **Support Data** | Data shared during support interactions |
| **Public Personal Data** | Personal data that is already public |

Full definitions: `classification/enterprise-taxonomy.md`.

## Data type terms (Controller / MSA side — selected)

| Term | Plain meaning |
|---|---|
| **Customer Content** | Content the user creates / stores |
| **Credentials Data** | Tokens, passwords, auth secrets (e.g., access tokens live here) |
| **Account Data / Customer Contact Data** | Account profile info |
| **Product and Service Usage Data** | Usage signals, resource IDs, system identifiers |
| **Product and Service Performance Data** | Perf telemetry |
| **Precise User Location Data** | Fine-grained location |
| **Browsing History Data** | Browsing history |
| **Search Requests and Query Data** | What the user searched |
| **Inking, Typing and Speech Utterance Data** | Raw input signals |
| **Biometric Data** | Fingerprint, face, voice biometrics |

Full list and definitions: `classification/controller-taxonomy.md`.

---

## Two super-common mix-ups

- ❌ Calling an **access token** "EUPI" in a Controller/MSA scenario → it's **Credentials Data**.
- ❌ Calling a **resource ID** (driveId, itemId, webUrl) "OII" in a Controller/MSA scenario → it's **Product and Service Usage Data**.

Always confirm Controller vs Processor **first**, then pick terms from the right taxonomy. See SKILL.md A0.2 (OUTPUT GATE).
