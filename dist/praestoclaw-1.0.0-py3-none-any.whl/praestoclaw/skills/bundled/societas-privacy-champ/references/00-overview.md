# Societas Privacy Champ — Overview

A practical guide for Microsoft internal teams navigating privacy reviews. Written for **people who are new to the process** — not for Privacy Managers.

---

## What this skill helps with

Two kinds of questions:

### Path A — Process questions
"Do I need a privacy review?" "How do I start?" "What Tasks do I need to do?" "Who signs off?"

### Path B — Data classification questions
"Is this EUII or Credentials Data?" "Which taxonomy applies in my scenario?" "Can I treat model output as less sensitive?"

---

## The whole process at a glance

```
┌─────────────────────────────────────────────────────────────────┐
│  Stage 0 — DECIDE          → 01-decide.md                       │
│  Do I need a review at all? Consult or formal?                  │
│  Exit: you know which path you're on                            │
└──────────────────────────────┬──────────────────────────────────┘
                               │ formal review needed
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 1 — KICKOFF         → 02-kickoff.md                      │
│  Submit 1CS Privacy Assessment                                  │
│  Exit: ADO User Story + Tasks generated                         │
└──────────────────────────────┬──────────────────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 2 — EXECUTE         → 03-execute.md                      │
│  Complete Tasks: Data Scout, DFD, DSR, DPIA, UI evidence        │
│  Keep everything consistent                                     │
│  Exit: all Tasks closed, artifacts durable and aligned          │
└──────────────────────────────┬──────────────────────────────────┘
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│  Stage 3 — CLOSE           → 04-close.md                        │
│  Pre-review → Signoff → Close User Story → Set 1-year revisit   │
│  Exit: review formally closed                                   │
└──────────────────────────────┬──────────────────────────────────┘
                               │ ~1 year (or earlier if feature changes)
                               ▼
                      Back to Stage 0
```

---

## Where to read what

### Path A — Process (time-ordered main flow)

| File | When |
|---|---|
| `01-decide.md` | Stage 0 — deciding if you need a review |
| `02-kickoff.md` | Stage 1 — submitting the 1CS Assessment |
| `03-execute.md` | Stage 2 — doing the Tasks |
| `04-close.md` | Stage 3 — pre-review, signoff, closing |
| `scenarios.md` | Edge cases and "what about…" questions not covered in the four stages |

### Path B — Classification (data type and handling)

Everything under `classification/`:

| File | For |
|---|---|
| `decision-guide.md` | Controller vs Processor, OUTPUT GATE, the two allow-lists |
| `controller-taxonomy.md` | Controller (MSA) side data type definitions |
| `enterprise-taxonomy.md` | Processor (AAD/Entra) side data type definitions |
| `data-handling-v5.md` | V5 handling obligations (Processor side) |
| `data-scout-reference.md` | Authoritative Data Scout field reference |
| `common-mistakes.md` | Cross-contamination and other classification pitfalls |

### Shared utilities

| File | For |
|---|---|
| `glossary.md` | Plain-language term definitions (1CS, DSR, DPIA, EUII, Controller, etc.) |
| `ops-permissions.md` | "Who can create/edit/view/close?" operational questions |
| `sources.md` | Traceability — raw materials, conclusions per source |

---

## Two iron rules

These apply to every answer, regardless of stage:

1. **Controller vs Processor FIRST.** Never answer a classification question without first confirming which side you're on (MSA vs AAD/Entra ID). See `classification/decision-guide.md`.
2. **Never overstate authority.** This skill helps you prepare. It does not replace a Privacy Manager's judgment. Escalate when risk is medium/high, novel, or ambiguous.

---

## If you're totally new

Read in this order:

1. This file (you're here)
2. `glossary.md` — pick up the vocabulary
3. `01-decide.md` — see if you actually need a review
4. If yes → follow the stages in order (02 → 03 → 04)
5. Keep `classification/decision-guide.md` open when you start filling Data Scout
