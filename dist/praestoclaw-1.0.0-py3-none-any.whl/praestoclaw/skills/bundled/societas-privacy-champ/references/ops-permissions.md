# Operations & Permissions

Operational / access questions that are NOT about privacy judgment — they are about "who can do what in which tool".

> ⚠️ Exact permission rules vary by org and tool version. Where this file says `<TODO: verify with team>`, treat it as a placeholder and confirm with your Privacy Champ or tool owner. Do not invent specific permission rules.

---

## 1. 1CS Privacy Assessment — permissions

> **Scope note**: This skill does **NOT** own the access-request process. If you don't have access to the 1CS portal yet, submit the standard request at **`aka.ms/o365Trustaccess`** and follow your org's normal approval flow. Who approves it, how to escalate a denied request, or how long it takes — **not covered here**. Ask your manager or follow your org's IT/access process.
>
> What this skill **can** tell you:
> - Where the 1CS portal is: `https://o365trustcompliance.visualstudio.com/Trust/_compliance/product/0f2370dc-d3cc-2e07-4604-540a…` → **Assessments → Compliance**
> - The access-request entry point: `aka.ms/o365Trustaccess`
> - Once you're in, how to use it (see `02-kickoff.md` and onward)

**Common questions (after you have access):**

| Question | Default answer (verify locally) |
|---|---|
| Who can **create** an assessment? | Anyone with O365 Trust VSO access. `<TODO: verify FTE/vendor rules>` |
| Who can **edit** an existing assessment? | Creator + designated reviewers/champs on the User Story. `<TODO: verify>` |
| Who can **view** an assessment? | Usually team members in the ADO area path; champs and Privacy Managers have broader view. `<TODO: verify>` |
| Who can **close / sign off**? | L3 champ (low-risk only) or Privacy Manager. See `04-close.md` Step 2. |
| Can vendors / contractors create one? | Depends on account type and org policy. `<TODO: verify>` |
| What happens when the creator leaves / transfers? | Ownership should transfer to a team member; champ can help reassign. `<TODO: verify exact process>` |

**Response template when asked about 1CS access/permissions:**
> For access to the 1CS portal, submit the request at **`aka.ms/o365Trustaccess`** and follow your org's standard access-request process — this skill doesn't own that flow. Once you have access, the portal is at the O365 Trust Compliance ADO project → **Assessments → Compliance**. For permissions **inside** the tool (who can edit/view/close), check team wiki or ask your Privacy Champ.

---

## 2. ADO User Story / Tasks — permissions

Privacy User Stories + Tasks live in ADO. Standard ADO rules apply:

- **View** — anyone with access to the area path
- **Edit** — work item owners, area path members, and champs
- **Assign / close** — usually the owner, plus leads and champs

**If you can't see a User Story you expect to see:**
1. Check you're in the right ADO project
2. Check the area path — many teams have a specific privacy area path
3. Check the query filters (your default query may hide done items)
4. Ask the champ to grant visibility if still blocked

---

## 3. Data Scout — permissions

| Question | Default answer (verify locally) |
|---|---|
| Who can edit entries for our service? | Team members listed as owners of the service entry. `<TODO: verify>` |
| How to become an owner / editor? | Via Data Scout admin or service owner. `<TODO: process>` |
| Can I see other teams' entries? | Often yes (read), edit no. `<TODO: verify>` |

---

## 4. Cross-team / cross-org reviews

When a feature spans multiple teams:

- Each team typically handles their own slice
- One team usually owns the **primary** assessment; other teams contribute artifacts
- Privacy Manager coordinates if it's medium/high risk
- Ownership should be clear **before** starting — not retroactively

**If you're the contributor (not owner):**
- Make sure you're listed on the User Story
- Provide your slice's Data Scout entry + DFD fragment
- Don't assume the owner team covered your data flow

---

## 5. Handovers (people leaving / moving)

- If **creator** leaves → champ reassigns the User Story to a remaining team member
- If **champ** leaves → team appoints a new champ; open reviews transfer
- If **Privacy Manager** changes → existing reviews continue; any new signoff uses the new Privacy Manager
- Always document the handover in the User Story so audit trail is intact

---

## 6. Audit & record-keeping

- Artifacts must be **durable evidence** — not fragile links
- Store final signoff record in the ADO User Story history
- Screenshots of UI/UX at time of review should be saved as files, not just linked to a page that may change
- Annual review brings everything back — keep artifacts retrievable a year later

---

## 7. What to do when you hit a permissions wall

Decision tree:

```
Can't access a tool
   │
   ├─ Error says "no access" / "not authorized"
   │     → Ask tool owner or champ for the right role/group
   │
   ├─ Can access, but can't edit what you need
   │     → You're probably viewer, not owner/contributor
   │     → Ask to be added as owner/contributor
   │
   ├─ Tool says "ask your admin" with no admin named
   │     → Ask your manager first, then Privacy Champ
   │
   └─ Completely stuck, no one knows
         → Escalate to Privacy Manager
```

**Template escalation message:**
> "I'm trying to `<action>` in `<tool>` for `<User Story / feature>`. I'm hitting `<error or 'no obvious entry point'>`. I've already asked `<who>`. Who owns access for this?"

---

## 8. What this file does NOT answer

This file is about **operational access**. For **privacy judgment** questions (does this need a review? is this EUII or EUPI? is this safe to sign off?), go to `scenarios.md` or the taxonomy references.

If a question mixes both (e.g., "I have permission to sign this off, but should I?"), answer the **should** part using 04-close.md, not this file.
