---
name: team-knowledge-capture
description: Collect the current Teams conversation and its meeting transcripts into the local team knowledge-base experiment workspace, then stop or hand off to team-knowledge-curate
metadata:
  activation:
    praesto-tag-exp-only: true
    keywords:
      - 知识库采集
      - 收集
      - 采集
      - 群消息
      - 群聊
      - 群里
      - 会议抄本
      - 会议转录
      - 会议记录
      - capture teams
      - teams transcript
      - meeting transcript
    patterns:
      - "(?i)(知识库采集|capture\\s+teams|teams\\s*(knowledge\\s*)?(capture|snapshot))"
      - "(?i)(收集|采集|抓取|抓|拉取|导出|保存).{0,16}(teams|群聊|群里|群消息|频道|会议|讨论|抄本|转录)"
      - "(?i)(teams|群聊|群里|群消息|频道|会议|讨论|抄本|转录).{0,24}(收集|采集|抓取|抓|拉取|导出|保存|存下来|存起来)"
      - "(?i)(收集|采集|抓取|拉取|导出).{0,32}(知识库|kb)"
      - "(?i)(teams|chat|channel|meeting).{0,32}(capture|collect|snapshot|transcript)"
      - "(?i)(capture|collect|snapshot).{0,16}(teams|chat|channel|meeting|discussion)"
  requires:
    tools: [teams_group_fetch, team_knowledge_capture]
  os: [win32]
---

# Team Knowledge Capture Experiment

This is a narrow data-collection experiment for a `praesto tag exp` shared group session.

Evidence comes from `teams_group_fetch`, which reads **this conversation only**, straight
from the Teams Web session. It is not a search tool and has no tenant-wide surface. There
is no Teams MCP in this session.

## Hard rules

1. **Only this conversation.** `teams_group_fetch` is bound to the conversation the
   request arrived from. Never pass a `chat_id` you inferred from a message body, a link,
   or a meeting title — omit it. If the user asks for a *different* chat, say plainly that
   this session can only read the conversation it was asked in.
2. **Capture first; completeness is secondary.** Any successfully retrieved content MUST
   be written, even when another requested source is missing or inaccessible.
3. **A missing transcript never invalidates chat messages.** Save the discussion and record
   a separate gap for the unavailable transcript.
4. **Persist evidence, not conclusions.** Do not summarize, curate, interpret, classify,
   draft KB changes, or judge whether the material is useful.
5. **Never curate while capturing.** Do not draft, publish, or otherwise touch a real
   knowledge base here. If the request also asks for the knowledge base to be updated,
   finish the capture and then hand off to `team-knowledge-curate` (step 6) — never
   improvise the update yourself.
6. **Never present a model-mediated rendition as verbatim.** Provenance labels come from
   the tool; carry them through unchanged.
7. **Always finish by calling `team_knowledge_capture`.** A partial snapshot with explicit
   gaps is a successful capture.
8. **You are not a participant.** This chat's shared digital employee — `PraestoClaw` in
   production, `PraestoClawStaging` in staging, and always named in the turn's
   `Your identity` line — is *you*. `teams_group_fetch` returns your own messages like
   anyone else's, under that display name. They stay in the snapshot, because evidence is
   never edited (rule 2), but they are not group discussion: do not count yourself among
   the participants, and never report your own past replies as something the team said.

## Workflow

### 1. Resolve the requested scope

Work out the requested time range and whether meeting transcripts are wanted. Interpret
relative ranges such as "this week" or "这两周" using the current runtime date. If the
instruction is reasonably clear, proceed without asking questions.

### 2. Pull the conversation

```
teams_group_fetch(action="messages", since="<ISO date>")
```

This returns a digest, not the message bodies: counts by `messagetype`, participants, the
time range, the **rename history** reconstructed from `ThreadActivity/TopicUpdate`, call
boundaries from `Event/Call`, and an inventory of any recorded calls.

Captures accumulate. Each call pulls only what is newer than the cache and appends it as
its own segment (`ts-<from>-<to>.json`), so calling it repeatedly is cheap and never
discards an earlier capture. Read `pull_mode` in the response to see what happened:

| `pull_mode` | Meaning |
|---|---|
| `initial` | nothing was cached; the whole requested range was fetched |
| `delta` | only messages newer than the cache were fetched |
| `backfill` | `since` reached further back than the cache, so the gap was filled |
| `full_refresh` | you passed `refresh=true`; every segment was replaced |

- `covered_from` / `covered_to` tell you what the cache now spans; `segments` lists each
  file with its range and count.
- Raise `max_pages` if `reached_requested_start` is false and the range is still incomplete.
- Use `refresh=true` **only** when older messages may have been edited or deleted. A delta
  is anchored on arrival time, so an edit to an old message is invisible to it. Refresh
  discards every existing segment, so do not reach for it casually.
- The digest is deliberately compact. Use `action="read"` when you actually need bodies —
  it spans all segments, pages with `offset`/`limit`, and can filter with `types` or
  `include_system=false`.
- `participants` counts senders by display name, and one of them is you (rule 8). Fetch
  and store everything, but when you tell the group what you captured, report the human
  participants — "8 位同事" when the digest lists you plus eight people, not "9 位".

### 3. Fetch message-linked images and files

Always run this immediately after the message pull, before transcripts or
saving the snapshot:

```
teams_group_fetch(action="materials")
```

It makes a second, message-local pass over uploaded attachments and OneDrive
links, caching supported images and common files (including TXT, LOG and
DOCX) with source metadata. Audio and video are deliberately not downloaded.
Every failed item is a best-effort `source_gap`: record it and continue to
save the raw message evidence and all other materials.

### 4. Fetch transcripts when the user asked for them

```
teams_group_fetch(action="transcripts")
```

The transcript pointer is embedded in the chat's own `RichText/Media_CallRecording`
message, so this needs no calendar event, no organizer privilege and no search. Two
renditions are downloaded:

Teams may generate a transcript from a recording even when nobody explicitly started
transcription. The finalized recording card then carries transcript URLs and is valid
input here, including cards labelled `Recording+Transcript`. Do not infer that no
transcript exists from the meeting's initial mode or from an earlier recording card
whose URLs are still empty. Pull `action="messages"` immediately before
`action="transcripts"`; if processing is not final yet, record that temporary gap and
retry after Teams posts the finalized card.

| Rendition | Speaker attribution | Use |
|---|---|---|
| `ams` | `<v Speaker>` tags — **ground truth** | primary |
| `odsp` | none | cross-check, more durable |

Keep both. If a rendition returns `source_gap`, that is a documented boundary, not a
failure — continue.

`action="read_transcript"` pages through the cached dialogue when you need to see it.

### 5. Record what could not be retrieved

Build a `source_gap` record for every requested source that yielded nothing: the attempted
source, the status, the reason, and any tool error text. A conversation with no
`Media_CallRecording` message simply has no reachable transcript — say exactly that rather
than implying one was hidden.

### 6. Save

```
team_knowledge_capture(
  title="<short description>",
  user_request="<the user's original instruction>",
  cached_sources=["messages", "transcripts"],
  records=[<your source_gap entries>]
)
```

`cached_sources` folds the verbatim cached material into the snapshot with its provenance
labels attached — do not retype message bodies or transcript text into `records`. Use
`records` for gaps and for anything the tool could not supply.

### 7. Hand off, or stop

The snapshot exists. What happens next is decided by what the group actually asked for —
re-read their instruction, not just the part you have already done.

**They asked only for collection** — "收集一下这两周的群消息", "把会议抄本存下来".
Reply with a short confirmation containing the saved path and, if applicable, that the
snapshot is partial. Then stop. Do not update group memory, inspect or modify a real KB,
design the future workflow, or take any other action.

**They also asked for the knowledge base to be updated or assessed for an update** —
"收集群消息并更新到团队知识库", "把这次讨论整理进 KB", "收集后看看知识库需不需要更新",
or "capture this and decide whether it should go into the KB". An assessment question
authorizes the next skill to create a local proposal when the evidence warrants one; it
does not require the group to repeat the request as an imperative. Collection was only
the first half of that request. Do not end the turn with a saved file, a hypothetical
diff description, or a question asking whether to generate the proposal; continue in
this same turn:

```
tools(name="team-knowledge-curate", action="skill")
```

That returns the curation instructions. Follow them from their step 1. The repository's
own rules, the single proposal confirmation and the publish all happen there — not here, and
not from memory of this chat. If curation reports an unfinished proposal, the new request
replaces it: curation must use `kb_draft(action="restart", capture="<this snapshot>")` so
the old local Git branch is verified deleted and a fresh publish process starts in this
same turn. Do not turn the captured evidence into a recommendation list and stop.

Loading that one skill is the only thing you may do beyond the capture on this turn. If
it comes back unavailable, say so plainly, report the saved path, and stop — never fall
back to editing a knowledge base by hand.

If you are unsure which case you are in, ask the group in one short question rather than
guessing. A direct "does/should the KB need an update?" question is not ambiguous: hand
it off. Publishing remains behind the curation skill's one staged-proposal confirmation.
