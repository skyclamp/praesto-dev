# GitHub Provider Reference

Read this for GitHub PR creation, checks, comments, review threads, and
completion audit.

## Establish

```bash
gh auth status
OWNER="$(gh repo view --json owner -q .owner.login)"
REPO="$(gh repo view --json name -q .name)"
BRANCH="$(git branch --show-current)"
gh pr list --repo "$OWNER/$REPO" --head "$BRANCH" --json number,url,state,title,headRefName,baseRefName
```

Verify referenced issues:

```bash
gh issue view <issue-number> --repo "$OWNER/$REPO" --json number,title,state,url
```

## Create Or Update PR

Create:

```bash
gh pr create --repo "$OWNER/$REPO" --base "$BASE_BRANCH" --head "$BRANCH" --title "$TITLE" --body "$(cat <<'EOF'
## Summary
- ...

## Validation
- `...`

Refs #<issue-number>
EOF
)"
```

Use `Closes #<issue>` or `Fixes #<issue>` only when this PR should close the
issue on merge. Use `Refs #<issue>` or `Part of #<issue>` for non-closing links.

Update or verify:

```bash
gh pr view "$PR" --repo "$OWNER/$REPO" \
  --json number,url,state,isDraft,mergeStateStatus,reviewDecision,statusCheckRollup,closingIssuesReferences,latestReviews,baseRefName,headRefName

gh pr edit "$PR" --repo "$OWNER/$REPO" \
  --title "$TITLE" \
  --body-file "$PR_BODY_FILE"
```

If repo-local instructions require GitHub project board updates or Copilot
review requests, execute those instructions after PR creation.

## CI

```bash
gh pr checks "$PR" --repo "$OWNER/$REPO"
gh pr view "$PR" --repo "$OWNER/$REPO" \
  --json mergeStateStatus,reviewDecision,isDraft,state,statusCheckRollup
```

For a failing check, inspect the exact run and job logs:

```bash
gh run view <run-id> --repo "$OWNER/$REPO" --json jobs
gh run view <run-id> --repo "$OWNER/$REPO" --job <job-id> --log
```

After each pushed fix, start a fresh monitor round with the commands above; do
not reuse stale check or review state from before the push.

## Comments And Threads

Fetch PR conversation comments, inline comments, and reviews:

```bash
gh pr view "$PR" --repo "$OWNER/$REPO" --comments
gh api --paginate --slurp "repos/$OWNER/$REPO/issues/$PR/comments"
gh api --paginate --slurp "repos/$OWNER/$REPO/pulls/$PR/comments"
gh pr view "$PR" --repo "$OWNER/$REPO" --json latestReviews,reviewDecision
```

Fetch review threads with pagination. Do not stop after the first page. If a
thread has more than 50 comments, fetch that thread's comments separately before
deciding it is resolved or obsolete:

```bash
gh api graphql \
  -f owner="$OWNER" -f name="$REPO" -F number="$PR" \
  -f query='query($owner:String!,$name:String!,$number:Int!,$cursor:String){repository(owner:$owner,name:$name){pullRequest(number:$number){reviewThreads(first:100,after:$cursor){pageInfo{hasNextPage endCursor}nodes{id,isResolved,isOutdated,path,line,comments(first:50){nodes{id,author{login},body,url,createdAt}}}}}}}'
```

Repeat the query with `-f cursor="$END_CURSOR"` while `hasNextPage` is true.

Reply to a PR-level comment:

```bash
gh pr comment "$PR" --repo "$OWNER/$REPO" --body "<reply>"
```

PR-level comments do not have a review-thread resolve action. After replying,
re-fetch PR comments and treat the item as handled only if the reply clearly
answers the actionable point.

Reply to and resolve a review thread:

```bash
gh api graphql -f threadId="$THREAD_ID" -f body="$REPLY" \
  -f query='mutation($threadId:ID!,$body:String!){addPullRequestReviewThreadReply(input:{pullRequestReviewThreadId:$threadId,body:$body}){comment{id,url}}}'

gh api graphql -f threadId="$THREAD_ID" \
  -f query='mutation($threadId:ID!){resolveReviewThread(input:{threadId:$threadId}){thread{id,isResolved}}}'
```

For a review thread, run `resolveReviewThread` after the fix is pushed or the
reply is sufficient. Do not leave handled threads unresolved. Re-run the
review-thread query and verify the thread reports `isResolved: true`; if it
still appears unresolved, continue handling it before the completion audit.

For comment- or CI-driven fixes, follow the shared decision policy in
`SKILL.md`; keep this provider reference focused on live GitHub state and
commands.

## Completion Audit

```bash
gh pr checks "$PR" --repo "$OWNER/$REPO"
gh pr view "$PR" --repo "$OWNER/$REPO" \
  --json number,url,state,mergedAt,mergeCommit,closingIssuesReferences,reviewDecision,statusCheckRollup,latestReviews,baseRefName,headRefName
```

Repeat the PR comment and review-thread queries. Prove no unresolved actionable
feedback remains, every handled review thread is resolved, and every handled
PR-level comment has an explicit reply.
