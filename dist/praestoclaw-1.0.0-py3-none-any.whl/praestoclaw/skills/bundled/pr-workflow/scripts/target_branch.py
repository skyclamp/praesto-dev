#!/usr/bin/env python3
"""Get or set the PR target branch for a project."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse


MISSING_TARGET_BRANCH = 1
FATAL_ERROR = 2


def _run_git(args: list[str], cwd: Path | None = None) -> str:
    command = ["git"]
    if cwd is not None:
        command.extend(["-C", str(cwd)])
    command.extend(args)
    return subprocess.check_output(command, text=True, stderr=subprocess.PIPE).strip()


def resolve_project_root(root: str | None) -> Path:
    if root:
        candidate = Path(root).expanduser().resolve()
        return Path(_run_git(["rev-parse", "--show-toplevel"], cwd=candidate)).resolve()
    return Path(_run_git(["rev-parse", "--show-toplevel"])).resolve()


def _strip_dot_git(path: str) -> str:
    return path[:-4] if path.endswith(".git") else path


def _normalize_remote_url(url: str) -> str | None:
    if url.startswith("git@") and ":" in url:
        host, path = url[4:].split(":", 1)
        path_parts = [_strip_dot_git(unquote(part)) for part in path.strip("/").split("/") if part]
        if not path_parts:
            return None
        if host == "ssh.dev.azure.com" and len(path_parts) >= 4 and path_parts[0] == "v3":
            return "dev.azure.com/" + "/".join(path_parts[1:4])
        return f"{host}/" + "/".join(path_parts)

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https", "ssh"} or not parsed.netloc:
        return None

    host = parsed.hostname or parsed.netloc
    path_parts = [
        _strip_dot_git(unquote(part)) for part in parsed.path.strip("/").split("/") if part
    ]

    if host == "ssh.dev.azure.com" and len(path_parts) >= 4 and path_parts[0] == "v3":
        return "dev.azure.com/" + "/".join(path_parts[1:4])

    if (host == "dev.azure.com" or host.endswith(".dev.azure.com")) and len(path_parts) >= 4 and path_parts[2] == "_git":
        return f"{host}/{path_parts[0]}/{path_parts[1]}/{path_parts[3]}"

    if (host == "visualstudio.com" or host.endswith(".visualstudio.com")) and len(path_parts) >= 3 and path_parts[1] == "_git":
        return f"{host}/{path_parts[0]}/{path_parts[2]}"

    if len(path_parts) >= 2:
        return f"{host}/" + "/".join(path_parts[:2])

    return None


def _default_remote_name(project_root: Path) -> str | None:
    try:
        upstream = _run_git(
            ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}"],
            cwd=project_root,
        )
        if "/" in upstream:
            return upstream.split("/", 1)[0]
    except subprocess.CalledProcessError:
        pass

    remotes = _run_git(["remote"], cwd=project_root).splitlines()
    if "origin" in remotes:
        return "origin"
    return remotes[0] if remotes else None


def default_project_name(project_root: Path, remote_name: str | None = None) -> str:
    remote_name = remote_name or _default_remote_name(project_root)
    if remote_name:
        remote_url = _run_git(["remote", "get-url", remote_name], cwd=project_root)
        normalized = _normalize_remote_url(remote_url)
        if normalized:
            return normalized
    return project_root.name


def resolve_project_name(
    project_root: Path,
    project_name: str | None,
    remote_name: str | None,
) -> str:
    if project_name:
        return project_name
    return default_project_name(project_root, remote_name)


def config_path() -> Path:
    return Path.home() / ".pr-workflow" / "config.json"


def read_config(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as f:
        config = json.load(f)
    if not isinstance(config, dict):
        raise ValueError("config.json must contain a JSON object")
    return config


def write_config(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, suffix=".tmp", prefix="config_")
    tmp_path = Path(tmp_name)
    try:
        with open(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, sort_keys=True)
            f.write("\n")
        tmp_path.replace(path)
    except BaseException:
        tmp_path.unlink(missing_ok=True)
        raise


def resolve_context(args: argparse.Namespace) -> tuple[Path, str]:
    root = resolve_project_root(args.root)
    return root, resolve_project_name(root, args.project_name, args.remote)


def get_target_branch(config: dict[str, Any], project_name: str) -> str | None:
    branches = config.get("branches", {})
    if not isinstance(branches, dict):
        raise ValueError("config.json field 'branches' must be an object")
    value = branches.get(project_name)
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise ValueError(f"target branch for {project_name!r} must be a non-empty string")
    return value


def set_target_branch(config: dict[str, Any], project_name: str, target_branch: str) -> None:
    if not target_branch:
        raise ValueError("target branch must be non-empty")
    branches = config.setdefault("branches", {})
    if not isinstance(branches, dict):
        raise ValueError("config.json field 'branches' must be an object")
    branches[project_name] = target_branch


def command_get(args: argparse.Namespace) -> int:
    _, project_name = resolve_context(args)
    config = read_config(config_path())
    target_branch = get_target_branch(config, project_name)
    if target_branch is None:
        return MISSING_TARGET_BRANCH
    print(target_branch)
    return 0


def command_set(args: argparse.Namespace) -> int:
    _, project_name = resolve_context(args)
    path = config_path()
    config = read_config(path)
    set_target_branch(config, project_name, args.base)
    write_config(path, config)
    return 0


def add_project_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--root", help="Project root. Defaults to git root.")
    parser.add_argument(
        "--remote",
        help="Remote used to derive the default config key. Defaults to upstream/origin.",
    )
    parser.add_argument(
        "--project-name",
        help=(
            "Config key under branches. Defaults to normalized remote identity, "
            "falling back to the git root directory name."
        ),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    get_parser = subparsers.add_parser(
        "get",
        help="Print only the configured target branch.",
    )
    add_project_args(get_parser)
    get_parser.set_defaults(func=command_get)

    set_parser = subparsers.add_parser(
        "set",
        help="Save the target branch for this project.",
    )
    add_project_args(set_parser)
    set_parser.add_argument(
        "--base",
        required=True,
        help="Default PR target/base branch for this project.",
    )
    set_parser.set_defaults(func=command_set)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return args.func(args)
    except (OSError, subprocess.CalledProcessError, json.JSONDecodeError, ValueError) as exc:
        msg = str(exc)
        if isinstance(exc, subprocess.CalledProcessError) and exc.stderr:
            msg = f"{msg}: {exc.stderr.strip()}"
        print(f"target_branch.py: {msg}", file=sys.stderr)
        return FATAL_ERROR


if __name__ == "__main__":
    raise SystemExit(main())
