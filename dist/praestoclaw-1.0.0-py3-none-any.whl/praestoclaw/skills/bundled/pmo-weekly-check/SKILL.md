---
name: pmo-weekly-check
description: "Use in PraestoClaw private chat or group chat for PMO weekly project documentation closeout: organize the ending week, @mention needed follow-ups, and run PMO grill pre-send self-check."
metadata:
  activation:
    keywords:
      - PMO weekly check
      - PMO 周检查
      - PMO 周报
      - 每周项目整理
      - 周文档归档
      - 周度风险检查
      - weekly PMO
      - weekly project closeout
      - weekly report knowledge base
    patterns:
      - "(?i)(pmo).{0,16}(weekly|week|周|周报|周检查|周度)"
      - "(?i)(每周|周度|本周|上周).{0,20}(pmo|项目).{0,20}(整理|归档|检查|周报|close)"
      - "(?i)(weekly).{0,20}(project|pmo).{0,20}(report|archive|closeout|check)"
      - "(?i)(整理|归档|关闭|close).{0,20}(本周|上周|周文档|weekly).{0,20}(知识库|kb|周报)"
  os: [win32]
  safe-tools:
    - tool: kb_scope
      match:
        action: "^show$"
    - tool: kb_inspect
      match:
        action: "^repos$"
    - tool: kb_inspect
      match:
        action: "^sync$"
    - tool: kb_inspect
      match:
        action: "^rules$"
    - tool: kb_inspect
      match:
        action: "^tree$"
    - tool: kb_inspect
      match:
        action: "^read$"
    - tool: kb_inspect
      match:
        action: "^search$"
    - tool: kb_change_history
      match:
        action: "^latest$"
    - tool: kb_change_history
      match:
        action: "^show$"
    - tool: kb_change_history
      match:
        action: "^file$"
---

# PMO Weekly Check

Use this skill in a direct PraestoClaw private chat or in the relevant project
group chat. It performs weekly project documentation closeout, generates the
weekly report, uses `pmo-grill` only as a pre-send self-check on that report,
and reports any recommended KB follow-up without writing to the KB.

## Conversation visibility

Keep the visible chat quiet. Keep internal plan progress, checklist progress,
step-by-step verification messages, and background status cards out of the
visible conversation. The user should see only the weekly closeout/report draft,
concise missing-evidence requests/reminders, PMO focus items, and source-read
status when KB/source access is blocked.

When the weekly result is going to Teams/cloud, mention every distinct human
owner/member represented in the weekly report or follow-up list, not only the
sender and not only rows with missing closeout. Send the result with
`notify(channel="cloud", content="...", teams_mentions=[...])` so the `@Name`
placeholders become real Teams mentions. Each mention item should include the
best available `name`, `upn`, or `id` from KB/person metadata. If only a display
name is available, include `{"name": "<display name>"}` so the channel layer can
attempt best-effort resolution. Plain `@Name` text is only a fallback when
mention metadata is unavailable. Do not use a broad `type="all"` mention unless
the user explicitly asks to mention everyone as a Teams-wide mention.

For owner-specific follow-ups, show a compact, copyable `pmo-grill` prompt under
that owner/goal. The group-visible message should show the owner, goal, missing
evidence, due date, and then the full prompt in a code block labelled `PMO grill
prompt`. The prompt must be self-contained so the owner can copy it into their
private chat and continue with `pmo-grill` without relying on group-chat history.

## Permission and approval model

Follow the same KB permission model as `pmo-grill`: KB tools are optional
capabilities for discovery and stay out of hard `requires.tools`. Safe KB read/discovery
actions are declared in `safe-tools`; KB write actions are outside this skill.
Use `kb_scope show`,
`kb_inspect` repos/sync/rules/tree/read/search, and `kb_change_history`
latest/show/file as the only KB read path. These KB read/discovery actions,
including `kb_inspect(action="sync")` even when it creates or updates the local
checkout, must run without interactive human approval. Do not ask the user to
approve KB reads, and do not substitute `shell`, `git`, `Remove-Item`, `curl`, or
filesystem commands for KB read/sync/discovery work. If a safe KB read tool is
missing or refused, report that exact capability as blocked and ask for the
needed KB text/link instead of requesting a shell approval. Do not call
KB write or KB binding mutation tools from weekly check.

## External source boundary

Default evidence sources are the configured KB, the current PraestoClaw turn,
and text or links the user explicitly provides in this weekly-check conversation.
Do not call Teams, M365 Copilot, M365 user, mail, calendar, SharePoint, WorkIQ,
or similar external MCP tools to inventory work, resolve people, search chat
history, inspect meetings, or fill missing evidence unless the current user
explicitly asks for that external search in this turn.

In particular, do not use or discover tools such as `MCP_teams_*`,
`MCP_m365-copilot_*`, `MCP_m365-user_*`, `MCP_mail_*`, `MCP_calendar_*`,
`MCP_sharepoint_*`, `MCP_workiq_*`, `teams_group_fetch`, or
`team_knowledge_capture` for a normal PMO weekly check. If the user explicitly
asks to search Teams/M365, keep that search narrowly scoped to the named chat,
person, meeting, date range, or message link, and label the result as external
evidence. Otherwise preserve missing material as an unresolved evidence gap,
carry-over item, or incomplete closeout instead of trying to recover it from
Teams/M365.

For follow-up mentions, use mention metadata already present in the KB or in the
current turn. Do not query Teams/M365 only to resolve a mention; fall back to
plain `@Name` text when structured mention metadata is unavailable.

Weekly check does not write KB content. Include a concise `Recommended KB
follow-up` section only when the available evidence shows a weekly/progress row
should be updated by a later `pmo-grill` run or a human maintainer.

## Mandatory preflight

Before weekly work starts, perform the same KB preflight as `pmo-grill`:

1. Run `kb_scope(action="show")`.
2. If no KB is configured and the current user provided a GitHub URL under
  `gim-home/SocietasKnowledgeBase/tree/main/...`, derive the repo and subfolder
  for this run without saving a conversation binding. Ask the user for a KB URL
  or PMO folder scope only when no KB binding and no usable KB URL are present.
3. Run `kb_inspect(action="sync")` so a missing clone is created and an existing
  checkout is updated to the latest remote state. This is a safe KB read/sync
  action and must not be replaced by an approval-gated shell/git command.
4. If a KB capability is unavailable in the current chat context, keep the weekly
  check moving. Ask the user for the KB URL or PMO folder scope when the
  destination cannot be resolved, continue from that provided source, and mark
  only the unavailable capability as blocked. Report the exact blocked
  capability: binding, live sync, or read.

## Reminder semantics

The weekly check message itself is the reminder. Send the check result without
waiting for member responses inside this skill. Read previous daily/weekly PMO
records and check whether each requested evidence/update has been supplied. Carry
unresolved items forward and increment or state the reminder count.

Every missing closeout/evidence row must @mention the responsible member when a
mention form is known, using the same spelling supplied by the KB or current
conversation. Example: `@Member：请在 <date/time> 前补 <goal> 的 closing evidence；这是第 2 次提醒。`

If a member replies later, the next daily/weekly check should detect the new
evidence or owner update and close or carry forward the follow-up in the next
report. Keep the current weekly check on its scheduled path.

## Mentions and follow-up list

After the weekly report, list exactly who still needs to do what. Mention the
member in the same spelling the KB or current conversation provides, using
`@Name` in the content and a matching item in `teams_mentions` whenever a
structured mention form is known. Include the reminder count when the same
missing closeout/update was already requested in a prior check:

- `@Member`: provide closing evidence for `<goal>` by `<date>`; reminder #N.
- `@Member`: confirm carry-over risk/mitigation for `<goal>` by `<date>`; reminder #N.
- `@Member`: make the weekly go/no-go or ship/no-ship decision for `<goal>` by `<date>`; reminder #N.
- `@Member`: unblock dependency with `<team/person>` by `<date>`; reminder #N.

The weekly report itself must also use the visible `@Name` form for each owner
or member row, and the `teams_mentions` array must contain one object for every
distinct mentioned human. If the same person appears in multiple rows, mention
them once in `teams_mentions` and use the same visible spelling everywhere.

When the weekly result contains any member row or follow-up, deliver the weekly
result through `notify(channel="cloud", content="...", teams_mentions=[...])`. The
`content` must contain the visible `@Name` text, and each `teams_mentions` item
must identify the same person with the best available `name`, `upn`, or `id`.
Use one mention object per mentioned member, for example:

```json
[
  {"name": "Coraline Gao", "upn": "cogao@microsoft.com"},
  {"name": "Wenkai Jiang", "upn": "wenkaij@microsoft.com"}
]
```

If only a display name is available, include `{"name": "<display name>"}` so
the channel layer can attempt best-effort resolution. If no structured mention
metadata is available, keep the visible `@Name` text and state in the report
that the follow-up used a plain-text mention fallback.

For each follow-up item, show a `PMO grill prompt` code block so the member can
copy it and update just that item without figuring out the prompt shape:

```text
Use pmo-grill: 执行 pmo grill skill，source="weekly", week="<YYYY-Www or date range>", owner="<owner>", goal="<goal>", 缺口="<missing update/evidence>", 风险="<weekly risk>", next_action="<requested action>", due="<date>", reminder_count=<N>, KB="<repo/subfolder or URL>"。
```

For each owner follow-up, provide one visible prompt per owner/goal. If a person
who is not the named owner uses the copied prompt, `pmo-grill` will ask a
delegation question before continuing.

When the member runs that prompt, `pmo-grill` should filter to that current-user
goal, ask only the missing facts needed for risk judgment, and write the result
back to KB according to grill's approval rules.

## Handoff to PMO grill

Weekly check creates the follow-up queue; `pmo-grill` resolves one follow-up at a
time with the responsible current user. Treat the weekly-to-grill link as a
structured handoff contract.

For every `carry-over` or `insufficient` row that needs owner input, include a
one-line handoff directly under that row or in the follow-up list:

```text
Use pmo-grill: 执行 pmo grill skill，source="weekly", week="<YYYY-Www or date range>", owner="<owner>", goal="<goal>", 缺口="<missing update/evidence>", 风险="<weekly risk>", next_action="<requested action>", due="<date>", reminder_count=<N>, KB="<repo/subfolder or URL>"。
```

Populate the fields from the weekly row rather than inventing new scope. Keep
`goal` as the stable key, keep `缺口` specific enough to drive grill's first
question, and include `KB` so grill can bind to the same repository or folder.
When a field is unknown, write `not provided` instead of omitting the field.

After a member uses the handoff, `pmo-grill` should read the same KB scope,
filter to that owner/goal pair, ask only the missing facts named in `缺口`, and
write back the focused result under grill's approval rules. Weekly's next run
then reads that KB update and either closes the follow-up or increments the
reminder count. This keeps the loop: weekly identifies and reminds; grill
collects accountable owner evidence; weekly closes or carries forward.

## Weekly workflow

1. Determine the ending week. Use the current runtime date when the user says
   "this week", "last week", or equivalent. If the week boundary is ambiguous,
   ask one short question.
2. Inventory the week's project material:
   - goals committed for the week;
   - documents, PRs, issues, demos, release/deploy notes, test evidence, meeting
     decisions, customer/user signals, and metrics;
   - open risks, closed risks, new blockers, escalations, and carried-over work;
   - documents that should be closed, archived, or marked superseded.
3. Organize the week into three buckets:
   - `closed`: finished work with evidence and no further weekly follow-up;
   - `carry-over`: still active work with owner, next action, date, and risk;
   - `insufficient`: claims or tasks without enough evidence to close or assess.
4. Generate a weekly report draft suitable for KB curation:
   - week range and project scope;
   - completed goals and evidence;
   - carried-over goals and next checkpoints;
   - risk changes since the previous weekly check;
   - decisions made and open decisions needed;
   - evidence gaps and owners;
  - PMO focus for the next week;
  - `Use pmo-grill` handoff lines for each owner follow-up that needs focused
    current-user evidence collection.
5. Before sending the weekly report, apply
  the `pmo-grill` evidence standard as an inline self-check on the draft. Use
  the standard directly inside weekly check: every closeout/carry-over/risk row
  needs status versus expectation,
   evidence or evidence gap, blocker/dependency, next action with date, risk
  reason, and recommended follow-up.
6. If the self-check finds a defect, revise the draft before sending. Ask a new
  question only when the defect makes the weekly report materially misleading
  and the row cannot be represented as incomplete, carried-over, or unresolved
  risk.
7. Close the ended week's documents logically in the report. Mark work complete
  when evidence supports completion. For unfinished work, name the carry-over
  owner and checkpoint.
8. After sending the weekly closeout/report, stop. Weekly check remains
  read-only and keeps any KB follow-up as a recommendation in the chat response.

## Weekly close criteria

The ended week is closeable only when all of these are true:

- every completed item has concrete evidence;
- every carry-over item has owner, next action, and date;
- every red/yellow risk has reason, mitigation, owner, and PMO follow-up;
- unresolved evidence gaps are listed with accountable people;
- the report distinguishes facts from PMO judgment.

If these criteria are not met, revise the weekly report so the missing criteria
are explicit. Ask targeted follow-up questions only when the report would
otherwise mislead the group; if the user cannot provide more information, close
the week as `incomplete` and preserve the missing evidence list.

## Recommended KB follow-up

Weekly check itself does not update the KB:

1. Read KB/source material only as needed to generate the weekly closeout view.
2. Provide the weekly report, carry-over list, and exact recommended KB updates
  in the chat response when useful.
3. Use `pmo-grill` handoff lines for owner-specific evidence collection and KB
  updates.
