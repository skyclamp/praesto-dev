---
name: azure-ops
description: Azure resource management via az CLI — groups, VMs, storage, deployments, monitoring
metadata:
  activation:
    keywords: [resource group, app service, aks]
    patterns:
      - "(?i)\\baz\\s+(group|vm|webapp|storage|aks|account|deployment|monitor|network|sql|login)\\b"
      - "(?i)\\bazure\\s+(vm|storage|webapp|aks|function|monitor|sql|redis|resource)\\b"
      - "(?i)\\b(deploy|provision)\\s+(to|on)\\s+azure\\b"
      - "(?i)\\bresource\\s+group\\b"
  requires:
    bins: [az]
  superseded-by:
    tools: [MCP_azure]
  # Positive whitelist of `az` commands that are safe to chain without per-call
  # approval.  Limited to subscription / topology / metadata reads that DO NOT
  # return secrets.
  #
  # Tail anchor `(?:[ \t][^;|&$`<>\n\r]*)?\Z` (CONSUMING under fullmatch)
  # does FOUR things at once:
  #   * keeps hyphen-extension verbs out (e.g. `show-connection-string`
  #     can't piggy-back on a `show` whitelist row).
  #   * lets legitimate trailing args through (e.g. `az account list -o
  #     json`) under ``re.fullmatch`` semantics.
  #   * leading ``[ \t]`` (NOT ``\s``) rejects newline/CR injection so
  #     ``az account show\nrm -rf /`` cannot bypass.
  #   * ``[^;|&$`<>\n\r]+`` rejects shell metacharacters in the tail so
  #     compound chains like ``az account show; az keyvault secret show
  #     ...`` cannot bypass.
  # Inter-token separators also use ``[ \t]+`` (not ``\s+``) so the
  # rejected-character set is uniform across the whole regex — a single
  # ``\n`` anywhere disqualifies the call.
  # Anything not listed here intentionally falls through to normal scoring.
  safe-tools:
    # Subscription / tenant / CLI metadata (no secrets).
    - tool: shell
      match:
        command: "^az[ \\t]+account[ \\t]+(show|list|list-locations|tenant[ \\t]+list)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    - tool: shell
      match:
        command: "^az[ \\t]+(version|--version|--help)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    # Resource topology — no -keys / -credentials / connection-string verbs.
    - tool: shell
      match:
        command: "^az[ \\t]+(group|resource|deployment|provider|feature|policy)[ \\t]+(show|list)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    # Compute / network read-only descriptors.
    - tool: shell
      match:
        command: "^az[ \\t]+(vm|vmss|disk|snapshot|image|nic|nsg|public-ip|lb|vnet)[ \\t]+(show|list|list-ip-addresses|list-skus|list-usage)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    # Storage / app-service metadata (excludes `keys list`, `show-connection-string`).
    - tool: shell
      match:
        command: "^az[ \\t]+storage[ \\t]+account[ \\t]+(show|list|check-name|show-usage)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    - tool: shell
      match:
        command: "^az[ \\t]+(webapp|functionapp|appservice|aks|containerapp)[ \\t]+(show|list|list-runtimes|list-locations)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
    # Monitoring / log queries — read-only by definition.
    - tool: shell
      match:
        command: "^az[ \\t]+monitor[ \\t]+(metrics[ \\t]+list|activity-log[ \\t]+list|log-analytics[ \\t]+query|alert[ \\t]+list|diagnostic-settings[ \\t]+list)(?:[ \\t][^;|&$`<>\\n\\r]*)?\\Z"
---
## Azure CLI Operations

Use the `shell` tool with `az` CLI commands.

Before running az commands, verify authentication by running `az account show`. If it fails, prompt the user to run `az login`.

### Account & Subscription
```
az account show -o json
az account list -o json
az account set --subscription "{NAME_OR_ID}"
```

### Resource Groups
```
az group list -o json
az group show --name {NAME} -o json
az group create --name {NAME} --location {LOCATION} -o json
az group delete --name {NAME} --yes
```

### Virtual Machines
```
az vm list -o json
az vm show --resource-group {RG} --name {VM} -o json
az vm create --resource-group {RG} --name {VM} --image Ubuntu2204 --admin-username azureuser --generate-ssh-keys -o json
az vm start --resource-group {RG} --name {VM}
az vm stop --resource-group {RG} --name {VM}
az vm deallocate --resource-group {RG} --name {VM}
```

### App Service / Web Apps
```
az webapp list -o json
az webapp show --resource-group {RG} --name {APP} -o json
az webapp create --resource-group {RG} --plan {PLAN} --name {APP} --runtime "PYTHON:3.12" -o json
az webapp deploy --resource-group {RG} --name {APP} --src-path {ZIP} --type zip
az webapp log tail --resource-group {RG} --name {APP}
```

### Storage
```
az storage account list -o json
az storage account show --name {ACCOUNT} -o json
az storage account create --name {ACCOUNT} --resource-group {RG} --sku Standard_LRS -o json
az storage blob list --account-name {ACCOUNT} --container-name {CONTAINER} -o json
```

### AKS (Kubernetes)
```
az aks list -o json
az aks show --resource-group {RG} --name {CLUSTER} -o json
az aks get-credentials --resource-group {RG} --name {CLUSTER}
```

### Deployments
```
az deployment group list --resource-group {RG} -o json
az deployment group create --resource-group {RG} --template-file {FILE} --parameters {PARAMS} -o json
```

### Monitor & Logs
```
az monitor activity-log list --resource-group {RG} -o json
az monitor metrics list --resource {RESOURCE_ID} --metric "Percentage CPU" -o json
```

### Guidelines
- Always use `-o json` for structured output
- Use `--query` (JMESPath) to filter large results: `--query "[].{name:name, location:location}"`
- Read operations (list, show, get) are low-risk
- Write operations (create, update, delete, start, stop) are medium-risk — confirm with user
- Dangerous operations (group delete, vm delete) are high-risk — always confirm
- Avoid `az ad`, `az role`, `az policy`, `az lock` unless explicitly requested (security-sensitive)
- The az CLI must be installed and authenticated: `az login`
