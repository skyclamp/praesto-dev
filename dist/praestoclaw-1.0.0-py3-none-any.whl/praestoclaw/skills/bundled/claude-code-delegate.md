---
name: claude-code-delegate
description: Delegate coding tasks to Claude Code (Agent SDK) for parallel execution — code, review, test, refactor, research
metadata:
  activation:
    keywords: [claude code, claude delegate, delegate to claude, claude review, claude refactor, claude test, claude research]
    patterns: ["(?i)\\bclaude\\s+(code|delegate)\\b", "(?i)\\bdelegate\\s+to\\s+claude\\b", "(?i)\\buse\\s+claude\\s+(to|for)\\b"]
  requires:
    tools: [claude_code]
---
## Claude Code Delegate

You have access to the `claude_code` and `claude_code_status` tools for delegating tasks to Claude Code via the Agent SDK.

### Authentication
Claude Code uses Anthropic's own auth (Claude subscription: Max/Pro/Team/Enterprise) or `ANTHROPIC_API_KEY`.
The SDK (`claude-agent-sdk`) includes the CLI — no separate binary install needed.

### When to use `claude_code`
- Code tasks: bug fixes, feature implementations — Claude Code has Bash, Edit, Read, Grep, Glob tools
- Code review: audit files for bugs, security issues, style violations
- Test writing: generate or expand tests using the existing test framework
- Refactoring: restructure code without changing behaviour
- Research: deep codebase exploration and analysis with specific code references
- Parallel work: submit multiple background tasks that run concurrently

### Available Claude Code Plugins
When delegating, Claude Code has these Agency plugins enabled via `.claude/settings.local.json`.
For PR reviews, prefer `task_type="review"` — this automatically instructs Claude to use the
plugin skills (`/review-pr`, `/code-review`) for structured analysis.

| Plugin | Skill | Use case |
|--------|-------|----------|
| pr-review-toolkit | `/review-pr` | Full PR review workflow — diff analysis, inline comments, verdict |
| code-review | `/code-review` | Deep code review — bugs, security, performance, style |
| security-guidance | — | Security best-practice analysis |
| feature-dev | `/feature-dev` | Feature development workflow |
| commit-commands | `/commit`, `/commit-push-pr` | Git commit helpers |
| playwright | — | Browser automation and testing |
| github | — | GitHub PR/issue integration |
| skill-creator | — | Create new skills |

Plugin-based PR review (posts inline comments per file/issue):
```
claude_code(
    task=(
        "Review PR #1425603 in repo infrastructure_web_adminportal-ui. "
        "Use the /review-pr plugin skill to analyse the diff. "
        "POST INLINE comments to: "
        "https://dev.azure.com/org/project/_apis/git/repositories/REPO_ID/"
        "pullRequests/PR_ID/threads?api-version=7.1 "
        "For each issue, use threadContext to pin the comment to the file "
        "and line: {comments: [{parentCommentId: 0, "
        "content: '[PraestoClaw Review] ...'}], status: 1, "
        "threadContext: {filePath: '/path/to/file', "
        "rightFileStart: {line: 42, offset: 1}, "
        "rightFileEnd: {line: 42, offset: 1}}} "
        "Then post a final summary thread (no threadContext) with verdict."
    ),
    task_type="review",
    mode="background",
    model="sonnet",
)
```

The ADO threads API `threadContext` field pins comments to specific file locations:
- `filePath`: path relative to repo root, prefixed with `/`
- `rightFileStart` / `rightFileEnd`: line range on the right (new) side of the diff
- `status: 1` = active (reviewer must resolve), `status: 4` = closed (informational)

### How to delegate

Background task (returns immediately, notifies when done):
```
claude_code(
    task="Review praestoclaw/security/ for bugs and security issues",
    task_type="review",
    files=["praestoclaw/security/"],
    mode="background",
    model="sonnet"
)
```

Wait mode (blocks, returns result inline — use for quick tasks):
```
claude_code(
    task="Add docstrings to all public methods in praestoclaw/bus/queue.py",
    task_type="code",
    files=["praestoclaw/bus/queue.py"],
    mode="wait",
    model="sonnet"
)
```

Read-only research (restrict tools for safety):
```
claude_code(
    task="How does the message bus handle backpressure?",
    task_type="research",
    allowed_tools=["Read", "Grep", "Glob"],
    mode="wait",
    model="sonnet"
)
```

Parallel fan-out (submit multiple background tasks):
```
claude_code(task="Review auth module", task_type="review", files=["praestoclaw/security/"], mode="background")
claude_code(task="Write tests for bus module", task_type="test", files=["praestoclaw/bus/"], mode="background")
claude_code(task="Refactor config loading", task_type="refactor", files=["praestoclaw/config/"], mode="background")
```

### Model selection
- Use sonnet (default) for most tasks — good balance of quality and speed
- Use opus for complex architectural reviews or large refactors
- Never use haiku for code tasks — quality is insufficient

### Check status
```
claude_code_status()                    # list all tasks
claude_code_status(task_id="abc123")    # check specific task
```
