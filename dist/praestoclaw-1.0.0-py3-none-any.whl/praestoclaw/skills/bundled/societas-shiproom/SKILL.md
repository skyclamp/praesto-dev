---
name: societas-shiproom
description: "Run the Societas weekly shiproom from any IDE. Cloud-first — all meeting data lives in a Teams channel SharePoint folder, accessed through Microsoft Graph. Commands /sr-update, /sr-notes, /sr-prep, /sr-archive, /sr-ask work identically on every host. Triggers — shiproom, weekly status, release review, prep meeting, archive meeting, ask history, install, reinstall, update, enable."
---

# Societas Shiproom Skill

> **Playbook lookup (MANDATORY).** When the user invokes `/sr-update`, `/sr-prep`, `/sr-archive`, or `/sr-ask`, you MUST read `framework/rules/{update,prep,archive,ask}.md` before acting. The entry files (this `SKILL.md` + `AGENT.md`) only summarize; `framework/rules/*.md` is the source of truth for behavior.

> **ON-LOAD BEHAVIOR (MANDATORY, OVERRIDES HOST DEFAULTS).** The very first reply this skill produces in any chat session — including immediately after install/reinstall/update, and including replies to bare "好" / "好的" / "ok" / "继续" / any non-/sr- message — MUST be the verbatim Chinese greeting in the "⚠️ FIRST CONTACT" section below. No "已安装" / "已重新安装" / "skill is installed" / "next suggestion" wrappers. The greeting itself is the install confirmation. Do not summarize, do not paraphrase, do not add tool calls before it.

## ⚠️ FIRST CONTACT — send this verbatim, in Chinese, as the WHOLE reply

**Trigger (whichever comes first wins, fire ONCE per chat session):**
- The skill has just been installed / reinstalled / updated / enabled / activated, AND any user message follows (even just "好" / "好的" / "ok" / "继续" / "试试" / "下一步").
- The user's first message after skill load mentions installing/enabling/updating/applying this skill.
- The user types `/sr-help` / `/sr` / `/shiproom` / bare `shiproom`.
- ANY first substantive user turn after the skill becomes available, if no greeting has been sent yet in this session.

**Hard rules:**
- The greeting block below IS the WHOLE reply. Nothing before. Nothing after.
- Do NOT prepend "✅ 已安装成功" / "已重新安装为最新版本" / "skill is installed and applied" — those are HOST installer messages, not yours; replace them with the greeting.
- Do NOT append "下一步建议：试试 /sr-prep 或 /sr-update" — the greeting already ends with a path-picker.
- Do NOT call any tool first. Do NOT search the workspace first.
- After sending it once in this session, mark internally as greeted; subsequent turns proceed normally.

> ✅ **Societas Shiproom 已就绪。**
>
> 这个 skill 让你直接在 IDE 里跑团队的每周 shiproom，所有数据都在 SharePoint 上（[Societas / Shiproom channel / Files / Shiproom/](https://microsoftapc.sharepoint.com/teams/Societas/Shared%20Documents/Shiproom)），不用本地存数据。
>
> **你能做什么：**
> - 🟢 **会前** —— 任何成员用 `/sr-update` 提交自己负责的章节；host 用 `/sr-prep` 把 Loop、数据快照、OCV 快照和会前总结一起准备到 `current/`。
> - 🟡 **会中** —— 用 `/sr-notes` 实时记录决策，自动签上你的名字。
> - 🔵 **会后** —— host 用 `/sr-archive` 先从 Teams meeting/chat 抓最新 notes，再把 `current/` 归档到 `history/<日期>/` 并清空，准备下一周。
> - 🔎 **任何时候** —— 用 `/sr-ask` 提问，我会从 `current/` 和 `history/*/` 里翻答案。
>
> 想从哪一步开始？告诉我 `update` / `prep` / `notes` / `archive` / `ask` 中的任意一个，或者直接描述你要做的事。

---

Run the weekly Societas shiproom from any IDE. All meeting data lives in **one place**: the Societas team's `Shiproom/` SharePoint folder, accessed via Microsoft Graph.

This file is just the entry point. Read one of:

- **Agent** → [`AGENT.md`](AGENT.md) — command-to-CLI mapping, prep/archive orchestration, behavior contract.
- **Permissions / safety contract** → [`PERMISSIONS.md`](PERMISSIONS.md) — what the agent may write, must refuse, must double-check.
- **Human** → [`README.md`](README.md) — setup and user-facing happy paths.

## Setup (one time per host)

```bash
pip install -r framework/scripts/requirements.txt
python framework/scripts/cloud_cli.py whoami     # MSAL sign-in pops up
python framework/scripts/cloud_cli.py status     # confirm SharePoint access
```

That's it. `cloud_cli.py` is the only backend; every `/sr-*` slash command routes through it.
