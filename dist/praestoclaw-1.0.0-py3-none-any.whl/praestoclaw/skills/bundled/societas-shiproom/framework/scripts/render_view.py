"""Deterministic renderer for Societas Shiproom current/view.html.

This module intentionally hard-codes the page structure and CSS so different
agents cannot invent different dashboard layouts during /sr-prep.

================================================================================
HARD FORMATTING RULES (do not relax without updating prep.md §6.2)
================================================================================

These rules govern the ① To Do action-item table rendered from
``current/updates/1-todo.md``. They exist because Loop's innerText dump is
noisy (person chips emit both an "EO" avatar token and an "Example Owner" full
name, dates appear in mixed locales, etc.). The parser must always normalize
to the canonical forms below — any new ETA / owner format spotted in the
wild MUST be added to ``_ETA_PAT`` / ``_normalize_eta`` / ``_NAME_PAT`` /
``_dedupe_owners`` rather than papered over downstream.

Owner column
------------
* Always render **full names only** (e.g. "Example Owner / Another Owner").
* Drop bare initials ("RY", "WD") when at least one full name exists in the
  same chunk. Initials are only kept as a last-resort fallback when no full
  name is available, so we never show an empty Owner cell.
* Multiple owners are joined with " / ", deduped, original order preserved.
* Full-name detection: an English token with a space ("Example Owner") or any
  CJK characters (``[\u4e00-\u9fa5]``) counts as a full name. Pure 2–4
  uppercase letters are treated as initials.

ETA column
----------
* Always render as ``YYYY-MM-DD``. Never leak Loop's raw strings into the
  table.
* Accepted input formats (extend ``_normalize_eta`` when you see new ones):
    - ``2026-05-26``
    - ``2026年5月26日`` / ``2026年5月26日周二``
    - ``May 26, 2026`` / ``Tue, May 26, 2026`` / ``May 26 2026``
    - ``5月26日`` (no year → assume current year)
    - ``5/26``   (no year → assume current year)
* If parsing fails, the original string is kept verbatim — that's a signal
  to add a new branch to ``_normalize_eta``, not to leave it broken.

Item / Notes columns
--------------------
* Anything in the chunk before the progress cell that is neither an ETA
  match nor a name match is treated as **item continuation** and joined to
  the item description with " — " (Loop frequently splits long titles
  across two rows).
* Notes is everything after the progress cell, space-joined.

Progress column
---------------
* Detected by exact (case-insensitive) match against
  ``{"in progress", "completed", "not started"}``.

Prep-summary prose
------------------
* Top Risks list and each section's intro bullets come from
  ``0-meeting-prep-summary.md`` and pass through this renderer **verbatim**.
  Full-name / no-initials enforcement for that prose lives in
  ``framework/rules/prep.md`` §6.1.1 rule 6, not here — do not try to
  rewrite owner names downstream.
"""
from __future__ import annotations

import datetime as dt
import html
import re
from dataclasses import dataclass


SECTION_SOURCES = {
    "todo": "current/updates/1-todo.md",
    "data": "current/updates/2-data.md",
    "ocv": "current/updates/3-ocv.md",
    "release": "current/updates/4-release.md",
    "mythos": "current/updates/5-mythos.md",
    "productivity": "current/updates/6-productivity.md",
    "showcase": "current/updates/7-showcase.md",
    "capabilities": "current/updates/8-capabilities.md",
    "foundation": "current/updates/9-foundation.md",
    "prep_summary": "current/updates/0-meeting-prep-summary.md",
    "loop": "current/currentloop.md",
    "live_notes": "current/live-notes.md",
}


@dataclass
class ViewInput:
    texts: dict[str, str]
    generated_at: dt.datetime | None = None
    archive_cutoff: dt.datetime | None = None  # set by render-view CLI from current/.last-archive
    overlays: dict[str, str] | None = None      # {node-slug: markdown} team /sr-update overlay layer


CSS = """
body{margin:0;background:#fff;color:#17212b;font:14px/1.55 "Segoe UI",Arial,sans-serif}
.page{max-width:1180px;margin:0 auto;padding:28px 32px 56px}
.toc{position:sticky;top:0;background:#fff;border-bottom:1px solid #c9d6e4;padding:10px 0;z-index:2}
.toc a{color:#0969da;text-decoration:none;margin-right:10px;white-space:nowrap}
h1{font-size:32px;margin:32px 0 8px}.meta{font-size:12px;color:#5f6b7a;border-bottom:1px solid #c9d6e4;padding-bottom:16px}
.top-risk{border:1px solid #f3c38c;background:#fff8f0;border-radius:6px;padding:16px 18px;margin:24px 0 34px}.top-risk h2{font-size:24px;margin:0 0 10px}
.section{border-top:3px solid #0969da;margin-top:36px;padding-top:24px}.section h2{background:#0969da;color:#fff;border-radius:4px;padding:10px 14px;margin:0 0 18px;font-size:24px}
h3{font-size:18px;margin:22px 0 10px;color:#0969da}
table{width:100%;border-collapse:collapse;margin:14px 0 22px}th,td{border:1px solid #d0d7de;padding:8px 10px;vertical-align:top}th{background:#f6f8fa;text-align:left}
.compact th,.compact td{font-size:13px;padding:5px 8px}
ul,ol{padding-left:24px}li{margin:6px 0}.warn{color:#b54708;font-weight:600}.bad{color:#cf222e;font-weight:600}.done,.good{color:#1a7f37;font-weight:600}.small{font-size:12px;color:#5f6b7a}.note{background:#f6f8fa;border-left:4px solid #8c959f;padding:10px 12px;margin:12px 0 18px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:14px 0}
.metric{border:1px solid #d0d7de;border-radius:8px;padding:10px 12px;background:#fbfcfe}
.metric h4{margin:0 0 8px;font-size:14px;color:#0969da}
.metric table{margin:0}
.loop-images{margin:14px 0 22px}.loop-images img{display:block;max-width:100%;height:auto;border:1px solid #d0d7de;border-radius:4px;margin:10px 0;background:#fff}.loop-images figure{margin:0 0 14px}.loop-images figcaption{font-size:12px;color:#5f6b7a;margin-top:4px}
code{background:#eff1f3;padding:1px 5px;border-radius:3px;font-size:13px}
td.owner{color:#0969da;font-weight:600;white-space:nowrap}
td.notes-cell{background:#fcfdff;cursor:text;min-width:240px}
td.notes-cell:focus{outline:2px solid #0969da;outline-offset:-2px;background:#fff}
td.notes-cell.edited{background:#fff8e1}
td.notes-cell.edited::after{content:" ✏";color:#b54708;font-size:11px}
.notes-meta{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:#5f6b7a;margin:-6px 0 14px}
.notes-meta button{font:inherit;color:#0969da;background:none;border:none;cursor:pointer;padding:2px 6px}
.notes-meta button:hover{text-decoration:underline}
.live-notes{border:1px solid #d0d7de;border-radius:6px;background:#fbfcfe;padding:12px;margin:18px 0 4px}.live-notes h3{margin:0 0 8px;font-size:16px;color:#17212b}.live-notes textarea{box-sizing:border-box;width:100%;min-height:82px;resize:vertical;border:1px solid #d0d7de;border-radius:4px;padding:8px 10px;font:14px/1.45 "Segoe UI",Arial,sans-serif}.live-notes textarea:focus{outline:2px solid #0969da;outline-offset:1px}.live-notes-actions{display:flex;gap:10px;align-items:center;margin-top:8px}.live-notes-actions button{background:#0969da;color:#fff;border:0;border-radius:4px;padding:6px 12px;cursor:pointer;font:inherit}.live-notes-actions button:disabled{background:#8c959f;cursor:not-allowed}.live-notes-status{font-size:12px;color:#5f6b7a}.saved-live-notes{background:#f6f8fa;border-left:4px solid #0969da;padding:8px 12px;margin:0 0 10px}.saved-live-notes h4{margin:0 0 6px;font-size:13px;color:#0969da}.saved-live-notes p{margin:5px 0}
.sync-all{display:flex;gap:10px;align-items:center;background:#f6f8fa;border:1px solid #d0d7de;border-radius:6px;padding:10px 12px;margin:16px 0 24px}.sync-all button{background:#0969da;color:#fff;border:0;border-radius:4px;padding:7px 14px;cursor:pointer;font:inherit}.sync-all button:disabled{background:#8c959f;cursor:not-allowed}.sync-all-status{font-size:12px;color:#5f6b7a}
.group{margin-top:46px}.group-head{background:#0b3a66;color:#fff;border-radius:6px;padding:14px 18px;margin:0;font-size:26px;letter-spacing:.3px}
.group .section{border-top:none;margin-top:18px;padding-top:4px;padding-left:16px;border-left:4px solid #c9d6e4}.group .section h2{background:#3b7dd8;font-size:20px}
.toc a.sub{color:#5f6b7a;font-size:12px}
.overlay{border-left:4px solid #1a7f37;background:#f3fbf5;padding:8px 12px;margin:12px 0 4px;border-radius:4px}.overlay h4{margin:0 0 6px;font-size:13px;color:#1a7f37}.overlay p{margin:5px 0}
.overview{border:1px solid #c9d6e4;background:#fbfdff;border-radius:8px;padding:18px 22px;margin:18px 0 34px}
.overview h2{background:none;color:#0b3a66;margin:0 0 4px;font-size:22px;padding:0}
.overview .ov-sub{color:#5f6b7a;font-size:13px;margin:0 0 16px}
.ov-rows{margin:0 0 18px}
.ov-row{display:flex;gap:12px;margin-bottom:12px;align-items:stretch}
.ov-row .ov-box{flex:1;border:1px solid #d0d7de;border-radius:6px;padding:10px 16px;background:#fff}
.ov-box strong{display:block;font-size:16px;color:#17212b}.ov-box em{font-style:normal;color:#5f6b7a;font-size:13px}
.ov-tag{display:flex;align-items:center;justify-content:center;min-width:54px;font-size:22px;font-weight:700;border-radius:6px;color:#fff}
.ov-internal .ov-tag{background:#0969da}.ov-external .ov-tag{background:#1a7f37}
.ov-layers{margin:0 0 14px}
.ov-layer{display:flex;gap:12px;align-items:stretch}
.ov-llabel{display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:72px;border-radius:6px;color:#fff;font-weight:700;padding:8px 0}
.ov-llabel small{font-weight:400;font-size:11px;opacity:.85}
.ov-skin{background:#5b8def}.ov-flesh{background:#2f6f43}.ov-bone{background:#0b3a66}
.ov-content{flex:1;border:1px solid #d0d7de;border-radius:6px;padding:10px 16px;background:#fff}
.ov-content .ov-title{font-weight:600;color:#17212b}
.ov-loop{margin-top:8px;font-family:Consolas,"Courier New",monospace;background:#f6f8fa;border:1px solid #e1e7ee;border-radius:4px;padding:8px 12px;color:#0b3a66;font-size:13px}
.ov-down{text-align:center;color:#8c959f;margin:3px 0;padding-left:84px}
.ov-explain{border-top:1px dashed #c9d6e4;margin-top:8px;padding-top:12px;font-size:13.5px}
.ov-explain p{margin:6px 0}.ov-explain li{margin:5px 0}
.ov-ascii-wrap{margin:16px 0 6px}.ov-ascii-label{font-size:12px;color:#5f6b7a;margin:0 0 6px}
.ov-ascii{font-family:Consolas,"Courier New",monospace;font-size:12px;line-height:1.3;background:#f6f8fa;border:1px solid #e1e7ee;border-radius:6px;padding:12px 14px;overflow-x:auto;white-space:pre;color:#24292f;margin:0 0 12px}
@media (max-width:780px){.grid{grid-template-columns:1fr}.toc{position:static}.ov-row{flex-direction:row}}
""".strip()


def render_view(payload: ViewInput) -> str:
    """Top-level wrapper. Per project policy: NEVER raise. If anything breaks
    we fall back to dumping the raw markdown so the user at least sees the
    real source content rather than a template page."""
    try:
        return _render_view_impl(payload)
    except Exception as exc:  # pragma: no cover - safety net
        return _render_view_fallback(payload, exc)


def _render_view_impl(payload: ViewInput) -> str:
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    texts = payload.texts
    title_date = generated_at.date().isoformat()
    cutoff = payload.archive_cutoff or _this_week_start()
    # Stash on a module global so legacy call sites (extract_manual_entries)
    # can read it without changing every signature.
    global _ACTIVE_CUTOFF
    _ACTIVE_CUTOFF = cutoff
    body = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shiproom {title_date}</title>
<style>{CSS}</style>
</head>
<body>
<main class="page">
<nav class="toc">
  <a href="#todo">0 Todo</a>
  <a href="#internal">1 Internal</a>
  <a href="#data" class="sub">·Data</a>
  <a href="#ocv" class="sub">·OCV</a>
  <a href="#release" class="sub">·Release</a>
  <a href="#security" class="sub">·Security</a>
  <a href="#productivity" class="sub">·10x Prod</a>
  <a href="#external">2 External</a>
  <a href="#showcase" class="sub">·Showcase</a>
  <a href="#capabilities" class="sub">·Capabilities</a>
  <a href="#foundation" class="sub">·Foundation</a>
</nav>

<h1>Shiproom {html.escape(title_date)}</h1>
<p class="meta">Source: current Loop / Data / OCV files under SharePoint current/. Generated {html.escape(generated_at.isoformat(timespec="minutes"))}.</p>

{render_section("todo", "0. Todo", render_todo(texts.get("todo", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}

<div class="group" id="internal">
<h2 class="group-head">1. Internal · 对内</h2>
{render_section("data", "Data", render_data(texts.get("data", ""), texts.get("prep_summary", ""), texts.get("loop", "")), texts.get("live_notes", ""))}
{render_section("ocv", "OCV", render_ocv(texts.get("ocv", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("release", "Release", render_release(texts.get("release", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("security", "Security Bug", render_mythos(texts.get("mythos", ""), texts.get("prep_summary", "")), texts.get("live_notes", ""))}
{render_section("productivity", "10x Productivity Research", render_workstream(texts.get("productivity", ""), texts.get("prep_summary", ""), "10x Productivity"), texts.get("live_notes", ""))}
</div>

<div class="group" id="external">
<h2 class="group-head">2. External · 对外</h2>
{render_section("showcase", "Showcase", render_workstream(texts.get("showcase", ""), texts.get("prep_summary", ""), "Showcase"), texts.get("live_notes", ""))}
{render_section("capabilities", "Capabilities", render_workstream(texts.get("capabilities", ""), texts.get("prep_summary", ""), "Capabilities"), texts.get("live_notes", ""))}
{render_section("foundation", "Foundation", render_workstream(texts.get("foundation", ""), texts.get("prep_summary", ""), "Foundation"), texts.get("live_notes", ""))}
</div>

<div class="sync-all"><button type="button" id="shiproom-sync-all-notes">Sync all notes to SharePoint</button><span class="sync-all-status">Todo Notes and section Live notes autosave locally until synced.</span></div>

{render_live_notes_script()}

</main>
</body>
</html>
"""
    return body


def _render_view_fallback(payload: ViewInput, exc: Exception) -> str:
    """Last-resort renderer used only if _render_view_impl raises. Dumps every
    raw source markdown verbatim. The user sees real content, not template
    waste text."""
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    title_date = generated_at.date().isoformat()
    sections = []
    for key, path in SECTION_SOURCES.items():
        raw = (payload.texts or {}).get(key, "") or ""
        if not raw.strip():
            continue
        sections.append(
            f'<section class="section"><h2>{html.escape(key)} ({html.escape(path)})</h2>'
            f'<pre style="white-space:pre-wrap;font:13px/1.45 Consolas,monospace;">'
            f'{html.escape(raw)}</pre></section>'
        )
    return (
        f'<!doctype html><html><head><meta charset="utf-8"><title>Shiproom {title_date} (raw)</title>'
        f'<style>{CSS}</style></head><body><main class="page">'
        f'<h1>Shiproom {html.escape(title_date)} <span class="small">(raw fallback)</span></h1>'
        f'<p class="note">Structured renderer failed: <code>{html.escape(type(exc).__name__)}: {html.escape(str(exc))}</code>. '
        f'Showing raw source markdown so the meeting can still proceed.</p>'
        + "".join(sections) +
        "</main></body></html>"
    )


def render_section(anchor: str, title: str, content: str, live_notes_md: str = "", owner: str = "") -> str:
    display_title = display_section_title(title, owner)
    notes = "" if anchor == "todo" else render_live_notes_panel(anchor, title, display_title, live_notes_md)
    return f'<section id="{anchor}" class="section">\n<h2>{html.escape(display_title)}</h2>\n{content}\n{notes}\n</section>'


def display_section_title(title: str, owner: str = "") -> str:
    """Append the section's real owner(s) — read from the Loop's own person
    chips — to the title. NEVER hard-code names; owner is passed in from the
    Loop node so the dashboard always mirrors whoever the Loop assigns."""
    return f"{title} ({owner})" if owner else title


_OWNER_INITIALS_RE = re.compile(r"^[A-Z]{2,4}$")


def _name_initials(name: str) -> str:
    core = re.sub(r"\([^)]*\)", "", name).strip()
    tokens = [t for t in re.split(r"\s+", core) if t and t[0].isalpha()]
    return "".join(t[0].upper() for t in tokens)


def extract_node_owners(body: str) -> list[str]:
    """Pull owner names from the Loop person-chips that sit right under a
    heading. Each chip dumps two lines: an initials avatar ("SZ") followed by
    the full name ("Example Owner"). We only accept a pair when the initials
    match the name's initials, which makes this precise enough to run over the
    whole node body without matching prose. Multiple owners (chained with "&"
    in the Loop) are returned in order, deduped."""
    lines = [re.sub(r"\[SR_[^\]]*\]", "", ln).strip() for ln in body.splitlines()]
    owners: list[str] = []
    i = 0
    n = len(lines)
    while i < n - 1:
        ini = lines[i]
        if _OWNER_INITIALS_RE.fullmatch(ini):
            name = lines[i + 1]
            if name and _looks_like_person_name(name) and _name_initials(name) == ini:
                owners.append(name)
                i += 2
                continue
        i += 1
    out: list[str] = []
    for o in owners:
        if o not in out:
            out.append(o)
    return out


def node_owner_label(node) -> str:
    return " & ".join(extract_node_owners(getattr(node, "body", "") or ""))


def render_live_notes_panel(anchor: str, title: str, display_title: str, live_notes_md: str) -> str:
    existing = render_saved_live_notes(title, live_notes_md)
    textarea_id = f"live-note-{anchor}"
    return f"""
<div class="live-notes" data-section="{html.escape(anchor)}">
    <h3>Live notes</h3>
    {existing}
    <textarea id="{html.escape(textarea_id)}" placeholder="Record meeting notes for {html.escape(display_title)}..."></textarea>
    <div class="live-notes-actions">
        <span class="live-notes-status">Autosaved locally. Use Sync all notes at the top when ready.</span>
    </div>
</div>
""".strip()


def render_saved_live_notes(title: str, live_notes_md: str) -> str:
    if not live_notes_md.strip():
        return ""
    title_re = re.escape(title)
    match = re.search(rf"^##\s+{title_re}\s*$", live_notes_md, re.M)
    if not match:
        return ""
    tail = live_notes_md[match.end():]
    stop = re.search(r"^##\s+", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    block = block.strip()
    if not block:
        return ""
    return '<div class="saved-live-notes"><h4>Saved notes</h4>' + markdown_to_html(block) + '</div>'


def render_live_notes_script() -> str:
    return r"""
<script>
(function(){
    const NS = 'shiproom.liveNotes.v1.';
    const TODO_NS = 'shiproom.todoNotes.v1.';
    const SERVER = 'http://127.0.0.1:8765/notes';
    document.querySelectorAll('.live-notes').forEach(panel => {
        const section = panel.dataset.section;
        const textarea = panel.querySelector('textarea');
        const status = panel.querySelector('.live-notes-status');
        const key = NS + section;
        const saved = localStorage.getItem(key);
        if (saved) textarea.value = saved;
        textarea.addEventListener('input', () => {
            localStorage.setItem(key, textarea.value);
            status.textContent = 'Autosaved locally. Use Sync all notes at the top when ready.';
        });
    });
    async function postNote(section, text){
        const res = await fetch(SERVER, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({section, text})
        });
        const payload = await res.json();
        if (!res.ok || !payload.ok) throw new Error(payload.error || ('HTTP ' + res.status));
        return payload;
    }
    document.getElementById('shiproom-sync-all-notes')?.addEventListener('click', async (event) => {
        const button = event.currentTarget;
        const status = document.querySelector('.sync-all-status');
        const jobs = [];
        document.querySelectorAll('td.notes-cell.edited').forEach(td => {
            const text = td.innerText.trim();
            if (!text) return;
            jobs.push({
                section: 'todo',
                text: `Todo: ${td.dataset.item || '(item)'}\n\n${text}`,
                cleanup: () => {
                    localStorage.removeItem(TODO_NS + td.dataset.key);
                    td.dataset.default = td.innerHTML.trim();
                    td.classList.remove('edited');
                }
            });
        });
        document.querySelectorAll('.live-notes').forEach(panel => {
            const section = panel.dataset.section;
            const textarea = panel.querySelector('textarea');
            const text = textarea.value.trim();
            if (!text) return;
            jobs.push({
                section,
                text,
                cleanup: () => {
                    localStorage.removeItem(NS + section);
                    textarea.value = '';
                    const panelStatus = panel.querySelector('.live-notes-status');
                    if (panelStatus) panelStatus.textContent = 'Synced. Refresh page to show saved note.';
                }
            });
        });
        if (!jobs.length) { status.textContent = 'No notes to sync.'; return; }
        button.disabled = true;
        status.textContent = `Syncing ${jobs.length} note(s)...`;
        try {
            for (const job of jobs) {
                await postNote(job.section, job.text);
                job.cleanup();
            }
            status.textContent = `Synced ${jobs.length} note(s) to SharePoint. Refresh page to show saved notes.`;
        } catch (err) {
            status.textContent = 'Sync failed. Start live_notes_server.py and retry. ' + err.message;
        } finally {
            button.disabled = false;
        }
    });
})();
</script>
""".strip()


def render_top_risk(summary: str, texts: dict[str, str]) -> str:
    # Prep summary heading is e.g. "## 🚨 Top Risks (...)"; older variants used
    # "Top callout". Try both, fall back to generic guidance.
    items = extract_list_after_heading(summary, "Top Risks", limit=6)
    if not items:
        items = extract_list_after_heading(summary, "Top callout", limit=6)
    if has_current_data_report(texts.get("data", "")):
        items = [item for item in items if not is_stale_data_missing_risk(item)]
    if not items:
        # No matchable Top Risk heading. Rather than emit template waste text,
        # surface whatever bullets exist at the top of prep_summary so the user
        # at least sees real content. If even that is empty, return raw dump.
        items = _first_bullets_anywhere(summary, limit=6)
    if not items:
        if summary.strip():
            return f'<pre style="white-space:pre-wrap;font:13px/1.5 Consolas,monospace;">{html.escape(summary[:2000])}</pre>'
        return '<p class="note">prep_summary 为空，跑 <code>/sr-prep</code> 后再渲染。</p>'
    return "<ol>" + "".join(f"<li>{inline_md(item)}</li>" for item in items[:6]) + "</ol>"


def _first_bullets_anywhere(text: str, limit: int = 6) -> list[str]:
    out: list[str] = []
    for line in text.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            item = m.group(1).strip()
            if item:
                out.append(item)
                if len(out) >= limit:
                    break
    return out


def has_current_data_report(data_md: str) -> bool:
    return "Executive Overview" in data_md and "Key Takeaways" in data_md


def is_stale_data_missing_risk(item: str) -> bool:
    lowered = item.lower()
    return (
        "2-data 缺失" in item
        or "data 缺失" in item
        or "尚未上传" in item
        or "还没贴 usage" in item
        or "has not uploaded" in lowered
        or "missing data" in lowered
    )


def render_todo(todo_md: str, summary: str) -> str:
    intro = section_summary(summary, "Todo")
    # Parse the Loop Action-Items table with links PRESERVED so each row's Notes
    # cell renders its links inline (1:1 with Loop). We deliberately do NOT emit
    # Links stay inline in the captured Markdown table so each Notes cell keeps
    # its own semantic context instead of duplicating links elsewhere.
    text_with_links = clean_markdown(todo_md, keep_links=True)
    rows = todo_rows_from_markdown(text_with_links)
    if rows:
        table = _render_todo_table(rows)
    else:
        text = clean_markdown(todo_md)
        rows = parse_todo_rows(text)
        table = _render_todo_table(rows) if rows else markdown_to_html(text)
    manual = extract_manual_entries(todo_md)
    return _intro_html(intro) + table + manual


def todo_rows_from_markdown(text: str) -> list[list[str]]:
    """Map the Loop Action-Items Markdown table (rebuilt at fetch time,
    columns Items / Owner / ETA / Progress / Notes) to the editable Todo rows.
    Returns [] when the body has no such table so callers fall back to the
    legacy flattened parser (``parse_todo_rows``)."""
    tbl = first_markdown_table(text)
    if not tbl:
        return []
    headers, raw_rows = tbl
    hjoined = " ".join(h.lower() for h in headers)
    if "owner" not in hjoined or "item" not in hjoined:
        return []
    rows: list[list[str]] = []
    for r in raw_rows:
        item, owner, eta, progress, notes = (r + [""] * 5)[:5]
        owners = _dedupe_owners([o.strip() for o in re.split(r"·|/|\[SR_BR\]", owner) if o.strip()])
        owner_txt = " / ".join(owners) if owners else "-"
        eta_txt = _normalize_eta(eta) if eta.strip() else "-"
        rows.append([
            str(len(rows) + 1),
            item.strip() or "-",
            owner_txt,
            eta_txt,
            progress.strip() or "-",
            notes.strip(),
        ])
    return rows


def _render_todo_table(rows: list[list[str]]) -> str:
    """Render the Todo table with:
    - Completed items excluded and remaining rows renumbered.
      - Owner cells styled blue (``td.owner``).
      - Notes cells made editable + persisted to ``localStorage`` keyed by a
        stable hash of the item text, so users can amend / annotate notes and
        their edits survive future re-renders. A small toolbar lets them
        revert all edits.
    """
    rows = [row for row in rows if len(row) < 5 or row[4].strip().casefold() != "completed"]
    if not rows:
        return '<p class="note">当前没有未完成的 Action Items。</p>'

    headers = ["#", "Item", "Owner", "ETA", "Progress", "Notes / meeting ask"]
    head = "".join(f"<th>{inline_md(h)}</th>" for h in headers)
    body: list[str] = []
    import hashlib
    for row_number, row in enumerate(rows, start=1):
        padded = (row + [""] * 6)[:6]
        _, item, owner, eta, progress, notes = padded
        key = hashlib.sha1(item.strip().encode("utf-8")).hexdigest()[:12]
        notes_html = inline_md(notes)
        body.append(
            "<tr>"
            f"<td>{row_number}</td>"
            f"<td>{inline_md(item)}</td>"
            f'<td class="owner">{inline_md(owner)}</td>'
            f"<td>{inline_md(eta)}</td>"
            f"<td>{inline_md(progress)}</td>"
            f'<td class="notes-cell" contenteditable="true" spellcheck="false" '
            f'data-key="{key}" data-item="{html.escape(item, quote=True)}" data-default="{html.escape(notes_html, quote=True)}">'
            f"{notes_html}</td>"
            "</tr>"
        )
    table = (
        f"<table><thead><tr>{head}</tr></thead>"
        f"<tbody>{''.join(body)}</tbody></table>"
    )
    toolbar = (
        '<div class="notes-meta">'
        '<span>✏ Notes 列可直接编辑，修改会自动保存在本地浏览器（localStorage），下次打开仍在。</span>'
        '<button type="button" onclick="shiproomResetNotes()">重置所有编辑</button>'
        "</div>"
    )
    script = """
<script>
(function(){
  const NS = 'shiproom.todoNotes.v1.';
  const cells = document.querySelectorAll('td.notes-cell');
  cells.forEach(td => {
    const key = NS + td.dataset.key;
    const saved = localStorage.getItem(key);
    if (saved !== null && saved !== td.dataset.default){
      td.innerHTML = saved;
      td.classList.add('edited');
    }
        td.addEventListener('input', () => {
            const cur = td.innerHTML.trim();
            if (cur === td.dataset.default){
                localStorage.removeItem(key);
                td.classList.remove('edited');
            } else {
                localStorage.setItem(key, cur);
                td.classList.add('edited');
            }
        });
    td.addEventListener('blur', () => {
      const cur = td.innerHTML.trim();
      if (cur === td.dataset.default){
        localStorage.removeItem(key);
        td.classList.remove('edited');
      } else {
        localStorage.setItem(key, cur);
        td.classList.add('edited');
      }
    });
    td.addEventListener('keydown', e => {
      // Esc reverts current cell to the freshly-loaded default.
      if (e.key === 'Escape'){
        td.innerHTML = td.dataset.default;
        localStorage.removeItem(key);
        td.classList.remove('edited');
        td.blur();
      }
    });
  });
  window.shiproomResetNotes = function(){
    if (!confirm('清除本页 Notes 列的所有本地编辑？')) return;
    cells.forEach(td => {
      localStorage.removeItem(NS + td.dataset.key);
      td.innerHTML = td.dataset.default;
      td.classList.remove('edited');
    });
  };
})();
</script>
""".strip()
    return toolbar + table + script


def render_data(data_md: str, summary: str = "", loop_md: str = "") -> str:
    # Data now comes straight from the SharePoint weekly brief (2-data.md); the
    # Loop "Business Metrics" block is no longer maintained, so we do not render
    # its links / "Key Metrics Definition Overview" / stray "(" ")" text.
    intro = section_summary(summary, "Data")
    overview = extract_between(data_md, r"##\s*.*Executive Overview", r"\n##\s+Slide\s+2\b")
    if not overview.strip():
        # No Executive Overview block — dump raw data_md so user sees real content.
        raw = clean_markdown(data_md)
        if raw.strip():
            return _intro_html(intro) + markdown_to_html(raw)
        return _intro_html(intro) + '<p class="note">2-data.md 为空。</p>'
    overview = re.sub(r"<!--\s*TAKEAWAYS:START\s*-->|<!--\s*TAKEAWAYS:END\s*-->", "", overview)
    grid_html = render_data_grid(overview)
    takeaways = extract_between(overview, r"###?\s+.*Key Takeaways", r"\n##\s+|\Z")
    takeaways_html = ""
    if takeaways.strip():
        takeaways_html = "<h3>Key Takeaways</h3>" + markdown_to_html(takeaways)
    if grid_html:
        # Key Takeaways first, then Executive Overview grid.
        return _intro_html(intro) + f"{takeaways_html}<h3>Executive Overview</h3>{grid_html}"
    return _intro_html(intro) + markdown_to_html(overview)


def render_business_metrics(loop_md: str, data_md: str = "") -> str:
    block = extract_loop_block(loop_md, ["Business Metrics"], ["Customer Voice - OCV", "OCV feedback", "Consumer Release status"])
    if not block.strip():
        return ""
    images = render_loop_images(extract_source_images(block))
    text = strip_sr_image_markers(block).strip()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    rows: list[tuple[str, str]] = []
    idx = 0
    if lines and lines[0] == "(":
        idx += 1
    if idx < len(lines) and "Key Metrics Definition Overview" in lines[idx]:
        idx += 1
    if idx < len(lines) and lines[idx] == ")":
        idx += 1
    while idx < len(lines):
        line = lines[idx]
        if line.startswith("Highlights:"):
            rows.append(("Highlights", line.split(":", 1)[1].strip()))
        elif line.startswith("Lowlights:"):
            rows.append(("Lowlights", line.split(":", 1)[1].strip()))
        elif line.startswith("Report"):
            value = line.split(":", 1)[1].strip() if ":" in line else ""
            rows.append(("Report", value))
        elif rows and rows[-1][0] == "Report":
            label, value = rows[-1]
            rows[-1] = (label, (value + " " + line).strip())
        idx += 1
    if rows:
        body = "".join(f"<p><strong>{html.escape(label)}:</strong> {inline_md(value)}</p>" for label, value in rows)
    else:
        body = markdown_to_html(text)
    overview = extract_between(data_md, r"##\s*.*Executive Overview", r"\n##\s+Slide\s+2\b")
    overview = re.sub(r"<!--\s*TAKEAWAYS:START\s*-->|<!--\s*TAKEAWAYS:END\s*-->", "", overview)
    grid_html = render_data_grid(overview) if overview.strip() else ""
    takeaways = extract_between(overview, r"###?\s+.*Key Takeaways", r"\n##\s+|\Z")
    takeaways_html = ""
    if takeaways.strip():
        takeaways_html = "<h3>Key Takeaways</h3>" + markdown_to_html(takeaways)
    report_html = ""
    if grid_html:
        report_html = f"<h3>Executive Overview</h3>{grid_html}{takeaways_html}"
    return body + images + report_html


def render_business_metric_links(loop_md: str) -> str:
    links = extract_business_metric_links(loop_md)
    if not links:
        return ""
    return " ".join(
        f'<a href="{html.escape(url, quote=True)}" target="_blank" rel="noopener noreferrer">{html.escape(label)}</a>'
        for label, url in links
    )


def extract_business_metric_links(loop_md: str) -> list[tuple[str, str]]:
    wanted = [
        "Key Metrics Definition Overview",
        "Office Agent - Your Generalist AI Agent",
    ]
    out: list[tuple[str, str]] = []
    for label in wanted:
        url = ""
        markdown_pat = re.compile(r"\[" + re.escape(label) + r"\]\((https?://[^)]+)\)")
        marker_pat = re.compile(re.escape(label) + r"[^\n]*\[SR_LINK:\s*(https?://[^\]\s]+)\]")
        for pat in (markdown_pat, marker_pat):
            m = pat.search(loop_md)
            if m:
                url = m.group(1).strip()
                break
        if url:
            out.append((label, url))
    return out


SR_LINK_RE = re.compile(r"\s*\[SR_LINK:\s*(https?://[^\]\s]+)\]")
SR_IMAGE_RE = re.compile(r"\s*\[SR_IMAGE:\s*((?:https?://|data:)[^\]|\s]+)\s*(?:\|\s*([^\]]+))?\]")


def extract_loop_block(loop_md: str, start_headings: list[str], end_headings: list[str]) -> str:
    lines = loop_md.splitlines()
    start = None
    for idx, line in enumerate(lines):
        if any(_heading_line_matches(line, heading) for heading in start_headings):
            start = idx + 1
            break
    if start is None:
        return ""
    end = len(lines)
    for idx in range(start, len(lines)):
        if any(_heading_line_matches(lines[idx], heading) for heading in end_headings):
            end = idx
            break
    return "\n".join(lines[start:end]).strip()


def _heading_line_matches(line: str, heading: str) -> bool:
    stripped = re.sub(r"^\s*(?:[•●◦\-*]|\d+(?:\.\d+)*\.?)\s*", "", line).strip().lower()
    target = heading.strip().lower()
    return stripped == target or (stripped.startswith(target) and len(stripped) > len(target) and not stripped[len(target)].isalnum())


def render_loop_images(images: list[tuple[str, str]]) -> str:
    if not images:
        return ""
    figures = []
    for url, label in images:
        caption = f"<figcaption>{html.escape(label)}</figcaption>" if label and label != "Loop image" else ""
        figures.append(
            f'<figure><img src="{html.escape(url, quote=True)}" alt="{html.escape(label, quote=True)}" loading="lazy">{caption}</figure>'
        )
    return '<div class="loop-images">' + "".join(figures) + "</div>"


def extract_source_links(text: str, limit: int = 12) -> list[tuple[str, str]]:
    links: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()
    for line in text.splitlines():
        marker = SR_LINK_RE.search(line)
        if marker:
            url = marker.group(1).strip()
            label = SR_LINK_RE.sub("", line).strip()
            label = re.sub(r"^#+\s*", "", label)
            label = re.sub(r"_\(from Loop[^_]*\)_", "", label).strip()
            if label and (label, url) not in seen:
                links.append((label, url))
                seen.add((label, url))
        for label, url in re.findall(r"\[([^\]]+)\]\((https?://[^)]+)\)", line):
            pair = (label.strip(), url.strip())
            if pair[0] and pair not in seen:
                links.append(pair)
                seen.add(pair)
        if len(links) >= limit:
            break
    return links[:limit]


def extract_source_images(text: str, limit: int = 6) -> list[tuple[str, str]]:
    images: list[tuple[str, str]] = []
    seen: set[str] = set()
    for match in SR_IMAGE_RE.finditer(text):
        url = match.group(1).strip()
        label = (match.group(2) or "Loop image").strip()
        if url not in seen:
            images.append((url, label))
            seen.add(url)
        if len(images) >= limit:
            break
    return images


def strip_sr_link_markers(text: str) -> str:
    return SR_LINK_RE.sub("", text)


def sr_links_to_markdown(text: str) -> str:
    pat = re.compile(r"(?P<label>[^\s\[][^\[]*?)\s*\[SR_LINK:\s*(?P<url>https?://[^\]\s]+)\]")
    return pat.sub(lambda m: f"[{m.group('label').strip()}]({m.group('url')})", text)


def strip_sr_image_markers(text: str) -> str:
    return SR_IMAGE_RE.sub("", text)


def render_data_grid(overview_md: str) -> str:
    """Pick out the 4 'COLUMN N: <name>' tables and lay them out as a 2x2 grid
    of metric cards. Returns empty string if the layout cannot be detected."""
    col_pat = re.compile(r"COLUMN\s+\d+[:：]\s*([^\n]+?)\n(.*?)(?=COLUMN\s+\d+[:：]|##\s|\Z)",
                          re.S | re.I)
    cards: list[str] = []
    for m in col_pat.finditer(overview_md):
        title = re.sub(r"^[^A-Za-z\u4e00-\u9fa5]+", "", m.group(1).strip()).strip()
        body_md = m.group(2).strip()
        # Drop ad-hoc notes lines (start with ⚠ / NOTE) before the table.
        body_md = re.sub(r"^[^\n|]*$\n", "", body_md, count=1, flags=re.M)
        table = first_markdown_table(body_md)
        if not table:
            continue
        headers, rows = table
        # Re-render the table compactly with status-colored cell where possible.
        thead = "<tr>" + "".join(f"<th>{html.escape(h)}</th>" for h in headers) + "</tr>"
        body_rows = []
        for row in rows:
            # Color the WoW cell based on the row's Status emoji (🔴 / 🟢),
            # because for negative metrics (failure rates) a "+" is BAD.
            row_text = " ".join(row)
            row_cls = ""
            if "🔴" in row_text or re.search(r"\bdown\b", row_text, re.I):
                row_cls = "bad"
            elif "🟢" in row_text or re.search(r"\bup\b|goal|completed", row_text, re.I):
                row_cls = "good"
            cells_html = []
            for idx, cell_val in enumerate(row):
                hl = headers[idx].lower() if idx < len(headers) else ""
                cls = ""
                if hl in {"wow", "status"} and row_cls:
                    cls = f" class=\"{row_cls}\""
                cells_html.append(f"<td{cls}>{html.escape(cell_val)}</td>")
            body_rows.append("<tr>" + "".join(cells_html) + "</tr>")
        compact_table = (
            f"<table class=\"compact\"><thead>{thead}</thead>"
            f"<tbody>{''.join(body_rows)}</tbody></table>"
        )
        cards.append(f"<div class=\"metric\"><h4>{html.escape(title)}</h4>{compact_table}</div>")
    if len(cards) < 2:
        return ""
    return "<div class=\"grid\">" + "".join(cards) + "</div>"


def render_ocv(ocv_md: str, summary: str = "") -> str:
    intro = section_summary(summary, "OCV")
    text = clean_markdown(ocv_md)
    table = first_markdown_table(text)
    rows_html = ""
    if table:
        headers, rows = table
        col = {name.lower(): idx for idx, name in enumerate(headers)}
        wanted = []
        for row in rows:
            row_type = cell(row, col, "type")
            title = cell(row, col, "title")
            if "problem" in row_type.lower() or "error" in title.lower() or "busy" in title.lower():
                wanted.append([
                    cell(row, col, "items"),
                    cell(row, col, "trend"),
                    title,
                    f"{cell(row, col, 'type')} / {cell(row, col, 'state')}",
                    cell(row, col, "bugs") or cell(row, col, "comments"),
                ])
        rows_html = table_html(["Items", "Trend", "Title", "Type / State", "Bug ID / note"], wanted[:8])
    if not rows_html:
        rows_html = markdown_to_html(text)
    # No separate "Loop links" box here: every OCV bug link already shows in
    # the table's "Bug ID / note" column, so a bare-ID link list is redundant.
    return _intro_html(intro) + rows_html


def render_release(release_md: str, summary: str = "") -> str:
    text = clean_markdown(release_md)
    if not text.strip():
        return "<p><em>本周无更新。</em></p>"
    return render_structured_loop_document(text)


def render_structured_loop_document(text: str) -> str:
    """Render the Loop's current structure without depending on section names.

    Headings are preserved verbatim. Markdown tables remain tables. For the
    legacy flattened Loop dump, a short column-header run followed by numbered
    rows is reconstructed positionally; everything else remains prose.
    """
    heading_re = re.compile(r"^###\s+(.+?)\s*$", re.M)
    matches = list(heading_re.finditer(text))
    if not matches:
        return render_structured_loop_block(text)
    out: list[str] = []
    preamble = text[:matches[0].start()].strip()
    if preamble:
        out.append(render_structured_loop_block(preamble))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        title = re.sub(r"_\(from Loop[^_]*\)_", "", match.group(1)).strip()
        out.append(f"<h3>{inline_md(title)}</h3>")
        out.append(render_structured_loop_block(text[match.end():end].strip()))
    return "".join(out)


def render_structured_loop_block(block: str) -> str:
    if not block.strip():
        return "<p><em>本周无更新。</em></p>"
    if first_markdown_table(block):
        return markdown_to_html(block)
    parsed = _parse_flattened_numbered_table(block)
    if not parsed:
        return markdown_to_html(strip_loop_chip_noise(block))
    intro, headers, rows = parsed
    parts: list[str] = []
    if intro.strip():
        parts.append(markdown_to_html(strip_loop_chip_noise(intro)))
    head = "<th>#</th>" + "".join(f"<th>{inline_md(header)}</th>" for header in headers)
    body = "".join(
        "<tr>"
        f"<td>{html.escape(number)}</td>"
        + "".join(f"<td>{inline_md(cell)}</td>" for cell in cells)
        + "</tr>"
        for number, cells in rows
    )
    parts.append(f"<table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table>")
    return "".join(parts)


def _parse_flattened_numbered_table(
    text: str,
) -> tuple[str, list[str], list[tuple[str, list[str]]]] | None:
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", text.strip()) if part.strip()]
    first_row = next((i for i, part in enumerate(paragraphs) if re.fullmatch(r"\d+", part)), None)
    if first_row is None:
        return None
    numbered = _numbered_release_chunks("\n\n".join(paragraphs[first_row:]))
    logical_widths: list[int] = []
    for _, chunks in numbered:
        owner_chunks, remaining = _take_owner_chunks(chunks[1:])
        logical_widths.append(1 + len(remaining) + (1 if owner_chunks else 0))
    if not logical_widths:
        return None
    column_count = max(set(logical_widths), key=lambda width: (logical_widths.count(width), -width))
    header_start = first_row
    while header_start > 0 and _is_flat_table_header_candidate(paragraphs[header_start - 1]):
        header_start -= 1
    available_headers = paragraphs[header_start:first_row]
    if column_count < 2 or len(available_headers) < column_count:
        return None
    headers = available_headers[-column_count:]
    header_start = first_row - column_count
    rows: list[tuple[str, list[str]]] = []
    owner_index = next((i for i, header in enumerate(headers) if "owner" in header.lower()), None)
    for number, chunks in numbered:
        cells = [""] * len(headers)
        if chunks:
            cells[0] = squash(chunks[0])
        remaining = chunks[1:]
        if owner_index is not None:
            owner_chunks, remaining = _take_owner_chunks(remaining)
            cells[owner_index] = ", ".join(
                filter(None, (collapse_owner(chunk) for chunk in owner_chunks))
            )
        target_indexes = [i for i in range(1, len(headers)) if i != owner_index]
        for position, target_index in enumerate(target_indexes):
            if position == len(target_indexes) - 1:
                cells[target_index] = " · ".join(squash(chunk) for chunk in remaining[position:])
            elif position < len(remaining):
                cells[target_index] = squash(remaining[position])
        rows.append((number, [cell or "-" for cell in cells]))
    return "\n\n".join(paragraphs[:header_start]), headers, rows


def _is_flat_table_header_candidate(text: str) -> bool:
    words = text.split()
    return (
        "\n" not in text
        and 0 < len(text) <= 50
        and 0 < len(words) <= 6
        and not re.fullmatch(r"\d+", text)
        and not re.search(r"[.!?。！？]$", text)
    )


def _numbered_release_chunks(text: str) -> list[tuple[str, list[str]]]:
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", text.strip()) if part.strip()]
    rows: list[tuple[str, list[str]]] = []
    index = 0
    while index < len(paragraphs):
        if not re.fullmatch(r"\d+", paragraphs[index]):
            index += 1
            continue
        number = paragraphs[index]
        index += 1
        chunks: list[str] = []
        while index < len(paragraphs) and not re.fullmatch(r"\d+", paragraphs[index]):
            chunks.append(paragraphs[index])
            index += 1
        if chunks:
            rows.append((number, chunks))
    return rows


def _is_owner_chunk(text: str) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip() and line.strip() != "&"]
    if len(lines) < 2 or len(lines) % 2:
        return False
    return all(re.fullmatch(r"[A-Z]{2,4}", lines[index]) for index in range(0, len(lines), 2))


def _take_owner_chunks(chunks: list[str]) -> tuple[list[str], list[str]]:
    owners: list[str] = []
    index = 0
    while index < len(chunks) and _is_owner_chunk(chunks[index]):
        owners.append(chunks[index])
        index += 1
    return owners, chunks[index:]


def squash(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def collapse_owner(text: str) -> str:
    # Loop alias dumps owners as initials + full name interleaved on separate lines.
    # Keep just the full names.
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    names: list[str] = []
    for ln in lines:
        if re.fullmatch(r"[A-Z]{2,3}", ln):
            continue
        names.append(ln)
    seen = []
    for n in names:
        if n not in seen:
            seen.append(n)
    return ", ".join(seen)


def render_deep_worker(deep_md: str, summary: str = "") -> str:
    images = render_loop_images(extract_source_images(deep_md))
    text = clean_markdown(deep_md)
    manual = extract_manual_entries(deep_md)
    return render_grouped_deep_work(text) + images + manual


def render_grouped_deep_work(text: str) -> str:
    text = strip_loop_chip_noise(text)
    out: list[str] = []
    bullets: list[str] = []

    def flush() -> None:
        if bullets:
            out.append("<ul>" + "".join(f"<li>{inline_md(item)}</li>" for item in bullets) + "</ul>")
            bullets.clear()

    heading_patterns = (
        r"^PPT to DeepWork$",
        r"^工程侧进展[:：]",
        r"^Quality 侧进展[:：]",
        r"^分析case发现的一些问题$",
        r"^模型升级$",
    )
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            flush()
            continue
        if line.startswith("### "):
            flush()
            out.append(f"<h3>{inline_md(line[4:].strip())}</h3>")
            continue
        if line in {"_(empty)_", "_(no matching section found in currentloop.md)_"}:
            continue
        if any(re.search(pat, line, re.I) for pat in heading_patterns):
            flush()
            out.append(f"<p><strong>{inline_md(line)}</strong></p>")
            continue
        bullets.append(line)
    flush()
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


def render_bulleted_prose(text: str) -> str:
    text = strip_loop_chip_noise(text)
    out: list[str] = []
    bullets: list[str] = []

    def flush() -> None:
        if bullets:
            out.append("<ul>" + "".join(f"<li>{inline_md(item)}</li>" for item in bullets) + "</ul>")
            bullets.clear()

    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            flush()
            continue
        if line.startswith("### "):
            flush()
            out.append(f"<h3>{inline_md(line[4:].strip())}</h3>")
            continue
        if line.startswith("## "):
            flush()
            out.append(f"<h3>{inline_md(line[3:].strip())}</h3>")
            continue
        if line in {"_(empty)_", "_(no matching section found in currentloop.md)_"}:
            continue
        # Lettered sub-items (a. / b. / c. ...) used by the Loop's Capabilities
        # block render as bold sub-headings rather than flat bullets.
        if re.match(r"^[a-hA-H]\.\s+\S", line):
            flush()
            out.append(f"<p><strong>{inline_md(line)}</strong></p>")
            continue
        line = re.sub(r"^[-*•●◦]\s+", "", line)
        bullets.append(line)
    flush()
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


def render_mythos(mythos_md: str, summary: str = "") -> str:
    images = render_loop_images(extract_source_images(mythos_md))
    text = clean_markdown(mythos_md)
    manual = extract_manual_entries(mythos_md)
    intro = section_summary(summary, "Security")
    body = render_bulleted_prose(text)
    return _intro_html(intro) + body + images + manual


def render_workstream(ws_md: str, summary: str = "", intro_key: str = "") -> str:
    """Render one Core Workstream sub-section (Skill Package / Excel / Internal
    Showcase / 10x Productivity). Content is free-form prose synced from the
    Loop "Workstream Plan" block plus any human /sr-update entries."""
    images = render_loop_images(extract_source_images(ws_md))
    text = clean_markdown(ws_md)
    manual = extract_manual_entries(ws_md)
    intro = section_summary(summary, intro_key) if intro_key else ""
    return _intro_html(intro) + render_bulleted_prose(text) + images + manual


def render_others(others_md: str, summary: str = "") -> str:
    text = clean_markdown(others_md)
    text = remove_heading_block(text, "Excel agent")
    intro = section_summary(summary, "7")
    if not text.strip():
        return _intro_html(intro) + "<p><em>本周无其他更新。</em></p>"
    return _intro_html(intro) + markdown_to_html(text)


def _intro_html(intro: str) -> str:
    """Emit intro markup. Never emit template waste.
    - empty/whitespace → nothing
    - already-built `<ul>...</ul>` (multi-bullet case from section_summary) → passthrough
    - single-line text → wrap as `<p>`
    """
    if not intro or not intro.strip():
        return ""
    if intro.lstrip().startswith("<ul>"):
        return intro
    return f"<p>{inline_md(intro)}</p>"


def clean_markdown(text: str, keep_links: bool = True) -> str:
    # Strip everything after the LOOP-SYNC end marker — that region is owned by
    # extract_manual_entries() (which applies a freshness filter). Keeping it
    # here would double-render manual updates AND bypass the freshness filter.
    if "<!-- END LOOP-SYNC -->" in text:
        text = text.split("<!-- END LOOP-SYNC -->", 1)[0]
    lines = []
    in_comment = False
    for line in text.replace("\r\n", "\n").split("\n"):
        stripped = line.strip()
        if in_comment:
            if "-->" in stripped:
                in_comment = False
            continue
        if stripped in {"<!-- BEGIN LOOP-SYNC -->", "<!-- END LOOP-SYNC -->"}:
            continue
        if stripped.startswith("<!--"):
            if "-->" not in stripped:
                in_comment = True
            continue
        if stripped.startswith("_Source:"):
            continue
        if stripped.startswith("# "):
            continue
        cleaned = strip_sr_image_markers(line if keep_links else strip_sr_link_markers(line))
        lines.append(SR_LI_STRIP_RE.sub("", cleaned))
    return "\n".join(lines).strip()


def extract_manual_entries(text: str) -> str:
    """Pull entries written after the LOOP-SYNC block (these come from
    `/sr-update`). Filters out blocks dated before this ISO week's Monday so
    last-week notes don't bleed into this week's view (this is the carry-forward
    archive safety net — see prep.md / archive.md)."""
    if "<!-- END LOOP-SYNC -->" not in text:
        return ""
    tail = text.split("<!-- END LOOP-SYNC -->", 1)[1].strip()
    if not tail:
        return ""
    fresh = _filter_fresh_manual_blocks(tail)
    if not fresh.strip():
        return ""
    return '<h3>Manual updates</h3>' + markdown_to_html(fresh)


def _this_week_start() -> dt.datetime:
    today = dt.date.today()
    monday = today - dt.timedelta(days=today.weekday())
    return dt.datetime.combine(monday, dt.time.min)


# Set by _render_view_impl before any extract_manual_entries call. Defaults to
# this week's Monday so unit tests / legacy callers still work.
_ACTIVE_CUTOFF: dt.datetime = _this_week_start()


_MANUAL_HEAD_RE = re.compile(r"^###\s+@\S+\s+·\s+(\S+)\s*$", re.M)


def _filter_fresh_manual_blocks(text: str) -> str:
    """Split tail on `### @user · ISO` headings; keep only blocks whose ISO
    timestamp is within the current weekly window. We keep the stricter of the
    last `/sr-archive` cutoff and "now - 7 days", so stale overlay notes fall
    out even if archive has not advanced. Blocks without a parseable timestamp
    are kept (conservative — prefer showing too much over hiding fresh content).
    """
    cutoff = _ACTIVE_CUTOFF
    cutoff_naive = cutoff.replace(tzinfo=None) if cutoff.tzinfo else cutoff
    week_cutoff_naive = (dt.datetime.now().astimezone() - dt.timedelta(days=7)).replace(tzinfo=None)
    if week_cutoff_naive > cutoff_naive:
        cutoff_naive = week_cutoff_naive
    matches = list(_MANUAL_HEAD_RE.finditer(text))
    if not matches:
        return text
    kept_chunks: list[str] = []
    if matches[0].start() > 0:
        preamble = text[:matches[0].start()].strip()
        if preamble:
            kept_chunks.append(preamble)
    for idx, m in enumerate(matches):
        ts_raw = m.group(1)
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
        block = text[m.start():end].rstrip()
        try:
            ts = dt.datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
            ts_naive = ts.replace(tzinfo=None) if ts.tzinfo else ts
            if ts_naive < cutoff_naive:
                continue  # stale: older than the last archive cutoff — drop
        except ValueError:
            pass  # unparseable — keep, don't silently lose content
        kept_chunks.append(block)
    return "\n\n".join(kept_chunks)


def extract_list_after_heading(text: str, heading: str, limit: int = 5) -> list[str]:
    pattern = re.compile(rf"^##+\s+.*{re.escape(heading)}.*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return []
    tail = text[match.end():]
    stop = re.search(r"^##\s+", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    items = []
    for line in block.splitlines():
        m = re.match(r"\s*(?:\d+\.|[-*])\s+(.*)", line)
        if m:
            items.append(m.group(1).strip())
            if len(items) >= limit:
                break
    return items


_CIRCLED = {"1": "①", "2": "②", "3": "③", "4": "④", "5": "⑤", "6": "⑥", "7": "⑦"}


def section_summary(summary: str, section_number: str, fallback: str = "") -> str:
    """Find the per-section block in the prep summary and return an intro
    snippet for the dashboard. Supports `### 1 — Title`, `## ① Title (1-todo)`,
    `## ... (1-todo)` heading shapes, and (new 3-group layout) a plain title
    match like `## Data` / `## Security Bug` / `## Skill Package ...`.

    Output rules (per project policy — NEVER emit template waste text):
      * 0 bullets / 0 paragraph found  → return fallback (default empty string).
      * 1 bullet                       → return that bullet as plain string
                                          (rendered as `<p>` by _intro_html).
      * ≥2 bullets                     → return a sentinel string starting with
                                          "<ul>" so each bullet is its own list
                                          item (avoids dense one-paragraph dump).
    """
    if section_number and not section_number.isdigit():
        # Title-based lookup for the 3-group layout. Match a heading whose text
        # contains the key (case-insensitive), e.g. key "Security" matches
        # "## Security Bug" or "## ⑥ Security Bug".
        key = re.escape(section_number)
        match = re.search(rf"^#{{2,3}}\s+.*{key}.*$", summary, re.M | re.I)
        if not match:
            return fallback
        tail = summary[match.end():]
        stop = re.search(r"^#{2,3}\s+", tail, re.M)
        block = tail[:stop.start()] if stop else tail
        bullets = extract_bullets(block)
        if len(bullets) >= 2:
            return "<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>"
        if len(bullets) == 1:
            return bullets[0]
        for para in re.split(r"\n\s*\n", block.strip()):
            para = para.strip()
            if para and not para.startswith("|") and not para.startswith("#"):
                return re.sub(r"\s+", " ", para)
        return fallback
    circled = _CIRCLED.get(section_number, "")
    patterns = [
        rf"^###\s+{re.escape(section_number)}\s+[—-].*$",
        rf"^##\s+{re.escape(circled)}\s+.*$" if circled else None,
        rf"^##\s+{re.escape(circled)}\s+.*\({section_number}-[\w-]+\).*$" if circled else None,
        rf"^##\s+.*\({section_number}-[\w-]+\).*$",
    ]
    match = None
    for pat in patterns:
        if not pat:
            continue
        match = re.search(pat, summary, re.M)
        if match:
            break
    if not match:
        return fallback
    tail = summary[match.end():]
    stop = re.search(r"^##\s+|^###\s+\d+\s+[—-]", tail, re.M)
    block = tail[:stop.start()] if stop else tail
    bullets = extract_bullets(block)
    if len(bullets) >= 2:
        return "<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>"
    if len(bullets) == 1:
        return bullets[0]
    for para in re.split(r"\n\s*\n", block.strip()):
        para = para.strip()
        if para and not para.startswith("|") and not para.startswith("#"):
            return re.sub(r"\s+", " ", para)
    return fallback


def extract_bullets(block: str) -> list[str]:
    out = []
    for line in block.splitlines():
        m = re.match(r"\s*[-*]\s+(.*)", line)
        if m:
            out.append(m.group(1).strip())
    return out


def extract_between(text: str, start_pat: str, end_pat: str) -> str:
    start = re.search(start_pat, text, re.I | re.M)
    if not start:
        return ""
    tail = text[start.end():]
    end = re.search(end_pat, tail, re.I | re.M)
    return tail[:end.start()] if end else tail


def extract_heading_block(text: str, heading: str) -> str:
    match = re.search(rf"^###\s+{re.escape(heading)}(?:\s+.*)?$", text, re.I | re.M)
    if not match:
        return ""
    tail = text[match.end():]
    stop = re.search(r"^###\s+", tail, re.M)
    return tail[:stop.start()] if stop else tail


def remove_heading_block(text: str, heading: str) -> str:
    pattern = re.compile(rf"^###\s+{re.escape(heading)}\s*$", re.I | re.M)
    match = pattern.search(text)
    if not match:
        return text
    tail = text[match.end():]
    stop = re.search(r"^###\s+", tail, re.M)
    end = match.end() + (stop.start() if stop else len(tail))
    return text[:match.start()] + text[end:]


# Be strict: every alternative must include at least one digit or a
# CJK "today/tomorrow/this-week" phrase. We MUST NOT match plain words
# like "ETA" or "May" that appear in notes prose.
_ETA_PAT = re.compile(
    r"\d{4}年|\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}|\d{1,2}月\d{1,2}日|"
    r"周[一二三四五六日天]|今天|明天|昨天|后天|本周|下周|"
    r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2}\b|"
    r"\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\b",
    re.I,
)
# Owner heuristic: pasted Loop mention chips arrive as a 2-line block per
# person — a 2–4 letter initials avatar ("EO") and a full name ("Example Owner"
# or "Another Owner (Team)" or a CJK full name). Anything that doesn't fit
# either shape is treated as item continuation.
_NAME_PAT = re.compile(
    r"^[A-Z]{2,4}$"                                             # initials
    r"|^[A-Z][A-Za-z'.\-]+(?:\s+[A-Z][A-Za-z'.\-]+){0,3}"       # English full name (1–4 tokens)
    r"(?:\s*\([^)]+\))?$"                                       # optional " (Societas)" suffix
    r"|^[\u4e00-\u9fa5]{2,4}(?:\s*\([^)]+\))?$"                 # CJK full name
)


def parse_todo_rows(text: str) -> list[list[str]]:
    # Loop's heading is sometimes literally "Action Items", sometimes the
    # weekly page is just "Shiproom Current" / "Items / Owner / ETA /
    # Progress / Notes" with no inline heading. Try the explicit heading
    # first; fall back to the whole text so we still parse the table.
    items_block = (
        extract_between(text, r"###\s+Action Items", r"\n###\s+|\Z")
        or extract_between(text, r"###\s+Shiproom Current", r"\n###\s+|\Z")
        or text
    )
    lines = [ln.strip() for ln in items_block.splitlines() if ln.strip()]
    # Drop the column-header preamble ("Items / Owner / ETA / Progress /
    # Notes") so it doesn't get mistaken for the first row's item text.
    header_tokens = {"items", "owner", "eta", "progress", "notes"}
    while lines and lines[0].lower() in header_tokens:
        lines.pop(0)
    starts = [idx for idx, ln in enumerate(lines) if re.fullmatch(r"\d+", ln)]
    progress_words = {"in progress", "completed", "not started"}
    # Defense in depth: even with the loop_fetch placeholder blacklist, the
    # Loop UI may surface new empty-cell prompts. Treat these as empty.
    ui_placeholders = {
        "选择日期", "选择人员", "选择状态", "添加日期", "添加人员",
        "核对清单",  # Loop checklist widget label, leaks as a CJK 4-char chip
        "pick a date", "add a date", "select date", "select person",
        "add person", "select status",
    }
    rows = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(lines)
        chunk = lines[start + 1:end]
        if not chunk:
            continue
        # Position-independent classification: Loop renders Progress and
        # ETA as chip elements whose innerText is often empty, so we can't
        # rely on a fixed column order. Instead, walk every line in the
        # chunk and bucket it by shape (progress / eta / name / other).
        item_parts: list[str] = []
        owners: list[str] = []
        eta = ""
        progress = ""
        notes_parts: list[str] = []
        seen_anchor = False  # flips True once we hit progress or an ETA
        for val in chunk:
            low = val.lower()
            if val.strip() in ui_placeholders or low in ui_placeholders:
                continue
            if not progress and low in progress_words:
                progress = val
                seen_anchor = True
            elif not eta and len(val) <= 40 and _ETA_PAT.search(val):
                # ETA chips render as short standalone lines (e.g.
                # "2026-05-26", "5/26", "周二"). Reject long prose that
                # merely *contains* a date-ish substring (e.g.
                # "(5/11切换后支持1M)" inside a notes paragraph).
                eta = val
                seen_anchor = True
            elif _NAME_PAT.match(val):
                owners.append(val)
                # First owner also anchors the row: in weeks where ETA /
                # Progress chips are empty, subsequent non-name lines are
                # notes prose, not more item title.
                seen_anchor = True
            elif not seen_anchor:
                # Anything before the first anchor that isn't a name is
                # part of the item title (Loop frequently splits long
                # titles across multiple lines).
                item_parts.append(val)
            else:
                notes_parts.append(val)
        if not item_parts and chunk:
            # Pathological case: first line was a name/eta/progress. Keep
            # raw chunk[0] as item so the row isn't empty.
            item_parts = [chunk[0]]
        item = " — ".join(p for p in item_parts if p).strip(" —") or "-"
        owners = _dedupe_owners(owners)
        owner = " / ".join(owners) if owners else "-"
        eta = _normalize_eta(eta) if eta else "-"
        progress = progress or "-"
        notes = " ".join(notes_parts).strip()
        rows.append([str(len(rows) + 1), item, owner, eta, progress, notes])
    return rows


def _dedupe_owners(owners: list[str]) -> list[str]:
    """Keep only full names; drop bare initials (e.g. "WD"). If nothing left,
    fall back to initials so we don't lose owner info entirely."""
    full = [o for o in owners if " " in o or re.search(r"[\u4e00-\u9fa5]", o)]
    pool = full if full else owners
    seen: list[str] = []
    for o in pool:
        if o not in seen:
            seen.append(o)
    return seen


_MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


def _normalize_eta(raw: str) -> str:
    """Normalize ETA strings like '2026年5月26日周二' or 'Tue, May 26, 2026'
    to 'YYYY-MM-DD'. Returns the original string when no date can be parsed."""
    s = raw.strip()
    # 2026-05-26
    m = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", s)
    if m:
        y, mo, d = map(int, m.groups())
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # 2026年5月26日
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日", s)
    if m:
        y, mo, d = map(int, m.groups())
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # May 26, 2026 / May 26 2026
    m = re.search(
        r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?[,\s]+(\d{4})",
        s, re.I,
    )
    if m:
        mo = _MONTHS[m.group(1).lower()]
        d = int(m.group(2))
        y = int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # 5月26日 (no year) -> assume current year
    m = re.search(r"(\d{1,2})月(\d{1,2})日", s)
    if m:
        from datetime import date
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{date.today().year:04d}-{mo:02d}-{d:02d}"
    # 5/26 (no year)
    m = re.fullmatch(r"\s*(\d{1,2})/(\d{1,2})\s*", s)
    if m:
        from datetime import date
        mo, d = int(m.group(1)), int(m.group(2))
        return f"{date.today().year:04d}-{mo:02d}-{d:02d}"
    return s


# A Loop content block, captured at fetch time as
#   [SR_B:<viewport-left-px>:<kind>] … [SR_ENDB]
# where <kind> is p(aragraph) / u(nordered item) / o(rdered item). The left
# offset encodes visual indentation; the renderer turns *relative* offsets into
# nesting depth. Old [SR_LI:…] markers are still stripped for back-compat with a
# currentloop.md captured before this change.
_SR_B_LINE_RE = re.compile(r"^\[SR_B:(-?\d+):([oup])\]\s*(.*)$")
_SR_B_SPAN_RE = re.compile(r"\[SR_B:(-?\d+):([oup])\](.*?)\[SR_ENDB\]", re.S)
SR_LI_STRIP_RE = re.compile(
    r"\[SR_B:-?\d+:[oup]\]\s*|\s*\[SR_ENDB\]"
    r"|\[SR_LI:\d+:[ou]\]\s*|\s*\[SR_ENDLI\]"
)

_INDENT_TOL = 13  # px: blocks whose left offsets are within this share a level


def _collapse_blocks(text: str) -> str:
    """Fold each ``[SR_B:left:kind] … [SR_ENDB]`` span (which innerText may wrap
    across lines — a trailing date pill, a soft-wrapped sentence) into a single
    logical line, so the renderer sees exactly one block per line."""
    def repl(m: re.Match) -> str:
        left, kind, body = m.group(1), m.group(2), m.group(3)
        body = re.sub(r"\s*\n\s*", " ", body).strip()
        return f"[SR_B:{left}:{kind}] {body}"

    return _SR_B_SPAN_RE.sub(repl, text)


def _block_depths(lefts: list[int]) -> list[int]:
    """Relative nesting depth (0-based) for a run of blocks, from their viewport
    left offsets via a monotonic stack. Absolute pixels are irrelevant — only
    whether a block is further right (deeper), the same, or shallower than the
    ones before it. Robust to Loop's mixed indent CSS (margin vs padding vs
    list-indent), which is why we don't trust aria-level."""
    depths: list[int] = []
    stack: list[int] = []
    for left in lefts:
        while stack and left < stack[-1] - _INDENT_TOL:
            stack.pop()
        if not stack or left > stack[-1] + _INDENT_TOL:
            stack.append(left)
        depths.append(len(stack) - 1)
    return depths


def _render_block_list(items: list[tuple[int, str, str]]) -> str:
    """Nested <ul>/<ol> from (depth, kind, html) list items. Depths are
    normalised to the group's shallowest so a group never over-indents."""
    base = min(d for d, _, _ in items)
    out: list[str] = []
    stack: list[tuple[int, str]] = []  # (level, tag)
    for d, kind, htext in items:
        level = d - base
        tag = "ol" if kind == "o" else "ul"
        while stack and stack[-1][0] > level:
            _, closing = stack.pop()
            out.append(f"</li></{closing}>")
        if stack and stack[-1][0] == level:
            out.append("</li>")
            if stack[-1][1] != tag:
                out.append(f"</{stack[-1][1]}><{tag}>")
                stack[-1] = (level, tag)
        else:
            out.append(f"<{tag}>")
            stack.append((level, tag))
        out.append(f"<li>{htext}")
    while stack:
        _, closing = stack.pop()
        out.append(f"</li></{closing}>")
    return "".join(out)


def _render_block_run(blocks: list[tuple[int, str, str]]) -> str:
    """Render a contiguous run of Loop blocks ``(left, kind, text)`` preserving
    the Loop's structure: consecutive list items collapse into one nested list;
    paragraphs render as <p>, indented in proportion to their nesting depth so
    an indented sub-paragraph (e.g. the lines under "Skills to Cowork:") reads as
    a group instead of a flush-left wall of text."""
    depths = _block_depths([left for left, _, _ in blocks])
    out: list[str] = []
    i = 0
    n = len(blocks)
    while i < n:
        if blocks[i][1] in ("u", "o"):
            group: list[tuple[int, str, str]] = []
            while i < n and blocks[i][1] in ("u", "o"):
                group.append((depths[i], blocks[i][1], inline_md(blocks[i][2])))
                i += 1
            out.append(_render_block_list(group))
        else:
            d = depths[i]
            html_txt = inline_md(blocks[i][2])
            if d > 0:
                out.append(f'<p style="margin-left:{min(d, 4) * 1.6:.1f}em">{html_txt}</p>')
            else:
                out.append(f"<p>{html_txt}</p>")
            i += 1
    return "".join(out)


def markdown_to_html(text: str) -> str:
    text = strip_loop_chip_noise(text)
    text = _collapse_blocks(text)
    lines = text.strip().splitlines()
    out: list[str] = []
    paragraph: list[str] = []
    idx = 0
    while idx < len(lines):
        line = lines[idx]
        if is_table_start(lines, idx):
            flush_paragraph(out, paragraph)
            headers, rows, consumed = parse_table_at(lines, idx)
            out.append(table_html(headers, rows))
            idx += consumed
            continue
        stripped = line.strip()
        b_match = _SR_B_LINE_RE.match(stripped)
        if b_match:
            flush_paragraph(out, paragraph)
            blocks: list[tuple[int, str, str]] = []
            while idx < len(lines):
                cur = lines[idx].strip()
                mm = _SR_B_LINE_RE.match(cur)
                if mm:
                    blocks.append((int(mm.group(1)), mm.group(2), mm.group(3)))
                    idx += 1
                    continue
                if not cur:
                    # A blank line only continues the run if another block
                    # follows it; otherwise the run ends here.
                    j = idx + 1
                    while j < len(lines) and not lines[j].strip():
                        j += 1
                    if j < len(lines) and _SR_B_LINE_RE.match(lines[j].strip()):
                        idx = j
                        continue
                break
            out.append(_render_block_run(blocks))
            continue
        if not stripped:
            flush_paragraph(out, paragraph)
        elif stripped.startswith("### "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[4:].strip())}</h3>")
        elif stripped.startswith("## "):
            flush_paragraph(out, paragraph)
            out.append(f"<h3>{inline_md(stripped[3:].strip())}</h3>")
        elif re.match(r"^[-*]\s+", stripped):
            flush_paragraph(out, paragraph)
            bullets = []
            while idx < len(lines) and re.match(r"^\s*[-*]\s+", lines[idx].strip()):
                bullets.append(re.sub(r"^[-*]\s+", "", lines[idx].strip()))
                idx += 1
            out.append("<ul>" + "".join(f"<li>{inline_md(b)}</li>" for b in bullets) + "</ul>")
            continue
        else:
            paragraph.append(stripped)
        idx += 1
    flush_paragraph(out, paragraph)
    return "\n".join(out) or "<p><em>本周无更新。</em></p>"


_PERSON_NAME_RE = re.compile(
    r"^[A-Z][a-zA-Z'’.\-]+(?:\s+[A-Z][a-zA-Z'’.\-]+){0,3}(?:\s*\([^)]+\))?$"
    r"|^[\u4e00-\u9fa5]{2,4}(?:\s*\([^)]+\))?$"
)


def _looks_like_person_name(s: str) -> bool:
    return bool(s) and len(s) <= 40 and bool(_PERSON_NAME_RE.match(s))


def strip_loop_chip_noise(text: str) -> str:
    """Drop standalone Loop avatar/person-chip lines from prose sections.

    This is intentionally applied at markdown rendering time rather than in
    clean_markdown(), because Todo's table parser still needs owner lines.
    """
    lines: list[str] = []
    prev_was_initials = False
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped == "&":
            continue
        # Bare two-letter uppercase lines are Loop avatar initials (CG / JT /
        # RC ...) that sit above the person's full name. Two letters keeps this
        # safe against 3-letter content acronyms (OCV / GPT / MCP / RAI).
        if re.fullmatch(r"[A-Z]{2}", stripped):
            prev_was_initials = True
            continue
        # A full-name line immediately following an avatar-initials line is the
        # person chip's name (e.g. "EO" then "Example Owner"). Drop it generically
        # so section owners never leak into the body — other sections don't
        # show owners either, and this needs no hard-coded name list.
        if prev_was_initials and _looks_like_person_name(stripped):
            prev_was_initials = False
            continue
        prev_was_initials = False
        if stripped in {"- BLOCKED"}:
            continue
        fixed = re.sub(r"^to update\s*", "", stripped, flags=re.I)
        fixed = re.sub(r"^update\s*", "", fixed, flags=re.I)
        fixed = fixed.replace("工程侧进展]", "工程侧进展：")
        fixed = fixed.replace("quality侧进展：", "Quality 侧进展：")
        lines.append(fixed if fixed != stripped else raw)
    return "\n".join(lines)


def flush_paragraph(out: list[str], paragraph: list[str]) -> None:
    if paragraph:
        out.extend(f"<p>{inline_md(line)}</p>" for line in paragraph if line.strip())
        paragraph.clear()


def inline_md(text: str) -> str:
    text = strip_sr_image_markers(sr_links_to_markdown(text))
    text = SR_LI_STRIP_RE.sub("", text)
    escaped = html.escape(text)
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", escaped)
    escaped = re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)
    escaped = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', escaped)
    # Auto-linkify bare URLs (e.g. "已提取到 https://github.com/..."). The
    # negative lookbehind skips URLs already inside an anchor's href="..." or
    # used as an anchor's visible text (preceded by '>').
    escaped = re.sub(
        r'(?<![">=])(https?://[^\s<)]+)',
        r'<a href="\1" target="_blank" rel="noopener noreferrer">\1</a>',
        escaped,
    )
    # Intra-cell line-break sentinel (see loop_fetch _inline_tables): render the
    # stacked points of a table cell on their own lines instead of one blob.
    escaped = escaped.replace("[SR_BR]", "<br>")
    return escaped


def first_markdown_table(text: str) -> tuple[list[str], list[list[str]]] | None:
    lines = text.splitlines()
    for idx in range(len(lines)):
        if is_table_start(lines, idx):
            headers, rows, _ = parse_table_at(lines, idx)
            return headers, rows
    return None


def is_table_start(lines: list[str], idx: int) -> bool:
    return idx + 1 < len(lines) and lines[idx].lstrip().startswith("|") and re.match(r"^\s*\|?\s*:?-{3,}:?", lines[idx + 1]) is not None


def parse_table_at(lines: list[str], idx: int) -> tuple[list[str], list[list[str]], int]:
    headers = split_table_row(lines[idx])
    rows: list[list[str]] = []
    consumed = 2
    for line in lines[idx + 2:]:
        if not line.lstrip().startswith("|"):
            break
        rows.append(split_table_row(line))
        consumed += 1
    return headers, rows, consumed


def split_table_row(line: str) -> list[str]:
    line = line.strip().strip("|")
    return [cell.strip() for cell in line.split("|")]


def table_html(headers: list[str], rows: list[list[str]]) -> str:
    if not rows:
        return ""
    head = "".join(f"<th>{inline_md(h)}</th>" for h in headers)
    body = []
    for row in rows:
        padded = row + [""] * max(0, len(headers) - len(row))
        body.append("<tr>" + "".join(f"<td>{inline_md(c)}</td>" for c in padded[:len(headers)]) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def cell(row: list[str], col: dict[str, int], name: str) -> str:
    idx = col.get(name)
    if idx is None or idx >= len(row):
        return ""
    return row[idx]


# ============================================================================
# Loop-as-tree renderer (dynamic outline; NO hard-coded section keywords).
# The dashboard mirrors whatever structure the Loop has. Only Data + OCV are
# injected from non-Loop sources; everything else renders the Loop's own nodes.
# ============================================================================


def _slug(title: str) -> str:
    import loop_tree
    return loop_tree.slug(title)


def _render_overlay_block(node, overlays: dict) -> str:
    """Render the team /sr-update overlay attached to this Loop node, if any."""
    md = (overlays or {}).get(_slug(node.title), "")
    if not md or not md.strip():
        return ""
    # Drop the "# Overlay — <title>" file header; it's storage metadata.
    md = re.sub(r"^#\s*Overlay\b.*$", "", md, count=1, flags=re.M).strip()
    md = _filter_fresh_manual_blocks(md).strip()
    if not md:
        return ""
    return (
        '<div class="overlay"><h4>\U0001F4DD 团队补充 / Team updates</h4>'
        + markdown_to_html(md)
        + "</div>"
    )


def _short_label(title: str, limit: int = 16) -> str:
    t = re.sub(r"\s+", " ", title).strip()
    return t if len(t) <= limit else t[: limit - 1] + "…"


def _overview_block() -> str:
    """Fixed 'mental model' header pinned at the top of every dashboard. Mirrors
    the team's two framing diagrams (内/外 and the 皮/肉/骨 of External) and
    explains how the weekly shiproom is organised."""
    ascii1 = (
        "+----------------------------------+    +------+\n"
        "|        10x Productivity          |    |  内  |\n"
        "|----------------------------------|    +------+\n"
        "|          我们是谁                |\n"
        "+----------------------------------+\n"
        "\n"
        "\n"
        "+----------------------------------+    +------+\n"
        "|     Contribute / Mainstream      |    |  外  |\n"
        "|----------------------------------|    +------+\n"
        "|   我们服务谁                     |\n"
        "+----------------------------------+"
    )
    ascii2 = (
        "+------+   +----------------------------------------------------------------+\n"
        "|  皮  |   |                          Showcase Site                         |\n"
        "+------+   +----------------------------------------------------------------+\n"
        "                                   |\n"
        "                                   v\n"
        "+------+   +----------------------------------------------------------------+\n"
        "|  肉  |   | GDPval selector | WXP skills | Taste+ | less AI more human | ...|\n"
        "+------+   +----------------------------------------------------------------+\n"
        "                                   |\n"
        "                                   v\n"
        "+------+   +----------------------------------------------------------------+\n"
        "|  骨  |   |                 Foundation / Operating Loop                    |\n"
        "|      |   |----------------------------------------------------------------|\n"
        "|      |   |                                                                |\n"
        "|      |   |     Trace  --->  Retro  --->  Iterate                          |\n"
        "|      |   |       ^                          |                             |\n"
        "|      |   |       |                          v                             |\n"
        "|      |   |     Release  <-------------- Eval                             |\n"
        "|      |   |                                                                |\n"
        "+------+   +----------------------------------------------------------------+"
    )
    a1 = html.escape(ascii1)
    a2 = html.escape(ascii2)
    return f"""
<section id="overview" class="overview">
  <h2>Shiproom 总览 · 我们怎么看这件事</h2>
  <p class="ov-sub">下面整个 dashboard 由团队的 Loop 自动生成(Loop 改结构,这里自动跟着变)。这一节是固定的心智模型,帮大家对齐组织逻辑。</p>

  <div class="ov-rows">
    <div class="ov-row ov-internal">
      <div class="ov-box"><strong>10x Productivity</strong><em>我们是谁 · Who we are —— 先拿自己 dogfood,把自己的效率拉到 10×</em></div>
      <span class="ov-tag">内</span>
    </div>
    <div class="ov-row ov-external">
      <div class="ov-box"><strong>Contribute / Mainstream</strong><em>我们服务谁 · Who we serve —— 把能力贡献出去,服务主流用户</em></div>
      <span class="ov-tag">外</span>
    </div>
  </div>

  <div class="ov-layers">
    <div class="ov-layer">
      <div class="ov-llabel ov-skin">皮<small>Skin</small></div>
      <div class="ov-content"><span class="ov-title">Showcase Site</span> —— 对外门面,别人第一眼看到的</div>
    </div>
    <div class="ov-down">↓</div>
    <div class="ov-layer">
      <div class="ov-llabel ov-flesh">肉<small>Flesh</small></div>
      <div class="ov-content"><span class="ov-title">Capabilities</span> —— GDPval selector · WXP skills · Taste+ · less AI more human · …</div>
    </div>
    <div class="ov-down">↓</div>
    <div class="ov-layer">
      <div class="ov-llabel ov-bone">骨<small>Bone</small></div>
      <div class="ov-content">
        <span class="ov-title">Foundation / Operating Loop</span> —— 支撑一切的运转引擎
        <div class="ov-loop">Trace &nbsp;→&nbsp; Retro &nbsp;→&nbsp; Iterate &nbsp;→&nbsp; Eval &nbsp;→&nbsp; Release &nbsp;⟲&nbsp; 回到 Trace</div>
      </div>
    </div>
  </div>

  <div class="ov-ascii-wrap">
    <div class="ov-ascii-label">📐 原图 / Original sketch</div>
    <pre class="ov-ascii">{a1}</pre>
    <pre class="ov-ascii">{a2}</pre>
  </div>

  <div class="ov-explain">
    <p><strong>整个 shiproom 的逻辑:</strong></p>
    <ul>
      <li><strong>两个视角 —— 内 / 外。</strong> <strong>内(我们是谁)</strong>= 10x Productivity,先用 AI 把自己的效率打到 10×;<strong>外(我们服务谁)</strong>= Contribute / Mainstream,把能力贡献给主流用户。</li>
      <li><strong>外这层再拆皮 / 肉 / 骨。</strong> <strong>皮</strong>=Showcase(门面)、<strong>肉</strong>=Capabilities(真正有料的功能)、<strong>骨</strong>=Foundation 的 Operating Loop:Trace→Retro→Iterate→Eval→Release 闭环,让能力持续被评估和迭代。</li>
      <li><strong>每周会就是顺这棵树走一遍。</strong> 下面每个 section 对应模型里的一块:Data / OCV / Release / Security 是运营信号,Showcase / Capabilities / Foundation 是对外的皮肉骨。人工补充走绿色「团队补充」块,不污染 Loop。</li>
    </ul>
  </div>
</section>
""".strip()


def render_view_tree(payload: ViewInput) -> str:
    """Entry point for the dynamic Loop-outline dashboard. NEVER raises; falls
    back to the raw dump on any error (same policy as render_view)."""
    try:
        return _render_view_tree_impl(payload)
    except Exception as exc:  # pragma: no cover - safety net
        return _render_view_fallback(payload, exc)


def _render_view_tree_impl(payload: ViewInput) -> str:
    import loop_tree

    texts = payload.texts
    generated_at = payload.generated_at or dt.datetime.now().astimezone()
    title_date = generated_at.date().isoformat()
    cutoff = payload.archive_cutoff or _this_week_start()
    global _ACTIVE_CUTOFF
    _ACTIVE_CUTOFF = cutoff
    live = texts.get("live_notes", "")
    overlays = payload.overlays or {}
    root = loop_tree.build_tree(texts.get("loop", ""))
    groups = loop_tree.content_root(root).children

    def section_content(node) -> str:
        return render_tree_section(node, texts) + _render_overlay_block(node, overlays)

    nav_parts: list[str] = []
    body_parts: list[str] = []
    for g in groups:
        ganchor = _slug(g.title)
        g_owner = node_owner_label(g)
        nav_parts.append(f'<a href="#{ganchor}">{html.escape(_short_label(display_section_title(g.title, g_owner)))}</a>')
        if g.children:
            subs = []
            for c in g.children:
                canchor = _slug(c.title)
                c_owner = node_owner_label(c)
                nav_parts.append(
                    f'<a href="#{canchor}" class="sub">·{html.escape(_short_label(display_section_title(c.title, c_owner), 14))}</a>'
                )
                subs.append(render_section(canchor, c.title, section_content(c), live, owner=c_owner))
            body_parts.append(
                f'<div class="group" id="{ganchor}">\n<h2 class="group-head">{html.escape(display_section_title(g.title, g_owner))}</h2>\n'
                + "\n".join(subs)
                + "\n</div>"
            )
        else:
            body_parts.append(
                render_section(ganchor, g.title, section_content(g), live, owner=g_owner)
            )

    nav = '<nav class="toc">\n  ' + "\n  ".join(nav_parts) + "\n</nav>"
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Shiproom {title_date}</title>
<style>{CSS}</style>
</head>
<body>
<main class="page">
{nav}

<h1>Shiproom {html.escape(title_date)}</h1>
<p class="meta">Source: live Loop outline + Data / OCV under SharePoint current/. Generated {html.escape(generated_at.isoformat(timespec="minutes"))}.</p>

{''.join(body_parts)}

<div class="sync-all"><button type="button" id="shiproom-sync-all-notes">Sync all notes to SharePoint</button><span class="sync-all-status">Todo Notes and section Live notes autosave locally until synced.</span></div>

{render_live_notes_script()}

</main>
</body>
</html>
"""


def render_tree_section(node, texts: dict) -> str:
    """Render one section node. A few nodes keep their special renderers
    (Todo's editable table, injected Data / OCV); everything else renders
    generically. The generic path recurses into child nodes so sub-tables
    (e.g. Pending Release, PPT/Word/Excel skill evals) are never dropped."""
    t = node.title.lower()
    body = node.body
    imgs = render_loop_images(extract_source_images(body))
    if "action item" in t:
        return render_todo(body, texts.get("prep_summary", "")) + imgs
    if "business metric" in t:
        return render_data(
            texts.get("data", ""), texts.get("prep_summary", ""), texts.get("loop", "")
        ) + imgs
    if "customer voice" in t or "ocv" in t:
        # Every bug ID remains inline in the injected 3-ocv.md table's
        # Bug ID / note column. See prep.md §6.2.2 rule 3.
        return render_ocv(
            texts.get("ocv", ""), texts.get("prep_summary", "")
        ) + imgs
    return render_tree_generic(node)


def render_loop_prose(body: str) -> str:
    """Render a Loop node body faithfully, preserving the Loop's own order:

      * Markdown tables (rebuilt from the DOM at fetch time) render as real
        tables — no more dropped / flattened tables.
      * Links render **inline where they appear** (e.g. "报告 [link]"), never
        hoisted into a separate box at the top of the section.
      * Images render in position, between the surrounding text.
      * Loop avatar / person-chip noise is dropped.
    """
    if not body or not body.strip():
        return ""
    parts: list[str] = []
    for seg in re.split(r"(\[SR_IMAGE:[^\]]*\])", body):
        if not seg.strip():
            continue
        img = SR_IMAGE_RE.match(seg.strip())
        if img and seg.strip().startswith("[SR_IMAGE"):
            url = img.group(1).strip()
            label = (img.group(2) or "Loop image").strip()
            parts.append(render_loop_images([(url, label)]))
            continue
        rendered = markdown_to_html(seg)
        if rendered and rendered != "<p><em>本周无更新。</em></p>":
            parts.append(rendered)
    return "".join(parts)


def render_tree_generic(node, depth: int = 3) -> str:
    out: list[str] = []
    body_html = render_loop_prose(node.body)
    if body_html:
        out.append(body_html)
    for c in node.children:
        tag = "h3" if depth <= 3 else "h4"
        out.append(f"<{tag}>{html.escape(display_section_title(c.title, node_owner_label(c)))}</{tag}>")
        out.append(render_tree_generic(c, depth + 1))
    if not out:
        out.append("<p><em>本周无更新。</em></p>")
    return "".join(out)
