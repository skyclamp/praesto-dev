"""Fetch the Current Shiproom Loop page as markdown via headless Chrome.

Why this exists:
- The Loop page is virtually-scrolled; a normal HTTP fetch returns ~empty.
- The "Print & PDF export" popup at loop.cloud.microsoft/print/... renders the
  FULL document tree at once (DOM, not canvas).
- We grab popup.innerText -- it contains everything, including paragraphs that
  Chromium's print-to-PDF + pdfminer drop on the floor.

Reused user-data-dir (under ~/.playwright/sharepoint-shiproom-loop) so the
MSAL/SharePoint cookies persist across runs after one interactive login.
"""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys
from pathlib import Path

USER_DATA_DIR = os.path.join(
    os.path.expanduser("~"), ".playwright", "sharepoint-shiproom-loop"
)


class LoopFetchError(RuntimeError):
    pass


def _ensure_playwright() -> None:
    """Lazy-install playwright + chromium driver if missing."""
    try:
        import playwright  # noqa: F401
    except ImportError:
        print("[loop_fetch] installing playwright ...", file=sys.stderr)
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "--quiet", "playwright>=1.40"]
        )
    # Ensure chromium driver / msedge channel is available. We only need the
    # 'chrome' channel (system Chrome). If user has no Chrome, we fall back
    # to bundled chromium.
    try:
        # Just verify the playwright CLI works.
        subprocess.check_call(
            [sys.executable, "-m", "playwright", "--version"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


async def _open_overflow(page) -> bool:
    """Click the Loop page header '...' (more options) button."""
    btns = await page.evaluate(
        """
        () => Array.from(document.querySelectorAll('button'))
          .filter(b => {
            const r = b.getBoundingClientRect();
            return r.top < 120 && r.right > window.innerWidth * 0.5
                   && r.width > 0 && r.height > 0;
          })
          .map(b => b.getAttribute('aria-label') || '')
        """
    )
    for a in btns:
        if a == "设置及更多":  # Edge/Chrome's own settings button -- skip
            continue
        if "更多选项" in a or "more options" in a.lower():
            await page.locator(f'button[aria-label="{a}"]').last.click()
            return True
    return False


async def _fetch_async(loop_url: str, timeout_ms: int = 60000,
                        headless: bool = True,
                        wait_for_user: bool = False) -> str:
    from playwright.async_api import async_playwright

    async with async_playwright() as p:
        # Try system Chrome first; fall back to bundled chromium.
        for launch_kwargs in (
            {"channel": "chrome"},
            {"channel": "msedge"},
            {},  # bundled chromium
        ):
            try:
                ctx = await p.chromium.launch_persistent_context(
                    user_data_dir=USER_DATA_DIR,
                    headless=headless,
                    viewport={"width": 1500, "height": 1000},
                    **launch_kwargs,
                )
                break
            except Exception as exc:  # noqa: BLE001
                last_exc = exc
        else:
            raise LoopFetchError(
                f"Could not launch browser: {last_exc}. "
                "Run `python -m playwright install chromium`."
            )

        try:
            page = ctx.pages[0] if ctx.pages else await ctx.new_page()
            _log("opening Loop page")
            await page.goto(loop_url, wait_until="domcontentloaded", timeout=timeout_ms)
            await _settle_loop_page(page)

            if wait_for_user:
                # Headed fallback: let the human SSO / approve access, then
                # press ENTER on stdin. Used by /sr-fetch-notes when headless
                # silent fetch fails (typically: profile has no token for the
                # other user's OneDrive yet).
                print("\n" + "=" * 70, file=sys.stderr)
                print("[loop_fetch] Browser opened. Sign in / approve access if needed,", file=sys.stderr)
                print("[loop_fetch] then press ENTER here to start the capture.", file=sys.stderr)
                print("=" * 70 + "\n", file=sys.stderr)
                delay = int(os.environ.get("SHIPROOM_LOOP_VISIBLE_WAIT_SEC", "0") or "0")
                if delay > 0:
                    print(f"[loop_fetch] Non-interactive mode: waiting {delay}s before capture.", file=sys.stderr)
                    await page.wait_for_timeout(delay * 1000)
                else:
                    await asyncio.get_event_loop().run_in_executor(None, input)

            print_url = await _get_print_url(ctx, page, timeout_ms=timeout_ms)
            _log(f"print URL ready: {print_url[:120]}")
            page2 = await _open_print_page(ctx, print_url, timeout_ms=timeout_ms)
            text = await _capture_print_text(page2)
            if not text or len(text) < 200:
                raise LoopFetchError(f"Print page innerText unexpectedly short ({len(text)} chars)")
            return text
        finally:
            await ctx.close()


def _log(message: str) -> None:
    print(f"[loop_fetch] {message}", file=sys.stderr, flush=True)


async def _settle_loop_page(page) -> None:
    _log("waiting for Loop page to settle")
    try:
        await page.wait_for_load_state("networkidle", timeout=45000)
    except Exception:
        _log("networkidle timed out; continuing")
    await page.wait_for_timeout(8000)


async def _get_print_url(ctx, page, timeout_ms: int = 60000) -> str:
    if not await _open_overflow(page):
        raise LoopFetchError(
            "Could not find Loop's '更多选项' / 'more options' button. "
            "Likely not signed in -- delete the user-data-dir and re-run."
        )
    await page.wait_for_timeout(800)
    for label in ("打印和 PDF 导出", "Print & PDF export"):
        try:
            _log(f"clicking menu item: {label}")
            async with ctx.expect_page(timeout=20000) as info:
                await page.get_by_text(label, exact=False).first.click(timeout=10000)
            popup = await info.value
            await popup.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
            print_url = popup.url
            await popup.close()
            if print_url:
                return print_url
        except Exception as exc:  # noqa: BLE001
            _log(f"menu item {label!r} failed: {type(exc).__name__}: {exc}")
    raise LoopFetchError("Could not open Loop Print & PDF export popup")


async def _open_print_page(ctx, print_url: str, timeout_ms: int = 60000):
    _log("opening print page with window.print neutralized")
    page = await ctx.new_page()
    await page.add_init_script("window.print = () => {};")
    await page.goto(print_url, wait_until="domcontentloaded", timeout=timeout_ms)
    try:
        await page.wait_for_load_state("networkidle", timeout=20000)
    except Exception:
        pass
    return page


async def _capture_print_text(page) -> str:
    _log("waiting for print page text")
    text = await _wait_until_stable(page, idle_ms=3000, max_ms=45000)
    _log(f"initial print text length: {len(text or '')}")
    await _inline_heading_levels(page)
    await _inline_person_chips(page)
    await _inline_business_metric_links(page)
    await _inline_tables(page)
    await _inline_blocks(page)
    img_map = await _capture_loop_images(page)
    text = await page.evaluate("() => document.body.innerText")
    for idx, uri, label in img_map:
        text = text.replace(f"[SR_IMG_SLOT:{idx}]", f"[SR_IMAGE: {uri} | {label}]")
    _log(f"final print text length: {len(text or '')}; links={text.count('[SR_LINK:') if text else 0}; images={text.count('[SR_IMAGE:') if text else 0}; headings={text.count('[SR_H:') if text else 0}")
    return text


async def _wait_until_stable(page, idle_ms: int = 6000, max_ms: int = 90000,
                              poll_ms: int = 500) -> str:
    """Poll document.body.innerText.length; return text once length is stable
    for `idle_ms` (or after `max_ms` total)."""
    elapsed = 0
    last_len = -1
    stable_for = 0
    text = ""
    while elapsed < max_ms:
        await page.wait_for_timeout(poll_ms)
        elapsed += poll_ms
        text = await page.evaluate("() => document.body.innerText")
        cur = len(text or "")
        if cur == last_len and cur > 0:
            stable_for += poll_ms
            if stable_for >= idle_ms:
                return text
        else:
            stable_for = 0
            last_len = cur
    return text


async def _inline_person_chips(page) -> None:
    """Loop renders @mentions / dates / status pills as elements with empty
    visible text — only an icon / colour pill / tooltip. Their `aria-label`
    (or nested `img.alt`) holds the actual value. Walk the DOM and inject
    that value as a real text node so the subsequent innerText capture
    picks it up.

    Covers three chip families found in the Shiproom Loop:
    - Person mentions (e.g. "Example Owner", "Another Owner (Team)", 中文姓名)
      - Date / ETA pills (e.g. "Tuesday, May 26, 2026", "今天", "5月26日 周二")
      - Progress pills ("In progress", "Completed", "Not started")

    Heuristic selectors are intentionally broad to survive Loop UI churn.
    """
    await page.evaluate(
        """
        () => {
          // Loop's empty date / person / status pickers also expose aria-labels
          // ("选择日期", "选择人员", "添加日期", "Pick a date", "Add a date"). They
          // must NOT be inlined as content — keep this list in sync with the
          // empty-cell placeholders observed in the wild.
          const UI_PLACEHOLDERS = new Set([
            '选择日期', '选择人员', '选择状态', '添加日期', '添加人员',
            '核对清单',
            'Pick a date', 'Add a date', 'Select date', 'Select person',
            'Add person', 'Select status'
          ]);
          const isPersonName = (s) => {
            if (!s) return false;
            const t = s.trim();
            if (!t || t.length > 60) return false;
            if (UI_PLACEHOLDERS.has(t)) return false;
            // English: 1-4 capitalised words, optional " (suffix)".
            // Chinese: 2-4 CJK chars, optional " (suffix)".
            return /^[A-Z][A-Za-z'.-]+(?:\\s+[A-Z][A-Za-z'.-]+){0,3}(?:\\s*\\([^)]+\\))?$/.test(t)
                || /^[\\u4e00-\\u9fa5]{2,4}(?:\\s*\\([^)]+\\))?$/.test(t);
          };
          const isDate = (s) => {
            if (!s) return false;
            const t = s.trim();
            if (!t || t.length > 80) return false;
            if (UI_PLACEHOLDERS.has(t)) return false;
            // YYYY-MM-DD, YYYY/M/D, M/D, 2026年5月26日(周二/星期二), May 26,
            // 2026 / Tue, May 26 2026 / 今天 / 明天 / 昨天 / 后天 / 本周 / 下周.
            return /^\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}/.test(t)
                || /^\\d{1,2}[\\/-]\\d{1,2}$/.test(t)
                || /^\\d{4}年\\d{1,2}月\\d{1,2}日/.test(t)
                || /^\\d{1,2}月\\d{1,2}日/.test(t)
                || /^(今天|明天|昨天|后天|本周|下周)$/.test(t)
                || /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)[a-z]*,?\\s/i.test(t)
                || /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\\s+\\d{1,2}/i.test(t);
          };
          const isStatus = (s) => {
            if (!s) return false;
            const t = s.trim().toLowerCase();
            return t === 'in progress' || t === 'completed'
                || t === 'not started' || t === 'blocked'
                || t === 'on hold' || t === 'done';
          };
          const isInteresting = (s) => isPersonName(s) || isDate(s) || isStatus(s);
          const inject = (el, value) => {
            if (!value) return;
            if (el.dataset.shipNameInjected === '1') return;
            el.dataset.shipNameInjected = '1';
            const tn = document.createTextNode(' ' + value + ' ');
            el.appendChild(tn);
          };
          const seen = new WeakSet();
          // Pass 1: any chip-shaped element with aria-label and empty text.
          const sel = [
            '[data-lpc-mention]', '[data-mention]',
            '[data-id][aria-label]',
            'button[aria-label]', '[role="link"][aria-label]',
            '[role="button"][aria-label]',
            'span[aria-label]', 'div[aria-label]'
          ].join(',');
          document.querySelectorAll(sel).forEach(el => {
            if (seen.has(el)) return;
            const text = (el.innerText || '').trim();
            if (text) return; // already has visible text — not a bare chip
            const label = el.getAttribute('aria-label') || '';
            if (isInteresting(label)) {
              inject(el, label);
              seen.add(el);
            }
          });
          // Pass 2: avatar / icon images inside otherwise-empty wrappers.
          document.querySelectorAll('img[alt]').forEach(img => {
            const alt = img.getAttribute('alt') || '';
            if (!isInteresting(alt)) return;
            let host = img.parentElement;
            while (host && host !== document.body) {
              const t = (host.innerText || '').trim();
              if (t) break;
              host = host.parentElement;
            }
            const target = host && host !== document.body ? host : img.parentElement;
            if (target && !seen.has(target)) {
              inject(target, alt);
              seen.add(target);
            }
          });
        }
        """
    )


async def _inline_business_metric_links(page) -> None:
        """Preserve hrefs for Loop content links."""
        await page.evaluate(
                """
                () => {
                      const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                    const hrefFor = (el) => {
                        const link = el.closest && el.closest('a[href]');
                        if (link) return link.href;
                        if (el.href) return el.href;
                        for (const attr of ['href', 'data-href', 'data-url', 'data-target-url']) {
                            const value = el.getAttribute && el.getAttribute(attr);
                              if (value && /^https?:\\/\\//i.test(value)) return value;
                        }
                        return '';
                    };
                    const labelFor = (el) => norm(
                        el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || ''
                    );
                    const candidates = Array.from(document.querySelectorAll(
                        'a[href], [role="link"], [data-href], [data-url], [data-target-url]'
                    ));
                    const seen = new Set();
                    for (const el of candidates) {
                        if (el.dataset.shiproomLinkInjected === '1') continue;
                        const href = hrefFor(el);
                        const label = labelFor(el);
                        if (!href || !label || label.length > 180) continue;
                        if (/^(https?:\\/\\/|mailto:)/i.test(label)) continue;
                        const key = `${label}\n${href}`;
                        if (seen.has(key)) continue;
                        seen.add(key);
                        el.dataset.shiproomLinkInjected = '1';
                        el.appendChild(document.createTextNode(` [SR_LINK: ${href}]`));
                    }
                }
                """
        )


async def _inline_blocks(page) -> None:
    """Capture the block STRUCTURE and visual INDENTATION of every Loop text
    block BEFORE the innerText capture, so the renderer can reproduce Loop's
    layout & hierarchy instead of flattening everything into a wall of
    look-alike paragraphs ("一坨").

    ``document.body.innerText`` drops bullet glyphs AND indentation, so a nested
    list — or an indented sub-paragraph like the lines under "Skills to Cowork:"
    — collapses into flat, same-looking lines. The DOM exposes each block as a
    ``div.scriptor-paragraph`` positioned by its own left offset; list items add
    ``scriptor-listItem`` and sit inside an ``<li>`` whose ``list-style-type``
    tells ordered ("1. ") from unordered ("• ").

    Each block gets an inline ``[SR_B:<left>:<kind>]`` start marker + a trailing
    ``[SR_ENDB]``:
      * ``<left>`` = rounded viewport x (``getBoundingClientRect().left``). The
        renderer derives RELATIVE nesting depth by comparing these, which is
        robust against Loop's mixed indent CSS (margin-left / aria-level are not
        reliable — sibling levels can share an aria-level yet differ in offset).
      * ``<kind>`` = ``o`` ordered item, ``u`` bullet item, ``p`` paragraph.
    Headings (already carrying ``[SR_H:]``) and empty blocks are skipped.
    """
    await page.evaluate(
        r"""
        () => {
          const paras = Array.from(document.querySelectorAll('div.scriptor-paragraph'));
          for (const el of paras) {
            if (el.dataset.srBDone === '1') continue;
            el.dataset.srBDone = '1';
            const txt = el.innerText || '';
            if (!txt.trim()) continue;
            if (txt.indexOf('[SR_H:') >= 0) continue;   // heading — leave as-is
            // A paragraph that wraps a table we already converted to Markdown
            // must NOT be wrapped as one block, or the whole table would collapse
            // into a single line. Leave the table markdown untouched.
            if (el.querySelector('[data-sr-table-done]') || /\|\s*---\s*\|/.test(txt)) continue;
            const left = Math.round(el.getBoundingClientRect().left);
            let kind = 'p';
            if ((el.className || '').toString().indexOf('scriptor-listItem') >= 0) {
              const li = el.closest('li');
              const lst = li ? (getComputedStyle(li).listStyleType || '').toLowerCase() : '';
              const ordered = /\d/.test(lst) || lst.indexOf('decimal') >= 0
                              || lst.indexOf('roman') >= 0 || lst.indexOf('alpha') >= 0;
              kind = ordered ? 'o' : 'u';
            }
            const start = document.createElement('span');
            start.textContent = `[SR_B:${left}:${kind}] `;
            el.insertBefore(start, el.firstChild);
            const end = document.createElement('span');
            end.textContent = ` [SR_ENDB]`;
            el.appendChild(end);
          }
        }
        """
    )


async def _inline_tables(page) -> None:
    """Convert every Loop table (``<table role="table">``) into a Markdown pipe
    table injected as text, BEFORE the innerText capture.

    Why: ``document.body.innerText`` flattens a table into one cell per line and
    silently drops empty / merged cells, so the row/column structure (and any
    alignment) is unrecoverable downstream. The DOM, however, exposes the table
    as ``role="columnheader"`` cells (the header row) followed by ``role="cell"``
    cells in strict row-major order (empty/merged cells present as ""), so we can
    rebuild a faithful Markdown table here and let the renderer's existing
    Markdown-table support draw it.

    Person chips inside a cell arrive as "EO Example Owner" (initials + full name);
    we drop the redundant initials when they match the following name. Any
    ``[SR_H:<px>]`` markers injected earlier into bold header cells are stripped.
    """
    await page.evaluate(
        r"""
        () => {
          const clean = (s) => (s || '')
              .replace(/\[SR_H:\d+\]/g, ' ')
              .replace(/\[SR_B:-?\d+:[oup]\]/g, ' ')
              .replace(/\[SR_ENDB\]/g, ' ')
              .replace(/[ \t]+/g, ' ')
              .trim();
          // Drop a person-chip's redundant initials ("EO Example Owner" -> "Example
          // Tang") only when the 2 uppercase letters match the following two
          // capitalised names -- safe against acronyms like MCP / GPT / OCV.
          const dropInitials = (s) => s.replace(
            /\b([A-Z])([A-Z])\s+([A-Z][a-z'’.\-]+)(?:\s+([A-Z][a-z'’.\-]+))?/g,
            (m, a, b, n1, n2) => {
              if (n2 && a === n1[0] && b === n2[0]) return n1 + ' ' + n2 + ' · ';
              return m;
            }
          );
          // Preserve intra-cell line breaks: a Loop cell often stacks several
          // points ("[Done] ...", "[0526] ...", "Action - ...") on their own
          // lines. Markdown rows can't contain a real newline, so we join the
          // lines with a [SR_BR] sentinel the renderer turns into <br>, instead
          // of collapsing them into one "一坨".
          const cellText = (el) => {
            const raw = el.innerText || el.textContent || '';
            const parts = raw.split(/\n+/)
              .map(clean)
              // Drop empty cells, Loop's placeholder, and bare avatar initials
              // ("JT", "CG") which now sit on their own line above the name.
              .filter((x) => x && x !== '单元格' && x !== 'Cell' && !/^[A-Z]{2}$/.test(x))
              .map((x) => dropInitials(x).replace(/\s*·\s*$/, ''));
            return parts.join(' [SR_BR] ').replace(/\|/g, '/');
          };
          const tables = Array.from(document.querySelectorAll('[role="table"]'));
          for (const t of tables) {
            if (t.dataset.srTableDone === '1') continue;
            const headers = Array.from(t.querySelectorAll('[role="columnheader"]')).map(cellText);
            const cells = Array.from(t.querySelectorAll('[role="cell"],[role="gridcell"]')).map(cellText);
            const ncol = headers.length;
            if (ncol < 1 || cells.length < 1) continue;
            const lines = [];
            lines.push('| ' + headers.join(' | ') + ' |');
            lines.push('| ' + headers.map(() => '---').join(' | ') + ' |');
            for (let i = 0; i < cells.length; i += ncol) {
              const row = cells.slice(i, i + ncol);
              while (row.length < ncol) row.push('');
              lines.push('| ' + row.join(' | ') + ' |');
            }
            const box = document.createElement('div');
            box.dataset.srTableDone = '1';
            const blank = () => { const d = document.createElement('div'); d.textContent = ''; return d; };
            box.appendChild(blank());
            for (const ln of lines) {
              const d = document.createElement('div');
              d.textContent = ln;
              box.appendChild(d);
            }
            box.appendChild(blank());
            t.replaceWith(box);
          }
        }
        """
    )


async def _inline_heading_levels(page) -> None:
    """Prepend a [SR_H:<px>] marker to every heading text-run so the renderer
    can rebuild the Loop's own outline (larger font-size == higher outline
    level) with zero hard-coded section keywords. A heading is any text span
    rendered bold (font-weight >= 600) at font-size >= 18px -- which is how the
    Loop/Scriptor editor styles its H1/H2/H3 headings."""
    await page.evaluate(
        """
        () => {
          const spans = Array.from(document.querySelectorAll('span'));
          for (const sp of spans) {
            let own = '';
            for (const n of sp.childNodes) { if (n.nodeType === 3) own += n.textContent; }
            if (!own.trim()) continue;
            const cs = getComputedStyle(sp);
            const fw = parseInt(cs.fontWeight) || 0;
            const fs = Math.round(parseFloat(cs.fontSize) || 0);
            if (fw < 600 || fs < 18) continue;
            const marker = document.createElement('span');
            marker.textContent = `[SR_H:${fs}] `;
            sp.insertBefore(marker, sp.firstChild);
          }
        }
        """
    )


async def _capture_loop_images(page) -> list:
    """Screenshot every embedded image / canvas region (>= 200x100 px) and
    return [(idx, data_uri, label)]. We screenshot the rendered region instead
    of grabbing the image URL because Loop images are canvas/blob-backed or sit
    behind expiring SharePoint-auth URLs that won't load in a standalone
    view.html. A base64 JPEG data URI makes the dashboard self-contained.

    JS tags each element with data-sr-img-idx and inserts a `[SR_IMG_SLOT:idx]`
    text marker (captured by innerText); Python then screenshots each element
    and the caller swaps the slot marker for a real `[SR_IMAGE: <uri> | label]`.
    """
    import base64

    metas = await page.evaluate(
        """
        () => {
          const out = [];
          let idx = 0;
          for (const el of Array.from(document.querySelectorAll('img, canvas'))) {
            const r = el.getBoundingClientRect();
            if (r.width < 200 || r.height < 100) continue;
            el.setAttribute('data-sr-img-idx', String(idx));
            const label = (el.getAttribute('alt') || el.getAttribute('aria-label')
                           || el.getAttribute('title') || 'Loop image')
                          .replace(/\\s+/g, ' ').trim();
            const m = document.createElement('div');
            m.textContent = `\n[SR_IMG_SLOT:${idx}]`;
            el.insertAdjacentElement('afterend', m);
            out.push({idx, label});
            idx++;
          }
          return out;
        }
        """
    )
    results = []
    for meta in metas:
        idx = meta["idx"]
        label = meta.get("label") or "Loop image"
        try:
            el = page.locator(f'[data-sr-img-idx="{idx}"]').first
            png = await el.screenshot(type="jpeg", quality=72, timeout=8000)
            uri = "data:image/jpeg;base64," + base64.b64encode(png).decode("ascii")
            results.append((idx, uri, label))
            _log(f"captured image {idx} ({len(png)} bytes) label={label!r}")
        except Exception as exc:  # noqa: BLE001
            _log(f"image {idx} screenshot failed: {type(exc).__name__}: {exc}")
    return results


async def _inline_loop_images(page) -> None:
        """Preserve useful embedded image URLs for renderer display."""
        await page.evaluate(
                """
                () => {
                      const norm = (s) => (s || '').replace(/\\s+/g, ' ').trim();
                    const seen = new Set();
                    for (const img of Array.from(document.querySelectorAll('img'))) {
                        const rect = img.getBoundingClientRect();
                        if (rect.width < 80 || rect.height < 50) continue;
                        const src = img.currentSrc || img.src || img.getAttribute('data-src') || '';
                        if (!/^https?:\\/\\//i.test(src) || src.length > 2000) continue;
                        if (!src || seen.has(src)) continue;
                        seen.add(src);
                        const label = norm(img.alt || img.getAttribute('aria-label') || img.getAttribute('title') || 'Loop image');
                        const marker = document.createElement('div');
                        marker.textContent = `[SR_IMAGE: ${src} | ${label}]`;
                        img.insertAdjacentElement('afterend', marker);
                    }
                }
                """
        )


def _clean(text: str) -> str:
    """Lightly normalize the Loop popup innerText -- collapse runs of empty
    table-cell separators and excessive blank lines."""
    out_lines: list[str] = []
    blank = 0
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            blank += 1
            if blank <= 1:
                out_lines.append("")
            continue
        blank = 0
        # Drop pure tab lines that come from empty table cells.
        if line.strip() == "":
            continue
        out_lines.append(line)
    return "\n".join(out_lines).rstrip() + "\n"


def fetch_loop_markdown(loop_url: str, *, headless: bool = True,
                         wait_for_user: bool = False) -> str:
    """Synchronous wrapper. Returns cleaned markdown-ish text or raises LoopFetchError.

    headless=True (default) is silent — used for the Current Loop and the common
    case for meeting-notes Loops (the persistent profile usually already has
    the SharePoint cookie).

    headless=False + wait_for_user=True is the fallback for first-time access
    to someone else's OneDrive Loop: the host sees a window, signs in / clicks
    "request access", presses ENTER, and the same capture path runs.
    """
    if not loop_url or not loop_url.startswith("http"):
        raise LoopFetchError(f"Invalid Loop URL: {loop_url!r}")
    _ensure_playwright()
    text = asyncio.run(_fetch_async(
        loop_url, headless=headless, wait_for_user=wait_for_user
    ))
    return _clean(text)


def fetch_loop_with_fallback(loop_url: str) -> str:
    """Try silent headless first; on LoopFetchError, retry with a visible
    browser so the host can SSO / approve once. After the first successful
    interactive run, the persistent profile holds the cookie and subsequent
    runs go silent."""
    try:
        return fetch_loop_markdown(loop_url, headless=True)
    except LoopFetchError as exc:
        print(f"[loop_fetch] silent fetch failed ({exc}); falling back to "
              f"headed mode for SSO ...", file=sys.stderr)
        return fetch_loop_markdown(loop_url, headless=False, wait_for_user=True)
