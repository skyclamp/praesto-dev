"""Quick consistency check between AGENT.md quick-ref sections and framework/rules/*.md.

For each command family (update / prep / archive / ask):
  - Pull the AGENT.md §2.x prose under that command.
  - Extract concrete identifiers from it (CLI tokens, function names, file paths,
    section / bullet headers).
  - Verify that every identifier also appears somewhere inside the matching
    `framework/rules/<name>.md`.

The check is intentionally strict-subset (AGENT identifiers ⊂ rules identifiers):
the playbooks may carry more detail, but the quick-ref must not introduce facts
the playbook doesn't back up.

Exit code 0 if consistent, 1 if drift detected. Use as a pre-commit / CI hook.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # societas-shiproom/

PAIRS = {
    "update": ("AGENT.md", r"^###\s+2\.2\s+`/sr-update", "framework/rules/update.md"),
    "prep":   ("AGENT.md", r"^###\s+2\.8\s+`/sr-prep",   "framework/rules/prep.md"),
    "archive":("AGENT.md", r"^###\s+2\.6\s+`/sr-archive",  "framework/rules/archive.md"),
    "ask":    ("AGENT.md", r"^###\s+2\.7\s+`/sr-ask",      "framework/rules/ask.md"),
}

# Identifier patterns we care about. Match anywhere in the text (backticks
# optional) — the playbooks freely mix `current/foo.md`, "current/foo.md" and
# bare `cloud_cli list-history` style.
TOKEN_PATTERNS = [
    re.compile(r"cloud_cli(?:\.py)?\s+([a-z][\w-]+)"),
    re.compile(r"cloud\.([a-z_]+)\("),
    re.compile(r"(current/[\w./-]+(?:\.md|\.html|\.pdf))"),
    re.compile(r"(history/[\w./<>-]+(?:\.md|\.html|\.pdf|/))"),
    re.compile(r"(/sr-[a-z-]+)"),
]


# Token aliases — different spellings of the same concept should be treated equal.
ALIASES: dict[str, str] = {
    # path placeholders
    "history/<date>/": "history/<date>/",
    "history/<latest>/": "history/<date>/",
}


def normalize(tok: str) -> str:
    return ALIASES.get(tok, tok)


def extract_section(text: str, header_pat: str) -> str:
    m = re.search(header_pat, text, re.M)
    if not m:
        return ""
    tail = text[m.end():]
    stop = re.search(r"^###\s+\d+\.\d", tail, re.M)
    return tail[:stop.start()] if stop else tail


def tokens(text: str) -> set[str]:
    out: set[str] = set()
    for pat in TOKEN_PATTERNS:
        for m in pat.finditer(text):
            out.add(normalize(m.group(1)))
    return out


def main() -> int:
    drift_found = False
    for cmd, (agent_rel, header_pat, rules_rel) in PAIRS.items():
        agent_path = ROOT / agent_rel
        rules_path = ROOT / rules_rel
        if not agent_path.exists() or not rules_path.exists():
            print(f"[skip] {cmd}: missing {agent_path if not agent_path.exists() else rules_path}")
            continue
        section = extract_section(agent_path.read_text(encoding="utf-8"), header_pat)
        if not section.strip():
            print(f"[skip] {cmd}: no section matched in {agent_rel}")
            continue
        rules_text = rules_path.read_text(encoding="utf-8")
        agent_tokens = tokens(section)
        rules_tokens = tokens(rules_text)
        missing = sorted(agent_tokens - rules_tokens)
        if missing:
            drift_found = True
            print(f"[drift] /sr-{cmd}: identifiers in AGENT quick-ref but NOT in {rules_rel}:")
            for tok in missing:
                print(f"  - {tok}")
        else:
            print(f"[ok]   /sr-{cmd}: {len(agent_tokens)} identifiers all backed by {rules_rel}")
    return 1 if drift_found else 0


if __name__ == "__main__":
    sys.exit(main())
