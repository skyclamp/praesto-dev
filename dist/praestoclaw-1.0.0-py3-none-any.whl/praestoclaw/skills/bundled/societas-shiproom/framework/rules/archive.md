# `/sr-archive` —— 会后存档流程说明

> **这份文档干嘛用的**：跟 [`prep.md`](prep.md)、[`update.md`](update.md)、[`ask.md`](ask.md) 是同级的 "playbook"，专门讲 agent 在 host 触发 `/sr-archive` 之后该怎么把这周的工作冻成 `history/<date>/`、清空 `current/`、为下一周开新页。
>
> **谁会读它**：上半部分（中文）是给人看的，让你理解整个流程是怎么跑的；下半部分（英文 rules block）是给 agent 看的，落实成具体的判断规则。

[`AGENT.md` §2.6](../../AGENT.md) 里的高阶描述指向这里。

---

## 一、整体逻辑（中文说明）

存档发生在**会议结束之后**。这一步要做的事情很简单 —— 把这一周累积在 `current/` 下面的所有东西（Loop、updates、notes）整体快照到 `history/<会议日期>/` 下面。

> **🔑 默认 carry-forward 模式**：archive **不会清空** `current/`。文件保留原位，mtime 也保持原样。这样下一次 prep 检查表会看到这些文件是上一个 meeting 周期的 → 自动标 `[STALE]` / `[LEFT]` → 强制 fetch-loop / fetch-ocv 重拓。
>
> **🕑 事件驱动的 cutoff（多会议节奏友好）**：archive 成功后会在 `current/.last-archive` 写入一个 ISO 时间戳（= 此次归档完成时间）。下次 prep / render_view 会读这个时间戳作为 cutoff：
> - 任何时间戳 ≥ cutoff 的 manual update 会进入本次 view。
> - 时间戳 < cutoff 的 → 已被上一个周期带走，不会出现在本次 view.html。
> - **完全不需要硬编码“周三 / 周五 / 上午10:30”**——只要 host 会后及时跑 `/sr-archive`，cutoff 自动跟上。
> - 首次部署 / 老仓库没有这个标记 → fall back “本周一 00:00”，下次 archive 后自然就有了。
>
> **怎么避免上周内容出现在这周 view？**
> 1. LOOP-SYNC 块：fetch-loop / fetch-ocv 覆盖块内所有内容 + 更新顶部 `<!-- Auto-synced at <ISO> -->` 时间戳。
> 2. Human entries（LOOP-SYNC 外的 `### @user · ISO`）：render_view 按 `.last-archive` cutoff 过滤，**上个周期的 /sr-update 不会出现在这次 view.html 里**（原始文件保留供以后 /sr-ask）。
> 3. 2-data.md：数据部分负责人重传会覆盖。没重传则 mtime 在 cutoff 之前 → prep 报 `[STALE]` → host 看得见。
>
> **什么时候用 `--clear`？**造错了需要重置 current/，或者进入一个全新项目期。日常周期不需要。

但在抢之前，我们要保证 `current/notes.md` 是**完整的**——也就是说，这次会议产出的最新 meeting notes 也已经抓下来了。这一点很关键，因为：

- `/sr-update`、`/sr-notes`、`/sr-prep` 都是**会前**写入的
- `current/notes.md` 里到归档之前可能只有 `/sr-notes` 的速记（如果有人在会中速记）
- 真正的会议结论是 Facilitator bot 在会议结束时发到群里的那一份 Loop（"各位，会议结束了"）

所以归档流程长这样：

```
host 说 /sr-archive
  │
  ├─ 1. 先看一眼 current/        (cloud_cli.py status)
  │     ↳ 让 host 心里有数：哪些文件在、有多大、最后修改时间
  │
  ├─ 2. 抓最新 meeting notes      (`/sr-fetch-notes` → `cloud_cli.py fetch-notes`)
  │     ↳ 默认 silent，30 秒搞定
  │     ↳ 失败就有头浏览器让 host SSO 一次
  │     ↳ 再失败就给 Loop URL，让 host 下 PDF 走 /sr-upload-notes
  │     ↳ host 明确说 "archive without notes" 也可以跳过
  │
  ├─ 3. 提醒 host：speed notes 也会被归档
  │     ↳ 任何用 /sr-notes 速记过的决策都已经在 current/notes.md 里
  │     ↳ 如果一条都没有也不用强求
  │
  ├─ 4. 显式确认                  ("快照 current/ 到 history/2026-05-15/（carry-forward, current/ 不动）?")
  │     ↳ 必须等 host 回 yes，不能默认推进
  │
  └─ 5. 执行                       (cloud_cli.py archive [<date>])
        ↳ 复制 current/ → history/<date>/
        ↳ 默认保留 current/ 不动（carry-forward；加 --clear 才会清空）
        ↳ 报回 SharePoint URL
```

### 几个关键决策点

**为什么是 host 来跑？** SharePoint 权限上谁都能跑，但团队约定由本周会议主持人收尾。Agent **不主动催别人**归档——只在 host 触发了 `/sr-archive` 之后才进入这个流程。

**日期默认是今天，但可以指定。** 如果 host 在周五开完会、周一才想起来归档，他可以 `/sr-archive 2026-05-15` 把日期指回会议当天。Agent 应该**主动提醒**这一点，尤其当 today != 最近一次 meeting notes 的日期时：

> 看 Teams 里最新的 meeting notes 是 5/8 那次。要归档到 `history/2026-05-08/` 还是用今天的日期 `history/2026-05-12/`？

**为什么不能跳过 notes？** 因为 `history/<date>/` 一旦创建就是会议快照，下周再想补 notes 就要去 `history/<date>/` 里塞，破坏了 history 的“快照”语义。所以 archive 前一定要把这次的 notes 落定。

**archive 不可逆。** Graph API 这一层没有撤销键。如果 `history/<date>/` 已经存在了，`archive` 会直接 refuse，让你换一个日期或者手动去 SharePoint 删掉旧的再来。这是故意的——防止"哎我以为我归档过这次"的覆盖事故。

---

## 二、追问逻辑（中文说明）

Archive 跟 update 不一样，不需要"两层问"——它的所有问题都是**程序性的**，不是策略性的。但是 agent 要根据 host 的回答做分支决策。

主要分支：

| host 回答 | agent 的动作 |
|---|---|
| `yes` / `归档` | 直接跑 `cloud_cli.py archive [<date>]` |
| `no` / `等等` | 停下，问 host 还想确认什么。常见是想再加一条 `/sr-notes` 速记 |
| `用上次开会的日期` | 跑 `cloud_cli.py archive <最新 notes 的日期>` |
| `archive without notes` | 跳过 fetch-notes，直接进 step 4 |
| 提供 PDF 路径 | 先跑 `/sr-upload-notes <path>`，然后回到 step 3 |

**fetch-notes 失败时怎么说**：把脚本 stderr 里的内容**原样**转给 host，不要美化、不要省略 URL。host 需要那个链接去手动操作。

**Idempotency 保护**：如果 host 重复触发 `/sr-archive` 而 `history/<date>/` 已经存在了，agent 不要自动改日期或者删旧的——直接告诉 host："`history/2026-05-12/` 已经存在了，想用别的日期吗？还是先去 SharePoint 把旧的删掉？"

---

## 三、写入反馈契约（中文说明）

每次成功归档之后，agent **必须**给一个统一格式的确认（归档路径本身就是 SharePoint 超链接，不要另起一行 "🔗 url"）：

```
✅ 已归档 current/ → [history/<date>/](<SharePoint URL for history/<date>/>)
   含：currentloop.md（auto-fetched）, notes.md（auto-fetched）,
       updates/0..7-*.md（all-week accumulated）
📎 current/ 保留原样（carry-forward）。下周 /sr-prep 会自动重拓 LOOP-SYNC 块，上周的 manual update 不会出现在下周 view.html 里。
```

SharePoint URL 由 `cloud_cli.py archive` 返回；host 点路径可直达归档目录。

归档后如果用户马上说“我要 update”或开始给下周更新，agent 要把最新 `history/<date>/view.html` / summary / Loop 当作上下文来源给用户参考，然后继续走 `/sr-update` 的正常两层追问。不要因为 `current/` 清空了就减少追问。

---

## 四、其他规则（中文说明）

- **archive 后不要立刻跑 prep**。下一次会议可能还有几天，host 不需要现在就开始下周准备。如果 host 接着问 "那下周的怎么开始？" 才指向 `/sr-prep`。
- **archive 后仍要认真处理 update**。`current/` 被清空只是说明上周内容已经在 `history/<date>/`，不是说明 agent 可以裸聊。后续 `/sr-update` 仍必须按 [`update.md`](update.md) 判断 FYI vs actionable；需要推动时轻量追问，明显 FYI 时直接写入。
- **不要建议删除 history**。`history/` 是只读语义——agent 收到 "把 history/X 删掉" 一律拒绝，让 host 走 SharePoint 回收站。
- **要不要也归档 `view.html`**：如果 `/sr-prep` 生成过 `current/view.html`，归档会把它一起带走。这是预期行为，不要特殊处理。

---

## 五、Agent rules — machine-readable summary

> Everything below is the authoritative ruleset the agent must follow.
> Keep this short. When in doubt, the rules here win over the prose above.

### Trigger

User intent that maps to `/sr-archive`:
- explicit slash command `/sr-archive [<YYYY-MM-DD>]`
- "归档", "存档", "archive this week", "close out the week", "把这周的归档了"

### Required preconditions before invoking `cloud_cli.py archive`

1. Run `cloud_cli.py status`. If `current/` is empty, do NOT archive — surface
   the state and ask the host whether they meant `/sr-prep` instead.
2. Decide the target date. Default = `dt.date.today()`. But if the latest
   meeting notes URL in the Teams chat is from a different date, surface BOTH
   options and ask which to use. NEVER silently use today's date when the
   meeting was clearly earlier.
3. Ensure `current/notes.md` is fresh:
   - If missing OR last-modified time is earlier than the latest Teams-chat
     meeting-notes timestamp → run `cloud_cli.py fetch-notes`.
   - If `fetch-notes` exit code is 0 → continue.
   - If exit code is 4 (manual PDF needed) → relay the printed Loop URL to
     the host verbatim. Wait for one of:
     - a local PDF path → run `cloud_cli.py upload-notes <path>`, then continue.
     - "archive without notes" / "跳过 notes" → continue without notes.
     - "let me check" / silence → stop. Do NOT archive.
4. Show the host the `notes.md` size + `/sr-notes` entry count (parse the file
   for `### @...` headers). Ask: "Any final summary to add via /sr-notes? (skip / type something)".
   Wait for explicit response.
5. Final confirm:
   > Snapshot `current/` → `history/<date>/` (carry-forward; current/ untouched). Continue? (yes / no)
   Wait for explicit `yes`. Any other reply = stop.
   If host explicitly asks to wipe current/, run with `--clear` and adjust the prompt.

### Idempotency

- If `cloud_cli.py archive` returns non-zero AND the message says `history/<date>/ already exists`:
  - Do NOT auto-change the date.
  - Do NOT auto-delete the existing folder.
  - Tell the host: "history/<date>/ 已经存在了。换个日期？或者你先去 SharePoint 删掉旧的再来？"

### Confirmation contract (after success)

Every successful archive MUST end with this exact format (path is the SharePoint hyperlink itself, no extra `🔗 url` line):

```
✅ 已归档 current/ → [history/<date>/](<SharePoint URL>)
📎 current/ 保留原样（carry-forward）。
```

(Include a one-line content summary if helpful: "含：currentloop.md, notes.md, updates/0..7-*.md".)
(If host requested `--clear`, change the second line to "🧹 current/ 已清空".)

### Failure handling

- `fetch-notes` failures: relay stderr verbatim, including the Loop URL line.
- `archive` failures (non-`already exists`): show stderr verbatim, do NOT retry,
  do NOT claim success. Ask the host to re-check `cloud_cli.py status` and decide.

### Things the agent MUST NOT do

- ❌ Auto-archive on schedule, on /sr-status, or on any path other than explicit user intent.
- ❌ Skip the final yes/no confirm "because the host already said /sr-archive".
- ❌ Delete anything under `history/` for any reason. Always refuse.
- ❌ Pick a target date silently when there's ambiguity between today and the meeting date.
- ❌ Continue past `fetch-notes` failure without an explicit "archive without notes" from the host.
