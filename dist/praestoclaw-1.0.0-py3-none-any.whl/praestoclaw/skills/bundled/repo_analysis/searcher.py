"""
searcher.py — Knowledge base search utilities for the repo-analysis skill.

Provides grep-level keyword search over the kb/ directory, fuzzy matching
against the QA cache, and module document lookup by name.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import NamedTuple


class SearchResult(NamedTuple):
    """A single search result from the knowledge base."""

    doc_path: str  # Relative path within kb/
    snippet: str  # Matched text excerpt (up to 300 chars)
    score: float  # Relevance score 0.0–1.0 (heuristic)
    line_no: int  # Line number of the match (1-indexed)


class QACacheEntry(NamedTuple):
    """An entry retrieved from the QA cache."""

    question: str
    answer: str
    module: str
    date: str
    source: str
    score: float  # Similarity score 0.0–1.0


class KBSearcher:
    """Search utilities for a knowledge base rooted at *kb_path*.

    All methods are synchronous for simplicity (file I/O is fast enough for
    the typical kb/ sizes).  Callers that need async behaviour should run
    these in a thread pool executor.

    Example::

        searcher = KBSearcher(kb_path=Path("kb"))
        results = searcher.search("authentication flow")
        entry = searcher.find_module("auth")
    """

    # Maximum number of results returned per search
    MAX_RESULTS: int = 20

    # Snippet context: characters to include before/after the match
    SNIPPET_CONTEXT: int = 150

    def __init__(self, kb_path: Path) -> None:
        self.kb_path = Path(kb_path)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def search(self, query: str, kb_path: Path | None = None) -> list[SearchResult]:
        """Grep-level keyword search across all Markdown files in *kb_path*.

        Splits *query* into tokens and scores each file section by the
        number of distinct tokens present (case-insensitive).  Returns up
        to MAX_RESULTS results sorted by descending score.

        Args:
            query: Natural-language or keyword query string.
            kb_path: Override the instance's kb_path for this call.

        Returns:
            Sorted list of SearchResult tuples (best match first).
        """
        root = Path(kb_path) if kb_path else self.kb_path
        if not root.exists():
            return []

        tokens = self._tokenize(query)
        if not tokens:
            return []

        results: list[SearchResult] = []
        for md_file in root.rglob("*.md"):
            try:
                text = md_file.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            file_results = self._search_file(md_file, text, tokens, root)
            results.extend(file_results)

        results.sort(key=lambda r: r.score, reverse=True)
        return results[: self.MAX_RESULTS]

    def search_qa_cache(self, query: str) -> list[QACacheEntry]:
        """Fuzzy-match *query* against questions recorded in qa_cache.md.

        Parses the QA cache file and scores each entry by token overlap
        between the query and the stored question.  Returns entries with
        score > 0, sorted by descending score.

        Args:
            query: User question string.

        Returns:
            List of QACacheEntry tuples ordered by relevance.
        """
        cache_path = self.kb_path / "qa_cache.md"
        if not cache_path.exists():
            return []

        try:
            content = cache_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []

        entries = self._parse_qa_cache(content)
        tokens = self._tokenize(query)

        scored: list[QACacheEntry] = []
        for entry in entries:
            q_tokens = self._tokenize(entry.question)
            score = self._jaccard_score(tokens, q_tokens)
            if score > 0:
                scored.append(entry._replace(score=score))

        scored.sort(key=lambda e: e.score, reverse=True)
        return scored

    def find_module(self, module_name: str) -> Path | None:
        """Return the path to the module's document directory, or None.

        Performs a case-insensitive prefix/suffix/contains match against
        the directory names under ``kb/modules/``.

        Args:
            module_name: Module name as known to the user (e.g. "auth").

        Returns:
            Path to the module directory if found, else None.
        """
        modules_dir = self.kb_path / "modules"
        if not modules_dir.exists():
            return None

        name_lower = module_name.lower()
        candidates: list[tuple[int, Path]] = []  # (priority, path)

        for module_dir in modules_dir.iterdir():
            if not module_dir.is_dir():
                continue
            dir_name = module_dir.name.lower()
            if dir_name == name_lower:
                return module_dir  # Exact match wins immediately
            if dir_name.startswith(name_lower) or dir_name.endswith(name_lower):
                candidates.append((1, module_dir))
            elif name_lower in dir_name:
                candidates.append((2, module_dir))

        if candidates:
            candidates.sort(key=lambda t: t[0])
            return candidates[0][1]
        return None

    def get_module_doc(self, module_name: str, doc_type: str) -> str | None:
        """Read a specific document from a module's kb directory.

        Args:
            module_name: Module name (e.g. "auth").
            doc_type: One of the audience keys defined in
                ``templates.AUDIENCE_DOCS`` — currently ``pm``, ``developer``,
                ``tester``, ``team_lead``, ``designer``, ``marketing``,
                ``security``, ``sre``, ``data``.

        Returns:
            File contents as a string, or None if not found.
        """
        module_dir = self.find_module(module_name)
        if module_dir is None:
            return None
        doc_path = module_dir / f"{doc_type}.md"
        if not doc_path.exists():
            return None
        try:
            return doc_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _tokenize(text: str) -> set[str]:
        """Split *text* into lowercase alphanumeric tokens (CJK-aware)."""
        # Split on non-word characters; also split CJK runs by character
        tokens: set[str] = set()
        for word in re.findall(r"[\w\u4e00-\u9fff]+", text.lower()):
            tokens.add(word)
            # Also add individual CJK characters for partial matching
            for char in word:
                if "\u4e00" <= char <= "\u9fff":
                    tokens.add(char)
        # Drop short ASCII tokens (noise) but keep single CJK characters.
        return {t for t in tokens if len(t) >= 2 or (len(t) == 1 and "\u4e00" <= t <= "\u9fff")}

    @staticmethod
    def _jaccard_score(a: set[str], b: set[str]) -> float:
        """Compute Jaccard similarity between two token sets."""
        if not a or not b:
            return 0.0
        intersection = len(a & b)
        union = len(a | b)
        return intersection / union if union else 0.0

    def _search_file(
        self,
        md_file: Path,
        text: str,
        tokens: set[str],
        root: Path,
    ) -> list[SearchResult]:
        """Search a single file for token matches, returning SearchResult items."""
        results: list[SearchResult] = []
        lines = text.splitlines()
        rel_path = str(md_file.relative_to(root))

        for i, line in enumerate(lines, start=1):
            line_lower = line.lower()
            matched_tokens = {t for t in tokens if t in line_lower}
            if not matched_tokens:
                continue

            score = len(matched_tokens) / len(tokens)
            # Build a snippet: include some context around the match
            start = max(0, i - 2)
            end = min(len(lines), i + 2)
            snippet_lines = lines[start:end]
            snippet = "\n".join(snippet_lines)
            if len(snippet) > 300:
                snippet = snippet[:297] + "..."

            results.append(
                SearchResult(
                    doc_path=rel_path,
                    snippet=snippet,
                    score=score,
                    line_no=i,
                )
            )

        # Deduplicate: keep only the best-scoring line per file section (H2)
        # by collapsing nearby hits within 5 lines
        deduped: list[SearchResult] = []
        last_line = -999
        for r in sorted(results, key=lambda x: x.line_no):
            if r.line_no - last_line > 5:
                deduped.append(r)
                last_line = r.line_no
        return deduped

    @staticmethod
    def _parse_qa_cache(content: str) -> list[QACacheEntry]:
        """Parse the qa_cache.md format into a list of QACacheEntry objects."""
        entries: list[QACacheEntry] = []
        # Each entry starts with "## Q: "
        blocks = re.split(r"(?=^## Q: )", content, flags=re.MULTILINE)
        for block in blocks:
            if not block.strip() or not block.startswith("## Q:"):
                continue
            question_match = re.match(r"## Q:\s*(.+)", block)
            if not question_match:
                continue
            question = question_match.group(1).strip()

            date_match = re.search(r"\*\*日期\*\*:\s*(.+)", block)
            module_match = re.search(r"\*\*相关模块\*\*:\s*(.+)", block)
            source_match = re.search(r"\*\*来源\*\*:\s*(.+)", block)

            # Answer is everything between the module line and the source line
            answer = ""
            answer_match = re.search(
                r"\*\*答案\*\*:\s*\n(.*?)(?=\*\*来源\*\*|\Z)", block, re.DOTALL
            )
            if answer_match:
                answer = answer_match.group(1).strip()

            entries.append(
                QACacheEntry(
                    question=question,
                    answer=answer,
                    module=module_match.group(1).strip() if module_match else "",
                    date=date_match.group(1).strip() if date_match else "",
                    source=source_match.group(1).strip() if source_match else "",
                    score=0.0,
                )
            )
        return entries
