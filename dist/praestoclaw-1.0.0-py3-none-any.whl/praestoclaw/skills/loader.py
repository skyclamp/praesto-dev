"""
Skill loader — discovers and loads markdown-based prompt skills.

Skills are .md files with YAML frontmatter.  Metadata resolution:

    metadata.praestoclaw.X  >  metadata.X
       (namespaced)           (flat)

The ``praestoclaw`` namespace wrapper is optional.  Fields can live
directly under ``metadata.*`` for brevity.

Sources (load order — later overrides earlier by name):

1. Built-in bundled skills  (praestoclaw/skills/bundled/*.md  or  bundled/*/SKILL.md)
2. User data dir skills     (~/.praestoclaw/skills/*.md  or  */SKILL.md)
3. User workspace skills    (.praestoclaw/skills/*.md  or  skills/*.md  or  */SKILL.md)
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml
from loguru import logger

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

SkillMode = Literal["always", "available"]
SourceTier = Literal["bundled", "user", "workspace", "custom"]


@dataclass
class Skill:
    """A single loaded skill."""

    name: str
    description: str
    content: str  # the markdown prompt body (after frontmatter)
    mode: SkillMode = "available"
    keywords: list[str] = field(default_factory=list)
    patterns: list[re.Pattern[str]] = field(default_factory=list)
    requires_bins: list[str] = field(default_factory=list)
    requires_any_bins: list[str] = field(default_factory=list)
    requires_env: list[str] = field(default_factory=list)
    requires_packages: list[str] = field(default_factory=list)
    requires_tools: list[str] = field(default_factory=list)
    superseded_by_tools: list[str] = field(default_factory=list)
    os_filter: list[str] = field(default_factory=list)
    context_git_remote: list[re.Pattern[str]] = field(default_factory=list)
    context_files: list[str] = field(default_factory=list)
    praesto_tag_exp_only: bool = False
    disable_model_invocation: bool = False
    source_path: str = ""  # relative path for read_file discovery
    source_tier: SourceTier = "bundled"
    # Long-task workflow metadata (optional). Populated from
    # metadata.workflow.* in the SKILL.md frontmatter. None for non-SOP skills.
    workflow: dict[str, Any] | None = None
    # Per-skill safe tool allowlist.  Each entry is a dict shaped like an
    # AllowlistEntry: {"tool": name, "match": {arg_key: regex}}.  When the
    # skill is loaded, these are merged into the runtime allowlist as
    # ephemeral entries (not persisted to disk) so the LLM can chain the
    # listed tools without per-call approval prompts inside that skill.
    safe_tools: list[dict[str, Any]] = field(default_factory=list)
    # Opt-in: run this recipe as a tracked plan (run-as-Plan). When True, the
    # workflow tool injects a plan-driving preamble so the spawned run creates +
    # steps through a persisted Plan (its plan file is the audit + progress
    # source). False for ordinary skills and legacy recipes — no behaviour change.
    plan_mode: bool = False
    # Recipe input parameters (workflow feature). List of declared params — each
    # a dict {name, type, required, default, options?}. None for skills / plain
    # recipes. The workflow tool validates + substitutes ``{name}`` at run time.
    parameters: list[dict[str, Any]] | None = None
    # Recipe capability limits (workflow Task 9). Optional mapping —
    # {allowed_tools, max_runtime, max_output} (``max_iterations`` is accepted in
    # frontmatter but its enforcement is deferred). None for skills / plain recipes.
    # Kept permissive here (any mapping); the workflow tool normalizes + enforces
    # it (caps the run's tools / wall-clock / output).
    limits: dict[str, Any] | None = None
    # Optional workflow instance limit. The workflow tool validates and enforces
    # ``max_instances`` and its optional ``key_parameters`` grouping.
    concurrency: dict[str, Any] | None = None
    # Optional project-profile contract: which scalars a recipe's per-project
    # configuration must declare, and where a repository-local one lives. Kept
    # permissive here like the two above — the workflow tool normalizes and
    # enforces it. This is what keeps one recipe's contract OUT of the generic
    # tool: the tool supplies the mechanism, the recipe supplies the policy.
    profile: dict[str, Any] | None = None

    def __init__(
        self,
        name: str,
        description: str,
        content: str,
        mode: SkillMode = "available",
        keywords: list[str] | None = None,
        patterns: list[re.Pattern[str]] | None = None,
        requires_bins: list[str] | None = None,
        requires_any_bins: list[str] | None = None,
        requires_env: list[str] | None = None,
        requires_packages: list[str] | None = None,
        requires_tools: list[str] | None = None,
        superseded_by_tools: list[str] | None = None,
        os_filter: list[str] | None = None,
        context_git_remote: list[re.Pattern[str]] | None = None,
        context_files: list[str] | None = None,
        praesto_tag_exp_only: bool = False,
        disable_model_invocation: bool = False,
        source_path: str = "",
        source_tier: SourceTier = "bundled",
        workflow: dict[str, Any] | None = None,
        safe_tools: list[dict[str, Any]] | None = None,
        *,
        triggers: list[str] | None = None,  # backward-compat alias for keywords
        plan_mode: bool = False,
        parameters: list[dict[str, Any]] | None = None,
        limits: dict[str, Any] | None = None,
        concurrency: dict[str, Any] | None = None,
        profile: dict[str, Any] | None = None,
    ) -> None:
        self.name = name
        self.description = description
        self.content = content
        self.mode = mode
        # triggers= is a backward-compat alias for keywords=
        self.keywords = triggers if triggers is not None else (keywords or [])
        self.patterns = patterns or []
        self.requires_bins = requires_bins or []
        self.requires_any_bins = requires_any_bins or []
        self.requires_env = requires_env or []
        self.requires_packages = requires_packages or []
        self.requires_tools = requires_tools or []
        self.superseded_by_tools = superseded_by_tools or []
        self.os_filter = os_filter or []
        self.context_git_remote = context_git_remote or []
        self.context_files = context_files or []
        self.praesto_tag_exp_only = praesto_tag_exp_only
        self.disable_model_invocation = disable_model_invocation
        self.source_path = source_path
        self.source_tier = source_tier
        self.workflow = workflow
        self.safe_tools = safe_tools or []
        self.plan_mode = plan_mode
        self.parameters = parameters
        self.limits = limits
        self.concurrency = concurrency
        self.profile = profile

    # ── backward compat ──────────────────────────────────────────────────

    @property
    def triggers(self) -> list[str]:
        """Backward-compatible alias for ``keywords``."""
        return self.keywords

    @triggers.setter
    def triggers(self, value: list[str]) -> None:
        """Backward-compatible setter for ``keywords``."""
        self.keywords = value

    # ── helpers ──────────────────────────────────────────────────────────

    def matches(self, text: str) -> bool:
        """Return True if *text* contains any of this skill's trigger keywords."""
        lower = text.lower()
        return any(trigger.lower() in lower for trigger in self.keywords)

    def score(self, text: str, workspace_context: dict[str, str] | None = None) -> int:
        """Score relevance of *text* to this skill.

        Scoring:
        - Keyword exact word match: 10 points each (cap 30)
        - Keyword substring match: 5 points each (cap 30)
        - Regex pattern match: 20 points each (cap 40)
        - Pattern-only penalty: halved if no keyword matched (patterns are
          broad — e.g. "create PR" hits both github and ado skills)
        - Context: git-remote match 20, files match 20 (cap 30)
        - Max total: 100
        """
        lower = text.lower()
        words = set(re.findall(r"\b[\w-]+\b", lower))

        # Keyword scoring — multi-word keywords use word-set subset match
        keyword_score = 0
        for kw in self.keywords:
            kw_lower = kw.lower()
            kw_words = set(kw_lower.split())
            if kw_words and kw_words.issubset(words):
                keyword_score += 10
            elif kw_lower in lower:
                keyword_score += 5
        keyword_score = min(keyword_score, 30)

        # Regex scoring
        pattern_score = 0
        for pat in self.patterns:
            if pat.search(text):
                pattern_score += 20
        pattern_score = min(pattern_score, 40)

        # Pattern-only penalty: patterns are broad (e.g. "create PR" matches
        # both github and ado).  Without keyword corroboration, halve the
        # pattern contribution to avoid false-positive injection.
        if keyword_score == 0 and pattern_score > 0:
            pattern_score //= 2

        base_score = keyword_score + pattern_score

        # Context scoring — workspace signals (git remote, file existence)
        # Only applies when the message already has some relevance (base_score > 0).
        context_score = 0
        if base_score > 0 and workspace_context:
            git_remotes = workspace_context.get("git_remotes", "")
            if git_remotes and self.context_git_remote:
                for pat in self.context_git_remote:
                    if pat.search(git_remotes):
                        context_score = 20
                        break
            workspace_file_set = set(workspace_context.get("workspace_files", "").splitlines())
            if workspace_file_set and self.context_files:
                for fpath in self.context_files:
                    if fpath in workspace_file_set:
                        context_score = min(context_score + 20, 30)
                        break
        context_score = min(context_score, 30)

        return min(base_score + context_score, 100)

    def check_requirements(self, tool_registry: Any | None = None) -> list[str]:
        """Return list of missing requirements (bin, env var, package, or tool names).

        Args:
            tool_registry: Optional ToolRegistry for checking ``requires_tools``.
        """
        missing: list[str] = []
        for b in self.requires_bins:
            if shutil.which(b) is None:
                missing.append(b)
        # any-bins: at least ONE of the listed bins must be present
        if self.requires_any_bins:
            if not any(shutil.which(b) is not None for b in self.requires_any_bins):
                missing.append(f"any({', '.join(self.requires_any_bins)})")
        for e in self.requires_env:
            if not os.environ.get(e):
                missing.append(e)
        import importlib.util

        # Note: uses importable module names (dash→underscore heuristic).
        # For packages where import name differs from dist name, use the import name.
        for pkg in self.requires_packages:
            if importlib.util.find_spec(pkg.replace("-", "_")) is None:
                missing.append(pkg)
        if tool_registry is not None:
            for t in self.requires_tools:
                if hasattr(tool_registry, "is_available"):
                    if not tool_registry.is_available(t):
                        missing.append(t)
                elif hasattr(tool_registry, "get"):
                    if tool_registry.get(t) is None:
                        missing.append(t)
        return missing

    def is_platform_eligible(self) -> bool:
        """True when ``os_filter`` is empty or current platform is listed."""
        if not self.os_filter:
            return True
        return sys.platform in self.os_filter

    def is_superseded(self, tool_registry: Any | None = None) -> bool:
        """True when ALL ``superseded_by_tools`` are available.

        Returns ``False`` if the list is empty or no registry is provided.
        """
        if not self.superseded_by_tools or tool_registry is None:
            return False
        for t in self.superseded_by_tools:
            if hasattr(tool_registry, "is_available"):
                if not tool_registry.is_available(t):
                    return False
            elif hasattr(tool_registry, "get"):
                if tool_registry.get(t) is None:
                    return False
            else:
                return False
        return True

    @property
    def available(self) -> bool:
        """True when all requirements are met and platform is eligible."""
        return self.is_platform_eligible() and len(self.check_requirements()) == 0


# ---------------------------------------------------------------------------
# Frontmatter parser
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(
    r"\A\s*---\s*\n(?P<meta>.*?)\n---\s*\n(?P<body>.*)",
    re.DOTALL,
)


def _resolve_metadata(meta: dict) -> dict:
    """Extract skill metadata from frontmatter.

    Resolution order: ``metadata.praestoclaw.X`` > ``metadata.X`` (flat).
    Shallow merge by top-level key — namespaced overrides flat entirely.
    """
    raw_metadata = meta.get("metadata", {})

    if not isinstance(raw_metadata, dict):
        return {}

    # Flat fields — everything in metadata except the praestoclaw namespace key
    flat = {k: v for k, v in raw_metadata.items() if k != "praestoclaw"}

    # Namespaced overrides (optional)
    namespaced = raw_metadata.get("praestoclaw", {})
    if not isinstance(namespaced, dict):
        namespaced = {}

    # Shallow merge: namespaced wins per top-level key
    return {**flat, **namespaced}


def _parse_skill_file(path: Path) -> Skill | None:
    """Parse a single .md skill file with YAML frontmatter.

    Metadata resolution: ``metadata.praestoclaw.*`` > ``metadata.*`` (flat).
    Also supports legacy flat format (``mode``, ``triggers``).

    Returns ``None`` if the file cannot be parsed.
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("Cannot read skill file {}: {}", path, exc)
        return None

    match = _FRONTMATTER_RE.match(raw)
    if not match:
        logger.warning("Skill file {} missing YAML frontmatter — skipped", path)
        return None

    try:
        meta: dict = yaml.safe_load(match.group("meta")) or {}
    except yaml.YAMLError as exc:
        logger.warning("Invalid YAML frontmatter in {}: {}", path, exc)
        return None

    name = meta.get("name", path.stem)
    description = meta.get("description", "")

    # ── Resolve metadata (praestoclaw namespace > flat) ──────────────────
    ns: dict[str, Any] = _resolve_metadata(meta)
    activation: dict = ns.get("activation") or {}
    requires: dict = ns.get("requires") or {}

    # Keywords: activation.keywords (PraestoClaw extension) → fallback to flat triggers
    triggers_raw = activation.get("keywords") or meta.get("triggers", [])
    if isinstance(triggers_raw, str):
        triggers_raw = [t.strip() for t in triggers_raw.split(",")]
    keywords: list[str] = [str(t) for t in triggers_raw]

    # Patterns: activation.patterns → compile regex
    patterns_raw = activation.get("patterns") or []
    if isinstance(patterns_raw, str):
        patterns_raw = [patterns_raw]
    compiled_patterns: list[re.Pattern[str]] = []
    for pat_str in patterns_raw:
        try:
            compiled_patterns.append(re.compile(str(pat_str)))
        except re.error as exc:
            logger.warning("Invalid regex pattern in skill '{}': {} — {}", name, pat_str, exc)

    # Mode: ns.always → fallback to flat mode
    ns_always = ns.get("always")
    if ns_always is not None:
        mode: SkillMode = "always" if ns_always else "available"
    else:
        mode = meta.get("mode", "available")
        if mode not in ("always", "available"):
            logger.warning("Skill {} has invalid mode '{}' — defaulting to 'available'", name, mode)
            mode = "available"

    # disable-model-invocation — handle string "true"/"false" from YAML
    dmi_raw = ns.get("disable-model-invocation", False)
    if isinstance(dmi_raw, str):
        disable_model_invocation = dmi_raw.lower() in ("true", "1", "yes")
    else:
        disable_model_invocation = bool(dmi_raw)

    # Requirements: requires.bins / requires.env (normalize scalar → list)
    bins_raw = requires.get("bins") or []
    if isinstance(bins_raw, str):
        bins_raw = [bins_raw]
    requires_bins: list[str] = [str(b) for b in bins_raw]

    any_bins_raw = requires.get("any-bins") or []
    if isinstance(any_bins_raw, str):
        any_bins_raw = [any_bins_raw]
    requires_any_bins: list[str] = [str(b) for b in any_bins_raw]

    env_raw = requires.get("env") or []
    if isinstance(env_raw, str):
        env_raw = [env_raw]
    requires_env: list[str] = [str(e) for e in env_raw]

    packages_raw = requires.get("packages") or []
    if isinstance(packages_raw, str):
        packages_raw = [packages_raw]
    requires_packages: list[str] = [str(p) for p in packages_raw]

    tools_raw = requires.get("tools") or []
    if isinstance(tools_raw, str):
        tools_raw = [tools_raw]
    requires_tools: list[str] = [str(t) for t in tools_raw]

    # context: workspace signals for scoring boost
    context: dict = activation.get("context") or {}
    ctx_remote_raw = context.get("git-remote") or []
    if isinstance(ctx_remote_raw, str):
        ctx_remote_raw = [ctx_remote_raw]
    context_git_remote: list[re.Pattern[str]] = []
    for pat_str in ctx_remote_raw:
        try:
            context_git_remote.append(re.compile(str(pat_str)))
        except re.error as exc:
            logger.warning(
                "Invalid context git-remote pattern in skill '{}': {} — {}", name, pat_str, exc
            )

    ctx_files_raw = context.get("files") or []
    if isinstance(ctx_files_raw, str):
        ctx_files_raw = [ctx_files_raw]
    context_files: list[str] = [str(f) for f in ctx_files_raw]

    praesto_tag_exp_only_raw = activation.get(
        "praesto-tag-exp-only",
        activation.get("praesto_tag_exp_only", False),
    )
    if isinstance(praesto_tag_exp_only_raw, str):
        praesto_tag_exp_only = praesto_tag_exp_only_raw.strip().lower() in ("true", "1", "yes")
    else:
        praesto_tag_exp_only = bool(praesto_tag_exp_only_raw)

    # superseded-by: tools that make this skill redundant
    superseded_by_raw = ns.get("superseded-by") or {}
    superseded_by: dict = superseded_by_raw if isinstance(superseded_by_raw, dict) else {}
    sb_tools_raw = superseded_by.get("tools") or []
    if isinstance(sb_tools_raw, str):
        sb_tools_raw = [sb_tools_raw]
    superseded_by_tools: list[str] = [str(t) for t in sb_tools_raw]

    # os: platform filter (e.g. ["darwin", "linux", "win32"])
    os_raw = ns.get("os") or []
    if isinstance(os_raw, str):
        os_raw = [os_raw]
    os_filter: list[str] = [str(o) for o in os_raw]

    # workflow: long-task SOP metadata. Optional. When present, the skill
    # tells the agent loop to enforce a `plan(create=...)` first turn and
    # may declare phases / checkpoints / max_turns / requires_user_confirm.
    workflow_raw = ns.get("workflow")
    workflow_meta: dict[str, Any] | None = None
    if isinstance(workflow_raw, dict):
        workflow_meta = {
            "phases": [str(p) for p in (workflow_raw.get("phases") or [])],
            "checkpoints": [str(c) for c in (workflow_raw.get("checkpoints") or [])],
            "requires_user_confirm": [
                str(p) for p in (workflow_raw.get("requires_user_confirm") or [])
            ],
            "max_turns": int(workflow_raw.get("max_turns") or 0) or None,
            "report_every": int(workflow_raw.get("report_every") or 0) or None,
        }

    body = match.group("body").strip()

    # safe-tools: per-skill allowlist hints (ephemeral, not persisted).
    # Frontmatter shape:
    #   safe-tools:
    #     - tool: gh
    #       match: {args: "^pr (list|view|status)"}
    #     - tool: read_file
    safe_tools_raw = ns.get("safe-tools") or ns.get("safe_tools") or []
    safe_tools: list[dict[str, Any]] = []
    if isinstance(safe_tools_raw, list):
        for item in safe_tools_raw:
            if isinstance(item, str):
                safe_tools.append({"tool": item, "match": {}})
            elif isinstance(item, dict) and "tool" in item:
                entry: dict[str, Any] = {"tool": str(item["tool"])}
                m = item.get("match") or {}
                if isinstance(m, dict):
                    entry["match"] = {str(k): str(v) for k, v in m.items()}
                else:
                    entry["match"] = {}
                safe_tools.append(entry)

    # ── plan_mode: opt-in to run-as-Plan. Top-level ``plan:`` is the documented
    # form (what `workflow add` could emit); ``metadata.plan`` is accepted as a
    # fallback. String/bool coerced the same way as disable-model-invocation. ──
    plan_raw = meta.get("plan")
    if plan_raw is None:
        plan_raw = ns.get("plan", False)
    if isinstance(plan_raw, str):
        plan_mode = plan_raw.strip().lower() in ("true", "1", "yes")
    else:
        plan_mode = bool(plan_raw)

    # ── parameters: recipe input schema (workflow 5b). Top-level ``parameters:``
    # (fallback ``metadata.parameters``); kept permissive here — the workflow
    # tool validates/uses them. Drop entries that aren't dicts or lack a name;
    # an empty/all-dropped list becomes None (no params). ──
    params_raw = meta.get("parameters")
    if params_raw is None:
        params_raw = ns.get("parameters")
    parameters: list[dict[str, Any]] | None = None
    if isinstance(params_raw, list):
        cleaned = [
            p for p in params_raw if isinstance(p, dict) and str(p.get("name") or "").strip()
        ]
        parameters = cleaned or None

    # ── limits: recipe capability caps (workflow Task 9). Precedence: top-level
    # ``limits:`` WINS; the ``metadata.limits`` form is only a fallback used when
    # top-level is absent (same as ``parameters`` above). Permissive here (accept
    # any mapping) — the workflow tool normalizes + enforces. Non-mapping → None. ──
    top_level_limits = meta.get("limits")  # frontmatter top level
    metadata_limits = ns.get("limits")  # nested `metadata:` block (fallback only)
    limits_raw = top_level_limits if top_level_limits is not None else metadata_limits
    limits: dict[str, Any] | None = limits_raw if isinstance(limits_raw, dict) else None

    top_level_concurrency = meta.get("concurrency")
    metadata_concurrency = ns.get("concurrency")
    concurrency_raw = (
        top_level_concurrency if top_level_concurrency is not None else metadata_concurrency
    )
    concurrency: dict[str, Any] | None = (
        concurrency_raw if isinstance(concurrency_raw, dict) else None
    )

    top_level_profile = meta.get("profile")
    metadata_profile = ns.get("profile")
    profile_raw = top_level_profile if top_level_profile is not None else metadata_profile
    profile: dict[str, Any] | None = profile_raw if isinstance(profile_raw, dict) else None

    return Skill(
        name=name,
        description=description,
        content=body,
        mode=mode,
        keywords=keywords,
        patterns=compiled_patterns,
        requires_bins=requires_bins,
        requires_any_bins=requires_any_bins,
        requires_env=requires_env,
        requires_packages=requires_packages,
        requires_tools=requires_tools,
        superseded_by_tools=superseded_by_tools,
        os_filter=os_filter,
        context_git_remote=context_git_remote,
        context_files=context_files,
        praesto_tag_exp_only=praesto_tag_exp_only,
        disable_model_invocation=disable_model_invocation,
        workflow=workflow_meta,
        safe_tools=safe_tools,
        plan_mode=plan_mode,
        parameters=parameters,
        limits=limits,
        concurrency=concurrency,
        profile=profile,
    )


def parse_skill_file(path: Path) -> Skill | None:
    """Public wrapper around the single-file parser (stable import surface).

    Consumers outside this module (e.g. the workflow tool) should import this
    rather than the underscore-prefixed ``_parse_skill_file``.
    """
    return _parse_skill_file(path)


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


class SkillLoader:
    """Discover and load skills from bundled and workspace directories."""

    def __init__(
        self,
        workspace: Path,
        skills_dir: Path | None = None,
        tool_registry: Any | None = None,
        disabled_names: list[str] | None = None,
    ) -> None:
        self._workspace = workspace
        self._skills_dir = skills_dir
        self._tool_registry = tool_registry
        self._disabled: set[str] = set(disabled_names or [])
        self._skills: list[Skill] = []
        self._loaded = False
        self._workspace_context: dict[str, str] | None = None

    # ── public API ───────────────────────────────────────────────────────

    def with_tool_registry(self, tool_registry: Any | None) -> SkillLoader:
        """Return a lightweight clone bound to a different tool registry.

        Spawned sub-agents run on a *scoped* tool registry, but skill
        eligibility (``check_requirements`` / ``is_superseded``) is evaluated
        against ``self._tool_registry``. Sharing the main loader would surface
        skills that require tools the sub-agent does not actually have. This
        returns a clone that shares the already-parsed skills (no disk
        re-scan) and the detected workspace context, but evaluates
        eligibility against the scoped ``tool_registry``.
        """
        clone = SkillLoader(
            self._workspace,
            skills_dir=self._skills_dir,
            tool_registry=tool_registry,
            disabled_names=list(self._disabled),
        )
        clone._skills = self._skills
        clone._loaded = self._loaded
        clone._workspace_context = self._workspace_context
        return clone

    def list_loaded(self) -> list[Skill]:
        """Return all currently loaded skills.

        Returns a shallow copy of the internal list.  The ``Skill`` objects
        are shared references — callers should treat them as read-only.
        """
        self._ensure_loaded()
        return list(self._skills)

    def load_all(self) -> list[Skill]:
        """Load skills from all sources and return the combined list.

        This method is idempotent — calling it multiple times reloads from
        disk each time so config changes are picked up.
        """
        self._skills = []

        # 1. Built-in bundled skills
        bundled_dir = Path(__file__).parent / "bundled"
        self._load_from_dir(bundled_dir, label="bundled", source_tier="bundled")

        # 2. User data dir skills (~/.praestoclaw/skills/) — heartbeat-generated + user-created
        from praestoclaw.utils.helpers import get_data_dir

        data_skills_dir = get_data_dir() / "skills"
        self._load_from_dir(
            data_skills_dir, label="user", use_absolute_path=True, source_tier="user"
        )

        # 3. User / workspace skills (override data dir skills by name)
        if self._skills_dir is not None:
            self._load_from_dir(
                self._skills_dir, label="custom", use_absolute_path=True, source_tier="custom"
            )
        else:
            # Convention: look in .praestoclaw/skills/ first, then skills/
            for candidate in (
                self._workspace / ".praestoclaw" / "skills",
                self._workspace / "skills",
            ):
                if candidate.is_dir():
                    self._load_from_dir(candidate, label="workspace", source_tier="workspace")

        self._loaded = True
        # Detect workspace context after all skills are loaded (needs context_files from skills)
        self._workspace_context = self._detect_workspace_context()
        logger.debug("Loaded {} skill(s) total", len(self._skills))
        return list(self._skills)

    def get_always_loaded(self) -> list[Skill]:
        """Return skills whose mode is ``always``, requirements met, and model-visible."""
        self._ensure_loaded()
        return [
            s
            for s in self._skills
            if s.mode == "always"
            and not s.disable_model_invocation
            and not s.praesto_tag_exp_only
            and s.name not in self._disabled
            and s.is_platform_eligible()
            and not s.check_requirements(self._tool_registry)
            and not s.is_superseded(self._tool_registry)
        ]

    def get_available(self) -> list[Skill]:
        """Return skills whose mode is ``available`` (on-demand)."""
        self._ensure_loaded()
        return [s for s in self._skills if s.mode == "available"]

    def get_model_visible(self) -> list[Skill]:
        """Return available skills that the LLM may see in the summary.

        Excludes skills with ``disable_model_invocation=True``, non-matching
        platform, or superseded by available tools.
        """
        self._ensure_loaded()
        return [
            s
            for s in self._skills
            if s.mode == "available"
            and not s.disable_model_invocation
            and not s.praesto_tag_exp_only
            and s.name not in self._disabled
            and s.is_platform_eligible()
            and not s.is_superseded(self._tool_registry)
        ]

    def set_disabled(self, names: list[str] | set[str]) -> None:
        """Update the user-disabled skill name set. Called after config changes."""
        self._disabled = set(names)

    def is_disabled(self, name: str) -> bool:
        """Whether the given skill name is in the user-disabled set."""
        return name in self._disabled

    def find_by_name(self, name: str) -> Skill | None:
        """Look up a skill by exact name. Returns ``None`` if not found."""
        self._ensure_loaded()
        for s in self._skills:
            if s.name == name:
                return s
        return None

    def find_by_trigger(self, text: str) -> list[Skill]:
        """Return all skills whose triggers match *text*."""
        self._ensure_loaded()
        return [s for s in self._skills if s.matches(text)]

    def match(
        self,
        text: str,
        *,
        threshold: int = 15,
        max_results: int = 1,
        praesto_tag_exp_active: bool = False,
    ) -> list[Skill]:
        """Score model-visible skills against *text* and return top matches above *threshold*.

        Args:
            text: User message to score against.
            threshold: Minimum score to include (default 15).
            max_results: Maximum number of results (default 1).
            praesto_tag_exp_active: Whether this is a shared-group experiment turn.
        """
        self._ensure_loaded()
        # Score first (cheap), then check requirements only for candidates above threshold
        scored: list[tuple[int, Skill]] = []
        for s in self._skills:
            if s.mode != "available":
                continue
            if s.disable_model_invocation:
                continue
            if praesto_tag_exp_active:
                from praestoclaw.security.praesto_tag_exp import (
                    PRAESTO_TAG_EXP_ALLOWED_SKILLS,
                )

                allowed_group_skill = s.source_tier == "bundled" and (
                    s.praesto_tag_exp_only or s.name in PRAESTO_TAG_EXP_ALLOWED_SKILLS
                )
                if not allowed_group_skill:
                    continue
            if s.praesto_tag_exp_only and not praesto_tag_exp_active:
                continue
            if s.name in self._disabled:
                continue
            if not s.is_platform_eligible():
                continue
            if s.is_superseded(self._tool_registry):
                continue
            sc = s.score(text, self._workspace_context)
            if sc >= threshold:
                scored.append((sc, s))
        scored.sort(key=lambda x: x[0], reverse=True)
        # Check requirements only for top candidates (expensive: shutil.which, find_spec)
        result: list[Skill] = []
        for _, s in scored:
            if not s.check_requirements(self._tool_registry):
                result.append(s)
                if len(result) >= max_results:
                    break
        return result

    # ── internals ────────────────────────────────────────────────────────

    def _detect_workspace_context(self) -> dict[str, str]:
        """Detect workspace signals for context-aware scoring.

        Runs once at :meth:`load_all`.  Results are startup-stable and cached.
        """
        ctx: dict[str, str] = {}

        # Check if any skill uses context signals — skip detection if none do
        needs_git = any(s.context_git_remote for s in self._skills)
        needs_files = any(s.context_files for s in self._skills)

        # git remote URLs (only if at least one skill declares context.git-remote)
        if needs_git:
            try:
                result = subprocess.run(
                    ["git", "remote", "-v"],
                    capture_output=True,
                    text=True,
                    cwd=self._workspace,
                    timeout=5,
                )
                ctx["git_remotes"] = result.stdout if result.returncode == 0 else ""
            except Exception:
                ctx["git_remotes"] = ""
        else:
            ctx["git_remotes"] = ""

        # Workspace file/directory existence (only if at least one skill declares context.files)
        if needs_files:
            markers: set[str] = set()
            for s in self._skills:
                for f in s.context_files:
                    markers.add(f)
            existing: list[str] = []
            for m in markers:
                if (self._workspace / m).exists():
                    existing.append(m)
            ctx["workspace_files"] = "\n".join(existing)
        else:
            ctx["workspace_files"] = ""

        existing = ctx["workspace_files"].splitlines() if ctx["workspace_files"] else []
        if ctx["git_remotes"] or existing:
            logger.debug(
                "Workspace context: remotes detected={}, files={}",
                bool(ctx["git_remotes"]),
                existing,
            )
        return ctx

    def _ensure_loaded(self) -> None:
        """Lazy-load skills if :meth:`load_all` has not been called yet."""
        if not self._loaded:
            self.load_all()

    def _upsert(self, skill: Skill) -> None:
        """Insert or replace a skill by name."""
        self._skills = [s for s in self._skills if s.name != skill.name]
        self._skills.append(skill)

    def _load_from_dir(
        self,
        directory: Path,
        *,
        label: str = "",
        use_absolute_path: bool = False,
        source_tier: SourceTier = "bundled",
    ) -> None:
        """Load skill files from *directory*.

        Scans both flat ``*.md`` files and ``*/SKILL.md`` sub-directories.
        Directory-style skills take precedence over flat files with the same name.
        Dot and underscore prefixed directories are skipped.
        """
        if not directory.is_dir():
            logger.debug("Skills directory does not exist: {} ({})", directory, label)
            return

        # Track which names came from directory-style (higher precedence)
        dir_names: set[str] = set()

        # 1. Directory-style: subdir/SKILL.md
        for child in sorted(directory.iterdir()):
            if not child.is_dir():
                continue
            # Skip dot/underscore prefixed dirs
            if child.name.startswith(".") or child.name.startswith("_"):
                continue
            skill_md = child / "SKILL.md"
            if not skill_md.is_file():
                # Fallback: accept lowercase skill.md (e.g. OPC uses this)
                skill_md_lower = child / "skill.md"
                if skill_md_lower.is_file():
                    skill_md = skill_md_lower
            if skill_md.is_file():
                skill = _parse_skill_file(skill_md)
                if skill is not None:
                    # Default name to directory name when SKILL.md has no name: field
                    if skill.name == "SKILL":
                        skill.name = child.name
                    skill.source_tier = source_tier
                    self._set_source_path(skill, skill_md, use_absolute_path)
                    self._upsert(skill)
                    dir_names.add(skill.name)
                    logger.debug(
                        "Loaded skill '{}' from {}/SKILL.md ({})", skill.name, child.name, label
                    )

        # 2. Flat-style: *.md files in the directory root
        md_files = sorted(directory.glob("*.md"))
        for path in md_files:
            skill = _parse_skill_file(path)
            if skill is not None:
                # Directory-style takes precedence — skip flat if already loaded from dir
                if skill.name in dir_names:
                    logger.debug(
                        "Skipping flat skill '{}' — directory-style takes precedence", skill.name
                    )
                    continue
                skill.source_tier = source_tier
                self._set_source_path(skill, path, use_absolute_path)
                self._upsert(skill)
                logger.debug("Loaded skill '{}' from {} ({})", skill.name, path.name, label)

    def _set_source_path(self, skill: Skill, path: Path, use_absolute_path: bool) -> None:
        """Set the source_path on a skill for read_file discovery."""
        try:
            skill.source_path = str(path.relative_to(self._workspace))
        except ValueError:
            skill.source_path = str(path) if use_absolute_path else ""
