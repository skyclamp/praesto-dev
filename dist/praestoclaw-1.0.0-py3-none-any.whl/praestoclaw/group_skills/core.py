"""Independent, per-chat Group Skill registry and matcher.

External repositories are user-selected, untrusted inputs. Snapshots isolate
chat state; they do not sandbox shell code executed from a Group Skill.
"""

from __future__ import annotations

import builtins
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import threading
import uuid
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal, cast
from urllib.parse import unquote, urlsplit

import yaml

_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,62}$")
_FRONTMATTER_RE = re.compile(r"\A---\s*\n(?P<meta>.*?)\n---\s*\n(?P<body>.*)\Z", re.DOTALL)
_PUBLIC_GIT_HOSTS = frozenset({"bitbucket.org", "dev.azure.com", "github.com", "gitlab.com"})
_PUBLIC_GIT_HOST_SUFFIXES = (".ghe.com", ".visualstudio.com")
_NONINTERACTIVE_GIT_ENV = {
    "GIT_TERMINAL_PROMPT": "0",
    "GCM_INTERACTIVE": "Never",
}


class GroupSkillError(ValueError):
    """Invalid group skill operation or snapshot."""


@dataclass(slots=True)
class GroupSkillRecord:
    chat_id: str
    name: str
    description: str
    content: str
    keywords: list[str] = field(default_factory=list)
    patterns: list[str] = field(default_factory=list)
    safe_tools: list[dict[str, Any]] = field(default_factory=list)
    source_type: Literal["import", "external"] = "import"
    source_locator: str = ""
    source_subpath: str = ""
    resolved_revision: str = ""
    content_hash: str = ""
    enabled: bool = False
    installed_by: str = ""
    installed_at: str = ""
    updated_at: str = ""
    source_path: str = ""

    def score(self, text: str) -> int:
        lower = text.lower()
        words = set(re.findall(r"\b[\w-]+\b", lower))
        name_parts = {part for part in re.split(r"[-_]", self.name.lower()) if len(part) >= 3}
        name_score = 20 if self.name.lower() in lower or name_parts.intersection(words) else 0
        keyword_score = 0
        for keyword in self.keywords:
            lowered = keyword.lower()
            parts = set(lowered.split())
            if parts and parts.issubset(words):
                keyword_score += 10
            elif lowered in lower:
                keyword_score += 5
        pattern_score = 0
        for pattern in self.patterns:
            try:
                if re.search(pattern, text):
                    pattern_score += 20
            except re.error:
                continue
        keyword_score = min(keyword_score, 30)
        pattern_score = min(pattern_score, 40)
        if keyword_score == 0:
            pattern_score //= 2
        return min(name_score + keyword_score + pattern_score, 100)


def _chat_key(chat_id: str) -> str:
    return hashlib.sha256(chat_id.encode("utf-8")).hexdigest()[:24]


def _repo_key(repo_url: str) -> str:
    return hashlib.sha256(repo_url.encode("utf-8")).hexdigest()[:24]


def _is_directory_link(path: Path) -> bool:
    if path.is_symlink():
        return True
    if os.name != "nt":
        return False
    try:
        attributes = getattr(os.lstat(path), "st_file_attributes", 0)
        return bool(attributes & stat.FILE_ATTRIBUTE_REPARSE_POINT)
    except (AttributeError, FileNotFoundError):
        return False


def _remove_directory_entry(path: Path) -> None:
    if path.is_symlink():
        path.unlink()
    elif _is_directory_link(path):
        os.rmdir(path)
    elif path.is_dir():
        shutil.rmtree(path)


def _create_directory_link(source: Path, destination: Path) -> None:
    if os.name == "nt":
        subprocess.check_call(
            ["cmd", "/c", "mklink", "/J", str(destination), str(source)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return
    relative_source = os.path.relpath(source, destination.parent)
    os.symlink(relative_source, destination, target_is_directory=True)


def _replace_directory_link(source: Path, destination: Path) -> None:
    staging = destination.parent / f".{destination.name}-{uuid.uuid4().hex}.tmp"
    backup = destination.parent / f".{destination.name}-{uuid.uuid4().hex}.bak"
    _create_directory_link(source, staging)
    try:
        had_destination = destination.exists() or _is_directory_link(destination)
        if had_destination:
            os.replace(destination, backup)
        try:
            os.replace(staging, destination)
        except OSError:
            if had_destination:
                os.replace(backup, destination)
            raise
        if had_destination:
            _remove_directory_entry(backup)
    finally:
        if staging.exists() or _is_directory_link(staging):
            _remove_directory_entry(staging)


def _remove_checkout(path: Path) -> None:
    if _is_directory_link(path):
        _remove_directory_entry(path)
        return

    def clear_readonly(func: Any, target: str, _exc_info: Any) -> None:
        os.chmod(target, stat.S_IWRITE | stat.S_IREAD)
        func(target)

    shutil.rmtree(path, onerror=clear_readonly)


def _resolve_disk_casing(path: Path) -> Path:
    entries = list(path.parent.iterdir())
    exact = next((entry for entry in entries if entry.name == path.name), None)
    if exact is not None:
        return exact.resolve()
    return next(
        entry for entry in entries if entry.name.casefold() == path.name.casefold()
    ).resolve()


def _normalise_name(value: str) -> str:
    name = str(value or "").strip()
    if not _NAME_RE.fullmatch(name):
        raise GroupSkillError("skill name must be lowercase letters, digits, '-' or '_'")
    return name


def _validate_external_repo_url(value: str) -> str:
    """Accept only HTTPS URLs for supported public Git hosting services."""
    url = str(value or "").strip()
    if not url:
        raise GroupSkillError("repo_url is required")
    try:
        parsed = urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise GroupSkillError("repo_url must be a valid HTTPS repository URL") from exc
    host = (parsed.hostname or "").casefold()
    if parsed.scheme.casefold() != "https" or not host:
        raise GroupSkillError("repo_url must be an HTTPS repository URL")
    if parsed.username or parsed.password:
        raise GroupSkillError("repo_url must not contain embedded credentials")
    if port not in {None, 443}:
        raise GroupSkillError("repo_url must use the standard HTTPS port")
    if host not in _PUBLIC_GIT_HOSTS and not host.endswith(_PUBLIC_GIT_HOST_SUFFIXES):
        raise GroupSkillError("repo_url host is not a supported public Git service")
    path_parts = [unquote(part) for part in parsed.path.split("/") if part]
    if len(path_parts) < 2 or any(part in {".", ".."} for part in path_parts):
        raise GroupSkillError("repo_url must identify a repository")
    if parsed.query or parsed.fragment:
        raise GroupSkillError("repo_url must not contain a query or fragment")
    return url


def _normalise_safe_tools(raw: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    if not isinstance(raw, list):
        return result
    for item in raw:
        if isinstance(item, dict) and str(item.get("tool") or "").strip():
            match = item.get("match")
            if not isinstance(match, dict) or not match:
                continue
            normalised_match: dict[str, str] = {}
            for key, value in match.items():
                pattern = str(value)
                try:
                    re.compile(pattern)
                except re.error as exc:
                    raise GroupSkillError(
                        f"invalid safe-tool pattern for {str(item['tool']).strip()}.{key}: {exc}"
                    ) from exc
                normalised_match[str(key)] = pattern
            result.append(
                {
                    "tool": str(item["tool"]).strip(),
                    "match": normalised_match,
                }
            )
    return result


def parse_group_skill(path: Path, *, chat_id: str) -> GroupSkillRecord:
    """Parse one snapshot without consulting personal skill state or caches."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise GroupSkillError(f"cannot read skill file: {exc}") from exc
    match = _FRONTMATTER_RE.match(raw)
    if match is None:
        raise GroupSkillError("SKILL.md must contain YAML frontmatter")
    try:
        meta = yaml.safe_load(match.group("meta")) or {}
    except yaml.YAMLError as exc:
        raise GroupSkillError(f"invalid YAML frontmatter: {exc}") from exc
    if not isinstance(meta, dict):
        raise GroupSkillError("skill frontmatter must be a mapping")
    name = _normalise_name(str(meta.get("name") or path.parent.name))
    metadata_raw = meta.get("metadata")
    metadata = cast(dict[str, Any], metadata_raw) if isinstance(metadata_raw, dict) else {}
    namespaced_raw = metadata.get("praestoclaw")
    namespaced = cast(dict[str, Any], namespaced_raw) if isinstance(namespaced_raw, dict) else {}
    resolved = {**{k: v for k, v in metadata.items() if k != "praestoclaw"}, **namespaced}
    activation_raw = resolved.get("activation")
    activation = cast(dict[str, Any], activation_raw) if isinstance(activation_raw, dict) else {}
    description = str(meta.get("description") or "")
    keywords_raw = activation.get("keywords") or meta.get("triggers") or []
    if isinstance(keywords_raw, str):
        keywords_raw = [part.strip() for part in keywords_raw.split(",")]
    patterns_raw = activation.get("patterns") or []
    if isinstance(patterns_raw, str):
        patterns_raw = [patterns_raw]
    # A large part of the existing bundled catalog predates activation
    # metadata and advertises triggers in its description. Preserve that
    # practical discovery contract for imported Group Skills without using the
    # personal SkillLoader. Slash commands are exact patterns; a conventional
    # ``Triggers:``/``Triggers —`` tail contributes keyword phrases.
    if not keywords_raw:
        trigger_tail = re.search(r"\btriggers?\s*(?:[:\-\u2014])\s*(.+)$", description, re.I)
        if trigger_tail:
            keywords_raw = [
                part.strip().rstrip(".")
                for part in trigger_tail.group(1).split(",")
                if part.strip()
            ]
    description_commands = sorted(set(re.findall(r"/[a-z0-9][a-z0-9_-]*", description, re.I)))
    if description_commands:
        keywords_raw = [
            *(list(keywords_raw) if isinstance(keywords_raw, list) else []),
            *description_commands,
        ]
        existing_patterns = list(patterns_raw) if isinstance(patterns_raw, list) else []
        patterns_raw = [
            *existing_patterns,
            *(rf"(?<!\w){re.escape(command)}\b" for command in description_commands),
        ]
    patterns: list[str] = []
    for value in patterns_raw if isinstance(patterns_raw, list) else []:
        pattern = str(value)
        try:
            re.compile(pattern)
        except re.error as exc:
            raise GroupSkillError(f"invalid activation pattern {pattern!r}: {exc}") from exc
        patterns.append(pattern)
    safe_raw = resolved.get("safe-tools") or resolved.get("safe_tools") or []
    content = match.group("body").strip()
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    return GroupSkillRecord(
        chat_id=chat_id,
        name=name,
        description=description,
        content=content,
        keywords=[str(value) for value in keywords_raw if str(value).strip()],
        patterns=patterns,
        safe_tools=_normalise_safe_tools(safe_raw),
        content_hash=digest,
    )


def _package_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(
        (
            item
            for item in root.rglob("*")
            if item.is_file() and ".git" not in item.relative_to(root).parts
        ),
        key=lambda item: item.relative_to(root).as_posix(),
    ):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(path.read_bytes())
    return digest.hexdigest()


class GroupSkillRegistry:
    """Durable registry and immutable-ish snapshot cache, isolated by chat."""

    def __init__(self, data_dir: Path) -> None:
        self.base_dir = data_dir / "group-skills"
        self._index_path = self.base_dir / "registry.json"
        self._lifecycle_lock = threading.RLock()
        self._lock = threading.RLock()
        self._records: dict[tuple[str, str], GroupSkillRecord] = {}
        self._load()

    def _skill_dir(self, chat_id: str, name: str) -> Path:
        return self.base_dir / _chat_key(chat_id) / "skills" / _normalise_name(name)

    def snapshot_path(self, chat_id: str, name: str) -> Path:
        package_dir = self._skill_dir(chat_id, name)
        canonical = package_dir / "SKILL.md"
        lowercase = package_dir / "skill.md"
        return lowercase if not canonical.is_file() and lowercase.is_file() else canonical

    def _repo_path(self, chat_id: str, repo_url: str) -> Path:
        return self.base_dir / _chat_key(chat_id) / "repos" / _repo_key(repo_url)

    def get(self, chat_id: str, name: str) -> GroupSkillRecord | None:
        with self._lock:
            record = self._records.get((str(chat_id), _normalise_name(name)))
            return GroupSkillRecord(**asdict(record)) if record else None

    def list(self, chat_id: str) -> list[GroupSkillRecord]:
        with self._lock:
            records = [
                GroupSkillRecord(**asdict(record))
                for (cid, _), record in self._records.items()
                if cid == str(chat_id)
            ]
        return sorted(records, key=lambda item: item.name)

    def install_snapshot(
        self,
        *,
        chat_id: str,
        requested_name: str,
        source_file: Path,
        source_type: Literal["import", "external"],
        source_locator: str,
        source_subpath: str = "",
        installed_by: str = "",
        resolved_revision: str = "",
        preserve_enabled: bool = False,
    ) -> GroupSkillRecord:
        cid = str(chat_id or "").strip()
        if not cid:
            raise GroupSkillError("current group chat id is required")
        requested = _normalise_name(requested_name)
        parsed = parse_group_skill(source_file, chat_id=cid)
        package_root = source_file.parent if source_file.name.lower() == "skill.md" else None
        parsed.content_hash = (
            _package_hash(package_root)
            if package_root is not None
            else hashlib.sha256(source_file.read_bytes()).hexdigest()
        )
        if parsed.name != requested:
            raise GroupSkillError(
                f"requested skill name '{requested}' does not match snapshot name '{parsed.name}'"
            )
        now = datetime.now(UTC).isoformat()
        parsed.source_type = source_type
        parsed.source_locator = source_locator
        parsed.source_subpath = source_subpath
        parsed.resolved_revision = resolved_revision
        parsed.updated_at = now
        package_dir = self._skill_dir(cid, requested)
        destination = package_dir / "SKILL.md"
        chat_dir = package_dir.parent
        chat_dir.mkdir(parents=True, exist_ok=True)
        staging = chat_dir / f".{requested}-{uuid.uuid4().hex}.tmp"
        try:
            # Snapshot the complete package, not only its prompt. Skills often
            # refer to sibling AGENT.md, scripts, frameworks, or assets.
            if package_root is not None:
                shutil.copytree(
                    package_root,
                    staging,
                    ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"),
                )
                staged_source = staging / source_file.name
            else:
                staging.mkdir()
                staged_source = staging / source_file.name
                shutil.copyfile(source_file, staged_source)
            canonical = staging / "SKILL.md"
            if staged_source != canonical:
                shutil.copyfile(staged_source, canonical)
            with self._lifecycle_lock, self._lock:
                key = (cid, requested)
                previous = self._records.get(key)
                parsed.enabled = bool(previous and previous.enabled and preserve_enabled)
                parsed.installed_by = installed_by or (previous.installed_by if previous else "")
                parsed.installed_at = previous.installed_at if previous else now
                backup = chat_dir / f".{requested}-{uuid.uuid4().hex}.bak"
                if package_dir.exists():
                    os.replace(package_dir, backup)
                try:
                    os.replace(staging, package_dir)
                    parsed.source_path = str(destination)
                    self._records[key] = parsed
                    self._persist()
                except Exception:
                    if package_dir.exists() or _is_directory_link(package_dir):
                        _remove_directory_entry(package_dir)
                    if backup.exists():
                        os.replace(backup, package_dir)
                    if previous is None:
                        self._records.pop(key, None)
                    else:
                        self._records[key] = previous
                    raise
                if backup.exists() or _is_directory_link(backup):
                    _remove_directory_entry(backup)
        finally:
            if staging.is_dir():
                shutil.rmtree(staging)
        return GroupSkillRecord(**asdict(parsed))

    def set_enabled(self, chat_id: str, name: str, enabled: bool) -> GroupSkillRecord:
        key = (str(chat_id), _normalise_name(name))
        with self._lock:
            record = self._records.get(key)
            if record is None:
                raise GroupSkillError(f"group skill '{name}' is not registered in this chat")
            record.enabled = enabled
            record.updated_at = datetime.now(UTC).isoformat()
            self._persist()
            return GroupSkillRecord(**asdict(record))

    def read_asset(self, chat_id: str, name: str, relative_path: str) -> str:
        """Read one UTF-8 text asset from an enabled current-chat snapshot."""
        with self._lock:
            record = self._records.get((str(chat_id), _normalise_name(name)))
            if record is None:
                raise GroupSkillError(f"group skill '{name}' is not registered in this chat")
            if not record.enabled:
                raise GroupSkillError(f"group skill '{name}' is not loaded in this chat")
            requested = str(relative_path or "").strip().replace("\\", "/")
            if not requested:
                raise GroupSkillError("path is required")
            package_root = self.snapshot_path(chat_id, name).parent.resolve()
            candidate = (package_root / requested).resolve()
            try:
                candidate.relative_to(package_root)
            except ValueError as exc:
                raise GroupSkillError("path must stay inside the group skill package") from exc
            if not candidate.is_file():
                raise GroupSkillError(f"group skill asset '{requested}' was not found")
            try:
                content = candidate.read_text(encoding="utf-8")
            except (OSError, UnicodeError) as exc:
                raise GroupSkillError(f"cannot read group skill asset: {exc}") from exc
            if len(content) > 100_000:
                raise GroupSkillError("group skill asset exceeds the 100K text limit")
            return content

    def remove(self, chat_id: str, name: str) -> bool:
        key = (str(chat_id), _normalise_name(name))
        with self._lifecycle_lock, self._lock:
            if key not in self._records:
                return False
            directory = self.snapshot_path(chat_id, name).parent
            record = self._records.pop(key)
            if directory.is_dir() or _is_directory_link(directory):
                _remove_directory_entry(directory)
            if record.source_type == "external" and not any(
                item.chat_id == record.chat_id
                and item.source_type == "external"
                and item.source_locator == record.source_locator
                for item in self._records.values()
            ):
                repo_dir = self._repo_path(record.chat_id, record.source_locator)
                if repo_dir.is_dir():
                    _remove_checkout(repo_dir)
            self._persist()
        return True

    def install_external(
        self,
        *,
        chat_id: str,
        name: str,
        repo_url: str,
        skill_path: str = "",
        installed_by: str = "",
        preserve_enabled: bool = False,
    ) -> GroupSkillRecord:
        records = self.install_external_many(
            chat_id=chat_id,
            repo_url=repo_url,
            name=name,
            skill_path=skill_path,
            installed_by=installed_by,
            preserve_enabled=preserve_enabled,
        )
        if len(records) != 1:
            raise GroupSkillError("repository selection must resolve to exactly one skill")
        return records[0]

    def install_external_many(
        self,
        *,
        chat_id: str,
        repo_url: str,
        name: str = "",
        skill_path: str = "",
        installed_by: str = "",
        preserve_enabled: bool = False,
    ) -> builtins.list[GroupSkillRecord]:
        """Install one named skill or every discovered skill from one per-chat checkout."""
        url = _validate_external_repo_url(repo_url)
        cid = str(chat_id or "").strip()
        if not cid:
            raise GroupSkillError("current group chat id is required")
        clone_dir = self._repo_path(cid, url)
        with self._lifecycle_lock:
            git_env = {**os.environ, **_NONINTERACTIVE_GIT_ENV}
            if clone_dir.is_dir() and not (clone_dir / ".git").is_dir():
                _remove_checkout(clone_dir)
            try:
                if clone_dir.is_dir():
                    subprocess.run(
                        ["git", "fetch", "--depth", "1", "origin"],
                        cwd=clone_dir,
                        check=True,
                        capture_output=True,
                        env=git_env,
                        text=True,
                        timeout=120,
                    )
                    subprocess.run(
                        ["git", "reset", "--hard", "FETCH_HEAD"],
                        cwd=clone_dir,
                        check=True,
                        capture_output=True,
                        env=git_env,
                        text=True,
                        timeout=30,
                    )
                else:
                    clone_dir.parent.mkdir(parents=True, exist_ok=True)
                    subprocess.run(
                        ["git", "clone", "--depth", "1", "--", url, str(clone_dir)],
                        check=True,
                        capture_output=True,
                        env=git_env,
                        text=True,
                        timeout=120,
                    )
                revision = subprocess.run(
                    ["git", "rev-parse", "HEAD"],
                    cwd=clone_dir,
                    check=True,
                    capture_output=True,
                    env=git_env,
                    text=True,
                    timeout=10,
                ).stdout.strip()
            except (OSError, subprocess.SubprocessError) as exc:
                if clone_dir.is_dir() and not (clone_dir / ".git").is_dir():
                    _remove_checkout(clone_dir)
                raise GroupSkillError(f"failed to fetch external skill: {exc}") from exc
            clone_dir = clone_dir.resolve()
            selected = self._discover_external_sources(
                clone_dir, chat_id=cid, name=name, skill_path=skill_path
            )
            with self._lock:
                related = [
                    record
                    for record in self._records.values()
                    if record.chat_id == cid
                    and record.source_type == "external"
                    and record.source_locator == url
                ]
                sources_by_name = dict(selected)
                for record in related:
                    source = (clone_dir / record.source_subpath).resolve()
                    try:
                        source.relative_to(clone_dir)
                    except ValueError as exc:
                        raise GroupSkillError(
                            "stored skill path must stay inside the repository"
                        ) from exc
                    sources_by_name[record.name] = source

                records: builtins.list[GroupSkillRecord] = []
                now = datetime.now(UTC).isoformat()
                selected_names = {requested_name for requested_name, _source in selected}
                for requested_name, source in sorted(sources_by_name.items()):
                    parsed = parse_group_skill(source, chat_id=cid)
                    if parsed.name != requested_name:
                        raise GroupSkillError(
                            f"requested skill name '{requested_name}' does not match snapshot "
                            f"name '{parsed.name}'"
                        )
                    parsed.content_hash = _package_hash(source.parent)
                    parsed.source_type = "external"
                    parsed.source_locator = url
                    parsed.source_subpath = source.relative_to(clone_dir).as_posix()
                    parsed.resolved_revision = revision
                    parsed.updated_at = now
                    key = (cid, requested_name)
                    previous = self._records.get(key)
                    selected_now = requested_name in selected_names
                    parsed.enabled = bool(
                        previous and previous.enabled and (preserve_enabled or not selected_now)
                    )
                    parsed.installed_by = (installed_by if selected_now else "") or (
                        previous.installed_by if previous else ""
                    )
                    parsed.installed_at = previous.installed_at if previous else now

                    package_dir = self._skill_dir(cid, requested_name)
                    package_dir.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        _replace_directory_link(source.parent, package_dir)
                    except (OSError, subprocess.SubprocessError) as exc:
                        raise GroupSkillError(f"failed to link external skill: {exc}") from exc
                    parsed.source_path = str(package_dir / source.name)
                    self._records[key] = parsed
                    records.append(GroupSkillRecord(**asdict(parsed)))
                self._persist()

                return [record for record in records if record.name in selected_names]

    @staticmethod
    def _discover_external_sources(
        clone_dir: Path,
        *,
        chat_id: str,
        name: str,
        skill_path: str,
    ) -> builtins.list[tuple[str, Path]]:
        clone_dir = clone_dir.resolve()
        scope = clone_dir
        if skill_path:
            candidate = (clone_dir / skill_path.replace("\\", "/")).resolve()
            try:
                candidate.relative_to(clone_dir)
            except ValueError as exc:
                raise GroupSkillError("skill_path must stay inside the repository") from exc
            if candidate.is_file():
                candidates = [candidate]
            elif candidate.is_dir():
                direct = [candidate / "SKILL.md", candidate / "skill.md"]
                source = next((item.resolve() for item in direct if item.is_file()), None)
                candidates = [source] if source else []
                if not candidates:
                    scope = candidate
            else:
                raise GroupSkillError(f"skill_path was not found in repository: {skill_path}")
        else:
            candidates = []

        if not candidates:
            found: dict[str, Path] = {}
            for pattern in ("SKILL.md", "skill.md"):
                for item in scope.rglob(pattern):
                    if item.is_file() and ".git" not in item.relative_to(clone_dir).parts:
                        resolved = item.resolve()
                        try:
                            relative = resolved.relative_to(clone_dir)
                        except ValueError:
                            continue
                        found.setdefault(relative.as_posix().casefold(), resolved)
            candidates = sorted(
                found.values(), key=lambda item: item.relative_to(clone_dir).as_posix()
            )

        requested = _normalise_name(name) if name else ""
        discovered: dict[str, Path] = {}
        for source in candidates:
            source = _resolve_disk_casing(source)
            try:
                source.relative_to(clone_dir)
            except ValueError as exc:
                if skill_path:
                    raise GroupSkillError("skill_path must resolve inside the repository") from exc
                continue
            try:
                parsed = parse_group_skill(source, chat_id=chat_id)
            except GroupSkillError:
                continue
            if requested and parsed.name != requested:
                continue
            if parsed.name in discovered:
                raise GroupSkillError(
                    f"repository contains multiple skills named '{parsed.name}'; provide skill_path"
                )
            discovered[parsed.name] = source

        if not discovered:
            target = f"skill '{requested}'" if requested else "any valid skills"
            raise GroupSkillError(f"repository does not contain {target}")
        return sorted(discovered.items())

    def _load(self) -> None:
        if not self._index_path.is_file():
            return
        try:
            payload = json.loads(self._index_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return
        if not isinstance(payload, dict) or payload.get("version") != 1:
            return
        for raw in payload.get("skills") or []:
            try:
                record = GroupSkillRecord(**raw)
                record.name = _normalise_name(record.name)
                if (
                    not record.chat_id
                    or not self.snapshot_path(record.chat_id, record.name).is_file()
                ):
                    continue
            except (TypeError, GroupSkillError):
                continue
            self._records[(record.chat_id, record.name)] = record

    def _persist(self) -> None:
        self.base_dir.mkdir(parents=True, exist_ok=True)
        payload = {
            "version": 1,
            "skills": [
                asdict(record)
                for record in sorted(
                    self._records.values(), key=lambda item: (item.chat_id, item.name)
                )
            ],
        }
        fd, tmp_name = tempfile.mkstemp(prefix="registry-", suffix=".tmp", dir=self.base_dir)
        tmp = Path(tmp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2)
                handle.write("\n")
            os.replace(tmp, self._index_path)
        finally:
            tmp.unlink(missing_ok=True)


class GroupSkillLoader:
    """Current-chat matcher over the independent group registry."""

    def __init__(self, registry: GroupSkillRegistry) -> None:
        self.registry = registry

    def match(self, chat_id: str, text: str, *, threshold: int = 15) -> list[GroupSkillRecord]:
        scored = [
            (record.score(text), record) for record in self.registry.list(chat_id) if record.enabled
        ]
        scored.sort(key=lambda item: (-item[0], item[1].name))
        return [record for score, record in scored if score >= threshold]

    def resolve_enabled(self, chat_id: str, names: list[str]) -> list[GroupSkillRecord]:
        """Resolve explicit task dependencies without scoring or silent omission."""
        records: list[GroupSkillRecord] = []
        seen: set[str] = set()
        for raw_name in names:
            name = _normalise_name(raw_name)
            if name in seen:
                continue
            seen.add(name)
            record = self.registry.get(chat_id, name)
            if record is None or not record.enabled:
                raise GroupSkillError(f"group skill '{name}' is not loaded in this chat")
            records.append(record)
        return records

    def prompt_section(self, chat_id: str) -> str:
        enabled = [record for record in self.registry.list(chat_id) if record.enabled]
        if not enabled:
            return ""
        lines = ["## Group Skills", "", "Enabled only for this group chat:"]
        lines.extend(f"- {record.name}: {record.description}" for record in enabled)
        return "\n".join(lines)
