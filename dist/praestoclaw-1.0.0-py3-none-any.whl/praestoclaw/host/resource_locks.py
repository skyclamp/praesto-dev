"""Conservative shared-resource locks for concurrent execution chains."""

from __future__ import annotations

import asyncio
import os
import threading
import weakref
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_PATH_KEYS = ("path", "file_path", "file", "filename")
_PATH_SCOPED_MUTATORS = {"write_file", "edit_file"}
_GLOBAL_MUTATORS = {
    "browser",
    "attachment_process",
    "config_praestoclaw",
    "cron",
    "git",
    "memory",
    "plan",
    "shell",
    "skill_manage",
    "tools",
    "web_fetch",
}


@dataclass(slots=True)
class _LoopResourceLocks:
    global_mutation: asyncio.Lock = field(default_factory=asyncio.Lock)
    path_locks: weakref.WeakValueDictionary[str, asyncio.Lock] = field(
        default_factory=weakref.WeakValueDictionary
    )

    def path_lock(self, key: str) -> asyncio.Lock:
        lock = self.path_locks.get(key)
        if lock is None:
            lock = asyncio.Lock()
            self.path_locks[key] = lock
        return lock


_loop_locks: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, _LoopResourceLocks] = (
    weakref.WeakKeyDictionary()
)
_loop_locks_guard = threading.Lock()


def _locks_for_running_loop() -> _LoopResourceLocks:
    loop = asyncio.get_running_loop()
    with _loop_locks_guard:
        locks = _loop_locks.get(loop)
        if locks is None:
            locks = _LoopResourceLocks()
            _loop_locks[loop] = locks
        return locks


def _path_lock_key(arguments: dict[str, Any], *, workspace: Path | None = None) -> str | None:
    for key in _PATH_KEYS:
        value = arguments.get(key)
        if isinstance(value, str) and value.strip():
            raw_path = Path(value.strip()).expanduser()
            base = workspace.expanduser() if workspace is not None else Path.cwd()
            resolved = (base / raw_path).resolve(strict=False)
            return os.path.normcase(str(resolved))
    return None


@asynccontextmanager
async def tool_resource_lock(
    tool_name: str,
    arguments: dict[str, Any],
    *,
    workspace: Path | None = None,
) -> AsyncIterator[None]:
    """Serialize known mutating tools across parallel execution chains."""

    if tool_name in _PATH_SCOPED_MUTATORS:
        key = _path_lock_key(arguments, workspace=workspace)
        if key is None:
            async with _locks_for_running_loop().global_mutation:
                yield
            return
        async with _locks_for_running_loop().path_lock(key):
            yield
        return

    if tool_name in _GLOBAL_MUTATORS or tool_name.startswith("MCP_"):
        async with _locks_for_running_loop().global_mutation:
            yield
        return

    yield
