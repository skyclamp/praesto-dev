"""OpenClaw-style execution-chain scheduler.

The runner gives each conversation/session its own serial lane while allowing
different sessions to run concurrently through bounded global lanes.
"""

from __future__ import annotations

import asyncio
import contextvars
import time
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any, Generic, TypeVar

from loguru import logger

T = TypeVar("T")

_CURRENT_CHAIN_SESSION: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "praestoclaw_execution_chain_session",
    default=None,
)
_CURRENT_CHAIN_TASK: contextvars.ContextVar[asyncio.Task[object] | None] = contextvars.ContextVar(
    "praestoclaw_execution_chain_task",
    default=None,
)
_CURRENT_CHAIN_REENTRY_LOCK: contextvars.ContextVar[asyncio.Lock | None] = contextvars.ContextVar(
    "praestoclaw_execution_chain_reentry_lock",
    default=None,
)


def detached_chain_context() -> contextvars.Context:
    """Return a context copy with execution-chain reentry vars reset to defaults.

    Fire-and-forget tasks (e.g. detached background sub-agents) are spawned from
    inside an active turn, so they would otherwise inherit that turn's
    ``_CURRENT_CHAIN_*`` vars and risk being mistaken for same-session reentry of
    the spawning turn. Running the detached task in this context keeps the
    scheduler's reentry detection correct.
    """
    ctx = contextvars.copy_context()

    def _reset() -> None:
        _CURRENT_CHAIN_SESSION.set(None)
        _CURRENT_CHAIN_TASK.set(None)
        _CURRENT_CHAIN_REENTRY_LOCK.set(None)

    ctx.run(_reset)
    return ctx


class ExecutionLane(StrEnum):
    MAIN = "main"
    SYSTEM = "system"
    SUBAGENT = "subagent"


class ExecutionChainError(RuntimeError):
    """Base class for execution-chain scheduling failures."""


class ExecutionChainQueueFullError(ExecutionChainError):
    """Raised when a session has too many pending turns."""


class ExecutionChainStoppedError(ExecutionChainError):
    """Raised when work is submitted after the runner starts shutting down."""


class ExecutionChainCancelledError(ExecutionChainError):
    """Raised for queued work cleared by an explicit session interrupt."""


@dataclass(slots=True)
class _ChainItem(Generic[T]):
    session_key: str
    turn_id: str
    lane: ExecutionLane
    execute: Callable[[], Awaitable[T]]
    future: asyncio.Future[T]
    run_task: asyncio.Task[T] | None = None


@dataclass(slots=True)
class _SessionState:
    queue: deque[_ChainItem[Any]] = field(default_factory=deque)
    active: _ChainItem[Any] | None = None
    worker: asyncio.Task[None] | None = None


class ExecutionChainRunner:
    """Schedule turns by session lane and bounded global execution lanes."""

    def __init__(
        self,
        *,
        main_max_concurrent: int = 10,
        system_max_concurrent: int = 10,
        subagent_max_concurrent: int = 8,
        pending_per_session: int = 20,
    ) -> None:
        self._pending_per_session = pending_per_session
        self._sessions: dict[str, _SessionState] = {}
        self._workers: set[asyncio.Task[None]] = set()
        self._stopped = False
        self._semaphores: dict[ExecutionLane, asyncio.Semaphore] = {
            ExecutionLane.MAIN: asyncio.Semaphore(main_max_concurrent),
            ExecutionLane.SYSTEM: asyncio.Semaphore(system_max_concurrent),
            ExecutionLane.SUBAGENT: asyncio.Semaphore(subagent_max_concurrent),
        }

    async def run(
        self,
        *,
        session_key: str,
        turn_id: str,
        lane: ExecutionLane = ExecutionLane.MAIN,
        execute: Callable[[], Awaitable[T]],
    ) -> T:
        """Queue work for a session and wait for its result."""
        future, item = self._submit(
            session_key=session_key,
            turn_id=turn_id,
            lane=lane,
            execute=execute,
        )
        try:
            return await future
        except asyncio.CancelledError:
            if item is not None:
                self._cancel_item_from_caller(item)
            raise

    def submit(
        self,
        *,
        session_key: str,
        turn_id: str,
        lane: ExecutionLane = ExecutionLane.MAIN,
        execute: Callable[[], Awaitable[T]],
    ) -> asyncio.Future[T]:
        """Synchronously enqueue work and return its completion future."""
        future, _ = self._submit(
            session_key=session_key,
            turn_id=turn_id,
            lane=lane,
            execute=execute,
        )
        return future

    def _submit(
        self,
        *,
        session_key: str,
        turn_id: str,
        lane: ExecutionLane,
        execute: Callable[[], Awaitable[T]],
    ) -> tuple[asyncio.Future[T], _ChainItem[T] | None]:
        current_task = asyncio.current_task()
        same_session_reentry = _CURRENT_CHAIN_SESSION.get() == session_key
        if current_task is not None and _CURRENT_CHAIN_TASK.get() is current_task:
            if same_session_reentry:
                return asyncio.ensure_future(execute()), None
        elif same_session_reentry:
            reentry_lock = _CURRENT_CHAIN_REENTRY_LOCK.get()
            if reentry_lock is not None:

                async def _run_reentrant() -> T:
                    async with reentry_lock:
                        return await execute()

                return asyncio.ensure_future(_run_reentrant()), None

        if self._stopped:
            raise ExecutionChainStoppedError("execution chain runner is stopping")

        state = self._sessions.setdefault(session_key, _SessionState())
        pending = sum(1 for queued in state.queue if not queued.future.done()) + (
            1 if state.active is not None and not state.active.future.done() else 0
        )
        if pending >= self._pending_per_session:
            raise ExecutionChainQueueFullError(
                f"session {session_key!r} already has {pending} active/pending turn(s)"
            )

        loop = asyncio.get_running_loop()
        future: asyncio.Future[T] = loop.create_future()
        item: _ChainItem[T] = _ChainItem(
            session_key=session_key,
            turn_id=turn_id,
            lane=lane,
            execute=execute,
            future=future,
        )

        def _cancel_submitted(done: asyncio.Future[T]) -> None:
            if done.cancelled():
                self._cancel_item_from_caller(item)

        future.add_done_callback(_cancel_submitted)

        state.queue.append(item)
        if state.worker is None or state.worker.done():
            state.worker = asyncio.create_task(
                self._drain_session(session_key, state),
                name=f"execution-chain:{session_key}",
            )
            self._workers.add(state.worker)
            state.worker.add_done_callback(lambda task: self._workers.discard(task))

        return future, item

    def has_session_work(self, session_key: str) -> bool:
        state = self._sessions.get(session_key)
        return bool(state and (state.active is not None or state.queue))

    def interrupt(self, session_key: str, reason: str = "session interrupted") -> bool:
        """Cancel the active turn and clear pending turns for one session."""
        state = self._sessions.get(session_key)
        if state is None:
            return False

        interrupted = False
        active = state.active
        if active is not None and active.run_task is not None and not active.run_task.done():
            interrupted = True
            logger.info("Interrupting execution chain session={} reason={}", session_key, reason)
            active.run_task.cancel()
        elif active is not None and active.run_task is None and not active.future.done():
            interrupted = True
            active.future.set_exception(ExecutionChainCancelledError(reason))

        while state.queue:
            interrupted = True
            item = state.queue.popleft()
            if not item.future.done():
                item.future.set_exception(ExecutionChainCancelledError(reason))

        return interrupted

    def interrupt_all(self, reason: str = "all sessions interrupted") -> int:
        interrupted = 0
        for session_key in list(self._sessions):
            if self.interrupt(session_key, reason):
                interrupted += 1
        return interrupted

    def _cancel_item_from_caller(self, item: _ChainItem[Any]) -> None:
        """Best-effort cleanup when the task awaiting ``run()`` is cancelled."""
        state = self._sessions.get(item.session_key)
        if state is None:
            return

        removed_from_queue = False
        try:
            state.queue.remove(item)
            removed_from_queue = True
        except ValueError:
            pass

        if removed_from_queue and not item.future.done():
            item.future.cancel()

        if state.active is item and not item.future.done():
            item.future.cancel()

        if state.active is item and item.run_task is not None and not item.run_task.done():
            logger.info(
                "Cancelling execution chain work after caller cancellation session={} turn_id={}",
                item.session_key,
                item.turn_id,
            )
            item.run_task.cancel()

    async def stop(self) -> None:
        """Reject new work, cancel active work, clear queues, and wait for workers."""
        self._stopped = True
        self.interrupt_all("execution chain runner stopping")
        workers = [task for task in self._workers if not task.done()]
        if workers:
            await asyncio.gather(*workers, return_exceptions=True)

    async def _drain_session(self, session_key: str, state: _SessionState) -> None:
        while True:
            if self._stopped and not state.queue:
                self._sessions.pop(session_key, None)
                return
            if not state.queue:
                state.worker = None
                if state.active is None:
                    self._sessions.pop(session_key, None)
                return

            item = state.queue.popleft()
            state.active = item
            try:
                async with self._semaphores[item.lane]:
                    if item.future.done():
                        continue
                    # Snapshot remaining backlog *after* dequeue, *before* run.
                    # This is the count of turns still waiting in this
                    # session's serial lane while this one starts executing.
                    queued_n = len(state.queue)
                    started_at = time.monotonic()
                    logger.info(
                        "chain.turn_start session_key={} turn_id={} lane={} queued_n={}",
                        item.session_key,
                        item.turn_id,
                        item.lane.value,
                        queued_n,
                    )
                    run_task = asyncio.create_task(
                        self._execute_with_reentry_context(item),
                        name=f"execution-turn:{item.turn_id or session_key}",
                    )
                    item.run_task = run_task
                    outcome = "success"
                    try:
                        result = await run_task
                    except asyncio.CancelledError as exc:
                        outcome = "cancelled"
                        if not item.future.done():
                            item.future.set_exception(exc)
                    except Exception as exc:  # noqa: BLE001 - future carries turn failure
                        outcome = "error"
                        if not item.future.done():
                            item.future.set_exception(exc)
                    else:
                        if not item.future.done():
                            item.future.set_result(result)
                    elapsed_ms = int((time.monotonic() - started_at) * 1000)
                    logger.info(
                        "chain.turn_end session_key={} turn_id={} lane={} elapsed_ms={} outcome={}",
                        item.session_key,
                        item.turn_id,
                        item.lane.value,
                        elapsed_ms,
                        outcome,
                    )
            finally:
                if state.active is item:
                    state.active = None

    @staticmethod
    async def _execute_with_reentry_context(item: _ChainItem[T]) -> T:
        session_token = _CURRENT_CHAIN_SESSION.set(item.session_key)
        task_token = _CURRENT_CHAIN_TASK.set(asyncio.current_task())
        lock_token = _CURRENT_CHAIN_REENTRY_LOCK.set(asyncio.Lock())
        try:
            return await item.execute()
        finally:
            _CURRENT_CHAIN_REENTRY_LOCK.reset(lock_token)
            _CURRENT_CHAIN_TASK.reset(task_token)
            _CURRENT_CHAIN_SESSION.reset(session_token)
