"""
Built-in hook handlers — the safety handlers always registered.

Deliberately not a count: the list below is the source of truth, and a hard-coded
number drifts the moment a handler is added (it already read "8" while twelve
registrations existed).

on_message_received:
  - InjectionScanner (priority 10)

pre_tool_use:
  - EStopGate (priority 1)
  - WorkflowCommandDenylist (priority 5) — recipe-declared command prohibitions
  - PolicyGate (priority 10)
  - ApprovalGate (priority 20) — allowlist check, classifier, human-in-the-loop

post_tool_use:
  - LeakScanner (priority 10)
  - Auditor (priority 30)

on_message_sent:
  - OutboundLeakScanner (priority 10)
"""

from __future__ import annotations

import asyncio
import inspect
import re
from dataclasses import replace
from typing import TYPE_CHECKING, Any

from loguru import logger

from praestoclaw.channels.teams_cards import wrap_for_teams
from praestoclaw.config.schema import ChannelType
from praestoclaw.hooks.manager import (
    HookManager,
    HookResult,
    MessageHookContext,
    PostToolHookContext,
    PreToolHookContext,
)
from praestoclaw.host.runtime_contracts import is_trusted_workflow_run
from praestoclaw.security.leak import detect_credentials, redact_credentials
from praestoclaw.security.praesto_tag_exp import (
    PRAESTO_TAG_EXP_ALLOW,
    PRAESTO_TAG_EXP_REJECT,
    praesto_tag_exp_classify_capability,
    praesto_tag_exp_is_active,
)
from praestoclaw.security.sanitizer import Sanitizer

if TYPE_CHECKING:
    from pathlib import Path

    from praestoclaw.bus.queue import EventBus, MessageBus
    from praestoclaw.channels.manager import ChannelManager
    from praestoclaw.security.allowlist import AllowlistManager
    from praestoclaw.security.approval import ApprovalManager
    from praestoclaw.security.audit import AuditLogger
    from praestoclaw.security.rbac import PolicyEngine
    from praestoclaw.security.scorer import RiskScorer


# ── on_message_received handlers ─────────────────────────────────────────────


class InjectionScanner:
    """Detect prompt injection patterns in inbound messages."""

    def __init__(self, *, block: bool = False) -> None:
        self._block = block

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        findings = Sanitizer.check_prompt_injection(ctx.content)
        if findings:
            logger.warning(
                "Injection patterns detected from {}: {}",
                ctx.sender_id or "unknown",
                findings,
            )
            if self._block:
                return HookResult.reject(f"Prompt injection detected: {findings[0]}")
        return HookResult.allow()


# ── pre_tool_use handlers ────────────────────────────────────────────────────


class EStopGate:
    """Reject all tool calls when E-stop is active."""

    def __init__(self, estop: object | None = None) -> None:
        self._estop = estop

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._estop is not None and getattr(self._estop, "is_halted", False):
            return HookResult.reject("E-stop is active — all tool execution halted")
        return HookResult.allow()


class PolicyGate:
    """Check RBAC permissions before tool execution."""

    def __init__(self, policy_engine: PolicyEngine | None = None) -> None:
        self._engine = policy_engine

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if self._engine is None:
            return HookResult.allow()
        # check_permission returns (allowed: bool, level: AutonomyLevel)
        # operation defaults to "write" for tools that modify state
        operation = (
            "read" if ctx.tool_name in ("read_file", "list_dir", "search_files") else "write"
        )
        allowed, _level = self._engine.check_permission(
            ctx.tool_name, operation, agent_name=ctx.agent_name
        )
        if not allowed:
            return HookResult.reject(
                f"Tool '{ctx.tool_name}' denied by policy for agent '{ctx.agent_name}'"
            )
        return HookResult.allow()


class WorkflowCommandDenylist:
    """Refuse shell commands the running recipe declared off-limits.

    ``limits.allowed_tools`` narrows WHICH tools may skip the HUMAN approval gate;
    it says nothing about their arguments. ``_workflow_scope_admits`` below closed
    that gap for one tool (``spawn``, issue #646) and recorded why it had to be
    closed in code: the recipe text forbidding the shape was present the whole time
    and did not hold, because prose is not a control.

    ``fix-praestoclaw-bug`` is the sharpest case. Its target repository is the
    source tree of the agent executing it, on a machine running a live PraestoClaw,
    and the commands that end the run mid-turn are ordinary shell calls —
    ``praestoclaw update`` locates the daemon through ``<data-dir>/web.pid`` and
    sends SIGTERM then SIGKILL. So a recipe lists those commands as regexes in
    ``limits.denied_commands`` and this gate enforces them, for that recipe's runs
    only. A recipe that declares none is untouched.

    This runs at priority 5: after E-stop, before PolicyGate and ApprovalGate. The
    ordering matters less than it looks — ApprovalGate applies workflow-scoped
    auto-approval only AFTER its decider runs, precisely so a hard reject still
    rejects an in-scope tool — but rejecting before any scoring work happens keeps
    the refusal cheap and independent of the risk tables.

    Not everything the recipe forbids is expressible here: signalling the live PID,
    binding its port, and a bare ``git push`` are invisible to a regex over the
    command string. Those stay prose, and the recipe says so.
    """

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        if ctx.tool_name != "shell":
            return HookResult.allow()
        patterns = (ctx.metadata or {}).get("workflow_denied_commands")
        if not isinstance(patterns, list):
            return HookResult.allow()
        command = str((ctx.args or {}).get("command") or "")
        for pattern in patterns:
            if not isinstance(pattern, str):
                continue
            try:
                matched = re.search(pattern, command)
            except re.error:
                # workflow._normalize_limits compiles every pattern before it
                # reaches metadata, so an unusable one arriving here means the
                # metadata was not built by that path. Skipping it would let a
                # crafted payload disable this gate one pattern at a time.
                logger.warning("denied_commands: unusable pattern in run metadata — failing closed")
                return HookResult.reject("BLOCKED: unreadable denied_commands pattern")
            if matched:
                logger.warning(
                    "denied_commands: refused a shell call in workflow={} on pattern={!r}",
                    ctx.metadata.get("workflow"),
                    pattern,
                )
                return HookResult.reject(
                    "BLOCKED by the running recipe's limits.denied_commands "
                    f"(pattern: {pattern}). This command is prohibited for this "
                    "workflow; see the recipe for why."
                )
        return HookResult.allow()


# ── Approval escalation helpers ───────────────────────────────────────────────

# Gateway inbound ``metadata.source`` values to their effective cloud
# sub-channel for escalation bookkeeping. The gateway uses
# ``"teams_bridge"`` (see ``endpoints/teams_bridge.py``) for messages
# arriving via the C# Teams bot HTTP bridge — those land on the same
# Teams surface as ``"cloud_teams"`` and MUST be tracked as such, or
# Stage 3 half-time escalation re-pushes the approval card and Teams
# shows two identical cards ~30 s apart (Stage 1 via /chatng response,
# Stage 3 via /api/notify).
_SOURCE_TO_CLOUD_SUBCHANNEL: dict[str, str] = {
    "cloud_webchat": "cloud_webchat",
    "cloud_teams": "cloud_teams",
    "teams_bridge": "cloud_teams",
}


def _cloud_subchannel_for_source(source: str) -> str:
    """Return the cloud sub-channel name effectively delivered to by *source*.

    ``""`` for non-cloud sources (web, cli, etc.); the caller falls back
    to the raw ``request.channel.value``.
    """
    return _SOURCE_TO_CLOUD_SUBCHANNEL.get(source, "")


def _track_push(attempted: set[str], ch_name: ChannelType, push_target: str | None) -> None:
    """Record a successful push delivery in *attempted*.

    For cloud, only a **targeted** push (``push_target`` set) is tracked —
    the Python client knows exactly which sub-channel was addressed.  A
    fan-out (``push_target=None``) is **not** tracked because the gateway
    may silently skip a sub-channel that has no active connection /
    conversation reference, and the Python client has no visibility into
    the per-sub-channel delivery outcome.  Leaving the set empty for
    fan-outs means Stage 3 will retry with targeted pushes — at worst
    this causes a duplicate card on a sub-channel that already received
    the fan-out, which is acceptable.
    """
    if ch_name == ChannelType.CLOUD:
        if push_target:
            attempted.add(f"{ch_name.value}_{push_target}")
        # fan-out (push_target=None): intentionally do NOT track — see docstring
    else:
        attempted.add(ch_name.value if hasattr(ch_name, "value") else str(ch_name))


def _approval_update_key(request_id: str) -> str:
    """(oid, update_key) -> activityId mapping key shared with the Teams bot.

    Cross-service contract: changing this format requires a matching change
    in the C# NotifyController's Redis key derivation.
    """
    return f"approval:{request_id}"


# The only spawn shape a workflow recipe's `limits.allowed_tools` may auto-approve.
# `explorer` is the sole agent name for which SpawnTool.assess_risk returns a
# deterministic RiskScore(2) (agent/tools/spawn.py) — every other name and every
# non-serial mode is a RiskPrompt(3..6/4..7), i.e. exactly the LLM-scored path that
# would otherwise reach HUMAN and get silently downgraded here.
_WORKFLOW_SCOPED_SPAWN_AGENT = "explorer"
_WORKFLOW_SCOPED_SPAWN_MODES = frozenset({"", "serial"})


def _workflow_scope_admits(ctx: PreToolHookContext) -> bool:
    """Whether *ctx*'s ARGS are inside what a workflow's allowed_tools may auto-approve.

    ``limits.allowed_tools`` is matched by tool NAME, so declaring `spawn` used to
    authorize `spawn(agent='default', mode='background', …)` exactly as readily as
    the read-only explorer review a recipe actually describes — and a spawned child
    is not itself workflow-scoped, so it runs with its own agent's full palette. For
    the default agent that palette is every registered tool (runtime.py resolves
    ``tools=None`` to all of them), which turns one auto-approved call into shell +
    file write + browser + spawn. Issue #646 removed `spawn` from the Societas bugfix
    recipe after an incident of exactly this shape; the recipe text forbidding other
    spawn shapes was present the whole time and did not hold, because prose is not a
    control.

    So for `spawn` the scope is narrowed here, in code: only the deterministic
    read-only reviewer shape is admitted. Everything else falls through to the normal
    decider, which is what recipes already assume happens. Non-spawn tools are
    unaffected — this returns True for them, leaving the name-based scope as it was.
    """
    if ctx.tool_name != "spawn":
        return True
    args = ctx.args if isinstance(ctx.args, dict) else {}
    agent = str(args.get("agent") or "").strip()
    mode = str(args.get("mode") or "").strip().casefold()
    return agent == _WORKFLOW_SCOPED_SPAWN_AGENT and mode in _WORKFLOW_SCOPED_SPAWN_MODES


class ApprovalGate:
    """Risk scorer approval gate for tool calls with human-in-the-loop (v2).

    Flow:
    1. Allowlist check -> allow (both scorer and no-scorer paths)
    2. No scorer wired -> fall back to deterministic assess_risk + policy;
       RiskPrompt without scorer -> reject (fail closed)
    3. Score tool call via scorer (assess_risk → LLM if needed) -> RiskScore
    4. Policy table lookup: score x profile -> Auto/Timeout-auto/Human/Reject
    5. On Human/Timeout-auto: request approval, send prompt, await resolution.

    """

    def __init__(
        self,
        scorer: RiskScorer | None = None,
        *,
        approval_manager: ApprovalManager | None = None,
        allowlist: AllowlistManager | None = None,
        bus: EventBus | None = None,
        channel_manager: ChannelManager | None = None,
        session_store: Any = None,
        auto_approve_timeout: int = 30,
        security_profile: str = "standard",
        decider: Any = None,
        praesto_tag_exp_approval_prompt: str | None = None,
    ) -> None:
        self._scorer = scorer
        self._security_profile = security_profile
        self._approval_manager = approval_manager
        self._allowlist = allowlist
        self._bus = bus
        self._channel_manager = channel_manager
        self._session_store = session_store
        self._auto_approve_timeout = auto_approve_timeout
        self._praesto_tag_exp_approval_prompt = praesto_tag_exp_approval_prompt
        # The decider produces the AUTO / HUMAN / REJECT decision. Default to the
        # scoring policy table so callers that only pass a scorer are unchanged.
        if decider is None:
            from praestoclaw.security.decider import ScoringDecider

            decider = ScoringDecider(scorer, security_profile)
        self._decider = decider

    async def __call__(self, ctx: PreToolHookContext) -> HookResult:
        from praestoclaw.security.risk import PolicyAction

        raw_source = ctx.metadata.get("source")
        source = raw_source if isinstance(raw_source, str) else ""

        # Per-run scoped auto-approval (replaces the coarse demo_auto_approve
        # bypass): launching a workflow authorizes the tools it DECLARED in its
        # recipe `limits.allowed_tools` (Task 9) to skip the per-action HUMAN gate
        # (same principle as cron tool-mode's "approved at scheduling time"). We
        # only compute the flag here and apply it BELOW, AFTER the decider runs, so
        # a hard REJECT (policy / score-10) still rejects an in-scope tool — scoped
        # auto-approval downgrades HUMAN→allow, it never overrides REJECT. E-stop /
        # RBAC / leak-scan are separate hooks and also still apply. A recipe that
        # declares NO allowed_tools gets no auto-approval (conservative default).
        # Anti-spoof (defense-in-depth): `workflow` / `workflow_allowed_tools` ride
        # runtime metadata only trustworthy on a genuine runtime-spawned run.
        # Require runtime-owned proof a plain inbound turn cannot carry: a valid
        # BackgroundTaskManager id preserved only across INTERNAL_API, or scheduler
        # provenance built by the canonical turn kernel. Coerce the scope to
        # list[str] before the membership check.
        workflow_scoped = False
        workflow_name = " ".join(str(ctx.metadata.get("workflow") or "").split())[:200]
        if workflow_name:
            raw_scope = ctx.metadata.get("workflow_allowed_tools")
            scope = (
                [t for t in raw_scope if isinstance(t, str)] if isinstance(raw_scope, list) else []
            )
            trusted_run = is_trusted_workflow_run(ctx.metadata)
            tool_in_scope = ctx.tool_name in scope
            args_in_scope = _workflow_scope_admits(ctx)
            workflow_scoped = trusted_run and tool_in_scope and args_in_scope
            if not workflow_scoped:
                if not trusted_run:
                    miss_reason = "untrusted_runtime"
                elif not tool_in_scope:
                    miss_reason = "tool_out_of_scope"
                else:
                    miss_reason = "args_out_of_scope"
                logger.debug(
                    "workflow scoped auto-approve skipped: workflow={} tool={} reason={}",
                    workflow_name,
                    ctx.tool_name,
                    miss_reason,
                )

        # 0. Hard-block config_praestoclaw in ANY cron context (before allowlist),
        #    including a scheduled workflow run (source == "cron"). This is
        #    deliberate defense-in-depth aligned with the cron layers that also drop
        #    it (CronTool schedule-time rejection + cron agent-mode exclude_tools at
        #    cron/service.py, which lists "config_praestoclaw" for every non-heartbeat
        #    run): an UNATTENDED job must never reconfigure the agent, even if a recipe
        #    declares config_praestoclaw in its scope. A scheduled workflow that needs
        #    a value config would provide (e.g. ado_repo_local_path) takes it from an
        #    explicit recipe parameter instead. The on-demand path (background_task_id,
        #    not source=="cron") is unaffected and can use config_praestoclaw normally.
        if source == "cron" and ctx.tool_name == "config_praestoclaw":
            return HookResult.reject("config_praestoclaw is not permitted in cron jobs")

        # ``feedback_submit`` is a protected built-in capability rather than a
        # general GitHub or shell write. It fixes the repository/label, accepts
        # the body only over stdin, and binds comment/edit to issue IDs created
        # by the same trusted session. The user's feedback request authorizes
        # this narrow operation in both personal and shared conversations.
        provenance = ctx.metadata.get("turn_provenance")
        human_initiated = isinstance(provenance, dict) and provenance.get("human_initiated") is True
        unattended = (
            source in {"cron", "heartbeat"} or ctx.metadata.get("execution_lane") == "system"
        )
        if ctx.tool_name == "feedback_submit" and human_initiated and not unattended:
            logger.debug("feedback_submit: auto-allowed protected feedback operation")
            return HookResult.allow()

        # 0b. praesto tag exp borrowed-identity capability gate.
        # The agent is on loan as a group's shared digital employee, backed by a
        # real employee's agent. Only plan, group memory, attachment processing,
        # scoped sub-agents/tasks, tool discovery, the current-chat-scoped meeting
        # automation tool, the conversation-scoped Teams reader, and the
        # knowledge-capture/curation tools are exposed, plus
        # loading the experiment's own skills (text, not capability — anything
        # they name is re-gated here when called). Personal/global MCP servers
        # remain unavailable; current-chat Group MCP tools are admitted from a
        # locally derived per-turn list. Every other tool is rejected.
        # Runs *before* the allowlist so the employee's own allowlist cannot
        # silently widen the borrowed scope. The approval prompt reaches the
        # employee's DM via the existing group→DM approval redirect.
        if praesto_tag_exp_is_active(ctx.metadata):
            decision = praesto_tag_exp_classify_capability(
                ctx.tool_name,
                ctx.args,
                current_cid=str(ctx.metadata.get("cid") or ""),
                group_skill_safe_tools=(
                    ctx.metadata.get("group_skill_safe_tools")
                    if isinstance(ctx.metadata.get("group_skill_safe_tools"), list)
                    else None
                ),
                group_mcp_tool_names=(
                    ctx.metadata.get("group_mcp_tool_names")
                    if isinstance(ctx.metadata.get("group_mcp_tool_names"), list)
                    else None
                ),
            )
            if decision == PRAESTO_TAG_EXP_ALLOW:
                # Some experiment tools enforce their own durable ordinary-chat
                # confirmation. Let that native gate run directly: routing the
                # same action through the optional borrowed-identity tightening
                # prompt would reintroduce the Adaptive Card the workflow
                # deliberately replaced, while execute() still fails closed on
                # missing or stale recorded approval.
                if self._handles_approval_internally(ctx):
                    return HookResult.allow()
                # Optional second opinion: when an operator has configured a
                # borrowed-identity tightening prompt AND the auto-mode
                # ("two-step") classifier is active, re-check what the
                # deterministic gate would auto-borrow. This lets an operator
                # narrow the auto-approved surface via prompt without widening
                # it (a classifier block only ever routes to the employee).
                tightened = await self._praesto_tighten_borrow(ctx)
                if tightened is not None:
                    return tightened
                logger.debug(
                    "praesto_tag_exp: auto-allowed borrowed-identity tool '{}'",
                    ctx.tool_name,
                )
                return HookResult.allow()
            if decision == PRAESTO_TAG_EXP_REJECT:
                return HookResult.reject(
                    "praesto_tag_exp: this tool is not available in the shared group session."
                )
            if not self._approval_manager:
                return HookResult.reject(
                    "praesto_tag_exp: this action borrows the employee's "
                    "permissions and needs their confirmation, but no approval "
                    "channel is available."
                )
            from praestoclaw.security.risk import RiskScore

            forced = RiskScore(
                8,
                "Borrowed-identity action (praesto tag exp): needs the lending "
                "employee's confirmation.",
            )
            return await self._route_to_approval(
                ctx, forced, PolicyAction.HUMAN, always_allow=False
            )

        # 1. Allowlist check — skip the decider entirely (both modes honor it).
        if self._allowlist and self._allowlist.check(ctx.tool_name, ctx.args):
            logger.debug("Allowlist hit for tool '{}' -- skipping decider", ctx.tool_name)
            return HookResult.allow()

        # 2. Delegate the AUTO / HUMAN / REJECT decision to the configured
        #    decider — the scoring policy table, or the auto-mode LLM classifier.
        #    Everything downstream (approval card, human review, resolution) is
        #    identical regardless of which decider produced the decision.
        decision = await self._decider.decide(ctx)

        if decision.action == PolicyAction.AUTO:
            return HookResult.allow()
        if decision.action == PolicyAction.REJECT:
            if decision.score is not None:
                return HookResult.reject(f"[score {decision.score} / 10] {decision.reason}")
            return HookResult.reject(decision.reason)

        # Workflow scoped auto-approval: an in-scope declared tool skips the HUMAN
        # gate (authorized when the workflow was launched). Reached only because the
        # decider did NOT hard-REJECT above — so a score-10 / policy reject still
        # rejects even inside a workflow's declared scope.
        if workflow_scoped:
            logger.debug(
                "workflow scoped auto-approve: workflow={} tool={} (in allowed_tools, non-reject)",
                workflow_name,
                ctx.tool_name,
            )
            return HookResult.allow()

        # A tool may declare that it enforces approval internally when executing
        # this exact call (for example by validating a persisted natural-language
        # approval and proposal fingerprint).  This hook is deliberately narrow:
        # it is consulted only after the normal decider asks for HUMAN/TIMEOUT_AUTO
        # review, and it cannot override a hard REJECT above.  Only the literal
        # boolean True is accepted; missing methods, false/non-boolean results, and
        # exceptions all retain the existing interactive approval-card path.
        if self._handles_approval_internally(ctx):
            return HookResult.allow()

        # 3. Human / Timeout-auto — route to approval (send card, await resolution).
        if not self._approval_manager:
            return HookResult.reject(f"Requires approval: {decision.reason}")

        from praestoclaw.security.risk import RiskScore

        return await self._route_to_approval(
            ctx,
            RiskScore(decision.score, decision.reason),
            decision.action,
            decision.always_allow,
        )

    @staticmethod
    def _handles_approval_internally(ctx: PreToolHookContext) -> bool:
        """Return whether *ctx.tool_ref* enforces approval during execution.

        Tools opt in with the synchronous method::

            handles_approval_internally(args: dict, metadata: dict) -> bool

        ``inspect.getattr_static`` avoids treating dynamic proxy attributes (for
        example a bare ``MagicMock``) as an implementation of this security-
        sensitive contract.  The subsequent normal ``getattr`` still binds a
        genuine instance/class method before calling it.
        """
        tool_ref = ctx.tool_ref
        if tool_ref is None:
            return False

        try:
            inspect.getattr_static(tool_ref, "handles_approval_internally")
        except AttributeError:
            return False

        try:
            checker = getattr(tool_ref, "handles_approval_internally", None)
            if not callable(checker):
                logger.warning(
                    "Tool '{}' exposes a non-callable handles_approval_internally; "
                    "using interactive approval",
                    ctx.tool_name,
                )
                return False
            approved = checker(ctx.args, ctx.metadata)
        except Exception as exc:
            logger.warning(
                "Internal approval handling check failed for tool '{}'; using "
                "interactive approval: {}",
                ctx.tool_name,
                exc,
            )
            return False

        if approved is True:
            logger.info(
                "Tool '{}' handles approval internally; skipping interactive approval",
                ctx.tool_name,
            )
            return True
        if approved is not False:
            logger.warning(
                "Tool '{}' returned a non-boolean internal approval result; "
                "using interactive approval",
                ctx.tool_name,
            )
        return False

    async def _praesto_tighten_borrow(self, ctx: PreToolHookContext) -> HookResult | None:
        """Re-check a would-be borrowed action through the auto-mode classifier.

        Returns ``None`` to keep the deterministic auto-borrow (no tightening
        configured, or the classifier agrees it is safe). Returns a
        :class:`HookResult` (allow via approval / reject) when the operator's
        borrowed-identity prompt makes the classifier want the lending employee
        to confirm — narrowing, never widening, the auto-approved surface.
        """
        prompt = self._praesto_tag_exp_approval_prompt
        if not prompt or not prompt.strip():
            return None

        # Only the auto-mode ("two-step") decider carries an LLM classifier that
        # can act on a free-form prompt; the scoring decider has no such hook.
        from praestoclaw.security.decider import (
            AUTO_MODE_EXTRA_INSTRUCTIONS_METADATA_KEY,
            AutoModeDecider,
        )

        if not isinstance(self._decider, AutoModeDecider):
            return None

        from praestoclaw.security.risk import PolicyAction

        # Inject the tightening prompt for this single decision without mutating
        # the caller's metadata.
        probe_ctx = replace(
            ctx,
            metadata={
                **(ctx.metadata or {}),
                AUTO_MODE_EXTRA_INSTRUCTIONS_METADATA_KEY: prompt,
            },
        )
        decision = await self._decider.decide(probe_ctx)

        if decision.action == PolicyAction.AUTO:
            # Classifier agrees the borrow is safe — keep the fast borrow.
            return None

        logger.info(
            "praesto_tag_exp: borrowed-identity prompt tightened '{}' "
            "(action={}) — routing to the lending employee",
            ctx.tool_name,
            getattr(decision.action, "name", decision.action),
        )

        if decision.action == PolicyAction.REJECT or not self._approval_manager:
            return HookResult.reject(
                "praesto_tag_exp: this borrowed action was narrowed by the "
                f"operator's approval policy and cannot be auto-run: {decision.reason}"
            )

        from praestoclaw.security.risk import RiskScore

        forced = RiskScore(
            decision.score if decision.score is not None else 8,
            decision.reason or "Borrowed-identity action narrowed by the operator approval prompt.",
        )
        return await self._route_to_approval(ctx, forced, decision.action, always_allow=False)

    async def _route_to_approval(
        self,
        ctx: PreToolHookContext,
        risk_score: Any,
        action: Any,
        always_allow: bool,
    ) -> HookResult:
        """Route a tool call to manual approval."""

        assert self._approval_manager is not None

        # ``PolicyAction.TIMEOUT_AUTO`` is still a policy-table value for
        # compatibility, but approval gates no longer auto-approve or
        # auto-reject. They remain pending until a user clicks Approve/Deny.
        auto_timeout: int | None = None
        reject_timeout: int | None = None

        # Resolve channel
        resolved_channel = ctx.channel
        if resolved_channel is None and self._channel_manager:
            active = self._channel_manager.active_channel_names()
            if active:
                resolved_channel = ChannelType.of(active[0])

        # Compute trigger context from metadata (cron, heartbeat, etc.)
        from praestoclaw.security.approval_format import (
            action_preview,
            risk_level,
            trigger_context,
        )

        trigger = trigger_context(ctx.metadata)

        request = await self._approval_manager.request_approval(
            tool_name=ctx.tool_name,
            args=ctx.args,
            agent_name=ctx.agent_name,
            channel=resolved_channel,
            channel_id=ctx.channel_id or "",
            score=risk_score.score,
            reason=risk_score.reason,
            always_allow=always_allow,
            trigger=trigger,
        )

        # Persist approval_request to session (with new card fields)
        if self._session_store and ctx.session_id:
            import json as _json

            _level, _color, _ = risk_level(risk_score.score)
            persistence = asyncio.create_task(
                self._session_store.add_message(
                    ctx.session_id,
                    {
                        "role": "approval_request",
                        "content": _json.dumps(
                            {
                                "request_id": request.id,
                                "tool_name": ctx.tool_name,
                                "action_preview": action_preview(ctx.tool_name, ctx.args),
                                "risk_level": _level,
                                "risk_color": _color,
                                "args": {k: str(v)[:200] for k, v in list(ctx.args.items())[:10]},
                                "score": risk_score.score,
                                "reason": risk_score.reason,
                                "agent_name": ctx.agent_name,
                                "trigger": trigger,
                                "always_allow": always_allow,
                                "status": "pending",
                            }
                        ),
                    },
                )
            )
            try:
                await asyncio.shield(persistence)
            except asyncio.CancelledError:
                # The request exists but was never delivered. Wait for the
                # shielded store write, append a terminal row after it,
                # and discard the pending waiter before propagating cancellation.
                try:
                    await persistence
                    await self._persist_approval_resolution(
                        ctx,
                        request.id,
                        status="abandoned",
                        resolver="cancelled",
                    )
                except Exception as exc:  # noqa: BLE001 - cleanup is best-effort
                    logger.debug(
                        "Cancelled approval persistence cleanup failed id={}: {}",
                        request.id,
                        exc,
                    )
                finally:
                    self._approval_manager.discard(request.id)
                raise

        # Emit APPROVAL_REQUESTED event
        if self._bus:
            from praestoclaw.bus.events import EventType

            self._bus.emit(
                EventType.APPROVAL_REQUESTED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "score": risk_score.score,
                    "reason": risk_score.reason,
                    "always_allow": always_allow,
                    "trigger": trigger,
                },
            )

        # --- Stage 1: primary channel ---
        source: str = ctx.metadata.get("source", "")
        attempted_channels: set[str] = set()
        sent = await self._send_approval_prompt(
            ctx, request, risk_score, auto_timeout, reject_timeout
        )
        # Track what Stage 1 covered — but only when it actually enqueued
        # AND the send was targeted (not a fan-out push whose sub-channel
        # delivery is uncertain).  For cloud, only mark the sub-channel when
        # the send used a real channel_id (interactive notification frame).
        # Fan-out pushes rely on push_ack below for precise tracking.
        if sent:
            cloud_sub = _cloud_subchannel_for_source(source)
            if (
                cloud_sub
                and ctx.channel_id
                and not ctx.channel_id.startswith(
                    ("scheduler:", "cron:", "agent-", "copilot-", "claude-")
                )
            ):
                attempted_channels.add(cloud_sub)
            elif request.channel != ChannelType.CLOUD:
                attempted_channels.add(request.channel.value)

        # For cloud push sends, verify actual delivery via push_ack.
        # _send_approval_prompt returns True when the frame is enqueued,
        # but the gateway may have no webchat/teams clients to deliver to.
        # Wait for the push_ack event (set by CloudChannel on receipt) to
        # confirm delivery, then update tracking.  Interactive notification
        # frames (with a routable channel_id) do not produce push_ack, so
        # skip this check to avoid any delay.
        _used_push_mode = (
            not ctx.channel_id
            or ctx.channel_id.startswith(("scheduler:", "cron:", "agent-", "copilot-", "claude-"))
            or ctx.channel_id == ChannelType.CLOUD.value
        )
        if sent and _used_push_mode and request.channel == ChannelType.CLOUD:
            delivered = await self._verify_cloud_push(request.id, attempted_channels)
            if not delivered:
                sent = False

        # --- Stage 2: next active channel (only if Stage 1 failed) ---
        #   Iterate candidates until one send succeeds.  For cloud pushes,
        #   verify via push_ack that at least one sub-channel received it.
        if not sent:
            for ch_name, push_target in self._fallback_channels(
                request.channel, source, attempted_channels
            ):
                sent = await self._send_push_approval(
                    ch_name, push_target, request, risk_score, auto_timeout, reject_timeout
                )
                if sent:
                    _track_push(attempted_channels, ch_name, push_target)
                    # Verify cloud push delivery
                    if ch_name == ChannelType.CLOUD:
                        delivered = await self._verify_cloud_push(request.id, attempted_channels)
                        if not delivered:
                            sent = False
                            continue  # try next fallback
                    break

        if not sent:
            await self._persist_approval_resolution(
                ctx,
                request.id,
                status="denied",
                resolver="undeliverable",
            )
            if self._bus:
                from praestoclaw.bus.events import EventType

                self._bus.emit(
                    EventType.TOOL_DENIED,
                    {
                        "request_id": request.id,
                        "tool_name": ctx.tool_name,
                        "resolver": "undeliverable",
                    },
                )
            self._approval_manager.discard(request.id)
            logger.warning(
                "Approval request could not be delivered; rejecting: id={} tool={}",
                request.id,
                ctx.tool_name,
            )
            return HookResult.reject(
                f"Approval request for tool '{ctx.tool_name}' could not be delivered"
            )

        # --- Wait until the configured escalation/reminder interval (Stage 3) ---
        escalation_delay = self._approval_manager.timeout_seconds
        max_age = self._approval_manager.max_age_seconds
        first_wait = min(escalation_delay, max_age) if max_age > 0 else escalation_delay

        resolved_early = await self._approval_manager.wait_partial(request.id, first_wait)
        resolved = None
        if not resolved_early:
            resolved = self._approval_manager.expire_if_stale(request.id)

        if (
            resolved is None
            and not resolved_early
            and self._approval_manager.is_pending(request.id)
        ):
            # Before escalating, check push delivery receipts from the gateway.
            # This narrows Stage 3 to only sub-channels that were NOT reached.
            if self._channel_manager:
                cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
                if cloud_ch:
                    ack = cloud_ch.get_push_delivery(request.id)
                    if ack:
                        if ack.get("webchat"):
                            attempted_channels.add("cloud_webchat")
                        if ack.get("teams"):
                            attempted_channels.add("cloud_teams")
                        # Preserve Teams card ActivityId for cross-channel card updates
                        _teams_aid_val = ack.get("teams_activity_id")
                        if isinstance(_teams_aid_val, str):
                            request.teams_activity_id = _teams_aid_val

            # Stage 3: expand to unattempted channels
            logger.info(
                "Approval {} not resolved after {}s, escalating to other channels",
                request.id,
                first_wait,
            )
            for ch_name, push_target in self._unattempted_channels(attempted_channels):
                ok = await self._send_push_approval(
                    ch_name, push_target, request, risk_score, auto_timeout, reject_timeout
                )
                if ok:
                    _track_push(attempted_channels, ch_name, push_target)
                    logger.info(
                        "Escalated approval {} to {}",
                        request.id,
                        f"{ch_name.value}_{push_target}" if push_target else ch_name.value,
                    )

        # Remaining wait — manual approval/rejection or max-age expiry.
        if resolved is None:
            resolved = await self._approval_manager.wait_for_resolution(
                request.id,
                expire_timeout=max_age,
            )

        # Emit resolution event
        if self._bus:
            from praestoclaw.bus.events import EventType

            approved = resolved.status.value == "approved"
            self._bus.emit(
                EventType.TOOL_APPROVED if approved else EventType.TOOL_DENIED,
                {
                    "request_id": request.id,
                    "tool_name": ctx.tool_name,
                    "resolver": resolved.resolver,
                },
            )

        from praestoclaw.security.approval import ApprovalStatus

        approved = resolved.status == ApprovalStatus.APPROVED
        logger.info(
            "APPROVAL_DECISION tool={} decision={} resolver={} score={} request_id={}",
            ctx.tool_name,
            "approved" if approved else "denied",
            resolved.resolver or "timeout",
            risk_score.score,
            request.id,
        )

        # Cross-channel resolution: notify only channels that consume the
        # structured approval_resolved control frame. Cloud/Teams push treats
        # unknown JSON as user-facing text, so do not send this frame there.
        if self._channel_manager:
            import json as _json2

            from praestoclaw.security.approval_format import build_resolved_card

            preview = action_preview(ctx.tool_name, ctx.args)
            # Derive specific outcome for accurate card labels
            _action = resolved.action or ""
            _resolver = resolved.resolver or ""
            if _action == "always":
                outcome = "approved_always"
            elif _resolver == "auto-approve-timeout":
                outcome = "approved_timeout"
            elif resolved.status == ApprovalStatus.EXPIRED:
                outcome = "expired"
            elif resolved.status == ApprovalStatus.TIMEOUT:
                outcome = "denied_timeout"
            else:
                outcome = resolved.status.value  # "approved" or "denied"
            if resolved.status == ApprovalStatus.EXPIRED:
                await self._persist_approval_resolution(
                    ctx,
                    request.id,
                    status=outcome,
                    resolver=resolved.resolver or "max-age",
                )
            resolved_card = build_resolved_card(
                tool_name=ctx.tool_name,
                action_preview=preview,
                score=risk_score.score,
                outcome=outcome,
                agent_name=getattr(ctx, "agent_name", ""),
                reason=risk_score.reason if hasattr(risk_score, "reason") else "",
            )
            # Structured notification — Web UI parses and collapses the card;
            # Gateway uses resolved_card to update Teams Adaptive Cards in-place.
            payload: dict[str, Any] = {
                "type": "approval_resolved",
                "request_id": request.id,
                "status": outcome,
                "resolver": resolved.resolver or "unknown",
                "tool_name": ctx.tool_name,
                "action_preview": preview,
                "resolved_card": resolved_card,
            }
            # Include Teams card ActivityId so the gateway can update the
            # card even after a restart (client-provided, not in-memory).
            _teams_aid = request.teams_activity_id
            if _teams_aid:
                payload["teams_activity_id"] = _teams_aid
            resolution_frame = _json2.dumps(payload)
            for ch_name in self._channel_manager.active_channel_names():
                ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                if ch_key != ChannelType.WEB.value:
                    continue
                ch = self._channel_manager.get(ch_name)
                if not ch:
                    continue
                try:
                    cid = ctx.channel_id or ch_name.value
                    await ch.send(cid, resolution_frame, keep_context=True)
                except Exception as exc:
                    logger.warning(
                        "Cross-channel resolution notification failed for {}: {}", ch_name, exc
                    )

            # cloud_tui-sourced approval: push the resolved frame back over
            # the cloud_tui notify route so the GUI's ApprovalsPanel collapses.
            if ctx.metadata.get("source") == "cloud_tui":
                cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
                session_id = ctx.metadata.get("channel_session_id")
                if cloud_ch and isinstance(session_id, str) and session_id:
                    notification_content = {
                        "kind": "approval_resolved",
                        "request_id": request.id,
                        "payload": payload,
                    }
                    try:
                        await cloud_ch.send(
                            session_id,
                            _json2.dumps(notification_content),
                            keep_context=True,
                            push_target="cloud_tui",
                            push_request_id=request.id,
                            thread_id=session_id,
                        )
                    except Exception as exc:  # noqa: BLE001
                        logger.warning(
                            "cloud_tui resolved push failed (request_id={}): {}",
                            request.id,
                            exc,
                        )

            # Cloud/Teams: push the greyed-out resolved card with the same
            # update_key so the bot UpdateActivityAsync-es the original in
            # place. Gated on prior cloud_teams delivery so users never see a
            # standalone resolved card without preceding context.
            if "cloud_teams" in attempted_channels:
                cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
                if cloud_ch:
                    try:
                        await cloud_ch.send(
                            ctx.channel_id or ChannelType.CLOUD.value,
                            _json2.dumps(wrap_for_teams(resolved_card)),
                            keep_context=True,
                            push_target="teams",
                            push_request_id=f"{request.id}:resolved",
                            update_key=_approval_update_key(request.id),
                        )
                    except Exception as exc:
                        logger.warning(
                            "Teams resolved-card update failed for request {}: {}",
                            request.id,
                            exc,
                        )

        if approved:
            return HookResult.allow()
        return HookResult.reject(
            f"Tool '{ctx.tool_name}' {resolved.status.value} by {resolved.resolver or 'timeout'}"
        )

    async def _persist_approval_resolution(
        self,
        ctx: PreToolHookContext,
        request_id: str,
        *,
        status: str,
        resolver: str,
    ) -> None:
        """Append an approval_resolved session row for a persisted request."""
        if not self._session_store or not ctx.session_id:
            return
        import json as _json

        try:
            await self._session_store.add_message(
                ctx.session_id,
                {
                    "role": "approval_resolved",
                    "content": _json.dumps(
                        {
                            "request_id": request_id,
                            "status": status,
                            "resolver": resolver,
                        }
                    ),
                },
            )
        except Exception as exc:  # noqa: BLE001
            logger.debug("Persist approval_resolved failed: {}", exc)

    async def _send_approval_prompt(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> bool:
        """Send an approval prompt to the primary channel.

        Returns ``True`` if the prompt was enqueued for delivery,
        ``False`` if the channel is unavailable or send failed.
        """
        import json as _json

        from praestoclaw.security.approval_format import get_approval_formatter

        # cloud_tui source uses the dedicated cloud_tui notify route
        # (docs/cloud-tui-approval-routing.md). Skip the legacy fan-out
        # cascade — gateway's _route_teams_notify hard-codes the
        # ``teams`` branch, so anything else here would just hit
        # console fallback.
        if ctx.metadata.get("source") == "cloud_tui":
            return await self._send_cloud_tui_notify(
                ctx, request, risk_score, auto_timeout, reject_timeout
            )

        if not self._channel_manager:
            return False
        channel = self._channel_manager.get(request.channel)
        if not channel:
            return False

        # For WebChannel, `is_connected` only tracks WebSocket push subscribers.
        # However, `/api/chat` uses per-request response queues that are still
        # reachable when `ctx.channel_id` is set (in-flight HTTP request).
        # Cron/scheduler passes synthetic IDs like "scheduler:{job}" that are
        # NOT real per-request queues — exclude those.
        _WEB_REQUEST_PREFIXES = ("web-req-", "web-sse-", "web-ws-")
        web_has_request = request.channel == ChannelType.WEB and any(
            ctx.channel_id.startswith(p) for p in _WEB_REQUEST_PREFIXES
        )
        if request.channel == ChannelType.WEB:
            if not (channel.is_connected or web_has_request):
                return False
        elif not channel.is_connected:
            return False

        effective_cid = (
            ctx.channel_id
            if web_has_request
            else (ctx.channel_id or (request.channel.value if request.channel else ""))
        )

        # Select formatter — Teams gets Adaptive Card, others get JSON.
        # ``cloud_teams`` is the legacy native-Teams path; ``teams_bridge`` is
        # the C#-bridge path (both ultimately render an Adaptive Card in
        # Teams, so both should use the Teams formatter).
        source = ctx.metadata.get("source", "")
        _used_push_mode = (
            not ctx.channel_id
            or ctx.channel_id.startswith(("scheduler:", "cron:", "agent-", "copilot-", "claude-"))
            or ctx.channel_id == ChannelType.CLOUD.value
        )
        _remembered_teams_route = False
        if request.channel == ChannelType.CLOUD:
            route_check = getattr(channel, "is_teams_routed", None)
            if callable(route_check):
                try:
                    # Require the concrete bool. Generic mocks and future channel
                    # implementations must not become Teams routes merely because
                    # their return value is truthy.
                    _remembered_teams_route = route_check(effective_cid) is True
                except Exception as exc:  # noqa: BLE001 - metadata remains the fallback
                    logger.debug("Approval Teams route lookup failed: {}", exc)
        _push_target = (
            "teams"
            if source in ("cloud_teams", "teams_bridge")
            or (request.channel == ChannelType.CLOUD and _used_push_mode)
            or _remembered_teams_route
            else None
        )
        formatter = get_approval_formatter(request.channel, push_target=_push_target)
        content = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )
        payload = _json.dumps(content) if isinstance(content, dict) else str(content)
        # ``notify_category`` on every channel, not just Teams: it is what lets a
        # channel tell a card the user must ACT on apart from progress
        # decoration. WebChannel needs it to decide which payload may take a
        # one-shot request's single response slot — without it an approval card
        # is indistinguishable from a plan progress card and loses the race
        # (issue #663).
        kwargs: dict[str, Any] = {
            "keep_context": True,
            "notify_category": "approval_prompt",
        }
        if _push_target:
            kwargs["push_target"] = _push_target
        if request.channel == ChannelType.CLOUD:
            kwargs["push_request_id"] = request.id
            # Seed (oid, update_key) -> activityId mapping on the Teams bot side
            # so that on resolution (including legacy resolver values) the agent can
            # push a greyed-out resolved card with the same update_key and the
            # bot will UpdateActivityAsync the original card in place.
            if _push_target == "teams":
                kwargs["update_key"] = _approval_update_key(request.id)
        try:
            await channel.send(effective_cid, payload, **kwargs)
            return True
        except Exception as exc:
            logger.error("Failed to send approval prompt: {}", exc)
            return False

    async def _send_cloud_tui_notify(
        self,
        ctx: PreToolHookContext,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> bool:
        """Send an approval card over the cloud_tui notify route.

        Uses ``conversation.message.notify`` with ``recipient.channel="cloud_tui"``
        and ``channel_conversation_id`` set to the inbound ``channel_session_id``.
        Gateway dispatches via ``CloudTuiChannel.push_notify_to_session``.
        Returns False if the cloud channel isn't connected or the
        channel_session_id is missing — caller logs and returns False so
        ApprovalManager auto-timeout takes over.
        """
        import json as _json

        from praestoclaw.security.approval_format import CloudApprovalFormatter

        if not self._channel_manager:
            return False
        cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
        if not cloud_ch or not cloud_ch.is_connected:
            logger.warning(
                "cloud_tui notify skipped: cloud channel not connected (request_id={})",
                request.id,
            )
            return False

        session_id = ctx.metadata.get("channel_session_id")
        if not isinstance(session_id, str) or not session_id:
            logger.warning(
                "cloud_tui notify skipped: missing channel_session_id (request_id={})",
                request.id,
            )
            return False

        payload_dict = CloudApprovalFormatter().format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )
        # Wrap as a notification envelope content body the gateway
        # recognises. ``kind`` mirrors the payload type so gateway can
        # surface the right c.notification kind without re-parsing.
        notification_content = {
            "kind": "approval_request",
            "request_id": request.id,
            "payload": payload_dict,
        }
        try:
            await cloud_ch.send(
                session_id,
                _json.dumps(notification_content),
                keep_context=True,
                push_target="cloud_tui",
                push_request_id=request.id,
                thread_id=session_id,
            )
            return True
        except Exception as exc:  # noqa: BLE001
            logger.warning("cloud_tui notify send failed (request_id={}): {}", request.id, exc)
            return False

    async def _send_push_approval(
        self,
        ch_name: ChannelType,
        push_target: str | None,
        request: Any,
        risk_score: Any,
        auto_timeout: int | None,
        reject_timeout: int | None = None,
    ) -> bool:
        """Send an approval prompt via push mode to *ch_name*.

        *push_target* is ``"teams"`` / ``"webchat"`` / ``None`` and is
        forwarded as a kwarg to ``CloudChannel.send()`` for targeted push.
        """
        import json as _json

        from praestoclaw.security.approval_format import get_approval_formatter

        if not self._channel_manager:
            return False
        channel = self._channel_manager.get(ch_name)
        if not channel or not channel.is_connected:
            return False

        if ch_name == ChannelType.INTERNAL:
            return False

        formatter = get_approval_formatter(ch_name, push_target=push_target)
        content = formatter.format_request(
            request, risk_score, auto_timeout, reject_timeout=reject_timeout
        )
        payload = _json.dumps(content) if isinstance(content, dict) else str(content)
        kwargs: dict[str, Any] = {
            "keep_context": True,
            # Same reason as _send_approval_prompt: a channel has to be able to
            # tell an ask the user must act on apart from progress decoration.
            "notify_category": "approval_prompt",
        }
        if push_target:
            kwargs["push_target"] = push_target
        if ch_name == ChannelType.CLOUD:
            kwargs["push_request_id"] = request.id
            if push_target == "teams":
                kwargs["update_key"] = _approval_update_key(request.id)
        try:
            cid = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
            await channel.send(cid, payload, **kwargs)
            return True
        except Exception as exc:
            logger.warning("Push approval to {}:{} failed: {}", ch_name, push_target, exc)
            return False

    async def _verify_cloud_push(
        self,
        request_id: str,
        attempted_channels: set[str],
    ) -> bool:
        """Wait for push_ack from the Cloud Gateway and update tracking.

        Returns ``True`` if at least one sub-channel received the push
        **or** no ack was received (conservatively assume delivered).
        Returns ``False`` only when the ack explicitly reports both
        sub-channels undelivered.  Uses an event-driven wait so the ack
        arrives (typically <100ms) instead of a fixed sleep.
        """
        if not self._channel_manager:
            return True  # can't verify — assume delivered
        cloud_ch = self._channel_manager.get(ChannelType.CLOUD)
        if not cloud_ch:
            return True

        # Register for push_ack event (set by CloudChannel._on_frame)
        evt = cloud_ch.wait_push_delivery(request_id)
        if evt is not None:
            try:
                await asyncio.wait_for(evt.wait(), timeout=2)
            except TimeoutError:
                pass  # old gateway or slow network — fall through

        ack = cloud_ch.get_push_delivery(request_id)
        if ack is None:
            return True  # no ack — conservatively assume delivered
        if ack.get("webchat"):
            attempted_channels.add("cloud_webchat")
        if ack.get("teams"):
            attempted_channels.add("cloud_teams")
        return bool(ack.get("webchat") or ack.get("teams"))

    def _fallback_channels(
        self,
        primary_channel: ChannelType,
        source: str,
        attempted_channels: set[str],
    ) -> list[tuple[ChannelType, str | None]]:
        """Return an ordered list of fallback ``(channel, push_target)`` candidates.

        The caller iterates and tries each until one send succeeds (e.g.
        a cloud sibling may be unreachable if the WSS is down).
        """
        candidates: list[tuple[ChannelType, str | None]] = []

        # 1. Cloud sub-channel sibling (only when source identifies a sub-channel).
        #    ``teams_bridge`` is the C# Teams bot HTTP relay — it delivers on
        #    the same Teams surface as ``cloud_teams`` and shares the same
        #    sibling-fallback semantics.
        cloud_sub = _cloud_subchannel_for_source(source)
        if primary_channel == ChannelType.CLOUD:
            if cloud_sub == "cloud_webchat" and "cloud_teams" not in attempted_channels:
                candidates.append((ChannelType.CLOUD, "teams"))
            elif cloud_sub == "cloud_teams" and "cloud_webchat" not in attempted_channels:
                candidates.append((ChannelType.CLOUD, "webchat"))

        def _append_cloud_subchannels(
            targets: list[tuple[ChannelType, str | None]],
            skip: set[str],
        ) -> None:
            """Split Cloud into targeted sub-channels (teams + webchat).

            A bare ``(CLOUD, None)`` push routes through the generic
            ``CloudApprovalFormatter`` / gateway backward-compat path.
            Always splitting ensures Teams uses ``TeamsApprovalFormatter``
            (pass-through cards) while webchat uses its own formatter.

            Idempotent — safe to call multiple times; checks both *skip* and
            existing entries in *targets* to avoid duplicates.
            """
            existing = {t for c, t in targets if c == ChannelType.CLOUD}
            if "cloud_teams" not in skip and "teams" not in existing:
                targets.append((ChannelType.CLOUD, "teams"))
            if "cloud_webchat" not in skip and "webchat" not in existing:
                targets.append((ChannelType.CLOUD, "webchat"))

        # 2. Other active channels — skip the primary (already tried in
        #    Stage 1) to avoid redundant sends.
        if self._channel_manager:
            for ch_name in self._channel_manager.active_channel_names():
                if ch_name == primary_channel:
                    continue
                ch = self._channel_manager.get(ch_name)
                if not ch or not ch.is_connected:
                    continue
                if ch_name == ChannelType.CLOUD:
                    _append_cloud_subchannels(candidates, attempted_channels)
                else:
                    ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                    if ch_key not in attempted_channels:
                        candidates.append((ch_name, None))

        # 3. escalation_channels config — always append (deduped) so
        #    config fallback is reachable even when dynamic candidates fail.
        if self._approval_manager:
            existing_keys = {
                c.value if hasattr(c, "value") else str(c)
                for c, t in candidates
                if t is None  # Cloud entries have t="teams"/"webchat", skip them
            }
            for ch_name in self._approval_manager.escalation_channels:
                if ch_name == ChannelType.CLOUD:
                    # Idempotent — deduplicates against both attempted + existing
                    _append_cloud_subchannels(candidates, attempted_channels)
                else:
                    ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                    if ch_key not in attempted_channels and ch_key not in existing_keys:
                        candidates.append((ch_name, None))

        return candidates

    def _unattempted_channels(
        self,
        attempted_channels: set[str],
    ) -> list[tuple[ChannelType, str | None]]:
        """Return half-time escalation targets not yet in *attempted_channels*.

        Stage 3 (half-time escalation) intentionally does NOT cross-fanout
        within the same cloud surface group: if ``cloud_webchat`` was
        successfully delivered we don't proactively push to ``cloud_teams``
        (and vice versa).  The user's primary surface already has the card;
        sending another card to a sibling surface mid-conversation is
        noise.  Stage 2 (``_fallback_channels``, runs only when primary
        delivery FAILED) still tries the sibling — that's the
        "primary-unreachable" fallback path and is unaffected.

        A prior fan-out (no sub-channel key tracked) does NOT suppress
        retries because the Python client cannot know which sub-channels
        the gateway actually delivered to.
        """
        cloud_already_delivered = bool(attempted_channels & {"cloud_webchat", "cloud_teams"})
        targets: list[tuple[ChannelType, str | None]] = []
        if not self._channel_manager:
            return targets
        for ch_name in self._channel_manager.active_channel_names():
            ch = self._channel_manager.get(ch_name)
            if not ch or not ch.is_connected:
                continue
            if ch_name == ChannelType.CLOUD:
                if cloud_already_delivered:
                    # Skip the cloud sibling — see docstring.
                    continue
                if "cloud_webchat" not in attempted_channels:
                    targets.append((ChannelType.CLOUD, "webchat"))
                if "cloud_teams" not in attempted_channels:
                    targets.append((ChannelType.CLOUD, "teams"))
            else:
                ch_key = ch_name.value if hasattr(ch_name, "value") else str(ch_name)
                if ch_key not in attempted_channels:
                    targets.append((ch_name, None))
        return targets


# ── post_tool_use handlers ───────────────────────────────────────────────────


class LeakScanner:
    """Scan tool output for credential patterns and env-var values."""

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based detection (JWT, AWS, GitHub PAT, etc.)
        findings = detect_credentials(ctx.result)
        if findings:
            types = ", ".join(sorted({t for t, _ in findings}))
            logger.warning(
                "Credential patterns detected in '{}' output: {}",
                ctx.tool_name,
                types,
            )

        # Env-var value detection (existing)
        redacted = Sanitizer.redact_env_values(ctx.result)
        if redacted != ctx.result:
            logger.warning("Env var leak detected in '{}' output", ctx.tool_name)

        return HookResult.allow()


class Redactor:
    """Replace detected secrets in tool output.

    Env-var values are replaced with ``[REDACTED]``.
    Credential patterns are replaced with ``[REDACTED:{type}]``
    (e.g. ``[REDACTED:JWT]``, ``[REDACTED:AWS Access Key]``).
    """

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        # Pattern-based redaction first, then env-var redaction
        cleaned = redact_credentials(ctx.result)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.result:
            ctx.result = cleaned
        return HookResult.allow(data=ctx)


class Auditor:
    """Log every tool call to the audit trail."""

    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger

    async def __call__(self, ctx: PostToolHookContext) -> HookResult:
        if self._audit is not None:
            self._audit.log_tool(
                tool=ctx.tool_name,
                actor=ctx.agent_name,
                args=ctx.args,
                result=ctx.result[:200] if ctx.result else "",
                is_error=not ctx.success,
                session_id=ctx.session_id,
                duration_ms=ctx.duration_ms,
            )
        return HookResult.allow()


# ── on_message_sent handlers ────────────────────────────────────────────────


class OutboundLeakScanner:
    """Scan outbound responses for credential leaks."""

    async def __call__(self, ctx: MessageHookContext) -> HookResult:
        cleaned = redact_credentials(ctx.content)
        cleaned = Sanitizer.redact_env_values(cleaned)
        if cleaned != ctx.content:
            logger.warning("Leak detected in outbound message to {}", ctx.channel)
            ctx.content = cleaned
        return HookResult.allow(data=ctx)


# ── Registration helper ──────────────────────────────────────────────────────


def register_builtin_handlers(
    hook_manager: HookManager,
    *,
    estop: object | None = None,
    policy_engine: PolicyEngine | None = None,
    audit_logger: AuditLogger | None = None,
    scorer: RiskScorer | None = None,
    approval_manager: ApprovalManager | None = None,
    allowlist: AllowlistManager | None = None,
    bus: EventBus | None = None,
    message_bus: MessageBus | None = None,
    channel_manager: ChannelManager | None = None,
    session_store: Any = None,
    auto_approve_timeout: int = 30,
    security_profile: str = "standard",
    block_injections: bool = False,
    tool_status_card_enabled: bool = False,
    workflow_suggest_enabled: bool = False,
    workflow_dir: Path | None = None,
    decider: Any = None,
    praesto_tag_exp_approval_prompt: str | None = None,
) -> None:
    """Register all built-in handlers onto a HookManager.

    Args:
        hook_manager: HookManager instance.
        estop: EStop instance (optional).
        policy_engine: PolicyEngine instance (optional).
        audit_logger: AuditLogger instance (optional).
        scorer: RiskScorer (v2) for the ApprovalGate (optional).
        approval_manager: ApprovalManager for human-in-the-loop (optional).
        allowlist: AllowlistManager for per-user tool allowlist (optional).
        bus: EventBus for emitting approval events (optional).
        message_bus: MessageBus used by ``ToolStatusCard`` to push tool
            progress Adaptive Cards back to Teams.
        channel_manager: ChannelManager for sending approval prompts (optional).
        auto_approve_timeout: Deprecated compatibility setting; approvals
            never execute automatically.
        block_injections: If True, reject messages with injection patterns.
        tool_status_card_enabled: If True, register the Teams tool-status card
            hook. Defaults to False so tool execution does not emit status cards
            unless explicitly configured.
        workflow_suggest_enabled: If True (and ``message_bus`` + ``workflow_dir``
            are supplied), register the workflow auto-suggest hook (P2) — nudges,
            at most once per session, to run a matching saved workflow or save a
            cued repeatable procedure. Defaults to False → not registered → zero
            diff, no cost. Suggest-only: never runs a workflow or alters a reply.
        workflow_dir: Directory of saved workflow recipes, used to build the
            suggester's cached recipe loader. Only read when
            ``workflow_suggest_enabled`` is True.
        decider: ApprovalDecider selecting how the AUTO/HUMAN/REJECT decision is
            made (scoring policy table vs auto-mode LLM classifier). When None,
            the ApprovalGate builds a ScoringDecider from ``scorer`` +
            ``security_profile`` (unchanged legacy behaviour).
        praesto_tag_exp_approval_prompt: Optional operator tightening prompt for
            borrowed-identity (``praesto tag``) turns. When set and the auto-mode
            decider is active, actions the deterministic capability gate would
            auto-borrow are re-checked through the classifier with this prompt
            injected, so the operator can narrow the auto-approved surface.
    """
    mgr = hook_manager

    # on_message_received
    mgr.register("on_message_received", InjectionScanner(block=block_injections), priority=10)

    # pre_tool_use
    mgr.register("pre_tool_use", EStopGate(estop), priority=1)
    # Ahead of PolicyGate/ApprovalGate: a command a recipe declared off-limits is
    # refused before any risk scoring or approval routing happens for it.
    mgr.register("pre_tool_use", WorkflowCommandDenylist(), priority=5)
    mgr.register("pre_tool_use", PolicyGate(policy_engine), priority=10)
    mgr.register(
        "pre_tool_use",
        ApprovalGate(
            scorer,
            approval_manager=approval_manager,
            allowlist=allowlist,
            bus=bus,
            channel_manager=channel_manager,
            session_store=session_store,
            auto_approve_timeout=auto_approve_timeout,
            security_profile=security_profile,
            decider=decider,
            praesto_tag_exp_approval_prompt=praesto_tag_exp_approval_prompt,
        ),
        priority=20,
    )

    # post_tool_use
    mgr.register("post_tool_use", LeakScanner(), priority=10)
    # Redactor disabled — redacting tool output breaks LLM tool chaining
    # (LLM can't use credentials returned by one tool in a subsequent call).
    # User-facing protection is handled by OutboundLeakScanner on_message_sent.
    # See: https://github.com/gim-home/PraestoClaw/issues/184
    mgr.register("post_tool_use", Auditor(audit_logger), priority=30)

    # ToolStatusCard — Teams-only "agent is working" Adaptive Card.
    # Runs *before* ApprovalGate (priority 20) on pre_tool_use so the
    # status card appears *before* any approval prompt, giving users an
    # early "agent is working on X" cue instead of an unexplained
    # approval card. Trade-off: if approval is denied or times out, the
    # row stays at "🔧 调用…" since post_tool_use never fires — the user
    # learns the outcome from the approval card itself. Skipped entirely unless
    # enabled by config and a MessageBus was supplied.
    if tool_status_card_enabled and message_bus is not None:
        from praestoclaw.bus.events import EventType
        from praestoclaw.hooks.tool_status_card import ToolStatusCard

        _status_card = ToolStatusCard(message_bus=message_bus)
        mgr.register("pre_tool_use", _status_card.pre, priority=15)
        mgr.register("post_tool_use", _status_card.post, priority=50)
        # Subscribe to TOOL_PROGRESS so streaming tools (web_fetch
        # download progress, shell stdout, browser navigation) animate
        # the *running* row of the same per-turn Teams status card
        # instead of being dropped at the /chatng sync waiter. Same
        # update_key as pre/post → bridge calls UpdateActivityAsync,
        # not SendActivityAsync.
        message_bus.events.on(EventType.TOOL_PROGRESS, _status_card.on_progress)

    # on_message_sent
    mgr.register("on_message_sent", OutboundLeakScanner(), priority=10)

    # WorkflowSuggester (P2) — opt-in, at most one 💡 per session. Registered
    # only when config.workflow.suggest is on AND a MessageBus + recipe dir were
    # supplied. Flag off → nothing registered → zero diff. Runs late (priority
    # 200) so it never fronts real security/leak handlers, and it only ever
    # side-emits a suggestion — it does not modify or block the reply.
    if workflow_suggest_enabled and message_bus is not None and workflow_dir is not None:
        from praestoclaw.agent.tools.workflow import make_recipe_loader
        from praestoclaw.agent.tools.workflow_suggest import WorkflowSuggester

        _suggester = WorkflowSuggester(
            message_bus=message_bus,
            recipes_provider=make_recipe_loader(workflow_dir),
        )
        mgr.register("on_message_received", _suggester.record, priority=200)
        mgr.register("on_message_sent", _suggester.suggest, priority=200)
