"""Shared Application Insights telemetry client for Praesto Python apps.

Public surface (the only things business code should import):

- :func:`init`     — initialise the SDK once at app startup.
- :func:`emit`     — emit a custom event; safe to call before ``init``.
- :func:`flush`    — synchronously flush pending events (with timeout).
- :func:`shutdown` — flush + disable further emits (atexit-friendly).
- :class:`Events`  — event-name constants; new events must be added here.

Everything else (``_client``, ``_connection``, …) is private; the public
contract is intentionally small so the SDK underneath can be swapped without
touching app code.
"""

from __future__ import annotations

from ._client import emit, flush, init, set_user_id, shutdown
from .app_types import AppType
from .events import Events

__all__ = [
    "AppType",
    "Events",
    "__version__",
    "emit",
    "flush",
    "init",
    "set_user_id",
    "shutdown",
]

__version__ = "0.1.0"
