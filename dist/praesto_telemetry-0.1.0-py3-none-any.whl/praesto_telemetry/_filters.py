"""Defensive filter for sensitive field names and obvious credential-shaped values.

Schema review is the primary guard — this filter exists so a single sloppy
``emit(..., password=user.password)`` cannot leak in production. Matched fields
are replaced with the sentinel ``[REDACTED]`` rather than dropped, so the event
still appears in Application Insights and the on-call engineer can spot the
mistake.
"""

from __future__ import annotations

import re
from typing import Any

_BANNED_FIELDS: frozenset[str] = frozenset(
    {
        "password",
        "passwd",
        "secret",
        "token",
        "access_token",
        "refresh_token",
        "id_token",
        "api_key",
        "apikey",
        "authorization",
        "cookie",
        "email",
        "upn",
        "user_principal_name",
        "phone",
        "phone_number",
        "credit_card",
        "ssn",
    }
)

_BANNED_VALUE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"@(?:microsoft|outlook)\.com", re.IGNORECASE),
    re.compile(r"\bBearer\s+ey[A-Za-z0-9_\-]+\."),  # JWT-shaped bearer tokens
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI-style secret keys
)

REDACTED = "[REDACTED]"


def sanitize(props: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow copy of ``props`` with sensitive entries redacted."""
    cleaned: dict[str, Any] = {}
    for key, value in props.items():
        if key.lower() in _BANNED_FIELDS:
            cleaned[key] = REDACTED
            continue
        if isinstance(value, str) and _looks_sensitive(value):
            cleaned[key] = REDACTED
            continue
        cleaned[key] = value
    return cleaned


def _looks_sensitive(value: str) -> bool:
    return any(pattern.search(value) for pattern in _BANNED_VALUE_PATTERNS)
