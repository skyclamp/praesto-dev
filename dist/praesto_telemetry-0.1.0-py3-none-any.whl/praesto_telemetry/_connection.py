"""Resolve the Application Insights connection string for the current environment.

Order of precedence:

1. ``DISABLE_TELEMETRY=true`` or ``CI=true`` → return ``None`` (init becomes no-op).
2. ``PRAESTO_TELEMETRY_CONN_STR`` env var → use as-is (local dev / per-run override).
3. ``PRAESTO_ENV`` env var → pick from the built-in table (default: ``production``).

Connection strings are intentionally hardcoded here, same approach Kosmos uses:
the Application Insights *instrumentation key* is a write-only ingestion
credential — a leaked key only lets an attacker push garbage data, it cannot
exfiltrate anything.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

# Production: PraestoProductionAI (RG PraestoProduction, workspace PraestoProductionLog).
_PROD_CONN_STR = (
    "InstrumentationKey=2d512b25-6f22-47d4-b5f0-34f6fe3bb74e;"
    "IngestionEndpoint=https://westus-0.in.applicationinsights.azure.com/;"
    "LiveEndpoint=https://westus.livediagnostics.monitor.azure.com/;"
    "ApplicationId=01309cc7-26b8-4b81-817a-11d09d1923d8"
)

# Staging: PraestoStagingAI (RG PraestoStaging, workspace PraestoStagingLog).
_STAGING_CONN_STR = (
    "InstrumentationKey=4eab5240-5ec7-4e32-a762-548875d62122;"
    "IngestionEndpoint=https://westus-0.in.applicationinsights.azure.com/;"
    "LiveEndpoint=https://westus.livediagnostics.monitor.azure.com/;"
    "ApplicationId=102539a9-2ca9-4ef2-b680-e8876c5ba3e3"
)

# Development: same as staging by default. Developers can point at a personal
# Application Insights via PRAESTO_TELEMETRY_CONN_STR for isolated tinkering.
_DEV_CONN_STR = _STAGING_CONN_STR

_CONN_STRINGS: dict[str, str] = {
    "production": _PROD_CONN_STR,
    "staging": _STAGING_CONN_STR,
    "development": _DEV_CONN_STR,
}


def resolve_connection_string() -> str | None:
    """Return the connection string to use, or ``None`` if telemetry is disabled."""
    if _is_truthy(os.environ.get("DISABLE_TELEMETRY")):
        logger.info("[telemetry] disabled via DISABLE_TELEMETRY")
        return None
    if _is_truthy(os.environ.get("CI")):
        logger.info("[telemetry] disabled in CI")
        return None

    override = os.environ.get("PRAESTO_TELEMETRY_CONN_STR")
    if override:
        return override

    env = os.environ.get("PRAESTO_ENV", "production").lower()
    # Normalise common aliases — but reject typos / unknown values rather than
    # silently routing them to prod (which is easy to do with PRAESTO_ENV=prod).
    env = {"prod": "production", "stg": "staging", "dev": "development"}.get(env, env)
    if env not in _CONN_STRINGS:
        logger.warning(
            "[telemetry] PRAESTO_ENV=%s is not recognised; telemetry disabled "
            "(expected one of: %s)",
            env,
            ", ".join(sorted(_CONN_STRINGS)),
        )
        return None
    conn = _CONN_STRINGS[env]
    if not conn:
        logger.warning(
            "[telemetry] no connection string configured for PRAESTO_ENV=%s; telemetry disabled",
            env,
        )
        return None
    return conn


def _is_truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}
