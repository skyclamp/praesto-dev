"""Per-installation anonymous device id + OS family details.

The device id is a random UUID persisted at ``<data_dir>/telemetry/device_id``
(defaults to ``~/.praesto/telemetry/`` when no data dir is provided). This
mirrors the approach used by Kosmos (``getOrCreateInstallationDeviceId``):

- It identifies the **installation**, not the hardware. A reinstall (or a
  cleared data dir) yields a new id — that's fine; we track "daily active
  installs", not unique humans, and never re-identify users.
- It never touches the OS-provided machine id, so we cannot accidentally
  cross-correlate users across products or leak a value that downstream
  consumers might treat as PII.
- When the host app provides ``data_dir`` to ``init()`` (e.g. client_agent
  passes ``~/.praestoclaw/``), the file lives there so each app's telemetry
  state sits next to its other state. Falling back to ``~/.praesto/`` keeps
  apps that don't pass a data_dir working.

OS details (``os`` / ``osVersion``) are derived from ``platform``; they're
metadata about the install environment, not identity.
"""

from __future__ import annotations

import logging
import os
import platform
import sys
import uuid
from functools import lru_cache
from pathlib import Path

logger = logging.getLogger(__name__)

_ENV_OVERRIDE = "PRAESTO_DEVICE_ID"
_DEFAULT_DIR = Path.home() / ".praesto" / "telemetry"


def _device_id_path(data_dir: Path | None = None) -> Path:
    base = data_dir / "telemetry" if data_dir else _DEFAULT_DIR
    return base / "device_id"


def get_or_create_device_id(data_dir: Path | None = None) -> str:
    """Return the persisted installation id, creating it on first call.

    Read order:

    1. ``PRAESTO_DEVICE_ID`` env var — pins an id for an instance / CI / dev.
    2. ``<data_dir>/telemetry/device_id`` if it exists and is non-empty.
    3. Generate a fresh random UUID and persist it.

    File I/O failures fall back to an in-memory random id so telemetry
    never breaks the host app, at the cost of cross-restart stability for
    that run.
    """
    if override := os.environ.get(_ENV_OVERRIDE):
        override = override.strip()
        if override:
            return override

    path = _device_id_path(data_dir)
    try:
        if path.exists():
            existing = path.read_text(encoding="utf-8").strip()
            if existing:
                return existing
    except OSError as exc:
        logger.warning("[telemetry] could not read device id (%s); regenerating", exc)

    fresh = str(uuid.uuid4())
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(fresh, encoding="utf-8")
    except OSError as exc:
        logger.warning("[telemetry] could not persist device id (%s); using in-memory id", exc)
    return fresh


# --- os details (used by _client global props) -----------------------------


@lru_cache(maxsize=1)
def get_os_details() -> dict[str, str]:
    """Return ``{"os": "macos|windows|linux|...", "osVersion": "..."}``."""
    family = _os_family()
    return {"os": family, "osVersion": _os_version(family)}


def _os_family() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform == "win32":
        return "windows"
    if sys.platform.startswith("linux"):
        return "linux"
    return sys.platform


def _os_version(family: str) -> str:
    try:
        if family == "macos":
            return platform.mac_ver()[0] or "unknown"
        if family == "windows":
            # platform.version() on Windows returns the build, e.g. "10.0.22631"
            return platform.version() or "unknown"
        if family == "linux":
            info = (
                platform.freedesktop_os_release()
                if hasattr(platform, "freedesktop_os_release")
                else {}
            )
            name = info.get("NAME", "Linux")
            ver = info.get("VERSION_ID", platform.release())
            return f"{name} {ver}".strip()
        return platform.release() or "unknown"
    except Exception:  # pragma: no cover - platform quirks
        return "unknown"
